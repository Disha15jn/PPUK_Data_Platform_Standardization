#!/usr/bin/env python3
"""Offline checks to run BEFORE any terraform apply or pipeline run. No Azure access needed.

usage: python3 scripts/pre_apply_check.py [--repo .]

1. Structure     duplicate variable/output/resource/module declarations in every root.
2. Landing zone  per-environment tfvars: both workspaces, no TODO, subnets inside the VNet,
                 no overlaps, no repeated names.
3. Platform      per-environment tfvars: both workspaces, matching the landing zone's keys.
4. Handoff 10->20  builds the landing zone's `network` output from each tfvars (sample IDs),
                 runs the REAL scripts/resolve_upstream.py on it, then checks the result
                 against the platform root's `network` variable rules.
5. Pipelines     publish step on every landing-zone pipeline, fetch step before init on every
                 platform pipeline, the right environment and var-file paths, no stray TODO.

Exit code 1 if any check fails. WARN lines are placeholders you still have to fill in.
"""
import argparse, collections, glob, ipaddress, json, os, re, subprocess, sys, tempfile
from pathlib import Path

FAILS, WARNS = [], []
def fail(m): FAILS.append(m); print("FAIL", m)
def warn(m): WARNS.append(m); print("WARN", m)
def ok(m): print("ok  ", m)

# ---------- minimal tfvars parser (strings, numbers, bools, lists, objects) ----------
TOKEN = re.compile(r'\s*(?:#[^\n]*|//[^\n]*|("(?:[^"\\]|\\.)*")|([{}\[\],=])|([A-Za-z_][\w-]*)|(-?\d+(?:\.\d+)?))')
def parse_tfvars(text):
    toks = []
    for m in TOKEN.finditer(text):
        if m.group(1): toks.append(("s", json.loads(m.group(1))))
        elif m.group(2): toks.append((m.group(2), m.group(2)))
        elif m.group(3): toks.append(("id", m.group(3)))
        elif m.group(4): toks.append(("n", float(m.group(4))))
    pos = 0
    def value():
        nonlocal pos
        t, v = toks[pos]
        if t == "{":
            pos += 1; obj = {}
            while toks[pos][0] != "}":
                k = toks[pos][1]; pos += 1
                if toks[pos][0] in ("=",): pos += 1
                obj[k] = value()
                if toks[pos][0] == ",": pos += 1
            pos += 1; return obj
        if t == "[":
            pos += 1; arr = []
            while toks[pos][0] != "]":
                arr.append(value())
                if toks[pos][0] == ",": pos += 1
            pos += 1; return arr
        pos += 1
        if t == "id": return {"true": True, "false": False, "null": None}.get(v, v)
        return v
    out = {}
    while pos < len(toks):
        k = toks[pos][1]; pos += 1
        assert toks[pos][0] == "=", f"expected = after {k}"
        pos += 1; out[k] = value()
    return out

def load(p):
    try: return parse_tfvars(Path(p).read_text())
    except Exception as e:
        fail(f"{os.path.relpath(p)}: cannot parse ({e})"); return {}

def check_conflicts(repo):
    bad = False
    for dp, dn, fn in os.walk(repo):
        dn[:] = [d for d in dn if d not in (".git", ".terraform", ".venv", "node_modules")]
        for f in fn:
            if not f.endswith((".tf", ".tfvars", ".yml", ".yaml", ".json", ".py", ".sh", ".md", ".hcl", ".template")): continue
            p = os.path.join(dp, f)
            for i, line in enumerate(open(p, errors="ignore"), 1):
                if re.match(r"^(<<<<<<< |=======\s*$|>>>>>>> )", line) and not p.endswith("pre_apply_check.py"):
                    bad = True; fail(f"{os.path.relpath(p, repo)}:{i}: unresolved merge-conflict marker"); break
    if not bad: ok("no unresolved merge-conflict markers")

# ---------- 1. structure ----------
def check_structure(repo):
    roots = ["infra/10-landing-zone", "infra/20-platform-services", "databricks"] + \
            sorted(os.path.relpath(d, repo) for d in glob.glob(f"{repo}/infra/modules/*"))
    pats = {"variable": r'^variable\s+"([^"]+)"', "output": r'^output\s+"([^"]+)"',
            "data": r'^data\s+"([^"]+)"\s+"([^"]+)"', "resource": r'^resource\s+"([^"]+)"\s+"([^"]+)"',
            "module": r'^module\s+"([^"]+)"'}
    bad = False
    for r in roots:
        if not os.path.isdir(f"{repo}/{r}"): continue
        seen = collections.defaultdict(list)
        for f in glob.glob(f"{repo}/{r}/*.tf"):
            s = "\n".join(l for l in open(f).read().splitlines() if not l.lstrip().startswith("#"))
            for kind, p in pats.items():
                for m in re.finditer(p, s, re.M): seen[(kind,) + m.groups()].append(os.path.basename(f))
        for k, v in seen.items():
            if len(v) > 1: bad = True; fail(f"{r}: {k[0]} '{'.'.join(k[1:])}' is declared {len(v)} times ({', '.join(v)})")
    if not bad: ok("no duplicate declarations in any root")

# ---------- 2. landing zone ----------
def lz_subnets(v):
    items = []
    for ws, pair in v.get("databricks_workspaces", {}).items():
        for part in ("host", "container"): items.append((f"{ws}.{part}", pair[part]))
    for ws, s in v.get("private_endpoint_subnets", {}).items(): items.append((f"pe.{ws}", s))
    return items

def check_landing_zone(repo, envs):
    data = {}
    for env in envs:
        p = f"{repo}/infra/10-landing-zone/environments/{env}.tfvars"
        if not os.path.exists(p): fail(f"landing zone {env}: {p} is missing"); continue
        v = load(p); data[env] = v
        tag = f"landing zone {env}"
        if "private_endpoint_subnet" in v: fail(f"{tag}: still has the old 'private_endpoint_subnet'; the root now declares 'private_endpoint_subnets' (anl, ops)")
        if v.get("environment") != env: fail(f"{tag}: environment is {v.get('environment')!r}")
        if set(v.get("databricks_workspaces", {})) != {"anl", "ops"}: fail(f"{tag}: databricks_workspaces must be exactly anl and ops")
        if set(v.get("private_endpoint_subnets", {})) != {"anl", "ops"}: fail(f"{tag}: private_endpoint_subnets must be exactly anl and ops")
        if not v: continue
        subs = lz_subnets(v)
        todos = [k for k, s in subs if "TODO" in str(s.get("address_prefix"))] + (["vnet"] if "TODO" in str(v.get("vnet")) else [])
        if todos: warn(f"{tag}: address range still TODO for {', '.join(todos)}"); 
        else:
            try:
                vnets = [ipaddress.ip_network(a) for a in v["vnet"]["address_space"]]
                nets = [(k, ipaddress.ip_network(s["address_prefix"])) for k, s in subs]
                for k, n in nets:
                    if not any(n.subnet_of(vn) for vn in vnets): fail(f"{tag}: {k} {n} is outside the VNet {v['vnet']['address_space']}")
                    if k.endswith(("host", "container")) and n.prefixlen > 26: fail(f"{tag}: {k} {n} is smaller than /26")
                for i in range(len(nets)):
                    for j in range(i + 1, len(nets)):
                        if nets[i][1].overlaps(nets[j][1]): fail(f"{tag}: {nets[i][0]} {nets[i][1]} overlaps {nets[j][0]} {nets[j][1]}")
            except Exception as e: fail(f"{tag}: bad address range ({e})")
        n_ph = Path(p).read_text().count("PLACEHOLDER")
        if n_ph: warn(f"{tag}: {n_ph} value(s) marked PLACEHOLDER (not confirmed by the client)")
        names = collections.Counter()
        for k, s in subs:
            for f in ("name", "nsg_name", "route_table_name"): names[(f, s[f])] += 1
        for (f, n), c in names.items():
            if c > 1: fail(f"{tag}: {f} '{n}' is used by {c} subnets")
        if not [x for x in FAILS if x.startswith(tag)]: ok(f"{tag}: workspaces, names and ranges consistent")
    # same names across envs must differ
    return data

# ---------- 3. platform ----------
def check_platform(repo, envs, lz):
    data = {}
    for env in envs:
        p = f"{repo}/infra/20-platform-services/environments/{env}.tfvars"
        if not os.path.exists(p): fail(f"platform {env}: {p} is missing"); continue
        v = load(p); data[env] = v
        got = set(v.get("workspaces", {}))
        if got != {"anl", "ops"}: fail(f"platform {env}: workspaces is {sorted(got)}, the client wants anl and ops in every environment")
        else: ok(f"platform {env}: workspaces anl and ops")
        if env in lz and got - set(lz[env].get("databricks_workspaces", {})): fail(f"platform {env}: has workspaces the landing zone has no subnets for")
    return data

# ---------- 4. handoff 10 -> 20 ----------
SUBS = {"dev": "00000000-0000-0000-0000-000000000001", "tst": "00000000-0000-0000-0000-000000000002",
        "stg": "00000000-0000-0000-0000-000000000003", "prd": "00000000-0000-0000-0000-000000000004"}
def build_network_output(env, v):
    base = f"/subscriptions/{SUBS[env]}/resourceGroups/{v['network_resource_group_name']}/providers/Microsoft.Network/virtualNetworks/{v['vnet']['name']}"
    sid = lambda n: f"{base}/subnets/{n}"
    zone = "/subscriptions/00000000-0000-0000-0000-00000000000e/resourceGroups/ppg-pdns-shd-con-rg-001/providers/Microsoft.Network/privateDnsZones/"
    net = {
        "virtual_network_id": base,
        "private_endpoint_subnet_id": sid(v["private_endpoint_subnets"]["anl"]["name"]),
        "private_endpoint_subnets": {w: {"id": sid(s["name"]), "name": s["name"]} for w, s in v["private_endpoint_subnets"].items()},
        "databricks_subnets": {w: {p: {"id": sid(pair[p]["name"]), "name": pair[p]["name"]} for p in ("host", "container")} for w, pair in v["databricks_workspaces"].items()},
        "log_analytics_workspace_id": "/subscriptions/00000000-0000-0000-0000-00000000000f/resourceGroups/dpx-la-inf-mgt-gwc-rg-001/providers/Microsoft.OperationalInsights/workspaces/dpx-inf-mgt-gwc-la-001",
        "private_dns_zone_ids": {k: zone + z for k, z in {"databricks": "privatelink.azuredatabricks.net", "blob": "privatelink.blob.core.windows.net", "dfs": "privatelink.dfs.core.windows.net", "vault": "privatelink.vaultcore.azure.net"}.items()},
    }
    return {"environment": {"sensitive": False, "type": "string", "value": env}, "network": {"sensitive": False, "type": "dynamic", "value": net}}

def check_handoff(repo, envs, lz, plat):
    script = f"{repo}/scripts/resolve_upstream.py"
    contract = None
    try:
        import yaml
        contract = set(yaml.safe_load(open(f"{repo}/config/upstream-contract.yaml"))["roots"]["infra/20-platform-services"]["upstream"])
    except Exception: pass
    for env in envs:
        if env not in lz: continue
        tag = f"handoff {env}"
        with tempfile.TemporaryDirectory() as d:
            src, out = f"{d}/network-{env}.json", f"{d}/upstream.tfvars.json"
            json.dump(build_network_output(env, lz[env]), open(src, "w"))
            r = subprocess.run([sys.executable, "-I", script, "--root", "infra/20-platform-services", "--environment", env,
                                "--upstream-outputs", src, "--out", out, "--config-dir", f"{repo}/config"], capture_output=True, text=True)
            if r.returncode: fail(f"{tag}: resolve step failed: {r.stderr.strip()}"); continue
            up = json.load(open(out))
            # wrong-environment file must be refused
            other = [e for e in SUBS if e != env][0]
            bad = f"{d}/bad.json"; json.dump(build_network_output(other, lz[env]), open(bad, "w"))
            r2 = subprocess.run([sys.executable, "-I", script, "--root", "infra/20-platform-services", "--environment", env,
                                 "--upstream-outputs", bad, "--out", f"{d}/x.json", "--config-dir", f"{repo}/config"], capture_output=True, text=True)
            if r2.returncode == 0: fail(f"{tag}: resolver accepted another environment's outputs")
        n = up["network"]
        if contract is not None and set(up) != contract: fail(f"{tag}: resolver wrote {sorted(up)}, the contract lists {sorted(contract)}")
        sub = SUBS[env].lower()
        ids = [n["virtual_network_id"], n["private_endpoint_subnet_id"]] + [x["id"] for p in n["databricks_subnets"].values() for x in p.values()]
        if any(i.split("/")[2].lower() != sub for i in ids): fail(f"{tag}: a network ID is in another subscription than the environment's")
        if not n["private_endpoint_subnet_id"].lower().startswith(n["virtual_network_id"].lower() + "/subnets/"): fail(f"{tag}: the private endpoint subnet is not in the VNet")
        for w, p in n["databricks_subnets"].items():
            for part, s in p.items():
                if not s["id"].endswith("/subnets/" + s["name"]): fail(f"{tag}: databricks_subnets.{w}.{part} id does not end with its name")
        pes = n.get("private_endpoint_subnets")
        if not pes: fail(f"{tag}: the resolver dropped private_endpoint_subnets, so the ops workspace cannot use its own endpoint subnet")
        else:
            if set(pes) != set(n["databricks_subnets"]): fail(f"{tag}: private_endpoint_subnets keys {sorted(pes)} differ from databricks_subnets keys {sorted(n['databricks_subnets'])}")
            for w, x in pes.items():
                if not x["id"].lower().startswith(n["virtual_network_id"].lower() + "/subnets/") or not x["id"].endswith("/subnets/" + x["name"]): fail(f"{tag}: private_endpoint_subnets.{w} is not a subnet of the VNet, or its id does not end with its name")
        if env in plat:
            missing = set(plat[env].get("workspaces", {})) - set(n["databricks_subnets"])
            if missing: fail(f"{tag}: the platform root has workspaces {sorted(missing)} with no databricks_subnets in the landing-zone output")
        if not [x for x in FAILS if x.startswith(tag)]: ok(f"{tag}: network output -> resolver -> platform `network` variable is consistent")

# ---------- 5. pipelines ----------
def check_pipelines(repo, envs):
    try: import yaml
    except ImportError: warn("PyYAML missing: pipeline checks skipped"); return
    def steps_of(d):
        out = []
        for st in d.get("stages", []) or []:
            for j in st.get("jobs", []) or []:
                s = j.get("steps") or (((j.get("strategy") or {}).get("runOnce") or {}).get("deploy") or {}).get("steps") or []
                out.append((st["stage"], s))
        return out
    for env in envs:
        for kind, root, key, state in (("10.LZone", "infra/10-landing-zone", "landing-zone", f"landing-zone/{env}.tfstate"),
                                       ("20-Platform", "infra/20-platform-services", "platform", f"platform-services/{env}.tfstate")):
            f = f"{repo}/pipelines/{kind}.{env}.yml"; tag = f"pipeline {kind}.{env}"
            if not os.path.exists(f): fail(f"{tag}: missing"); continue
            try: d = yaml.safe_load(open(f))
            except Exception as e: fail(f"{tag}: not valid YAML ({str(e).splitlines()[0]})"); continue
            txt = open(f).read()
            if "extends" in d: fail(f"{tag}: still the short 'extends:' form, which has no place for the publish/fetch step (use the expanded pipeline)"); continue
            if d.get("trigger") != "none": fail(f"{tag}: trigger must be 'trigger: none'")
            if state not in txt: fail(f"{tag}: state key {state} not found")
            if f"environments/{env}.tfvars" not in txt: fail(f"{tag}: not using environments/{env}.tfvars")
            if "infra/" + root.split("/")[1] + "/environments" in txt.replace("#", ""): pass
            stages = steps_of(d)
            names = [(sn, [s.get("displayName", "") for s in ss]) for sn, ss in stages]
            if kind == "10.LZone":
                ap = [s for sn, ss in stages if sn == "Apply" for s in ss]
                pub = [s for s in ap if "publish" in str(s.get("inputs", {}).get("scriptPath", ""))]
                if not pub: fail(f"{tag}: no publish step in the Apply stage"); continue
                if pub[-1].get("env", {}).get("ENVIRONMENT") != env: fail(f"{tag}: publish step ENVIRONMENT is {pub[-1].get('env', {}).get('ENVIRONMENT')!r}, expected {env!r}")
            else:
                build = [s for sn, ss in stages if sn == "Build" for s in ss]
                idx = {"fetch": None, "init": None}
                for i, s in enumerate(build):
                    if "fetch" in str(s.get("inputs", {}).get("scriptPath", "")): idx["fetch"] = i
                    if s.get("displayName") == "Terraform-Init": idx["init"] = idx["init"] if idx["init"] is not None else i
                if idx["fetch"] is None: fail(f"{tag}: no fetch/resolve step before Terraform-Init"); continue
                if idx["init"] is not None and idx["fetch"] > idx["init"]: fail(f"{tag}: the fetch step runs after Terraform-Init")
                fe = [s for s in build if "fetch" in str(s.get("inputs", {}).get("scriptPath", ""))][0]
                if fe.get("env", {}).get("ENVIRONMENT") != env: fail(f"{tag}: fetch step ENVIRONMENT is {fe.get('env', {}).get('ENVIRONMENT')!r}, expected {env!r}")
                if "upstream.tfvars.json" not in txt: fail(f"{tag}: plan does not pass upstream.tfvars.json")
            if "TF_VAR_" not in txt.split("stages:")[-1]: fail(f"{tag}: plan/apply steps do not map TF_VAR_* from the variable group (Azure DevOps upper-cases group variable names, which Terraform does not read)")
            if "TODO" in txt: warn(f"{tag}: has TODO placeholders ({', '.join(sorted(set(re.findall(r'TODO[-\\w]*', txt))))})")
            if not [x for x in FAILS if x.startswith(tag)]: ok(f"{tag}: publish/fetch wiring present")

def check_platform_endpoints(repo):
    v = Path(f"{repo}/infra/20-platform-services/variables.tf").read_text()
    m = Path(f"{repo}/infra/20-platform-services/main.tf").read_text()
    if "private_endpoint_subnets" not in v: fail("platform root: `network` has no private_endpoint_subnets, so the ops workspace's endpoint cannot use its own subnet")
    elif "workspace_private_endpoints[each.key]" not in m: fail("platform root: the workspace module does not use its own private endpoint subnet")
    else: ok("platform root: each workspace's endpoint uses its own private endpoint subnet")

def main():
    ap = argparse.ArgumentParser(); ap.add_argument("--repo", default="."); a = ap.parse_args()
    repo = os.path.abspath(a.repo); envs = ["dev", "tst", "stg", "prd"]
    print("== 0 merge conflicts"); check_conflicts(repo)
    print("== 1 structure"); check_structure(repo)
    print("== 2 landing zone"); lz = check_landing_zone(repo, envs)
    print("== 3 platform"); plat = check_platform(repo, envs, lz)
    print("== 4 handoff 10 -> 20"); check_handoff(repo, envs, lz, plat)
    print("== 5 pipelines"); check_pipelines(repo, envs)
    print("== 6 platform endpoints"); check_platform_endpoints(repo)
    print(f"\n{len(FAILS)} FAIL, {len(WARNS)} WARN"); sys.exit(1 if FAILS else 0)

if __name__ == "__main__": main()
