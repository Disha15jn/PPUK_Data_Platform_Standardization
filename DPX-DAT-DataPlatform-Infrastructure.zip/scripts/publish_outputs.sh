#!/usr/bin/env bash
# Publish a root's `terraform output -json` for the next root to read.
# Run in the root's apply job, after `terraform apply`, from the repo root.
#
# Required env: ENVIRONMENT, STATE_STORAGE_ACCOUNT, TF_WORKING_DIR, FILE_PREFIX
#   FILE_PREFIX  names the blob: <FILE_PREFIX>-<ENVIRONMENT>.json
# Optional env:
#   OUTPUTS_CONTAINER  (default: outputs)
#   REQUIRED_OUTPUTS   space-separated output names that must be present and non-empty
#   ENVIRONMENT_OUTPUT_CHECK  "true" to also require an 'environment' output equal to ENVIRONMENT
# Auth: the pipeline identity's az login (Storage Blob Data Contributor on the container).
set -euo pipefail

: "${ENVIRONMENT:?set ENVIRONMENT}"
: "${STATE_STORAGE_ACCOUNT:?set STATE_STORAGE_ACCOUNT}"
: "${TF_WORKING_DIR:?set TF_WORKING_DIR}"
: "${FILE_PREFIX:?set FILE_PREFIX}"
CONTAINER="${OUTPUTS_CONTAINER:-outputs}"
BLOB="${FILE_PREFIX}-${ENVIRONMENT}.json"
mkdir -p handoff-outputs
OUT="$(pwd)/handoff-outputs/${BLOB}"   # also published as a pipeline artifact (see pipelines)

terraform -chdir="$TF_WORKING_DIR" output -json > "$OUT"

python3 - "$OUT" "$ENVIRONMENT" "${REQUIRED_OUTPUTS:-}" "${ENVIRONMENT_OUTPUT_CHECK:-false}" <<'PY'
import json, sys
path, env, required, check_env = sys.argv[1], sys.argv[2], sys.argv[3].split(), sys.argv[4] == "true"
data = json.load(open(path))
if not data:
    sys.exit("terraform output is empty: nothing to publish")
if check_env and data.get("environment", {}).get("value") != env:
    sys.exit(f"environment output is {data.get('environment', {}).get('value')!r}, expected {env!r}")
for name in required:
    if data.get(name, {}).get("value") in (None, "", {}, []):
        sys.exit(f"output {name!r} is missing, null or empty")
PY

az storage blob upload \
  --auth-mode login \
  --account-name "$STATE_STORAGE_ACCOUNT" \
  --container-name "$CONTAINER" \
  --name "$BLOB" \
  --file "$OUT" \
  --overwrite
echo "Published ${BLOB} to ${STATE_STORAGE_ACCOUNT}/${CONTAINER}"
