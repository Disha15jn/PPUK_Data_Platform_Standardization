output "environment" {
  description = "The environment that published these outputs. The platform pipeline refuses a file from another environment's state."
  value       = var.environment
}

# The single object infra/20-platform-services reads as its `network` variable.
# Attribute names and nesting are a published interface: they are read by name
# downstream (databricks_subnets.anl.host.id, for instance). Do not rename.
output "network" {
  description = "The network state required by infra/20-platform-services."
  value = {
    virtual_network_id = module.databricks_vnet.resource_id
    # The analytical workspace's endpoint subnet, kept as the default attribute the
    # platform root already reads.
    private_endpoint_subnet_id = module.databricks_subnets["pe_anl_snet"].resource_id

    # One private endpoint subnet per workspace.
    private_endpoint_subnets = {
      for workspace in keys(var.private_endpoint_subnets) : workspace => {
        id   = module.databricks_subnets["pe_${workspace}_snet"].resource_id
        name = module.databricks_subnets["pe_${workspace}_snet"].name
      }
    }

    # One host and one container subnet per workspace: anl everywhere, ops too in prd.
    databricks_subnets = {
      for workspace in keys(var.databricks_workspaces) : workspace => {
        host = {
          id   = module.databricks_subnets["${workspace}_host"].resource_id
          name = module.databricks_subnets["${workspace}_host"].name
        }
        container = {
          id   = module.databricks_subnets["${workspace}_con"].resource_id
          name = module.databricks_subnets["${workspace}_con"].name
        }
      }
    }

    log_analytics_workspace_id = data.azurerm_log_analytics_workspace.central.id

    private_dns_zone_ids = {
      //tabricks = data.azurerm_private_dns_zone.databricks.id
      blob       = data.azurerm_private_dns_zone.blob.id
      //s        = data.azurerm_private_dns_zone.dfs.id
      vault      = data.azurerm_private_dns_zone.vault.id
    }
  }
}
