# infra/10-landing-zone: tst.
#
# PLACEHOLDER ranges: every address_prefix and the VNet range marked PLACEHOLDER below are NOT
# confirmed by the client. They follow dev's layout (dev: 10.130.252.0/22) so that validate and
# plan work. Replace them with the allocated ranges before the first apply: subnets cannot be
# resized in place once resources use them. Names follow dpx-dat-<id>-<env>-int-gwc-<type>-<nnn>.
#
# Subnet names are force-new on the Databricks workspace.
#
# subscription_id, tenant_id, law_central_sub_id and pdns_sub_id are identifiers: they come from
# the pipeline's variable groups, not from this file.

environment = "tst"
location    = "germanywestcentral"

# Placeholder ranges: plan and apply are blocked until the client confirms them and this is set to true.
ranges_confirmed            = false
network_resource_group_name = "dpx-dat-net-tst-int-gwc-rg-001"

vnet = {
  name          = "dpx-dat-net-tst-int-gwc-vnet-001"
  address_space = ["10.130.248.0/22"] # PLACEHOLDER: not confirmed by the client
}

private_endpoint_subnets = {
  anl = {
    name             = "dpx-dat-pep-tst-int-gwc-snet-001"
    address_prefix   = "10.130.250.0/27" # PLACEHOLDER
    nsg_name         = "dpx-dat-pep-tst-int-gwc-nsg-001"
    route_table_name = "dpx-dat-pep-tst-int-gwc-rt-001"
  }
  ops = {
    name             = "dpx-dat-pep-tst-int-gwc-snet-002"
    address_prefix   = "10.130.250.32/27" # PLACEHOLDER
    nsg_name         = "dpx-dat-pep-tst-int-gwc-nsg-002"
    route_table_name = "dpx-dat-pep-tst-int-gwc-rt-002"
  }
}

databricks_workspaces = {
  anl = {
    host = {
      name             = "dpx-dat-dbx-tst-int-gwc-snet-001"
      address_prefix   = "10.130.248.0/25" # PLACEHOLDER
      nsg_name         = "dpx-dat-dbx-tst-int-gwc-nsg-001"
      route_table_name = "dpx-dat-dbx-tst-int-gwc-rt-001"
    }
    container = {
      name             = "dpx-dat-dbx-tst-int-gwc-snet-002"
      address_prefix   = "10.130.248.128/25" # PLACEHOLDER
      nsg_name         = "dpx-dat-dbx-tst-int-gwc-nsg-002"
      route_table_name = "dpx-dat-dbx-tst-int-gwc-rt-002"
    }
  }
  ops = {
    host = {
      name             = "dpx-dat-dbx-tst-int-gwc-snet-003"
      address_prefix   = "10.130.249.0/25" # PLACEHOLDER
      nsg_name         = "dpx-dat-dbx-tst-int-gwc-nsg-003"
      route_table_name = "dpx-dat-dbx-tst-int-gwc-rt-003"
    }
    container = {
      name             = "dpx-dat-dbx-tst-int-gwc-snet-004"
      address_prefix   = "10.130.249.128/25" # PLACEHOLDER
      nsg_name         = "dpx-dat-dbx-tst-int-gwc-nsg-004"
      route_table_name = "dpx-dat-dbx-tst-int-gwc-rt-004"
    }
  }
}
