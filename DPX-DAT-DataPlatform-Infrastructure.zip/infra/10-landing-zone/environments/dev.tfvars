# infra/10-landing-zone: dev.
#
# Dev ranges confirmed by the client (CIDR allocation for DEV). Names follow the
# dpx-dat-<id>-<env>-int-gwc-<type>-<nnn> pattern (identifiers net, pep, dbx). Subnets
# 1, 2 and 5 are the anl workspace (host, container, private endpoint); 3, 4 and 6 are
# ops. Subnet names are force-new on the Databricks workspace.
#
# subscription_id, tenant_id, law_central_sub_id and pdns_sub_id are identifiers: they
# come from the pipeline's variable groups as TF_VAR_*, not from this file.

environment = "dev"
location    = "germanywestcentral"

# Dev ranges are confirmed by the client.
ranges_confirmed            = true
network_resource_group_name = "dpx-dat-net-dev-int-gwc-rg-001"

vnet = {
  name          = "dpx-dat-net-dev-int-gwc-vnet-001"
  address_space = ["10.130.252.0/22"]
}

private_endpoint_subnets = {
  anl = {
    name             = "dpx-dat-pep-dev-int-gwc-snet-001"
    address_prefix   = "10.130.254.0/27"
    nsg_name         = "dpx-dat-pep-dev-int-gwc-nsg-001"
    route_table_name = "dpx-dat-pep-dev-int-gwc-rt-001"
  }
  ops = {
    name             = "dpx-dat-pep-dev-int-gwc-snet-002"
    address_prefix   = "10.130.254.32/27"
    nsg_name         = "dpx-dat-pep-dev-int-gwc-nsg-002"
    route_table_name = "dpx-dat-pep-dev-int-gwc-rt-002"
  }
}

databricks_workspaces = {
  anl = {
    host = {
      name             = "dpx-dat-dbx-dev-int-gwc-snet-001"
      address_prefix   = "10.130.252.0/25"
      nsg_name         = "dpx-dat-dbx-dev-int-gwc-nsg-001"
      route_table_name = "dpx-dat-dbx-dev-int-gwc-rt-001"
    }
    container = {
      name             = "dpx-dat-dbx-dev-int-gwc-snet-002"
      address_prefix   = "10.130.252.128/25"
      nsg_name         = "dpx-dat-dbx-dev-int-gwc-nsg-002"
      route_table_name = "dpx-dat-dbx-dev-int-gwc-rt-002"
    }
  }
  ops = {
    host = {
      name             = "dpx-dat-dbx-dev-int-gwc-snet-003"
      address_prefix   = "10.130.253.0/25"
      nsg_name         = "dpx-dat-dbx-dev-int-gwc-nsg-003"
      route_table_name = "dpx-dat-dbx-dev-int-gwc-rt-003"
    }
    container = {
      name             = "dpx-dat-dbx-dev-int-gwc-snet-004"
      address_prefix   = "10.130.253.128/25"
      nsg_name         = "dpx-dat-dbx-dev-int-gwc-nsg-004"
      route_table_name = "dpx-dat-dbx-dev-int-gwc-rt-004"
    }
  }
}
