# Every name and address range comes from environments/<env>.tfvars. Nothing
# environment-specific is hard-coded here.

locals {
  # One host and one container subnet per Databricks workspace key (anl; ops
  # too in prd), plus the shared private endpoint subnet. Subnet names are
  # force-new on the workspace, so settle them before the first apply.
  databricks_subnet_defs = merge([
    for workspace, pair in var.databricks_workspaces : {
      "${workspace}_host" = merge(pair.host, { delegation_name = "databricks_workspace_delegation_${workspace}_host" })
      "${workspace}_con"  = merge(pair.container, { delegation_name = "databricks_workspace_delegation_${workspace}_con" })
    }
  ]...)

  subnets = merge(
    {
      for key, subnet in local.databricks_subnet_defs : key => {
        name          = subnet.name
        address_space = subnet.address_prefix
        delegations = [
          {
            name = subnet.delegation_name
            service_delegation = {
              name = "Microsoft.Databricks/workspaces"
            }
          },
        ]
        private_endpoint_network_policies_enabled = true
        private_endpoint_network_policies         = "Disabled"
        nsg                                       = subnet.nsg_name
        rt                                        = subnet.route_table_name
      }
    },
    {
      for workspace, subnet in var.private_endpoint_subnets : "pe_${workspace}_snet" => {
        name                                      = subnet.name
        address_space                             = subnet.address_prefix
        delegations                               = null
        private_endpoint_network_policies_enabled = true
        private_endpoint_network_policies         = "Enabled"
        nsg                                       = subnet.nsg_name
        rt                                        = subnet.route_table_name
      }
    },
  )

  # Inbound rule each private endpoint subnet's NSG needs while private endpoint network
  # policies are enabled on it: TCP 443, 6666, 3306 and 8443-8451 from inside the VNet.
  databricks_private_link_rule = {
    allow_databricks_private_link_inbound = {
      name                       = "allow-databricks-private-link-inbound"
      priority                   = 100
      direction                  = "Inbound"
      access                     = "Allow"
      protocol                   = "Tcp"
      source_port_range          = "*"
      destination_port_ranges    = ["443", "6666", "3306", "8443-8451"]
      source_address_prefix      = "VirtualNetwork"
      destination_address_prefix = "VirtualNetwork"
    }
  }

  nsg_rules = {
    for workspace in keys(var.private_endpoint_subnets) : "pe_${workspace}_snet" => local.databricks_private_link_rule
  }
}
