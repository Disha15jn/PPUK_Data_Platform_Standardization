# infra/10-landing-zone: the network and security root, and the handover notes for Hexaware

This is the root **Hexaware write and apply**, in this repository. Cynozure's two roots,
`infra/20-platform-services` and `databricks`, only read its published outputs; nothing here is
ours to change. This README is the handover document: what we have built and where it touches the
network, what we need from Hexaware, and how values pass from this root to ours. Every Microsoft
page cited was checked on 30 September 2026.

## What we have built, and where it touches your network

Our two roots create no network of their own: no VNet, subnet, NSG, route table, DNS zone or Log
Analytics workspace. Everything they build sits inside the network this root provides. Per
environment, that is:

- **Databricks workspaces**, VNet-injected into your VNet, one per workspace key (`anl`
  everywhere; `ops` too in production). Each takes a host and a container subnet from you, with
  secure cluster connectivity (no public IPs), public network access off and
  `NoAzureDatabricksRules`, so all traffic goes through Private Link. Each workspace's own storage
  account, which Azure creates in its managed resource group, has its firewall on too, so it is
  reached only through the endpoints below.
- **Private endpoints in your private endpoint subnet**: one `databricks_ui_api` endpoint per
  workspace, `blob` and `dfs` endpoints on each of the two storage accounts and on each
  workspace's own storage account, and one `vault` endpoint on each of the two Key Vaults. Nine
  per environment, twelve in production, which has two workspaces; please size the subnet for
  them. Each is named, and each registers in the matching central private DNS zone through a DNS zone group,
  unless you tell us Landing Zone policy does that (see [What we need from Hexaware](#what-we-need-from-hexaware)).
- **Network Connectivity Configurations** on the Databricks account side, one per tier, so that
  serverless compute can reach each environment's trusted storage account privately. Their private
  endpoint rules appear as pending private endpoint connections on the storage account, to be
  approved there; they use no address in your subnets.
- **Diagnostic settings** on every Key Vault, storage account and workspace, all sending to the
  Landing Zone's central Log Analytics workspace.

Nothing of ours creates a `browser_authentication` private endpoint: that belongs to the web-auth
workspace described below, and our tests assert we never add one.

## The outputs contract

After every apply of this root, for each environment, publish `terraform output -json`. It holds
two outputs: `environment`, the environment that published it (`dev`, `tst`, `stg` or `prd`), and
`network`, one object with the attributes below. `scripts/resolve_upstream.py` refuses a file
published by another environment, reads each value through `config/landing-zone-outputs.yaml`,
fails if any is missing, null or empty, and passes them to `infra/20-platform-services` as its
`network` variable. Nothing in this contract is secret.

| Attribute of `network` | Shape | Used for |
|---|---|---|
| `virtual_network_id` | VNet resource ID | Every Databricks workspace's VNet injection. Force-new on the workspace |
| `databricks_subnets` | map, by workspace key (`anl` and `ops`), of `{ host = { id, name }, container = { id, name } }` | Each workspace's host (public) and container (private) subnets: names for the workspace, IDs for its NSG association. Force-new on the workspace |
| `private_endpoint_subnets` | map, by workspace key, of `{ id, name }`, each in `virtual_network_id`'s VNet | Each workspace's own endpoints: its `databricks_ui_api` endpoint, which serves its clusters as well as its users, and the `blob` and `dfs` endpoints on its workspace storage account. Clusters must reach them inside their own VNet; `infra/20-platform-services` rejects a subnet in another VNet |
| `private_endpoint_subnet_id` | Subnet resource ID, in `virtual_network_id`'s VNet: the analytical workload's endpoint subnet | The shared endpoints: `blob` and `dfs` on both storage accounts, and `vault` on both Key Vaults |
| `log_analytics_workspace_id` | Log Analytics workspace resource ID, the same in every environment | Where every diagnostic setting sends its logs: the Landing Zone's central workspace, `dpx-inf-mgt-gwc-la-001` in the management subscription `dpx-sub-inf-mgt-gwc-001`. It may be in any subscription |
| `private_dns_zone_ids` | map with keys `databricks`, `blob`, `dfs` and `vault` | The central private DNS zones each endpoint registers in |

`infra/20-platform-services/tests/fixtures/network-outputs-dev.json` is a worked example of the
exact JSON shape, and `variable "network"` in `infra/20-platform-services/variables.tf` validates
the values once they are resolved.

**`config/landing-zone-outputs.yaml` is where we follow this shape.** It says, for every value
our root needs, the path it is read from in the published file. If this root renames or moves an
output, we change that path and refresh the fixture; nothing else changes on our side.

**Every environment has two workspaces, analytical and operational,** and Azure gives every
VNet-injected workspace its own pair of subnets, so each environment publishes two pairs and two
endpoint subnets: six subnets in all.

Each Databricks subnet must be delegated to `Microsoft.Databricks/workspaces` and have a network
security group associated; Azure Databricks manages the NSG rules and the delegation itself
([Deploy Azure Databricks in your Azure virtual network](https://learn.microsoft.com/en-us/azure/databricks/security/network/classic/vnet-inject)).

**The workspace VNet must resolve `privatelink.azuredatabricks.net`**, through a link to the zone
or through the hub's DNS forwarding. Clusters fail to start with 'Control Plane Request Failure'
if they cannot resolve the workspace URL to the private endpoint
([Configure classic compute plane private connectivity](https://learn.microsoft.com/en-us/azure/databricks/security/network/classic/private-link-standard)).
If private endpoint network policies are enabled on the private endpoint subnet, its network
security group must allow inbound TCP 443, 6666, 3306 and 8443 to 8451
([Private Link concepts](https://learn.microsoft.com/en-us/azure/databricks/security/network/concepts/privatelink-concepts)).

**Everything but the DNS zones and the Log Analytics workspace is in the environment's own
subscription.** Each environment deploys into a subscription of its own, and production's holds
both workspaces. A private endpoint must be in the same subscription and region as its virtual
network ([What is a private endpoint?](https://learn.microsoft.com/en-us/azure/private-link/private-endpoint-overview)),
and so must a VNet-injected workspace ([Deploy Azure Databricks in your Azure virtual network](https://learn.microsoft.com/en-us/azure/databricks/security/network/classic/vnet-inject)).
So each environment's VNet, private endpoint subnet and Databricks subnets must be in that
environment's subscription; `infra/20-platform-services` rejects them at plan otherwise. The
private DNS zones may sit in a hub subscription.

**Treat these outputs as a published interface.** Renaming a Databricks subnet replaces the
workspace. Tell Cynozure before changing any output above, so that the mapping and the fixture
change with it; Cynozure are optional reviewers on this root's pull requests.

## How to hand outputs across

The same mechanism carries values from this root into `infra/20-platform-services`, and from
there into `databricks`. No root reads another's state, and nobody retypes a value.

1. **Publish.** At the end of each apply of this root, for environment `<env>`:

   ```bash
   terraform output -json > network-<env>.json
   ```

   Put the file where the platform pipeline can read it. A pipeline artefact on the run, or a
   small container in the state storage account, both work; it is your choice, since you own the
   pipelines. One file per environment, overwritten on every apply.

2. **Resolve**, in the `infra/20-platform-services` pipeline for that environment, before
   `terraform init`:

   ```bash
   python scripts/resolve_upstream.py --root infra/20-platform-services --environment <env> \
       --upstream-outputs network-<env>.json --out upstream.tfvars.json
   ```

   The script checks the `environment` output, reads each value through
   `config/landing-zone-outputs.yaml`, adds the entity list from `config/entities.yaml`, and writes
   `upstream.tfvars.json`. If a value is missing, null or empty it fails, names the value and the
   file, and writes nothing. It never falls back to a default, so a broken publish stops
   the plan rather than planning against stale values.

3. **Plan and apply**, passing the generated file last, so that it wins:

   ```bash
   terraform init -backend-config=environments/<env>.tfbackend
   terraform plan -var-file=environments/<env>.tfvars -var-file=upstream.tfvars.json
   ```

   The identifier variables (`subscription_id`, `tenant_id` and the object IDs) come from the
   pipeline's variable groups as `TF_VAR_*`, as `config/upstream-contract.yaml` sets out. The
   `.tfbackend` file is built from the tracked `.tfbackend.template` with the state storage you
   provide; it is never committed.

4. **Repeat for the Databricks root.** After `infra/20-platform-services` applies, publish its
   `terraform output -json` as `platform-<env>.json` in the same way. The Databricks pipeline
   resolves with `--root databricks --environment <env> --workspace anl` (or `ops`), and the script
   refuses outputs published by a different environment's state.

`config/upstream-contract.yaml` is the written contract: which variables each root takes upstream,
which are identifiers and which variable group each identifier comes from. The script is tested to
produce exactly the upstream variables listed there, and `scripts/check_var_files.py` fails the
build if a tracked var file sets one of them.

## What we need from Hexaware

### The web-auth workspace, in the hub

Browser sign-in to a workspace with public access off needs a `browser_authentication` private
endpoint. Azure allows only one per region and private DNS zone
([Private Link concepts](https://learn.microsoft.com/en-us/azure/databricks/security/network/concepts/privatelink-concepts)),
and all our workspaces share your central zones, so one endpoint serves every environment. If its
workspace is deleted, web login fails for every workspace in the region. Our roots do not create
it or depend on it; until it exists no one can sign in through a browser, but the REST API,
Terraform and the pipelines work. It is regional network plumbing, so it belongs with this root.
Microsoft's requirements
([Configure inbound Private Link for workspaces](https://learn.microsoft.com/en-us/azure/databricks/security/network/front-end/front-end-private-connect)):

- A resource group and a VNet of its own, in the hub, with two subnets for VNet injection. The
  concepts page sizes them at `/28` or `/27`.
- Premium tier, secure cluster connectivity, public network access disabled and
  `NoAzureDatabricksRules`.
- A Delete lock.
- No workloads, and no private endpoint other than `browser_authentication`: do not create a
  `databricks_ui_api` endpoint for it.
- The endpoint in a subnet users can reach, registered in `privatelink.azuredatabricks.net` with
  the A record `pl-auth.<region>`, for example `pl-auth.germanywestcentral`. The classic compute
  page says that record name 'is required for the UI to complete the authentication process'.

**Agreed:** the web-auth workspace is shared and sits in the hub, in a subscription other than the
environments' own; which subscription is still to be confirmed. Hexaware deploy it from this root. Nothing of
ours hosts the endpoint on any other workspace, so nothing in our roots changes with it: the one
`browser_authentication` endpoint serves every environment, and the pieces around it (the subnets, the
`pl-auth` record in the central zone, the lock, reachability for users) are Hexaware's to put in place.

### The private route for build agents and users

Workspaces have public network access off, so their URLs resolve to private addresses that a
Microsoft-hosted agent cannot reach. The plan and apply pipelines for both our roots therefore run
on a private pool, one per tier (non-production and production), attached to delegated subnets.
Each pool needs:

- a route to the private endpoint subnet of every environment in its tier, and to the Terraform
  state account;
- DNS through the central `databricks`, `blob`, `dfs` and `vault` zones.

`pipelines/validate.yml` stays on a hosted agent: it makes no cloud call. The Databricks account
console, `accounts.azuredatabricks.net`, stays public, so the account-level provider is unaffected.

The same zones matter for users. The workspace storage account's firewall means that any client
downloading large query results through Cloud Fetch (the ODBC and JDBC drivers, above about
5 MiB) must reach its `blob` and `dfs` endpoints, and the Power BI service would need a data
gateway to do so ([Enable firewall support for your workspace storage account](https://learn.microsoft.com/en-us/azure/databricks/security/network/storage/firewall-support)).
There is no Power BI requirement yet.

Users need the same route: VPN or ExpressRoute into the hub, peering from the hub to each
environment's VNet, and conditional forwarding of `*.azuredatabricks.net`,
`*.privatelink.azuredatabricks.net` and `*.databricksapps.com` to Azure DNS
([Configure inbound Private Link for workspaces](https://learn.microsoft.com/en-us/azure/databricks/security/network/front-end/front-end-private-connect),
under custom DNS configuration).

### Log Analytics: the Landing Zone's central workspace

Our roots create no Log Analytics workspace. Every diagnostic setting we create sends to the
Landing Zone's workspace, `dpx-inf-mgt-gwc-la-001` in the management subscription
`dpx-sub-inf-mgt-gwc-001`. We need:

- **Its resource ID as the `log_analytics_workspace_id` output**, for every environment. The
  resolve step fails without it.
- **A right on the workspace for each tier's pipeline identity**, granted by the workspace's
  owner. Microsoft: 'The destination doesn't have to be in the same subscription as the resource
  that's sending logs if the user who configures the setting has appropriate Azure role-based
  access control (RBAC) access to both subscriptions'
  ([Diagnostic settings in Azure Monitor](https://learn.microsoft.com/en-us/azure/azure-monitor/data-collection/diagnostic-settings)).
  The right is `Microsoft.OperationalInsights/workspaces/read` and
  `Microsoft.OperationalInsights/workspaces/sharedKeys/action`, which let an identity 'enumerate
  the workspace and use it as a destination for diagnostic settings' but not query it
  ([Manage access to Log Analytics workspaces](https://learn.microsoft.com/en-us/azure/azure-monitor/logs/manage-access)).
  A custom role at the workspace's scope grants exactly that; *Monitoring Contributor* is the
  broader built-in alternative.

**One question for the Calandra team: does a Landing Zone policy already deploy diagnostic
settings to this workspace for these resource types?** A resource takes at most five diagnostic
settings (same Microsoft page), and two settings on one resource cannot both send a category to the
same workspace. If a policy does, either exclude our resource groups from it or tell us, and we
drop ours.

Querying is the workspace owner's concern. People with read access to a resource can query its
logs if the workspace uses resource-context access (the 'Access mode' section of the page above);
please confirm its setting. We need no Azure Monitor Private Link Scope for this: logs from a
diagnostic setting 'use a secure private Microsoft channel and aren't controlled by' the
workspace's public ingestion and query settings
([Design Azure Monitor Private Link configuration](https://learn.microsoft.com/en-us/azure/azure-monitor/fundamentals/private-link-design)).

### Rights our pipeline identities need on this root's resources

For Hexaware and the zones' owners to grant, to each tier's pipeline identity:

- `Microsoft.Network/virtualNetworks/subnets/join/action` on the private endpoint subnet and on
  each Databricks subnet, ideally through a custom role scoped to those subnets.
- `Microsoft.Network/virtualNetworks/subnets/write` on each Databricks subnet as well. Microsoft
  says the workspace creator needs 'the Network contributor role on the VNet, or a custom role
  with `Microsoft.Network/virtualNetworks/subnets/join/action` and
  `Microsoft.Network/virtualNetworks/subnets/write`'
  ([Deploy Azure Databricks in your Azure virtual network](https://learn.microsoft.com/en-us/azure/databricks/security/network/classic/vnet-inject)).
- The right to register records in each central private DNS zone, for the endpoints' DNS zone
  groups. **If Landing Zone policy creates the zone groups instead, tell us**: each wrapper module
  takes `manage_dns_zone_group = false` in its `private_endpoint` input, and we set it.
- On the central Log Analytics workspace, the right above, from its owner.

### Pipelines, identities and runbooks

These are Hexaware's to build. Nothing in this repository does them; `pipelines/validate.yml` is
the only pipeline here and it runs only checks.

**Pipelines.** A plan and apply pipeline per root, ideally from shared templates, running on the
private pools. Each should:

- fetch the upstream outputs and run the resolve step before `terraform init`, as above;
- publish its own `terraform output -json` after every apply, for the next root;
- refuse a destroy unless explicitly asked (a destroy guard);
- run an `identity-preflight` step before a Databricks plan or apply: check that the pipeline
  identity is an account admin and a member of the Databricks admin group, and that the workspace
  URL resolves to a private address. Both fail early and clearly where a plan would fail half-way.

Azure Repos Git ignores a YAML `pr:` trigger ([Build Azure Repos Git repositories](https://learn.microsoft.com/en-us/azure/devops/pipelines/repos/azure-repos-git)),
so `pipelines/validate.yml` gates pull requests only once a Build validation branch policy runs
it on `development`, `production` and `main`. It also needs a secure file of sanitisation sweep
patterns (Cynozure supply the file; its email rule must exclude ADLS URIs of the form
`<container>@<account>.dfs.core.windows.net`) and a read-only `GITHUB_TOKEN` secret variable, so
that `tflint --init` is not rate-limited.

**Identities.** One pipeline identity per tier, non-production and production, planning and
applying both of our roots. Whether that is one service connection per environment or one scoped
above the subscriptions is your choice; workload identity federation, with approval and
required-template checks, is what we assumed. Each identity needs, in every subscription of its
tier:

- Contributor, or a narrower custom role.
- *Role Based Access Control Administrator*, conditioned to the roles we assign: *Storage Blob
  Data Contributor* and *Storage Blob Delegator*.
- Resource provider registration: `infra/20-platform-services` registers none.
- The subnet, DNS zone and Log Analytics rights above.

The identifier variables go in the variable group their scope names in
`config/upstream-contract.yaml`: `subscription_id` in a group per environment (dev, tst, stg,
prd), everything else in a group per tier.

Before any Databricks plan, both pipeline identities must be Databricks account admins **and
members of the Databricks admin group**, which owns everything the Databricks root creates. The
first account admin is set by an Entra Global Administrator. This is a hard prerequisite: without
it the first Databricks apply fails, and the root's explicit grants to the identity cannot stand in
for it.

**Runbooks.** Five we can see the need for:

- *NCC private endpoint approval.* Each environment's analytical Databricks state adds private
  endpoint rules for its own trusted storage account. Each rule is approved on that storage
  account, in that environment's subscription, and expires if it is left pending for 14 days
  ([Manage private endpoint rules](https://learn.microsoft.com/en-us/azure/databricks/security/network/serverless-network-security/manage-private-endpoint-rules)).
  The one exception is the lower-environment provision: its rules sit on the non-production NCC
  but are approved on production's storage.
- *Workspace storage endpoint approval.* Each workspace's own storage account gets a `blob` and a
  `dfs` endpoint when the platform root applies. Microsoft says they 'might auto-approve, or you
  might need to approve them on the storage account', which sits in the workspace's managed
  resource group ([Enable firewall support for your workspace storage account](https://learn.microsoft.com/en-us/azure/databricks/security/network/storage/firewall-support)). Until they
  are approved, classic clusters cannot reach the DBFS root.
- *Identity provisioning.* The first account admin, then the two pipeline identities into the
  account-admin role and the Databricks admin group.
- *Upstream outage.* What to do when a publish fails and the resolve step stops a plan.
- *State recovery.*

And two one-off steps after the first apply of each analytical Databricks state: run the job in its
`masking_functions_job_id` output to create the masking functions, then set
`enable_masking_policies = true` and apply again.
