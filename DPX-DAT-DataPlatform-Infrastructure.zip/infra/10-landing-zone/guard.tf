# Stops a plan or apply of an environment whose address ranges are not confirmed.
# Subnets cannot be resized once Databricks workspaces use them.
resource "terraform_data" "ranges_confirmed" {
  lifecycle {
    precondition {
      condition     = var.ranges_confirmed
      error_message = "The address ranges in environments/${var.environment}.tfvars are placeholders, not confirmed by the client. Subnets cannot be resized once workspaces use them. Confirm the ranges, then set ranges_confirmed = true in that file."
    }
  }
}
