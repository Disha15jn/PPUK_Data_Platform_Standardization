variable "subscription_id" {
  description = "Identifier. The subscription this environment deploys into: each environment has its own, and production's holds both workspaces. From the environment's variable group."
  type        = string
  nullable    = false

  validation {
    condition     = can(regex("^[0-9a-f]{8}-([0-9a-f]{4}-){3}[0-9a-f]{12}$", var.subscription_id))
    error_message = "subscription_id must be a lower-case GUID."
  }
}

variable "law_central_sub_id" {
  description = "Identifier. The subscription this environment deploys into: each environment has its own, and production's holds both workspaces. From the environment's variable group."
  type        = string
  nullable    = false
}

variable "pdns_sub_id" {
  description = "Identifier. The subscription this environment deploys into: each environment has its own, and production's holds both workspaces. From the environment's variable group."
  type        = string
  nullable    = false
}

variable "tenant_id" {
  description = "Identifier. The Entra tenant. From the tier's variable group."
  type        = string
  nullable    = false

  validation {
    condition     = can(regex("^[0-9a-f]{8}-([0-9a-f]{4}-){3}[0-9a-f]{12}$", var.tenant_id))
    error_message = "tenant_id must be a lower-case GUID."
  }
}

variable "location" {
  type    = string
  default = "germanywestcentral"
}

variable "environment" {
  description = "The environment this state deploys: dev, tst, stg or prd. Published as the 'environment' output so the platform pipeline can refuse another environment's file."
  type        = string
  nullable    = false

  validation {
    condition     = contains(["dev", "tst", "stg", "prd"], var.environment)
    error_message = "environment must be dev, tst, stg or prd."
  }
}

variable "network_resource_group_name" {
  description = "Name of the resource group this root creates for the VNet, subnets, NSGs and route tables. The Databricks and storage resource groups are created by infra/20-platform-services, not here."
  type        = string
  nullable    = false
}

variable "vnet" {
  description = "The environment's VNet: name and address space."
  type = object({
    name          = string
    address_space = list(string)
  })
  nullable = false
}

variable "private_endpoint_subnets" {
  description = <<-EOT
    A private endpoint subnet for each workspace, keyed by workspace ('anl' and 'ops'), each with
    its own NSG and route table. The 'anl' subnet is also published as the default
    private_endpoint_subnet_id.
  EOT
  type = map(object({
    name             = string
    address_prefix   = string
    nsg_name         = string
    route_table_name = string
  }))
  nullable = false

  validation {
    condition     = toset(keys(var.private_endpoint_subnets)) == toset(["anl", "ops"])
    error_message = "private_endpoint_subnets must have exactly the keys 'anl' and 'ops'."
  }
}

variable "databricks_workspaces" {
  description = <<-EOT
    The Databricks subnet pair for each workspace, keyed by workspace: 'anl' and 'ops' in
    every environment. Subnet names are force-new on the workspace.
  EOT
  type = map(object({
    host = object({
      name             = string
      address_prefix   = string
      nsg_name         = string
      route_table_name = string
    })
    container = object({
      name             = string
      address_prefix   = string
      nsg_name         = string
      route_table_name = string
    })
  }))
  nullable = false

  validation {
    condition     = toset(keys(var.databricks_workspaces)) == toset(["anl", "ops"])
    error_message = "Every environment has both workspaces: databricks_workspaces must have exactly the keys 'anl' and 'ops'."
  }
}

variable "ranges_confirmed" {
  description = "Set true only once every address range in this environment's tfvars has been confirmed by the client. Subnets cannot be resized once workspaces use them, so a plan fails while this is false."
  type        = bool
  default     = false
  nullable    = false
}
