# Fetch the Central Log Analytics Workspace
data "azurerm_log_analytics_workspace" "central" {
  name                = "dpx-inf-mgt-gwc-la-001"
  resource_group_name = "dpx-la-inf-mgt-gwc-rg-001"
  provider            = azurerm.law
}

# data "azurerm_private_dns_zone" "databricks" {
#   name                = "privatelink.azuredatabricks.net"
#   resource_group_name = "ppg-pdns-shd-con-gwc-rg-001"
#   provider            = azurerm.pdns
# }

data "azurerm_private_dns_zone" "blob" {
  name                = "privatelink.blob.core.windows.net"
  resource_group_name = "ppg-pdns-shd-con-gwc-rg-001"
  provider            = azurerm.pdns
}

# data "azurerm_private_dns_zone" "dfs" {
#   name                = "privatelink.dfs.core.windows.net"
#   resource_group_name = "ppg-pdns-shd-con-gwc-rg-001"
#   provider            = azurerm.pdns
# }

data "azurerm_private_dns_zone" "vault" {
  name                = "privatelink.vaultcore.azure.net"
  resource_group_name = "ppg-pdns-shd-con-gwc-rg-001"
  provider            = azurerm.pdns
}


