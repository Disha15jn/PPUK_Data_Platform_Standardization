
module "databricks_network_rg" {
  source           = "Azure/avm-res-resources-resourcegroup/azurerm"
  version          = "0.4.0"
  name             = var.network_resource_group_name
  location         = var.location
  enable_telemetry = false
}

module "databricks_vnet" {
  source           = "Azure/avm-res-network-virtualnetwork/azurerm"
  name             = var.vnet.name
  version          = "0.22.2"
  location         = var.location
  parent_id        = module.databricks_network_rg.resource_id
  enable_telemetry = false
  address_space    = var.vnet.address_space
}

module "databricks_subnets" {
  for_each                                  = local.subnets
  source                                    = "Azure/avm-res-network-virtualnetwork/azurerm//modules/subnet"
  version                                   = "0.22.2"
  name                                      = local.subnets[each.key].name
  address_prefix                            = local.subnets[each.key].address_space
  parent_id                                 = module.databricks_vnet.resource_id
  delegations                               = local.subnets[each.key].delegations
  private_endpoint_network_policies_enabled = local.subnets[each.key].private_endpoint_network_policies_enabled
  private_endpoint_network_policies         = local.subnets[each.key].private_endpoint_network_policies
  network_security_group = {
    id = module.all_nsgs[each.key].resource_id
  }
  route_table = {
    id = module.all_route_tables[each.key].resource_id
  }

  depends_on = [module.all_nsgs, module.all_route_tables]
}

module "all_nsgs" {
  for_each            = local.subnets
  source              = "Azure/avm-res-network-networksecuritygroup/azurerm"
  version             = "0.5.2"
  name                = local.subnets[each.key].nsg
  security_rules      = lookup(local.nsg_rules, each.key, {})
  location            = var.location
  resource_group_name = module.databricks_network_rg.name
  enable_telemetry    = false
}

module "all_route_tables" {
  for_each            = local.subnets
  source              = "Azure/avm-res-network-routetable/azurerm"
  version             = "0.5.0"
  name                = local.subnets[each.key].rt
  location            = var.location
  resource_group_name = module.databricks_network_rg.name
  enable_telemetry    = false
}

# module "databricks_private_dns_zone" {
#   source  = "Azure/avm-res-network-privatednszone/azurerm"
#   version = "0.5.0"
#   domain_name = "privatelink.azuredatabricks.net"
#   parent_id = data.azurerm_private_dns_zone.blob.resource_group_name
#   virtual_network_links = {
#     link1 = {
#       name = "dbx_pdns_to_dbx_vnet"
#       virtual_network_id = module.databricks_vnet.resource_id
#     }
#   }
#   providers = {
#     azurerm = azurerm.pdns
#   }
# }
# landing zone policy suspects to deny the manual dns zone creation. Commenting out until confirmation.









