provider "azurerm" {
  features {
  }
  subscription_id = var.subscription_id
  resource_provider_registrations = "none"
}

provider "azapi" {
  subscription_id = var.subscription_id
  tenant_id       = var.tenant_id
}

# Central Log Analytics workspace's subscription (read-only lookups).
provider "azurerm" {
  alias = "law"

  features {}
  subscription_id = var.law_central_sub_id
  resource_provider_registrations = "none"
}

# Hub private DNS zones' subscription (read-only lookups).
provider "azurerm" {
  alias = "pdns"

  features {}
  subscription_id = var.pdns_sub_id
  resource_provider_registrations = "none"
}
