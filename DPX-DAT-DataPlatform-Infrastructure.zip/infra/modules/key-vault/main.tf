# A Key Vault in one of two access models:
#
#   rbac           the platform vault. Azure RBAC authorisation.
#   access_policy  the Databricks secret scope's vault. Key Vault-backed secret
#                  scopes support only the access-policy model (Microsoft Learn,
#                  checked 24 September 2026).
#
# Both vaults disable public network access and are reached through their
# private endpoint. The firewall denies by default and keeps the trusted
# Microsoft services bypass, which Azure Databricks uses to read the secret
# scope's vault. Microsoft documents that the bypass still applies with public
# access disabled ('Configure network security for Azure Key Vault', checked
# 16 October 2026), although the secret scope documentation still describes
# public access from selected networks.
#
# Purge protection is always on. Access policies are separate
# azurerm_key_vault_access_policy resources inside the module, so the policy
# Databricks adds when the scope is created is never removed by a plan.

locals {
  access_policy_mode = var.access_model == "access_policy"

  # Every diagnostic setting the vault gets, and where it sends its logs.
  diagnostic_settings = {
    log_analytics = {
      workspace_resource_id = var.log_analytics_workspace_id
    }
  }

  network_settings = {
    bypass                        = "AzureServices"
    default_action                = "Deny"
    public_network_access_enabled = false
  }

  # Exactly what Azure Databricks adds for a Key Vault-backed scope, so that a
  # plan after the scope is created shows no change.
  secret_reader_permissions = ["Get", "List"]
}

module "key_vault" {
  source  = "Azure/avm-res-keyvault-vault/azurerm"
  version = "0.11.0"

  diagnostic_settings = local.diagnostic_settings
  enable_telemetry    = var.enable_telemetry
  legacy_access_policies = local.access_policy_mode ? {
    for key, object_id in var.secret_reader_object_ids : key => {
      object_id          = object_id
      secret_permissions = local.secret_reader_permissions
    }
  } : {}
  legacy_access_policies_enabled = local.access_policy_mode
  location                       = var.location
  lock                           = var.lock_enabled ? { kind = "CanNotDelete" } : null
  name                           = var.name
  network_acls = {
    bypass         = local.network_settings.bypass
    default_action = local.network_settings.default_action
  }
  private_endpoints = {
    vault = {
      subnet_resource_id            = var.private_endpoint.subnet_id
      private_dns_zone_resource_ids = [var.private_endpoint.private_dns_zone_ids["vault"]]
    }
  }
  private_endpoints_manage_dns_zone_group = var.private_endpoint.manage_dns_zone_group
  public_network_access_enabled           = local.network_settings.public_network_access_enabled
  purge_protection_enabled                = true
  resource_group_name                     = var.resource_group_name
  sku_name                                = var.sku_name
  soft_delete_retention_days              = var.soft_delete_retention_days
  tags                                    = var.tags
  tenant_id                               = var.tenant_id
}
