output "diagnostic_workspace_ids" {
  description = "The Log Analytics workspaces the workspace's diagnostic settings send to, so that tests can check them."
  value       = toset([for setting in values(local.diagnostic_settings) : setting.workspace_resource_id])
}

output "name" {
  description = "Name of the workspace."
  value       = module.workspace.name
}

output "network_settings" {
  description = "The VNet and subnets the workspace is injected into, so that tests can check them."
  value = {
    container_subnet_name = var.container_subnet.name
    host_subnet_name      = var.host_subnet.name
    virtual_network_id    = var.virtual_network_id
  }
}

output "private_endpoint_settings" {
  description = "The subnet and DNS zone of each of the workspace's private endpoints, by sub-resource, so that tests can check them."
  value = {
    for endpoint in values(local.private_endpoints) : endpoint.subresource_name => {
      subnet_id            = endpoint.subnet_resource_id
      private_dns_zone_ids = endpoint.private_dns_zone_resource_ids
    }
  }
}

output "resource_id" {
  description = "Azure resource ID of the workspace."
  value       = module.workspace.resource_id
}

output "settings" {
  description = "The workspace's fixed network and encryption settings, so that tests can check them."
  value       = local.settings
}

output "storage_firewall" {
  description = "The workspace storage account's firewall: the Access Connector passed to the Verified Module, and that connector's name, so that tests can check them. Whether it is on is in settings."
  value = {
    access_connector_id   = local.storage_firewall.access_connector_id
    access_connector_name = var.storage_connector_name
  }
}

output "storage_private_endpoint_settings" {
  description = "The workspace storage account's private endpoints, by sub-resource: name, resource group, subnet, target and DNS zones, as passed to the private endpoint module or planned as the policy-managed resource, so that tests can check them."
  value = {
    for subresource, endpoint in local.storage_private_endpoints : subresource => {
      name                  = endpoint.name
      resource_group_name   = var.resource_group_name
      subnet_id             = var.private_endpoint.subnet_id
      target_resource_id    = local.workspace_storage_account_id
      private_dns_zone_ids  = toset(var.private_endpoint.manage_dns_zone_group ? endpoint.private_dns_zone_ids : [])
      manage_dns_zone_group = var.private_endpoint.manage_dns_zone_group
    }
  }
}

output "storage_account_sku_name" {
  description = "The SKU of the workspace's own storage account, which sets its replication, so that tests can check it."
  value       = var.storage_account_sku_name
}

output "workspace_id" {
  description = "The workspace's numeric ID in the Databricks control plane."
  value       = module.workspace.databricks_workspace_id
}

output "workspace_region_number" {
  description = "The number in the workspace URL, adb-<workspace_id>.<number>.azuredatabricks.net, which the Databricks provider host is built from. Fails rather than returning null if the URL has another form."
  value       = regex("^adb-[0-9]+\\.([0-9]+)\\.azuredatabricks\\.net$", module.workspace.databricks_workspace_url)[0]
}

output "workspace_url" {
  description = "The workspace URL, adb-<workspace_id>.<number>.azuredatabricks.net."
  value       = module.workspace.databricks_workspace_url
}
