# An Azure Databricks workspace, injected into the network and security state's
# VNet, reached only through Private Link.
#
# - VNet injection with secure cluster connectivity (no public IPs). The host
#   and container subnets, and the VNet, come from the network state. They are
#   force-new arguments: renaming either subnet replaces the workspace.
# - Front-end and back-end Private Link: public network access off, and
#   NoAzureDatabricksRules, through one databricks_ui_api private endpoint.
# - Premium SKU, and infrastructure encryption on the workspace storage.
# - The workspace storage account's firewall on. Azure creates that account in
#   the managed resource group, for the DBFS root, job output and system data,
#   and by default it accepts authenticated connections from any network. With
#   the firewall on its public access is off: Azure Databricks reaches it
#   through an Access Connector of the workspace's own, the VNet through the
#   blob and dfs private endpoints below, and serverless compute through the
#   network security perimeter Azure Databricks attaches ('Enable firewall
#   support for your workspace storage account', Microsoft Learn, checked
#   30 September 2026:
#   https://learn.microsoft.com/en-us/azure/databricks/security/network/storage/firewall-support).

# The Verified Module looks up its resource group with a data source, which
# Terraform reads at plan time whenever the name is known. On a new
# environment's first plan the group does not exist yet, so the plan would
# fail. terraform_data's output is unknown until it is created, which is after
# the group, so on that first plan the lookup waits for the apply; on every
# later plan the output is known and the lookup reads as usual. depends_on
# would not do: it would defer the lookup whenever the group had any pending
# change, such as a tag, leaving the workspace's parent unknown, which plans a
# replacement.
resource "terraform_data" "resource_group_ready" {
  input = var.resource_group_name
}

locals {
  settings = {
    default_storage_firewall_enabled      = true
    infrastructure_encryption_enabled     = true
    network_security_group_rules_required = "NoAzureDatabricksRules"
    no_public_ip                          = true
    public_network_access_enabled         = false
    sku                                   = "premium"
  }

  private_endpoint = {
    subresource_name              = "databricks_ui_api"
    subnet_resource_id            = var.private_endpoint.subnet_id
    private_dns_zone_resource_ids = [var.private_endpoint.private_dns_zone_ids["databricks"]]
  }

  # Every endpoint the workspace gets, and only this one. Azure allows one
  # browser_authentication endpoint per region and private DNS zone, and it
  # belongs to the dedicated web-auth workspace in the hub: a second one here
  # would clash with it. The key names the endpoint (pe-<workspace>-ui_api).
  private_endpoints = { ui_api = local.private_endpoint }

  # The workspace storage account's firewall. The connector must be a new one:
  # Microsoft does not allow the one in the managed resource group.
  storage_firewall = {
    access_connector_id = module.storage_access_connector.resource_id
  }

  # The workspace storage account's two endpoints. They sit in the workspace's
  # own resource group, because Microsoft does not allow them in the managed one.
  storage_private_endpoints = {
    for subresource in ["blob", "dfs"] : subresource => {
      name                 = "pe-${var.name}-dbstorage-${subresource}"
      private_dns_zone_ids = [var.private_endpoint.private_dns_zone_ids[subresource]]
    }
  }

  # Azure gives the workspace storage account a random name, and the Verified
  # Module does not output it, so it is read back from the workspace itself.
  workspace_storage_account_id = join("/", [
    data.azapi_resource.workspace.output.managed_resource_group_id,
    "providers/Microsoft.Storage/storageAccounts",
    data.azapi_resource.workspace.output.storage_account_name,
  ])

  # Every diagnostic setting the workspace gets, and where it sends its logs.
  diagnostic_settings = {
    log_analytics = {
      workspace_resource_id = var.log_analytics_workspace_id
      metric_categories     = []
    }
  }
}

# Azure Databricks uses this connector's system-assigned identity to reach the
# workspace storage account once its firewall is on. It needs no role
# assignment from us: the account sits in the managed resource group, which
# only Azure Databricks may change.
module "storage_access_connector" {
  source  = "Azure/avm-res-databricks-accessconnector/azurerm"
  version = "0.1.0"

  enable_telemetry = var.enable_telemetry
  location         = var.location
  managed_identities = {
    system_assigned = true
  }
  name      = var.storage_connector_name
  parent_id = var.resource_group_id
  tags      = var.tags
}

module "workspace" {
  source  = "Azure/avm-res-databricks-workspace/azurerm"
  version = "0.5.0"

  access_connector_id = local.storage_firewall.access_connector_id
  custom_parameters = {
    no_public_ip                                         = local.settings.no_public_ip
    virtual_network_id                                   = var.virtual_network_id
    public_subnet_name                                   = var.host_subnet.name
    public_subnet_network_security_group_association_id  = var.host_subnet.id
    private_subnet_name                                  = var.container_subnet.name
    private_subnet_network_security_group_association_id = var.container_subnet.id
    storage_account_sku_name                             = var.storage_account_sku_name
  }
  default_storage_firewall_enabled        = local.settings.default_storage_firewall_enabled
  diagnostic_settings                     = local.diagnostic_settings
  enable_telemetry                        = var.enable_telemetry
  infrastructure_encryption_enabled       = local.settings.infrastructure_encryption_enabled
  location                                = var.location
  managed_resource_group_name             = var.managed_resource_group_name
  name                                    = var.name
  network_security_group_rules_required   = local.settings.network_security_group_rules_required
  private_endpoints                       = local.private_endpoints
  private_endpoints_manage_dns_zone_group = var.private_endpoint.manage_dns_zone_group
  public_network_access_enabled           = local.settings.public_network_access_enabled
  resource_group_name                     = terraform_data.resource_group_ready.output
  sku                                     = local.settings.sku
  tags                                    = var.tags
}

# The workspace as Azure reports it. Its ID is unknown only until the workspace
# is created, so on a new environment's first plan this read waits for the
# apply, and on every later plan it reads as usual.
data "azapi_resource" "workspace" {
  type        = "Microsoft.Databricks/workspaces@2026-01-01"
  resource_id = module.workspace.resource_id

  response_export_values = {
    managed_resource_group_id = "properties.managedResourceGroupId"
    storage_account_name      = "properties.parameters.storageAccountName.value"
  }
}

# The workspace storage account's private endpoints, one per sub-resource, for
# the classic compute plane and anything else that reaches it over the VNet,
# through the private endpoint Verified Module. The workspace Verified Module
# cannot create them: its private_endpoints input connects only to the
# workspace itself. There are two blocks because the module cannot ignore a
# DNS zone group it did not create: this one when we manage the zone groups,
# the resource below when Landing Zone policy does.
module "workspace_storage_private_endpoint" {
  source   = "Azure/avm-res-network-privateendpoint/azurerm"
  version  = "0.2.0"
  for_each = var.private_endpoint.manage_dns_zone_group ? local.storage_private_endpoints : {}

  enable_telemetry                = var.enable_telemetry
  location                        = var.location
  name                            = each.value.name
  network_interface_name          = null
  private_connection_resource_id  = local.workspace_storage_account_id
  private_dns_zone_group_name     = "default"
  private_dns_zone_resource_ids   = each.value.private_dns_zone_ids
  private_service_connection_name = "pse-${each.value.name}"
  resource_group_name             = var.resource_group_name
  subnet_resource_id              = var.private_endpoint.subnet_id
  subresource_names               = [each.key]
  tags                            = var.tags
}

# The same endpoints when Landing Zone policy creates the DNS zone groups. The
# zone group the policy adds is left alone. This is the one Azure resource in
# the platform root that no Verified Module creates: the private endpoint
# module has no way to ignore a zone group it did not create, so it would plan
# the policy's removal on every run.
resource "azurerm_private_endpoint" "workspace_storage_unmanaged_dns" {
  for_each = var.private_endpoint.manage_dns_zone_group ? {} : local.storage_private_endpoints

  location            = var.location
  name                = each.value.name
  resource_group_name = var.resource_group_name
  subnet_id           = var.private_endpoint.subnet_id
  tags                = var.tags

  private_service_connection {
    is_manual_connection           = false
    name                           = "pse-${each.value.name}"
    private_connection_resource_id = local.workspace_storage_account_id
    subresource_names              = [each.key]
  }

  lifecycle {
    ignore_changes = [private_dns_zone_group]
  }
}
