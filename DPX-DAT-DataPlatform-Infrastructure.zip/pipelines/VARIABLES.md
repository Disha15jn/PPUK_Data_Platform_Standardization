# Pipeline variables and their placeholder values

Every value below that is not in a tracked `*.tfvars` file comes from an Azure DevOps variable
group or the pipeline itself. **All values here are placeholders**: replace each one before the
first run. Nothing secret or environment-specific is committed.

Azure DevOps upper-cases variable names when it turns them into environment variables, and
Terraform reads `TF_VAR_<name>` case-sensitively. So the pipelines do not rely on `TF_VAR_*`
variables in a group: each plan and apply step maps them explicitly, for example
`TF_VAR_subscription_id: $(subscription_id)`. Create the variables below with exactly these names
(lower-case, as written) and link the group to the pipeline.

Placeholder GUIDs are all zeros. Placeholder names are in `<angle brackets>`.

## State backend: group `TF-Backend-GWC` (non-production) and the production equivalent

| Variable | Used by | Placeholder |
|---|---|---|
| `backend-subscription-id` | every root | `00000000-0000-0000-0000-000000000000` |
| `backend-resource-group-name` | every root | `<state-resource-group>` |
| `backend-storage-account-name` | every root; also where the `outputs` container lives | `<state-storage-account>` |
| `backend-container-name` | landing zone, platform | `<state-container>` |

One state storage account per tier (non-production, production) so the production identity needs
no rights on non-production storage. The `outputs` container (`network-<env>.json`,
`platform-<env>.json`, `databricks-<instance>.json`) is in that account:
Storage Blob Data Contributor for the publishing pipeline's identity, Reader for the reading one's.
The Databricks pipeline uses a container named `databricks` for its state.

## Identifiers: group `TF-Identifiers-<env>` (dev, tst, stg, prd)

One group per environment. The platform and Databricks pipelines both link it: the Databricks
pipeline builds the name from the instance, so `dev-anl` and `dev-ops` read `TF-Identifiers-dev`.
The first three values differ by environment. The last four are the same for every environment
in a tier (non-production, production), so each non-production group holds the same values.

| Variable | Used by | Placeholder |
|---|---|---|
| `subscription_id` | landing zone, platform | `00000000-0000-0000-0000-000000000000` (that environment's subscription) |
| `law_central_sub_id` | landing zone | `00000000-0000-0000-0000-000000000000` (central Log Analytics subscription) |
| `pdns_sub_id` | landing zone | `00000000-0000-0000-0000-000000000000` (central private DNS subscription) |
| `tenant_id` | landing zone, platform | `00000000-0000-0000-0000-000000000000` |
| `azure_databricks_service_principal_object_id` | platform | `00000000-0000-0000-0000-000000000000` (object ID of the AzureDatabricks enterprise application, application ID `2ff814a6-3304-4ab8-85cb-cd0e6f879c1d`: `az ad sp show --id 2ff814a6-3304-4ab8-85cb-cd0e6f879c1d --query id -o tsv`) |
| `databricks_account_id` | Databricks | `00000000-0000-0000-0000-000000000000` |
| `service_principal_application_id` | Databricks | `00000000-0000-0000-0000-000000000000` (the tier's pipeline identity) |

## Already in use

`ADO-SSH` (SSH key variables), the service connection `ado-sc-dat-dataplatform-001` and the pool
`dpx_inf_gwc_linux_pba` for non-production.

## Still to name (placeholders in the pipelines)

| Where | Placeholder to replace |
|---|---|
| `10.LZone.prd.yml`, `20-Platform.prd.yml`, `30-Databricks.yml` (prd instances) | `TODO-prod-service-connection`, `TODO-prod-agent-pool` |
| `30-Databricks.yml` | `TODO-TF-Backend-GWC-Prod` (group name) |
| Azure DevOps environments (approvals) | `dpx-dat-<env>_deployment`, `dpx-dat-<instance>_databricks` |
