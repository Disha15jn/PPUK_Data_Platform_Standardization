#!/usr/bin/env python3
"""Write a root's upstream values into upstream.tfvars.json.

The pipeline runs this before `terraform init`. It reads the upstream root's
published outputs, in `terraform output -json` form, adds the values that come
from config/, and writes the generated var file that is passed as the LAST
-var-file, so it wins. Nobody types an upstream value.

It fails loudly, and writes nothing, if an expected output is missing, null or
empty, naming the output and the file it should have been in. It never falls
back to a default. Terraform's variable validations then check each value's
shape.

  infra/20-platform-services  <- the landing zone's outputs, read through config/landing-zone-outputs.yaml,
                                 plus config/entities.yaml
  databricks                  <- infra/20-platform-services's outputs for the same environment,
                                 plus config/entities.yaml and config/entra-groups.yaml.
                                 No state reads another environment's outputs: each
                                 analytical state's NCC rules are for its own storage.

Usage:
  resolve_upstream.py --root infra/20-platform-services --environment dev \\
      --upstream-outputs network-dev.json --out upstream.tfvars.json
  resolve_upstream.py --root databricks --environment prd --workspace anl \\
      --upstream-outputs platform-prd.json --out upstream.tfvars.json

The variables produced are exactly the upstream variables listed for the root in
config/upstream-contract.yaml; a test holds the two together.
"""

from __future__ import annotations

import argparse
import json
import re
import sys
from pathlib import Path
from typing import Any

import yaml

import output_mapping

ENTITY_KEY = re.compile(r"^[a-z][a-z0-9]{1,9}$")
TRACKS = ("anl", "ops")

# Where each value of the platform root's `network` variable sits in the landing
# zone's published outputs, in config/. Hexaware own that root, so its shape is
# theirs to change; when it changes, the mapping changes, not this script.
LANDING_ZONE_MAPPING = "landing-zone-outputs.yaml"

# infra/20-platform-services outputs copied straight into the Databricks root,
# under the reference platform's variable names.
PLATFORM_SCALARS = (
    "unity_catalog_storage",
    "storage_account_name",
    "resource_group_name",
    "key_vault_name",
    "access_connectors",
    "subscription_id",
)


class ResolveError(Exception):
    pass


def read_yaml(path: Path) -> dict[str, Any]:
    try:
        return yaml.safe_load(path.read_text())
    except FileNotFoundError:
        raise ResolveError(f"{path} is missing") from None


class Outputs:
    """One upstream root's published outputs, read with loud failures."""

    def __init__(self, path: Path) -> None:
        self.path = path
        try:
            data = json.loads(path.read_text())
        except FileNotFoundError:
            raise ResolveError(f"published outputs {path} not found") from None
        if not isinstance(data, dict) or not all(isinstance(v, dict) and "value" in v for v in data.values()):
            raise ResolveError(f"{path} is not in `terraform output -json` form")
        self.data = data

    def get(self, name: str) -> Any:
        if name not in self.data:
            raise ResolveError(f"upstream output '{name}' is missing from {self.path}")
        value = self.data[name]["value"]
        if value is None:
            raise ResolveError(f"upstream output '{name}' is null in {self.path}")
        if value in ("", {}, []):
            raise ResolveError(f"upstream output '{name}' is empty in {self.path}")
        return value


def load_entities(config: Path) -> tuple[dict[str, dict[str, str]], str]:
    data = read_yaml(config / "entities.yaml")
    entities = data.get("entities") or {}
    if not entities:
        raise ResolveError("config/entities.yaml lists no entities")
    for key in entities:
        if not ENTITY_KEY.match(key):
            raise ResolveError(
                f"entity key '{key}' in config/entities.yaml must be 2 to 10 lower-case letters and digits, starting with a letter"
            )
    shared = data.get("shared_entity")
    if shared not in entities:
        raise ResolveError(f"shared_entity '{shared}' in config/entities.yaml is not one of its entities")
    return entities, shared


def tier_of(config: Path, environment: str) -> str:
    environments = read_yaml(config / "environments.yaml")["environments"]
    if environment not in environments:
        raise ResolveError(f"environment '{environment}' is not in config/environments.yaml")
    return environments[environment]["tier"]


def resolve_platform_services(config: Path, environment: str, upstream: Path) -> dict[str, Any]:
    published = Outputs(upstream)
    try:
        mapping = output_mapping.load(config / LANDING_ZONE_MAPPING)
        check_published_by(upstream, output_mapping.published_environment(mapping, published.data, upstream), environment)
        entities, _ = load_entities(config)
        network = output_mapping.resolve(mapping, published.data, upstream)
    except output_mapping.MappingError as error:
        raise ResolveError(str(error)) from None
    return {"network": network, "entities": entities}


def group_names(config: Path, environment: str, entities: dict[str, Any]) -> tuple[dict[str, str], dict[str, dict[str, str]]]:
    """Map config/entra-groups.yaml onto the reference platform's role keys."""
    groups = read_yaml(config / "entra-groups.yaml")
    tier = tier_of(config, environment)
    external_group_names = {
        "platform_admins": groups["admins"]["databricks"],
        "engineers": groups["personas"]["engineers"],
        "analysts": groups["personas"]["analysts"],
        "sp_databricks": groups["workloads"][tier],
        "pii_authorized": groups["pii_authorised"],
    }
    data_groups = groups.get("entity_data_groups") or {}
    external_entity_group_names = {}
    for entity in entities:
        pair = data_groups.get(entity) or {}
        for role in ("reader", "contributor"):
            if not pair.get(role):
                raise ResolveError(f"entity '{entity}' has no {role} data group in config/entra-groups.yaml")
        # The Contributor takes the reference platform's 'engineers' key, which its
        # writing grants hang off; the Reader takes 'analysts'.
        external_entity_group_names[entity] = {"engineers": pair["contributor"], "analysts": pair["reader"]}
    return external_group_names, external_entity_group_names


def check_published_by(source: Path, published_by: Any, environment: str) -> None:
    """Fail unless the outputs in source were published by the named environment's state."""
    if published_by != environment:
        raise ResolveError(
            f"{source} was published by '{published_by}', not '{environment}': "
            "these are another environment's outputs"
        )


def ncc_rules(environment: str, platform: Outputs) -> list[dict[str, str]]:
    """Blob and dfs private endpoint rules for this environment's trusted storage."""
    storage_id = platform.get("trusted_storage_account_id")
    return [
        {"name": f"{environment}-trusted-{group_id}", "resource_id": storage_id, "group_id": group_id}
        for group_id in ("blob", "dfs")
    ]


def resolve_databricks(
    config: Path,
    environment: str,
    workspace: str,
    upstream: Path,
    singletons_only: bool = False,
) -> dict[str, Any]:
    """The Databricks root's upstream values for one state instance.

    singletons_only is for prd-anl's first apply: the entity
    lists and connectors are written empty, so the plan creates the
    production NCC and its rules and no entity object, from unchanged var files.
    """
    if workspace not in TRACKS:
        raise ResolveError(f"workspace must be one of {', '.join(TRACKS)}")
    if singletons_only and (environment, workspace) != ("prd", "anl"):
        raise ResolveError("--singletons-only is for prd-anl alone, which owns the production NCC")
    platform = Outputs(upstream)
    check_published_by(upstream, platform.get("environment"), environment)
    entities, shared = load_entities(config)

    workspaces = platform.get("workspaces")
    if workspace not in workspaces:
        raise ResolveError(f"{upstream} has no '{workspace}' workspace in its 'workspaces' output")
    chosen = workspaces[workspace]

    external_group_names, external_entity_group_names = group_names(config, environment, entities)
    domains = list(entities)

    values: dict[str, Any] = {
        "workspace_id": chosen["workspace_id"],
        "workspace_region_number": chosen["workspace_region_number"],
        "workspace_name": chosen["workspace_name"],
        **{name: platform.get(name) for name in PLATFORM_SCALARS},
        # The operational state shares its environment's trusted account, whose
        # rules that environment's analytical state adds.
        "ncc_private_endpoint_rules": ncc_rules(environment, platform) if workspace == "anl" else [],
        "business_domains": domains,
        # Which workspace this file was resolved for; the root checks it against workspace_type.
        "workspace_track": workspace,
        "shared_business_domain_name": shared,
        "external_group_names": external_group_names,
        "external_entity_group_names": external_entity_group_names,
    }
    if singletons_only:
        values.update(business_domains=[], external_entity_group_names={}, access_connectors={})
    return values


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("--root", required=True, choices=["infra/20-platform-services", "databricks"])
    parser.add_argument("--environment", required=True)
    parser.add_argument("--workspace", choices=TRACKS)
    parser.add_argument("--upstream-outputs", required=True, type=Path)
    parser.add_argument(
        "--singletons-only", action="store_true", help="prd-anl's first apply: write no entities"
    )
    parser.add_argument("--config-dir", type=Path, default=Path(__file__).resolve().parents[1] / "config")
    parser.add_argument("--out", required=True, type=Path)
    args = parser.parse_args(argv)

    if args.root == "databricks" and args.workspace is None:
        print("--workspace is required for the databricks root", file=sys.stderr)
        return 2

    try:
        tier_of(args.config_dir, args.environment)
        if args.root == "databricks":
            values = resolve_databricks(
                args.config_dir,
                args.environment,
                args.workspace,
                args.upstream_outputs,
                args.singletons_only,
            )
        else:
            values = resolve_platform_services(args.config_dir, args.environment, args.upstream_outputs)
    except ResolveError as error:
        print(f"resolve-upstream failed: {error}", file=sys.stderr)
        return 1

    args.out.write_text(json.dumps(values, indent=2, sort_keys=True) + "\n")
    print(f"Wrote {len(values)} upstream variables to {args.out}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
