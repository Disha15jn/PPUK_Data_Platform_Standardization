#!/usr/bin/env bash
# Before a Databricks plan or apply, fail early and clearly if:
#   1. the pipeline identity is not a Databricks account admin,
#   2. it is not a member of the Databricks admin group, or
#   3. the workspace URL does not resolve to a private address.
# Run inside an AzureCLI@2 task on the tier's service connection, from the repo root,
# after fetch_upstream.sh has written databricks/upstream.tfvars.json.
#
# Required env: DATABRICKS_ACCOUNT_ID, SERVICE_PRINCIPAL_APPLICATION_ID
# Optional env: UPSTREAM_FILE (default: databricks/upstream.tfvars.json),
#               ENTRA_GROUPS_FILE (default: config/entra-groups.yaml)
set -euo pipefail

: "${DATABRICKS_ACCOUNT_ID:?set DATABRICKS_ACCOUNT_ID}"
: "${SERVICE_PRINCIPAL_APPLICATION_ID:?set SERVICE_PRINCIPAL_APPLICATION_ID}"
UPSTREAM_FILE="${UPSTREAM_FILE:-databricks/upstream.tfvars.json}"
ENTRA_GROUPS_FILE="${ENTRA_GROUPS_FILE:-config/entra-groups.yaml}"
# Azure Databricks' fixed Entra application ID.
DATABRICKS_RESOURCE="2ff814a6-3304-4ab8-85cb-cd0e6f879c1d"

python3 -c "import yaml" 2>/dev/null || pip3 install --user PyYAML==6.0.3
TOKEN="$(az account get-access-token --resource "$DATABRICKS_RESOURCE" --query accessToken -o tsv)"
ACCOUNT_API="https://accounts.azuredatabricks.net/api/2.0/accounts/${DATABRICKS_ACCOUNT_ID}/scim/v2"

get() { curl -fsS -H "Authorization: Bearer ${TOKEN}" -G "$1" --data-urlencode "filter=$2"; }

ADMIN_GROUP="$(python3 -c "import yaml,sys;print(yaml.safe_load(open(sys.argv[1]))['admins']['databricks'])" "$ENTRA_GROUPS_FILE")"

SP_JSON="$(get "${ACCOUNT_API}/ServicePrincipals" "applicationId eq \"${SERVICE_PRINCIPAL_APPLICATION_ID}\"")" \
  || { echo "preflight FAILED: could not read service principals from the Databricks account. The identity may not be an account admin."; exit 1; }
GROUP_JSON="$(get "${ACCOUNT_API}/Groups" "displayName eq \"${ADMIN_GROUP}\"")" \
  || { echo "preflight FAILED: could not read groups from the Databricks account."; exit 1; }

python3 - "$SP_JSON" "$GROUP_JSON" "$ADMIN_GROUP" "$SERVICE_PRINCIPAL_APPLICATION_ID" <<'PY'
import json, sys
sp_json, group_json, group_name, app_id = sys.argv[1:5]
sps = json.loads(sp_json).get("Resources", [])
if not sps:
    sys.exit(f"preflight FAILED: service principal {app_id} is not in the Databricks account.")
sp = sps[0]
if "account_admin" not in [r.get("value") for r in sp.get("roles", [])]:
    sys.exit(f"preflight FAILED: {app_id} is not a Databricks account admin.")
groups = json.loads(group_json).get("Resources", [])
if not groups:
    sys.exit(f"preflight FAILED: group '{group_name}' is not in the Databricks account yet (automatic identity management has not brought it in).")
members = [m.get("value") for m in groups[0].get("members", [])]
if sp.get("id") not in members:
    sys.exit(f"preflight FAILED: {app_id} is not a member of the Databricks admin group '{group_name}'.")
print("preflight OK: account admin and member of", group_name)
PY

HOST="$(python3 - "$UPSTREAM_FILE" <<'PY'
import json, sys
v = json.load(open(sys.argv[1]))
print(f"adb-{v['workspace_id']}.{v['workspace_region_number']}.azuredatabricks.net")
PY
)"
IP="$(getent hosts "$HOST" | awk '{print $1}' | head -n1 || true)"
if [ -z "$IP" ]; then echo "preflight FAILED: ${HOST} does not resolve from this agent."; exit 1; fi
python3 - "$IP" "$HOST" <<'PY'
import ipaddress, sys
ip, host = sys.argv[1:3]
if not ipaddress.ip_address(ip).is_private:
    sys.exit(f"preflight FAILED: {host} resolves to {ip}, which is not a private address (check hub DNS and the privatelink zone).")
print(f"preflight OK: {host} resolves to private address {ip}")
PY
