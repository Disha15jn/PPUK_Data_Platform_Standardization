#!/usr/bin/env bash
# Run the Terraform unit tests for one state instance.
#
# Usage: scripts/terraform_test.sh <root> <instance>
#
# One invocation of `terraform test` takes one set of var files, so each state
# instance has its own test directory, tests/<instance>/, and runs with that
# instance's tracked var files plus the hand-written upstream fixture:
#
#   infra/20-platform-services  environments/<instance>.tfvars
#   databricks                  environments/common-<track>.tfvars, environments/<instance>.tfvars
#
#   then tests/fixtures/upstream-<instance>.json and tests/fixtures/identifiers.json
#
# JUnit results go to test-results/ when JUNIT=1.
set -euo pipefail

if [ $# -ne 2 ]; then
  echo "usage: $0 <root> <instance>" >&2
  exit 2
fi

root=$1
instance=$2
here=$(cd "$(dirname "$0")/.." && pwd)

if [ ! -d "$here/$root/tests/$instance" ]; then
  echo "No unit tests for $root $instance: expected $root/tests/$instance/" >&2
  exit 1
fi

var_files=()
case "$root" in
  databricks)
    track=${instance##*-}
    var_files+=("environments/common-$track.tfvars")
    ;;
esac
var_files+=(
  "environments/$instance.tfvars"
  "tests/fixtures/upstream-$instance.json"
  "tests/fixtures/identifiers.json"
)

args=()
for file in "${var_files[@]}"; do
  if [ ! -f "$here/$root/$file" ]; then
    echo "Missing var file for $root $instance: $root/$file" >&2
    exit 1
  fi
  args+=("-var-file=$file")
done

if [ "${JUNIT:-0}" = "1" ]; then
  mkdir -p "$here/test-results"
  args+=("-junit-xml=$here/test-results/${root//\//-}-$instance.xml")
fi

echo "== terraform test $root $instance"
# Modules that test files call directly are installed only when init is pointed
# at their test directory. The committed lock file is used as it is.
terraform -chdir="$here/$root" init -backend=false -input=false -lockfile=readonly \
  -test-directory="tests/$instance" >/dev/null

log=$(mktemp)
trap 'rm -f "$log"' EXIT

status=0
if ! terraform -chdir="$here/$root" test -no-color -test-directory="tests/$instance" "${args[@]}" 2>&1 | tee "$log"; then
  status=1
fi

# A run block that derives a value from a variable the test file never declares
# only warns today. Terraform deprecates it, so fail now rather than when it
# becomes an error, and so that the warning cannot come back unnoticed.
if grep -q 'Variable referenced without definition' "$log"; then
  echo "FAIL: $root $instance: a test file references a variable it does not declare." >&2
  echo "Declare it in a variable block at the top of that file; the root's own declaration still checks its type." >&2
  status=1
fi
exit "$status"
