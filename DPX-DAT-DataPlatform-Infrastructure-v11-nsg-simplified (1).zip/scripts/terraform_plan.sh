#!/usr/bin/env bash
# Print one state instance's plan under mock providers, to plans/<root>-<instance>.txt.
#
# Usage: scripts/terraform_plan.sh <root> <instance>
#
# Same var files and fixtures as scripts/terraform_test.sh, but a different test
# directory, <root>/plan-tests/<instance>/, whose single run stubs no module, so
# the plan lists every resource. `terraform test -verbose` prints that plan.
# Nothing is created and nothing is read from a cloud.
set -euo pipefail

if [ $# -ne 2 ]; then
  echo "usage: $0 <root> <instance>" >&2
  exit 2
fi

root=$1
instance=$2
here=$(cd "$(dirname "$0")/.." && pwd)

if [ ! -d "$here/$root/plan-tests/$instance" ]; then
  echo "No plan test for $root $instance: expected $root/plan-tests/$instance/" >&2
  exit 1
fi

var_files=()
case "$root" in
  databricks)
    track=${instance##*-}
    var_files+=("environments/common-$track.tfvars")
    ;;
esac
var_files+=(
  "environments/$instance.tfvars"
  "tests/fixtures/upstream-$instance.json"
  "tests/fixtures/identifiers.json"
)

args=()
for file in "${var_files[@]}"; do
  if [ ! -f "$here/$root/$file" ]; then
    echo "Missing var file for $root $instance: $root/$file" >&2
    exit 1
  fi
  args+=("-var-file=$file")
done

mkdir -p "$here/plans"
out="$here/plans/${root//\//-}-$instance.txt"

echo "== plan $root $instance"
terraform -chdir="$here/$root" init -backend=false -input=false -lockfile=readonly \
  -test-directory="plan-tests/$instance" >/dev/null
if ! terraform -chdir="$here/$root" test -no-color -verbose \
  -test-directory="plan-tests/$instance" "${args[@]}" >"$out" 2>&1; then
  cat "$out" >&2
  exit 1
fi
echo "   wrote plans/$(basename "$out")"
