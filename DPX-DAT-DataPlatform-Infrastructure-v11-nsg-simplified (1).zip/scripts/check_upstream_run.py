#!/usr/bin/env python3
"""Check that downloaded upstream outputs came from the newest completed run.

A pipeline that downloads another pipeline's artifact takes it from one run. If
a newer run has since failed before publishing, that artifact describes a
network that may no longer be what is deployed, so planning against it would be
wrong. This script asks the Azure DevOps builds API for the upstream pipeline's
recent runs on a branch and fails unless:

1. No run is queued or in progress. The upstream state may be changing.
2. The run the artifact came from is the newest completed run. A newer run
   that failed, or was cancelled, before publishing leaves the older file stale.

On success it prints which run, commit and finish time the outputs came from, so
every plan records the network it was made against.

With --mode latest-available both rules are lifted, because the outputs were
deliberately taken from the newest run that published them (see
select_outputs_run.py). The run must still be a completed one, and the line it
prints says how many newer runs there are, so the plan records that too.

Usage:
  check_upstream_run.py --definition-id ID --branch REF --source-run-id RUN
                        [--mode newest-run|latest-available]

It reads SYSTEM_COLLECTIONURI and SYSTEM_TEAMPROJECT, which Azure Pipelines sets,
and SYSTEM_ACCESSTOKEN, which the step must map from $(System.AccessToken). It
uses only the standard library, so it runs before any package is installed.

Exit codes: 0 the run is the newest; 1 it is not, or a run is active; 2 the
arguments, the environment or the API call are wrong.
"""

import argparse
import json
import os
import urllib.error
import urllib.parse
import urllib.request

ERROR = "##vso[task.logissue type=error]"


class UpstreamRunError(Exception):
    """The downloaded outputs cannot be trusted to describe the newest run."""


def fetch_runs(collection_uri, project, definition_id, branch, token, opener=None):
    """Return the upstream pipeline's most recent runs on a branch, newest queued first."""
    opener = opener or urllib.request.urlopen
    query = urllib.parse.urlencode(
        {
            "definitions": definition_id,
            "branchName": branch,
            "statusFilter": "all",
            "queryOrder": "queueTimeDescending",
            "$top": 20,
            "api-version": "7.1",
        }
    )
    url = f"{collection_uri.rstrip('/')}/{urllib.parse.quote(project)}/_apis/build/builds?{query}"
    request = urllib.request.Request(url, headers={"Authorization": f"Bearer {token}"})
    with opener(request, timeout=30) as response:
        return json.load(response)["value"]


def check(source_run_id, runs, allow_older=False):
    """Return a provenance line if source_run_id is the newest completed run, else raise.

    With allow_older, any completed run is accepted and a newer run, finished or
    active, is reported in the line instead of refused.
    """
    if allow_older:
        return check_older_allowed(source_run_id, runs)
    for found in runs:
        if found["status"] != "completed":
            raise UpstreamRunError(
                f"Run {found['id']} of the upstream pipeline is {found['status']}. "
                "The network may be changing: re-run this pipeline when it finishes."
            )
    completed = [found for found in runs if found["status"] == "completed"]
    if not completed:
        raise UpstreamRunError(
            "The upstream pipeline has no completed runs on this branch, or the build service "
            "cannot read its runs."
        )
    newest = max(completed, key=lambda found: found["id"])
    if newest["id"] != source_run_id:
        raise UpstreamRunError(
            f"The outputs came from run {source_run_id}, but the newest completed run is "
            f"{newest['id']} (result {newest['result']}). It published no outputs, so its apply "
            "did not finish. Fix the upstream pipeline and re-run it before planning."
        )
    return provenance(newest)


def provenance(found):
    return (
        f"Using run {found['id']} on {found['sourceBranch']}: commit {found['sourceVersion'][:7]}, "
        f"finished {found['finishTime']}, result {found['result']}."
    )


def check_older_allowed(source_run_id, runs):
    """Return a provenance line for a completed run, noting any newer runs; else raise."""
    source = next(
        (found for found in runs if found["id"] == source_run_id and found["status"] == "completed"),
        None,
    )
    if source is None:
        raise UpstreamRunError(
            f"Run {source_run_id} is not among the upstream pipeline's recent completed runs on "
            "this branch, so there is nothing to say where the outputs came from."
        )
    newer = sorted((found["id"] for found in runs if found["id"] > source_run_id), reverse=True)
    line = provenance(source)
    if newer:
        line += (
            f" NOT the newest: {len(newer)} newer run(s) ({', '.join(str(run_id) for run_id in newer)}) "
            "published no outputs or are still active."
        )
    return line


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("--definition-id", required=True)
    parser.add_argument("--branch", required=True)
    parser.add_argument("--source-run-id", required=True)
    parser.add_argument("--mode", choices=("newest-run", "latest-available"), default="newest-run")
    args = parser.parse_args(argv)

    def refuse(message, code):
        print(f"{ERROR}{message}")
        return code

    if not args.source_run_id.isdigit():
        return refuse(
            f"--source-run-id is {args.source_run_id!r}, not a run number. "
            "Check the step that sets OutputsRunId ran before this one.",
            2,
        )
    token = os.environ.get("SYSTEM_ACCESSTOKEN", "")
    if not token:
        return refuse("SYSTEM_ACCESSTOKEN is not set: map System.AccessToken into the step's env.", 2)
    try:
        runs = fetch_runs(
            os.environ["SYSTEM_COLLECTIONURI"],
            os.environ["SYSTEM_TEAMPROJECT"],
            args.definition_id,
            args.branch,
            token,
        )
    except KeyError as missing:
        return refuse(f"{missing.args[0]} is not set; this script runs inside an Azure Pipelines job.", 2)
    except urllib.error.HTTPError as error:
        return refuse(
            f"Azure DevOps returned {error.code} listing the runs of pipeline {args.definition_id}. "
            "The project's build service identity needs permission to view that pipeline.",
            2,
        )
    except urllib.error.URLError as error:
        return refuse(f"Could not reach Azure DevOps: {error.reason}", 2)
    try:
        print(check(int(args.source_run_id), runs, allow_older=args.mode == "latest-available"))
    except UpstreamRunError as error:
        return refuse(str(error), 1)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
