#!/usr/bin/env bash
# Write a root's `terraform output -json` to handoff-outputs/ and check it. Nothing is uploaded:
# the pipeline saves handoff-outputs/ as a pipeline artifact, and the next root reads it from there.
# publish_outputs.sh calls this, then uploads the same file for the pipelines that still publish.
# Run in the root's apply job, after `terraform apply`, from the repo root.
#
# Required env: ENVIRONMENT, TF_WORKING_DIR, FILE_PREFIX
#   FILE_PREFIX  names the file: <FILE_PREFIX>-<ENVIRONMENT>.json
# Optional env:
#   REQUIRED_OUTPUTS          space-separated output names that must be present and non-empty
#   ENVIRONMENT_OUTPUT_CHECK  "true" to also require an 'environment' output equal to ENVIRONMENT
set -euo pipefail

: "${ENVIRONMENT:?set ENVIRONMENT}"
: "${TF_WORKING_DIR:?set TF_WORKING_DIR}"
: "${FILE_PREFIX:?set FILE_PREFIX}"
BLOB="${FILE_PREFIX}-${ENVIRONMENT}.json"
mkdir -p handoff-outputs
OUT="$(pwd)/handoff-outputs/${BLOB}"

terraform -chdir="$TF_WORKING_DIR" output -json > "$OUT"

python3 - "$OUT" "$ENVIRONMENT" "${REQUIRED_OUTPUTS:-}" "${ENVIRONMENT_OUTPUT_CHECK:-false}" <<'PY'
import json, sys
path, env, required, check_env = sys.argv[1], sys.argv[2], sys.argv[3].split(), sys.argv[4] == "true"
data = json.load(open(path))
if not data:
    sys.exit("terraform output is empty: nothing to publish")
if check_env and data.get("environment", {}).get("value") != env:
    sys.exit(f"environment output is {data.get('environment', {}).get('value')!r}, expected {env!r}")
for name in required:
    if data.get(name, {}).get("value") in (None, "", {}, []):
        sys.exit(f"output {name!r} is missing, null or empty")
PY

echo "Wrote handoff-outputs/${BLOB}"
