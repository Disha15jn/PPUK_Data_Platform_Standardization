#!/usr/bin/env bash
# Publish a root's `terraform output -json` for the next root to read.
# Run in the root's apply job, after `terraform apply`, from the repo root.
#
# The writing and checking live in write_outputs.sh, which this script calls. The upload to the
# outputs container is commented out below (2026-10-23): the container does not exist and is not
# the hand-off route any more. The hand-off is the handoff-outputs pipeline artifact. The upload code
# is kept so it can be restored if a container is ever used again.
#
# Required env: ENVIRONMENT, TF_WORKING_DIR, FILE_PREFIX
#   FILE_PREFIX  names the file: <FILE_PREFIX>-<ENVIRONMENT>.json
# Optional env:
#   REQUIRED_OUTPUTS          space-separated output names that must be present and non-empty
#   ENVIRONMENT_OUTPUT_CHECK  "true" to also require an 'environment' output equal to ENVIRONMENT
set -euo pipefail

: "${ENVIRONMENT:?set ENVIRONMENT}"
: "${TF_WORKING_DIR:?set TF_WORKING_DIR}"
: "${FILE_PREFIX:?set FILE_PREFIX}"
BLOB="${FILE_PREFIX}-${ENVIRONMENT}.json"
OUT="$(pwd)/handoff-outputs/${BLOB}"   # also published as a pipeline artifact (see pipelines)

bash "$(dirname "$0")/write_outputs.sh"

# Upload to the outputs container, disabled 2026-10-23 because the container does not exist.
# Restore these lines, and the two : "${...}" guards and CONTAINER below, to bring it back.
# : "${STATE_STORAGE_ACCOUNT:?set STATE_STORAGE_ACCOUNT}"
# CONTAINER="${OUTPUTS_CONTAINER:-outputs}"
# az storage blob upload \
#   --auth-mode login \
#   --account-name "$STATE_STORAGE_ACCOUNT" \
#   --container-name "$CONTAINER" \
#   --name "$BLOB" \
#   --file "$OUT" \
#   --overwrite
# echo "Published ${BLOB} to ${STATE_STORAGE_ACCOUNT}/${CONTAINER}"

echo "Wrote ${BLOB} for the pipeline artifact handoff-outputs (no container upload)"
