"""Tests for resolve_upstream.py, the pipeline's resolve step.

Upstream outputs are written in `terraform output -json` form. Every value here
is invented; the GUIDs are all zeros.
"""

import copy
import json
import subprocess
import sys
from pathlib import Path

import pytest
import yaml

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import resolve_upstream  # noqa: E402

CONFIG = Path(__file__).resolve().parents[2] / "config"
SUB = "/subscriptions/00000000-0000-0000-0000-000000000000"
NET_RG = f"{SUB}/resourceGroups/rg-net"

# Each environment has its own subscription, which both of its workspaces
# share.
SUBSCRIPTIONS = {
    "dev": "00000000-0000-0000-0000-000000000001",
    "tst": "00000000-0000-0000-0000-000000000002",
    "stg": "00000000-0000-0000-0000-000000000003",
    "prd": "00000000-0000-0000-0000-000000000004",
}


def outputs(values: dict) -> dict:
    """Shape plain values as `terraform output -json` does."""
    return {name: {"sensitive": False, "type": "string", "value": value} for name, value in values.items()}


def subnet(name: str) -> dict:
    return {"id": f"{NET_RG}/providers/Microsoft.Network/virtualNetworks/vnet/subnets/{name}", "name": name}


NETWORK = {
    "virtual_network_id": f"{NET_RG}/providers/Microsoft.Network/virtualNetworks/vnet",
    "databricks_subnets": {
        track: {
            "host": subnet(f"snet-dbx-{track}-host"),
            "container": subnet(f"snet-dbx-{track}-container"),
            "private_endpoint_subnet_id": subnet(f"snet-pe-{track}")["id"],
        }
        for track in ("anl", "ops")
    },
    "private_endpoint_subnet_id": subnet("snet-pe-anl")["id"],
    "log_analytics_workspace_id": (
        "/subscriptions/00000000-0000-0000-0000-00000000000f/resourceGroups/rg-mgt/providers/"
        "Microsoft.OperationalInsights/workspaces/log-central"
    ),
    "private_dns_zone_ids": {
        key: f"{NET_RG}/providers/Microsoft.Network/privateDnsZones/{key}"
        for key in ("databricks", "blob", "dfs", "vault")
    },
}



def landing_zone(network: dict = NETWORK, environment: str = "dev") -> dict:
    """NETWORK as the landing zone publishes it: an `environment` output, and one
    `network` output object with each workspace's private endpoint subnet in a
    map of its own."""
    published = copy.deepcopy(network)
    published["private_endpoint_subnets"] = {}
    for key, pair in published["databricks_subnets"].items():
        subnet_id = pair.pop("private_endpoint_subnet_id")
        published["private_endpoint_subnets"][key] = {"id": subnet_id, "name": subnet_id.rsplit("/", 1)[1]}
    return outputs({"environment": environment, "network": published})

def platform(environment: str, tracks: tuple[str, ...] = ("anl",)) -> dict:
    sub = f"/subscriptions/{SUBSCRIPTIONS[environment]}"
    storage = f"{sub}/resourceGroups/rg-{environment}-storage/providers/Microsoft.Storage/storageAccounts/st{environment}trusted"
    return {
        "environment": environment,
        "subscription_id": SUBSCRIPTIONS[environment],
        "workspaces": {
            track: {
                "workspace_id": f"12345{index}",
                "workspace_region_number": "7",
                "workspace_name": f"dbw-{environment}-{track}",
                "workspace_url": f"adb-12345{index}.7.azuredatabricks.net",
            }
            for index, track in enumerate(tracks)
        },
        "unity_catalog_storage": f"st{environment}trusted",
        "storage_account_name": f"st{environment}trusted",
        "trusted_storage_account_id": storage,
        "resource_group_name": f"rg-{environment}-ops",
        "key_vault_name": f"kv-{environment}-scope",
        "access_connectors": {
            entity: {"id": f"{sub}/x/accessConnectors/ac-{entity}", "principal_id": "00000000-0000-0000-0000-000000000000"}
            for entity in ("grp", "duk")
        },
        "trusted_containers": {"grp": ["grp-uc"], "duk": ["duk-uc"]},
    }


def write_json(path: Path, data: dict) -> Path:
    path.write_text(json.dumps(data))
    return path


def contract_keys(root: str) -> set[str]:
    contract = yaml.safe_load((CONFIG / "upstream-contract.yaml").read_text())
    return set(contract["roots"][root]["upstream"])


# --- 20-platform-services: from the network and security state -------------


def test_platform_services_takes_network_outputs_as_one_object(tmp_path: Path) -> None:
    upstream = write_json(tmp_path / "network.json", landing_zone())

    values = resolve_upstream.resolve_platform_services(CONFIG, "dev", upstream)

    assert values["network"] == NETWORK


def test_platform_services_takes_entities_from_config(tmp_path: Path) -> None:
    upstream = write_json(tmp_path / "network.json", landing_zone())

    values = resolve_upstream.resolve_platform_services(CONFIG, "dev", upstream)

    assert values["entities"] == {
        "grp": {"display_name": "Group"},
        "duk": {"display_name": "Doubtless Pet Insurance - UK and Europe"},
    }


def test_platform_services_produces_exactly_the_contract(tmp_path: Path) -> None:
    upstream = write_json(tmp_path / "network.json", landing_zone())

    values = resolve_upstream.resolve_platform_services(CONFIG, "dev", upstream)

    assert set(values) == contract_keys("infra/20-platform-services")


def test_a_missing_value_fails_naming_it_its_file_and_its_use(tmp_path: Path) -> None:
    published = landing_zone()
    del published["network"]["value"]["private_endpoint_subnets"]["ops"]
    upstream = write_json(tmp_path / "network.json", published)

    with pytest.raises(
        resolve_upstream.ResolveError,
        match=r"'network/private_endpoint_subnets/ops/id' is missing from .*network\.json .*"
        r"wanted for network\.databricks_subnets\.ops\.private_endpoint_subnet_id",
    ):
        resolve_upstream.resolve_platform_services(CONFIG, "dev", upstream)


@pytest.mark.parametrize("empty", [None, "", {}, []])
def test_a_null_or_empty_value_fails(tmp_path: Path, empty: object) -> None:
    upstream = write_json(tmp_path / "network.json", landing_zone({**NETWORK, "virtual_network_id": empty}))

    with pytest.raises(resolve_upstream.ResolveError, match=r"'network/virtual_network_id' is (null|empty)"):
        resolve_upstream.resolve_platform_services(CONFIG, "dev", upstream)


def test_a_file_not_in_terraform_output_form_fails(tmp_path: Path) -> None:
    upstream = write_json(tmp_path / "network.json", NETWORK)

    with pytest.raises(resolve_upstream.ResolveError, match="terraform output -json"):
        resolve_upstream.resolve_platform_services(CONFIG, "dev", upstream)


def test_platform_services_reads_through_the_mapping_in_config(tmp_path: Path) -> None:
    config = copy_config(tmp_path)
    mapping = yaml.safe_load((config / "landing-zone-outputs.yaml").read_text())
    mapping["network"]["virtual_network_id"] = "vnet"
    (config / "landing-zone-outputs.yaml").write_text(yaml.safe_dump(mapping))
    moved = f"{NET_RG}/providers/Microsoft.Network/virtualNetworks/moved"
    published = landing_zone()
    published["vnet"] = {"sensitive": False, "type": "string", "value": moved}
    upstream = write_json(tmp_path / "network.json", published)

    values = resolve_upstream.resolve_platform_services(config, "dev", upstream)

    assert values["network"]["virtual_network_id"] == moved


def test_landing_zone_outputs_published_by_another_environment_fail(tmp_path: Path) -> None:
    upstream = write_json(tmp_path / "network.json", landing_zone(environment="tst"))

    with pytest.raises(resolve_upstream.ResolveError, match=r"published by 'tst', not 'dev'"):
        resolve_upstream.resolve_platform_services(CONFIG, "dev", upstream)


def test_landing_zone_outputs_without_an_environment_fail(tmp_path: Path) -> None:
    published = landing_zone()
    del published["environment"]
    upstream = write_json(tmp_path / "network.json", published)

    with pytest.raises(
        resolve_upstream.ResolveError, match=r"'environment' is missing from .*network\.json, wanted for the environment check"
    ):
        resolve_upstream.resolve_platform_services(CONFIG, "dev", upstream)


def test_the_environment_is_checked_before_the_network(tmp_path: Path) -> None:
    # A file from the wrong environment is refused as that, even if it is also broken.
    upstream = write_json(tmp_path / "network.json", outputs({"environment": "tst"}))

    with pytest.raises(resolve_upstream.ResolveError, match=r"published by 'tst', not 'dev'"):
        resolve_upstream.resolve_platform_services(CONFIG, "dev", upstream)


def test_main_refuses_another_environments_network_outputs(tmp_path: Path, capsys: pytest.CaptureFixture[str]) -> None:
    upstream = write_json(tmp_path / "network.json", landing_zone(environment="prd"))
    out = tmp_path / "upstream.tfvars.json"

    code = resolve_upstream.main(
        ["--root", "infra/20-platform-services", "--environment", "dev", "--upstream-outputs", str(upstream), "--out", str(out)]
    )

    assert code == 1
    assert not out.exists()
    assert "published by 'prd', not 'dev'" in capsys.readouterr().err


def test_a_missing_workspace_fails_naming_it(tmp_path: Path) -> None:
    anl_only = {**NETWORK, "databricks_subnets": {"anl": NETWORK["databricks_subnets"]["anl"]}}
    upstream = write_json(tmp_path / "network.json", landing_zone(anl_only))

    with pytest.raises(resolve_upstream.ResolveError, match=r"databricks_subnets/ops/host/id' is missing from .*network\.json"):
        resolve_upstream.resolve_platform_services(CONFIG, "dev", upstream)


def test_a_missing_mapping_file_fails(tmp_path: Path) -> None:
    config = copy_config(tmp_path)
    (config / "landing-zone-outputs.yaml").unlink()
    upstream = write_json(tmp_path / "network.json", landing_zone())

    with pytest.raises(resolve_upstream.ResolveError, match=r"landing-zone-outputs\.yaml is missing"):
        resolve_upstream.resolve_platform_services(config, "dev", upstream)


def test_the_script_runs_as_the_pipeline_calls_it(tmp_path: Path) -> None:
    # The pipeline runs `python3 scripts/resolve_upstream.py ...` from the repository root:
    # the script must find output_mapping.py beside it and config/ by default.
    upstream = write_json(tmp_path / "network.json", landing_zone())
    out = tmp_path / "upstream.tfvars.json"

    result = subprocess.run(
        [sys.executable, "scripts/resolve_upstream.py", "--root", "infra/20-platform-services",
         "--environment", "dev", "--upstream-outputs", str(upstream), "--out", str(out)],
        cwd=CONFIG.parent, capture_output=True, text=True, check=False,
    )

    assert result.returncode == 0, result.stderr
    assert json.loads(out.read_text())["network"] == NETWORK


# --- databricks: from 20-platform-services and config/ ----------------------


def test_databricks_takes_its_workspace_scalars_from_its_track(tmp_path: Path) -> None:
    upstream = write_json(tmp_path / "prd.json", outputs(platform("prd", ("anl", "ops"))))

    values = resolve_upstream.resolve_databricks(CONFIG, "prd", "ops", upstream)

    assert (values["workspace_id"], values["workspace_region_number"], values["workspace_name"]) == (
        "123451",
        "7",
        "dbw-prd-ops",
    )


def test_databricks_takes_the_subscription_its_environment_deployed_into(tmp_path: Path) -> None:
    upstream = write_json(tmp_path / "dev.json", outputs(platform("dev")))

    values = resolve_upstream.resolve_databricks(CONFIG, "dev", "anl", upstream)

    assert values["subscription_id"] == SUBSCRIPTIONS["dev"]


def test_both_production_workspaces_take_production_s_subscription(tmp_path: Path) -> None:
    prd = write_json(tmp_path / "prd.json", outputs(platform("prd", ("anl", "ops"))))

    anl = resolve_upstream.resolve_databricks(CONFIG, "prd", "anl", prd)
    ops = resolve_upstream.resolve_databricks(CONFIG, "prd", "ops", prd)

    assert anl["subscription_id"] == ops["subscription_id"] == SUBSCRIPTIONS["prd"]


def test_databricks_maps_groups_onto_the_reference_role_keys(tmp_path: Path) -> None:
    upstream = write_json(tmp_path / "dev.json", outputs(platform("dev")))

    values = resolve_upstream.resolve_databricks(CONFIG, "dev", "anl", upstream)

    assert values["external_group_names"] == {
        "platform_admins": "PG-DPX-DAT-RBAC-Databricks-Administrator",
        "engineers": "PG-DPX-DAT-RBAC-Engineer",
        "analysts": "PG-DPX-DAT-RBAC-Analyst",
        "sp_databricks": "PG-DPX-DAT-RBAC-ServicePrincipals-NonProd",
        "pii_authorized": "PG-DPX-DAT-RBAC-PiiAuthorised-Reader",
    }
    # Each entity's Contributor takes the reference platform's 'engineers' key, which
    # its writing grants hang off; its Reader takes 'analysts'.
    assert values["external_entity_group_names"] == {
        "grp": {
            "engineers": "PG-DPX-DAT-RBAC-GroupShared-Contributor",
            "analysts": "PG-DPX-DAT-RBAC-GroupShared-Reader",
        },
        "duk": {
            "engineers": "PG-DPX-DAT-RBAC-DoubtlessUK-Contributor",
            "analysts": "PG-DPX-DAT-RBAC-DoubtlessUK-Reader",
        },
    }


def test_production_uses_the_prod_tier_workload_group(tmp_path: Path) -> None:
    upstream = write_json(tmp_path / "prd.json", outputs(platform("prd", ("anl", "ops"))))

    values = resolve_upstream.resolve_databricks(CONFIG, "prd", "ops", upstream)

    assert values["external_group_names"]["sp_databricks"] == "PG-DPX-DAT-RBAC-ServicePrincipals-Prod"


def test_both_tracks_get_the_same_entities_and_their_own_track(tmp_path: Path) -> None:
    # One catalogue per environment per entity: the analytical state creates it, the
    # operational state binds it, so both are given the same entity list.
    upstream = write_json(tmp_path / "prd.json", outputs(platform("prd", ("anl", "ops"))))

    anl = resolve_upstream.resolve_databricks(CONFIG, "prd", "anl", upstream)
    ops = resolve_upstream.resolve_databricks(CONFIG, "prd", "ops", upstream)

    assert anl["business_domains"] == ops["business_domains"] == ["grp", "duk"]
    assert anl["shared_business_domain_name"] == ops["shared_business_domain_name"] == "grp"
    assert (anl["workspace_track"], ops["workspace_track"]) == ("anl", "ops")
    assert "operational_business_domains" not in anl and "operational_business_domains" not in ops


@pytest.mark.parametrize("environment", ["dev", "tst", "stg", "prd"])
def test_each_analytical_state_gets_rules_for_its_own_trusted_storage(tmp_path: Path, environment: str) -> None:
    upstream = write_json(tmp_path / f"{environment}.json", outputs(platform(environment)))

    values = resolve_upstream.resolve_databricks(CONFIG, environment, "anl", upstream)

    storage = platform(environment)["trusted_storage_account_id"]
    assert values["ncc_private_endpoint_rules"] == [
        {"name": f"{environment}-trusted-blob", "resource_id": storage, "group_id": "blob"},
        {"name": f"{environment}-trusted-dfs", "resource_id": storage, "group_id": "dfs"},
    ]


@pytest.mark.parametrize("environment", ["dev", "tst", "stg", "prd"])
def test_every_operational_state_gets_no_ncc_rules(tmp_path: Path, environment: str) -> None:
    # <env>-ops shares its environment's trusted account, whose rules <env>-anl adds.
    upstream = write_json(tmp_path / f"{environment}.json", outputs(platform(environment, ("anl", "ops"))))

    values = resolve_upstream.resolve_databricks(CONFIG, environment, "ops", upstream)

    assert values["ncc_private_endpoint_rules"] == []
    assert values["workspace_track"] == "ops"


def test_outputs_published_by_another_environment_fail(tmp_path: Path) -> None:
    dev = write_json(tmp_path / "dev.json", outputs(platform("dev", ("anl", "ops"))))

    with pytest.raises(resolve_upstream.ResolveError, match=r"published by 'dev'.*'prd'"):
        resolve_upstream.resolve_databricks(CONFIG, "prd", "anl", dev)


def test_the_resolver_reads_no_other_environments_outputs(tmp_path: Path, capsys: pytest.CaptureFixture[str]) -> None:
    # Each state's NCC rules come from its own environment's outputs.
    prd = write_json(tmp_path / "prd.json", outputs(platform("prd", ("anl", "ops"))))

    assert "ncc_environments" not in yaml.safe_load((CONFIG / "environments.yaml").read_text())
    with pytest.raises(SystemExit) as exit_info:
        resolve_upstream.main(
            [
                "--root", "databricks", "--environment", "prd", "--workspace", "anl",
                "--upstream-outputs", str(prd), "--ncc-outputs", f"dev={prd}", "--out", str(tmp_path / "o.json"),
            ]
        )
    assert exit_info.value.code == 2
    assert "unrecognized arguments: --ncc-outputs" in capsys.readouterr().err


def test_singletons_only_writes_no_entities_and_keeps_the_singletons(tmp_path: Path) -> None:
    prd = write_json(tmp_path / "prd.json", outputs(platform("prd", ("anl", "ops"))))

    values = resolve_upstream.resolve_databricks(CONFIG, "prd", "anl", prd, singletons_only=True)

    assert values["business_domains"] == []
    assert values["workspace_track"] == "anl"
    assert values["external_entity_group_names"] == {}
    assert values["access_connectors"] == {}
    assert [rule["name"] for rule in values["ncc_private_endpoint_rules"]] == ["prd-trusted-blob", "prd-trusted-dfs"]
    assert values["workspace_id"] == platform("prd", ("anl", "ops"))["workspaces"]["anl"]["workspace_id"]
    assert set(values) == contract_keys("databricks")


@pytest.mark.parametrize(("environment", "workspace"), [("dev", "anl"), ("prd", "ops")])
def test_singletons_only_is_for_prd_anl_alone(tmp_path: Path, environment: str, workspace: str) -> None:
    upstream = write_json(tmp_path / f"{environment}.json", outputs(platform(environment, ("anl", "ops"))))

    with pytest.raises(resolve_upstream.ResolveError, match="prd-anl"):
        resolve_upstream.resolve_databricks(CONFIG, environment, workspace, upstream, singletons_only=True)


def test_a_workspace_track_missing_from_the_outputs_fails(tmp_path: Path) -> None:
    upstream = write_json(tmp_path / "dev.json", outputs(platform("dev")))

    with pytest.raises(resolve_upstream.ResolveError, match=r"no 'ops' workspace"):
        resolve_upstream.resolve_databricks(CONFIG, "dev", "ops", upstream)


def test_databricks_produces_exactly_the_contract(tmp_path: Path) -> None:
    upstream = write_json(tmp_path / "dev.json", outputs(platform("dev")))

    values = resolve_upstream.resolve_databricks(CONFIG, "dev", "anl", upstream)

    assert set(values) == contract_keys("databricks")


# --- config/ validation ------------------------------------------------------


def copy_config(tmp_path: Path) -> Path:
    target = tmp_path / "config"
    target.mkdir()
    for source in CONFIG.glob("*.yaml"):
        (target / source.name).write_text(source.read_text())
    return target


@pytest.mark.parametrize(
    ("remove", "message"),
    [
        (None, r"entity 'duk' has no reader data group"),
        ("reader", r"entity 'duk' has no reader data group"),
        ("contributor", r"entity 'duk' has no contributor data group"),
    ],
)
def test_an_entity_needs_both_a_reader_and_a_contributor_group(tmp_path: Path, remove: str | None, message: str) -> None:
    config = copy_config(tmp_path)
    groups = yaml.safe_load((config / "entra-groups.yaml").read_text())
    if remove is None:
        del groups["entity_data_groups"]["duk"]
    else:
        del groups["entity_data_groups"]["duk"][remove]
    (config / "entra-groups.yaml").write_text(yaml.safe_dump(groups))
    upstream = write_json(tmp_path / "dev.json", outputs(platform("dev")))

    with pytest.raises(resolve_upstream.ResolveError, match=message):
        resolve_upstream.resolve_databricks(config, "dev", "anl", upstream)


@pytest.mark.parametrize("key", ["G", "x", "1abc", "grp-uk", "averylongkey"])
def test_an_invalid_entity_key_fails(tmp_path: Path, key: str) -> None:
    config = copy_config(tmp_path)
    entities = yaml.safe_load((config / "entities.yaml").read_text())
    entities["entities"][key] = {"display_name": "Bad"}
    (config / "entities.yaml").write_text(yaml.safe_dump(entities))
    upstream = write_json(tmp_path / "network.json", landing_zone())

    with pytest.raises(resolve_upstream.ResolveError, match="entity key"):
        resolve_upstream.resolve_platform_services(config, "dev", upstream)


def test_the_shared_entity_must_be_an_entity(tmp_path: Path) -> None:
    config = copy_config(tmp_path)
    entities = yaml.safe_load((config / "entities.yaml").read_text())
    entities["shared_entity"] = "nope"
    (config / "entities.yaml").write_text(yaml.safe_dump(entities))
    upstream = write_json(tmp_path / "network.json", landing_zone())

    with pytest.raises(resolve_upstream.ResolveError, match="shared_entity"):
        resolve_upstream.resolve_platform_services(config, "dev", upstream)


# --- the command line --------------------------------------------------------


def test_main_writes_the_generated_var_file(tmp_path: Path) -> None:
    upstream = write_json(tmp_path / "network.json", landing_zone())
    out = tmp_path / "upstream.tfvars.json"

    code = resolve_upstream.main(
        ["--root", "infra/20-platform-services", "--environment", "dev", "--upstream-outputs", str(upstream), "--out", str(out)]
    )

    assert code == 0
    assert json.loads(out.read_text())["network"] == NETWORK


def test_main_reports_a_resolve_error_and_writes_nothing(tmp_path: Path, capsys: pytest.CaptureFixture[str]) -> None:
    upstream = write_json(tmp_path / "network.json", outputs({}))
    out = tmp_path / "upstream.tfvars.json"

    code = resolve_upstream.main(
        ["--root", "infra/20-platform-services", "--environment", "dev", "--upstream-outputs", str(upstream), "--out", str(out)]
    )

    assert code == 1
    assert not out.exists()
    assert "is missing" in capsys.readouterr().err


def test_main_requires_a_workspace_for_databricks(tmp_path: Path, capsys: pytest.CaptureFixture[str]) -> None:
    upstream = write_json(tmp_path / "dev.json", outputs(platform("dev")))

    code = resolve_upstream.main(
        ["--root", "databricks", "--environment", "dev", "--upstream-outputs", str(upstream), "--out", str(tmp_path / "o.json")]
    )

    assert code == 2
    assert "--workspace" in capsys.readouterr().err


def test_main_passes_singletons_only(tmp_path: Path) -> None:
    prd = write_json(tmp_path / "prd.json", outputs(platform("prd", ("anl", "ops"))))
    out = tmp_path / "upstream.tfvars.json"

    code = resolve_upstream.main(
        [
            "--root", "databricks", "--environment", "prd", "--workspace", "anl",
            "--upstream-outputs", str(prd), "--singletons-only", "--out", str(out),
        ]
    )

    assert code == 0
    assert json.loads(out.read_text())["business_domains"] == []
