"""The agreed names obey Azure's rules, and each var file carries exactly them.

The rules are the ones the wrapper modules validate, written out again here so
that the tst and stg names are checked too: the Terraform unit tests run only
for dev and prd.
"""

import re
import sys
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[2]
PLATFORM = ROOT / "infra/20-platform-services"
sys.path.insert(0, str(PLATFORM / "tests"))

from agreed_names import NAMES  # noqa: E402

ENVIRONMENTS = ["dev", "tst", "stg", "prd"]

# category -> (pattern, maximum length), as in infra/modules/*/variables.tf
RULES = {
    "resource_groups": (r"^[-\w.()]{1,90}$", 90),
    "managed_resource_groups": (r"^[-\w.()]{1,90}$", 90),
    "key_vaults": (r"^[A-Za-z][A-Za-z0-9-]{1,22}[A-Za-z0-9]$", 24),
    "storage": (r"^[a-z0-9]{3,24}$", 24),
    "access_connectors": (r"^[A-Za-z0-9][A-Za-z0-9_.-]{1,62}[A-Za-z0-9_]$", 64),
    "storage_connectors": (r"^[A-Za-z0-9][A-Za-z0-9_.-]{1,62}[A-Za-z0-9_]$", 64),
    "workspaces": (r"^[A-Za-z0-9][A-Za-z0-9_-]{1,62}[A-Za-z0-9]$", 64),
    "identities": (r"^[A-Za-z0-9][A-Za-z0-9_-]{2,127}$", 128),
}


def all_names(environment: str):
    for category, group in NAMES[environment].items():
        for key, name in group.items():
            yield category, key, name


@pytest.mark.parametrize("environment", ENVIRONMENTS)
def test_every_agreed_name_obeys_its_azure_rule(environment: str) -> None:
    for category, key, name in all_names(environment):
        pattern, limit = RULES[category]
        assert re.match(pattern, name), f"{environment} {category}.{key}: '{name}' breaks the naming rule"
        assert len(name) <= limit, f"{environment} {category}.{key}: '{name}' is {len(name)} characters, limit {limit}"
        assert name == name.strip(), f"{environment} {category}.{key}: '{name}' has stray whitespace"


def test_no_name_is_used_twice() -> None:
    seen: dict[str, str] = {}
    for environment in ENVIRONMENTS:
        for category, key, name in all_names(environment):
            where = f"{environment} {category}.{key}"
            assert name not in seen, f"'{name}' is used by both {seen[name]} and {where}"
            seen[name] = where


@pytest.mark.parametrize("environment", ENVIRONMENTS)
def test_var_file_carries_the_agreed_names_and_no_placeholders(environment: str) -> None:
    text = (PLATFORM / f"environments/{environment}.tfvars").read_text()
    strings = set(re.findall(r'"([^"]*)"', text))

    for category, key, name in all_names(environment):
        assert name in strings, f"{environment}.tfvars lacks {category}.{key}: {name}"
    placeholders = sorted(s for s in strings if "tbc" in s and s != "tbc")
    assert not placeholders, f"{environment}.tfvars still has placeholder names: {placeholders}"
