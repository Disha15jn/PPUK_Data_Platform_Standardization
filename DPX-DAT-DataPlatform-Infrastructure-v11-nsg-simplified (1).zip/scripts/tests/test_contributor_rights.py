"""Who may write, per environment, as the tracked var files set it.

A Contributor group writes in dev and tst and only reads in stg and prd. The
Terraform tests cover dev-anl, dev-ops, prd-anl and prd-ops in full, and tst-ops
and stg-ops by a smoke test; this checks every var file, including tst-anl and
stg-anl, which have no Terraform tests.
"""

import re
from pathlib import Path

import pytest

ENVIRONMENTS = Path(__file__).resolve().parents[2] / "databricks/environments"
WRITES = {"MODIFY", "CREATE_SCHEMA", "WRITE_VOLUME", "ALL_PRIVILEGES"}


def setting(instance: str, name: str) -> set[str]:
    """The list a var file sets, ignoring commented-out overrides."""
    text = "\n".join(line for line in (ENVIRONMENTS / f"{instance}.tfvars").read_text().splitlines() if not line.lstrip().startswith("#"))
    match = re.search(rf"^{name}\s*=\s*\[(.*?)\]", text, re.S | re.M)
    assert match, f"{instance}.tfvars does not set {name}"
    return set(re.findall(r'"([^"]+)"', match.group(1)))


@pytest.mark.parametrize("instance", ["dev-anl", "dev-ops", "tst-anl", "tst-ops"])
def test_contributors_write_in_dev_and_tst(instance: str) -> None:
    assert {"MODIFY", "CREATE_SCHEMA"} <= setting(instance, "catalog_privileges_entity_engineers")
    assert "WRITE_VOLUME" in setting(instance, "volume_privileges_entity_engineers")


@pytest.mark.parametrize("instance", ["stg-anl", "stg-ops", "prd-anl", "prd-ops"])
def test_contributors_only_read_in_stg_and_prd(instance: str) -> None:
    assert not WRITES & setting(instance, "catalog_privileges_entity_engineers")
    assert not WRITES & setting(instance, "volume_privileges_entity_engineers")
    assert "SELECT" in setting(instance, "catalog_privileges_entity_engineers")


@pytest.mark.parametrize("instance", ["dev-anl", "dev-ops", "tst-anl", "tst-ops", "stg-anl", "stg-ops", "prd-anl", "prd-ops"])
def test_readers_never_write_anywhere(instance: str) -> None:
    track = instance.rsplit("-", 1)[1]
    assert not WRITES & setting(f"common-{track}", "catalog_privileges_entity_analysts")
