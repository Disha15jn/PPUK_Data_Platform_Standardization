"""Tests for apply_readiness.sh.

The script reports, before a platform apply, what a plan cannot see: whether
the resource providers are registered, whether a workspace NSG already holds a
rule at priority 100 (where Databricks adds its own), and whether the pipeline
identity holds roles on the DNS zones, the subscription and the Log Analytics
workspace. It reports and never fails. The Azure CLI is replaced by a stub that
answers from a table, so no test needs Azure.
"""

import base64
import json
import os
import stat
import subprocess
from pathlib import Path

import pytest

SCRIPT = Path(__file__).resolve().parents[1] / "apply_readiness.sh"
SUB = "/subscriptions/sub-1"
NSG = f"{SUB}/resourceGroups/net-rg/providers/Microsoft.Network/networkSecurityGroups/nsg-ahx"
ZONES = {
    "databricks": "/subscriptions/dns-sub/resourceGroups/dns-rg/providers/Microsoft.Network/privateDnsZones/privatelink.azuredatabricks.net",
    "blob": "/subscriptions/dns-sub/resourceGroups/dns-rg/providers/Microsoft.Network/privateDnsZones/privatelink.blob.core.windows.net",
    "dfs": "/subscriptions/dns-sub/resourceGroups/dns-rg/providers/Microsoft.Network/privateDnsZones/privatelink.dfs.core.windows.net",
    "vault": "/subscriptions/dns-sub/resourceGroups/dns-rg/providers/Microsoft.Network/privateDnsZones/privatelink.vaultcore.azure.net",
}
LAW = "/subscriptions/mgt-sub/resourceGroups/la-rg/providers/Microsoft.OperationalInsights/workspaces/la-1"
SUBNETS = {
    f"{ws}.{role}": f"{SUB}/resourceGroups/net-rg/providers/Microsoft.Network/virtualNetworks/vnet/subnets/{ws}-{role}"
    for ws in ("anl", "ops")
    for role in ("host", "container")
}
STUB = """#!/usr/bin/env python3
import json, os, sys
if os.environ.get("FAKE_AZ_READS_STDIN"):
    sys.stdin.read()
line = " ".join(sys.argv[1:])
for rule in json.load(open(os.environ["FAKE_AZ_FILE"])):
    if rule["match"] in line:
        sys.stdout.write(rule.get("out", ""))
        sys.exit(rule.get("rc", 0))
sys.exit(1)
"""


def jwt(claims):
    payload = base64.urlsafe_b64encode(json.dumps(claims).encode()).decode().rstrip("=")
    return f"eyJhbGciOiJub25lIn0.{payload}.c2lnbmF0dXJl"


TOKEN = jwt({"oid": "oid-123", "appid": "app-123"})


def good_answers():
    answers = [
        {"match": "get-access-token", "out": TOKEN + "\n"},
        {"match": "provider show", "out": "Registered\n"},
        {"match": "vnet subnet show", "out": NSG + "\n"},
        {"match": "nsg show", "out": ""},
        {"match": "--assignee-object-id oid-123", "out": "Owner\n"},
    ]
    return answers


@pytest.fixture
def run(tmp_path):
    bindir = tmp_path / "bin"
    bindir.mkdir()
    az = bindir / "az"
    az.write_text(STUB)
    az.chmod(az.stat().st_mode | stat.S_IEXEC)
    upstream = tmp_path / "upstream.tfvars.json"
    upstream.write_text(
        json.dumps(
            {
                "network": {
                    "databricks_subnets": {
                        ws: {role: {"id": SUBNETS[f"{ws}.{role}"], "name": f"{ws}-{role}"} for role in ("host", "container")}
                        for ws in ("anl", "ops")
                    },
                    "private_dns_zone_ids": ZONES,
                    "log_analytics_workspace_id": LAW,
                }
            }
        )
    )

    def go(answers, **env):
        table = tmp_path / "answers.json"
        table.write_text(json.dumps(answers))
        result = subprocess.run(
            ["bash", str(SCRIPT)],
            capture_output=True,
            text=True,
            env={
                **os.environ,
                "PATH": f"{bindir}:{os.environ['PATH']}",
                "FAKE_AZ_FILE": str(table),
                "UPSTREAM_FILE": str(upstream),
                "SUBSCRIPTION_ID": "sub-1",
                **env,
            },
        )
        return result

    return go


def lines(result, kind):
    return [line for line in result.stdout.splitlines() if line.startswith(kind)]


def test_everything_in_place_reports_no_problem(run):
    result = run(good_answers())
    assert result.returncode == 0
    assert lines(result, "PROBLEM") == []
    assert lines(result, "UNKNOWN") == []
    assert len(lines(result, "OK")) >= 10


def test_an_unregistered_provider_is_a_problem_that_names_it(run):
    answers = [{"match": "Microsoft.Databricks", "out": "NotRegistered\n"}, *good_answers()]
    result = run(answers)
    assert result.returncode == 0
    (problem,) = lines(result, "PROBLEM")
    assert "Microsoft.Databricks" in problem


def test_a_rule_at_priority_100_on_a_workspace_nsg_is_a_problem_that_names_both(run):
    answers = [{"match": "nsg show", "out": "allow-vnet-outbound\n"}, *good_answers()]
    result = run(answers)
    problems = lines(result, "PROBLEM")
    assert problems and all("nsg-ahx" in p and "allow-vnet-outbound" in p and "100" in p for p in problems)


def test_no_role_on_a_dns_zone_is_a_problem_that_names_the_zone(run):
    answers = [{"match": "privatelink.dfs.core.windows.net", "out": "Reader\n"}, *good_answers()]
    result = run(answers)
    (problem,) = lines(result, "PROBLEM")
    assert "dfs" in problem and "Reader" in problem


def test_no_role_assignment_rights_on_the_subscription_is_a_problem(run):
    answers = [{"match": f"--scope {SUB} ", "out": "Reader\n"}, *good_answers()]
    result = run(answers)
    (problem,) = lines(result, "PROBLEM")
    assert "role assignment" in problem.lower() or "RBAC" in problem


def test_a_failing_az_call_is_unknown_never_a_failure(run):
    answers = [{"match": "provider show", "rc": 1}, *good_answers()]
    result = run(answers)
    assert result.returncode == 0
    assert lines(result, "UNKNOWN")


def test_it_never_fails_even_when_every_call_fails(run):
    result = run([])
    assert result.returncode == 0
    assert lines(result, "UNKNOWN")


def test_a_missing_upstream_file_is_reported_not_fatal(run, tmp_path):
    result = run(good_answers(), UPSTREAM_FILE=str(tmp_path / "absent.json"))
    assert result.returncode == 0
    assert any("upstream" in line.lower() for line in lines(result, "UNKNOWN"))


def test_a_failing_nsg_rule_listing_is_unknown_not_ok(run):
    result = run([{"match": "nsg show", "rc": 1}, *good_answers()])
    unknowns = lines(result, "UNKNOWN")
    assert unknowns and all("nsg-ahx" in u for u in unknowns)
    assert lines(result, "PROBLEM") == []
    assert not any("nsg-ahx" in line for line in lines(result, "OK"))


def test_a_failing_role_listing_is_unknown_not_a_problem(run):
    result = run([{"match": "role assignment list", "rc": 1}, *good_answers()])
    assert len(lines(result, "UNKNOWN")) == 6
    assert lines(result, "PROBLEM") == []


def test_roles_are_looked_up_by_object_id_taken_from_the_token(run):
    result = run(good_answers())
    assert lines(result, "PROBLEM") == [] and lines(result, "UNKNOWN") == []


def test_the_token_is_never_printed(run):
    result = run(good_answers())
    assert TOKEN not in result.stdout + result.stderr
    assert TOKEN.split(".")[1] not in result.stdout + result.stderr


def test_a_token_without_an_object_id_makes_every_role_line_unknown(run):
    answers = [{"match": "get-access-token", "out": jwt({"appid": "app-123"}) + "\n"}, *good_answers()]
    result = run(answers)
    assert len(lines(result, "UNKNOWN")) == 6
    assert lines(result, "PROBLEM") == []


def test_nsg_rules_are_read_from_the_nsg_by_its_own_id(run):
    answers = [{"match": f"nsg show --ids {NSG} ", "out": "allow-vnet-outbound\n"}, *good_answers()]
    result = run(answers)
    assert any("allow-vnet-outbound" in line for line in lines(result, "PROBLEM"))


def test_databricks_own_priority_100_rules_are_not_a_problem(run):
    owned = "Microsoft.Databricks-workspaces_UseOnly_databricks-worker-to-worker-inbound\n"
    result = run([{"match": "nsg show", "out": owned}, *good_answers()])
    assert lines(result, "PROBLEM") == []
    assert any("nsg-ahx" in line for line in lines(result, "OK"))


def test_only_a_rule_that_is_not_databricks_own_is_named(run):
    owned = "Microsoft.Databricks-workspaces_UseOnly_databricks-worker-to-worker-inbound\nallow-vnet-outbound\n"
    result = run([{"match": "nsg show", "out": owned}, *good_answers()])
    (problem,) = lines(result, "PROBLEM")
    assert "allow-vnet-outbound" in problem and "worker-to-worker" not in problem


def test_every_check_runs_even_when_az_reads_standard_input(run):
    nsgs = {role: f"{SUB}/resourceGroups/net-rg/providers/Microsoft.Network/networkSecurityGroups/nsg-{role}" for role in SUBNETS}
    answers = [
        *({"match": f"subnets/{key.replace('.', '-')} ", "out": nsg + "\n"} for key, nsg in nsgs.items()),
        *good_answers(),
    ]
    result = run(answers, FAKE_AZ_READS_STDIN="1")
    oks = " ".join(lines(result, "OK"))
    for key in SUBNETS:
        assert f"nsg-{key}" in oks, key
    for zone in ZONES:
        assert f"DNS zone {zone}" in oks, zone
