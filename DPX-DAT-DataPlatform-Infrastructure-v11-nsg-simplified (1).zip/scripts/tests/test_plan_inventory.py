"""Tests for plan_inventory.py.

A small printed plan is parsed for each kind of block the real plans hold: a
plain create, an azapi resource named by its Azure type, a data read, an
in-place update, a replacement, and the note lines that are not resources.
"""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import plan_inventory  # noqa: E402

# Terraform prints attributes alphabetically, so a resource's `body` comes before
# its `name`: the nested `name` must not be taken for the resource's.
PLAN = '''\
tests/plan.tftest.hcl... in progress
  run "plan"... pass

Terraform will perform the following actions:

  # module.storage.azapi_resource.this will be created
  + resource "azapi_resource" "this" {
      + body      = {
          + sku = {
              + name = "Standard_LRS"
            }
        }
      + id        = (known after apply)
      + name      = "sttbcdevtrusted"
      + type      = "Microsoft.Storage/storageAccounts@2023-05-01"
    }

  # databricks_catalog.this["grp"] will be created
  + resource "databricks_catalog" "this" {
      + name = "dev_grp"
    }

  # module.x.data.azurerm_resource_group.parent will be read during apply
  # (config refers to values not yet known)
 <= data "azurerm_resource_group" "parent" {
      + name = (known after apply)
    }

  # databricks_cluster.shared will be updated in-place
  ~ resource "databricks_cluster" "shared" {
      ~ cluster_name = "old" -> "new"
    }

  # azurerm_key_vault.this must be replaced
-/+ resource "azurerm_key_vault" "this" {
      ~ name = "kv-a" -> "kv-b" # forces replacement
    }

Plan: 2 to add, 1 to change, 1 to destroy.
'''


def by_address() -> dict[str, plan_inventory.Resource]:
    return {r.address: r for r in plan_inventory.parse_plan(PLAN)}


def test_every_resource_block_is_found_and_notes_are_not() -> None:
    assert len(plan_inventory.parse_plan(PLAN)) == 5


def test_an_azapi_resource_is_shown_by_its_azure_type() -> None:
    resource = by_address()["module.storage.azapi_resource.this"]
    assert resource.type == "Microsoft.Storage/storageAccounts@2023-05-01"
    assert resource.name == "sttbcdevtrusted"


def test_a_nested_name_is_not_taken_for_the_resource_name() -> None:
    assert by_address()["module.storage.azapi_resource.this"].name != "Standard_LRS"


def test_actions_are_named() -> None:
    actions = {a: r.action for a, r in by_address().items()}
    assert actions == {
        "module.storage.azapi_resource.this": "create",
        'databricks_catalog.this["grp"]': "create",
        "module.x.data.azurerm_resource_group.parent": "read",
        "databricks_cluster.shared": "update",
        "azurerm_key_vault.this": "replace",
    }


def test_a_computed_name_reads_unknown() -> None:
    assert by_address()["module.x.data.azurerm_resource_group.parent"].name == "unknown"


def test_the_report_carries_the_summary_and_a_count_by_type(tmp_path: Path) -> None:
    resources = plan_inventory.parse_plan(PLAN)
    report = plan_inventory.render("demo", PLAN, resources)
    assert "Plan: 2 to add, 1 to change, 1 to destroy." in report
    assert "| `databricks_catalog` | create | 1 |" in report


def test_a_pipe_in_a_value_cannot_break_the_table() -> None:
    assert plan_inventory.cell("a|b") == "a\\|b"


def test_a_file_with_no_resources_fails(tmp_path: Path) -> None:
    empty = tmp_path / "empty.txt"
    empty.write_text("Success! 0 passed.\n")
    assert plan_inventory.main([str(empty)]) == 1
    assert not (tmp_path / "empty.md").exists()
