"""The Databricks root changes nothing it did not create.

The germanywestcentral metastore is shared with other programmes' workspaces,
and no one owns the account as a whole. This root may read the metastore, but
must never declare a resource that changes the metastore itself, its
assignments or grants, or anything else every workspace on it shares.
"""

import re
from pathlib import Path

import pytest

DATABRICKS = Path(__file__).resolve().parents[2] / "databricks"

# Resource types that write state every workspace on the metastore, or in the
# account, shares.
FORBIDDEN_RESOURCES = [
    "databricks_metastore",
    "databricks_metastore_assignment",
    "databricks_metastore_data_access",
    "databricks_system_schema",
    "databricks_group_role",
    "databricks_service_principal_role",
    "databricks_user_role",
]

RESOURCE = re.compile(r'^resource\s+"(?P<type>\w+)"', re.MULTILINE)
IMPORT = re.compile(r"^import\s*\{", re.MULTILINE)
METASTORE_ARGUMENT = re.compile(r"^\s*metastore\s*=", re.MULTILINE)
# The system catalogue and its schemas hold the whole account's system tables.
SYSTEM_GRANT = re.compile(r'^\s*(?:catalog|schema)\s*=\s*"system[".]', re.MULTILINE)


def configuration() -> dict[str, str]:
    return {path.name: path.read_text() for path in sorted(DATABRICKS.glob("*.tf"))}


@pytest.mark.parametrize("resource_type", FORBIDDEN_RESOURCES)
def test_declares_no_shared_resource(resource_type: str) -> None:
    declared = {match["type"] for text in configuration().values() for match in RESOURCE.finditer(text)}

    assert resource_type not in declared


def test_imports_nothing() -> None:
    # An import adopts an object someone else created.
    assert [name for name, text in configuration().items() if IMPORT.search(text)] == []


def test_grants_nothing_on_the_metastore() -> None:
    # A grant on the metastore changes what every workspace on it may do.
    assert [name for name, text in configuration().items() if METASTORE_ARGUMENT.search(text)] == []


def test_grants_nothing_on_the_system_tables() -> None:
    # System tables cover every workspace in the account, so access to them is
    # for whoever runs the account to give.
    assert [name for name, text in configuration().items() if SYSTEM_GRANT.search(text)] == []
