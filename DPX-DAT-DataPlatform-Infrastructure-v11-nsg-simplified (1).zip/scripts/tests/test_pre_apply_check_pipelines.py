"""The pipeline wiring checks in pre_apply_check.py.

A platform pipeline gets its network outputs either from a fetch step (the
outputs container) or, for dev, from a step that selects a landing-zone run
and downloads its artifact. Either must run before Terraform-Init. A platform
pipeline with neither must still be reported.
"""

import sys
from pathlib import Path

import pytest

REPO = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(REPO / "scripts"))

import pre_apply_check  # noqa: E402


@pytest.fixture(autouse=True)
def clean_results():
    pre_apply_check.FAILS.clear()
    yield
    pre_apply_check.FAILS.clear()


def platform_failures(env):
    return [m for m in pre_apply_check.FAILS if m.startswith(f"pipeline 20-Platform.{env}")]


def test_dev_platform_pipeline_wiring_passes():
    pre_apply_check.check_pipelines(str(REPO), ["dev"])
    assert platform_failures("dev") == []


def test_the_container_fetch_form_still_passes_for_tst():
    pre_apply_check.check_pipelines(str(REPO), ["tst"])
    assert platform_failures("tst") == []


def test_a_platform_pipeline_with_no_network_step_is_reported(tmp_path):
    (tmp_path / "pipelines").mkdir()
    (tmp_path / "pipelines" / "20-Platform.dev.yml").write_text(
        "trigger: none\n"
        "# platform-services/dev.tfstate environments/dev.tfvars upstream.tfvars.json TF_VAR_x\n"
        "stages:\n"
        "- stage: Build\n"
        "  jobs:\n"
        "  - job: TerraformPlan\n"
        "    steps:\n"
        "    - task: TerraformCLI@1\n"
        "      displayName: Terraform-Init\n"
    )
    pre_apply_check.check_pipelines(str(tmp_path), ["dev"])
    assert any("before Terraform-Init" in m for m in platform_failures("dev"))
