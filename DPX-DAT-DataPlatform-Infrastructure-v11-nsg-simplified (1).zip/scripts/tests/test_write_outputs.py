"""Tests for write_outputs.sh and for publish_outputs.sh, which calls it.

write_outputs.sh writes a root's `terraform output -json` into handoff-outputs/ and
checks it. It never calls the Azure CLI, so the dev platform pipeline can hand the
outputs on as an artifact alone. publish_outputs.sh still uploads for the other
pipelines. Both tools are replaced by stubs on PATH, so no test needs Azure or
Terraform.
"""

import json
import os
import stat
import subprocess
from pathlib import Path

import pytest

SCRIPTS = Path(__file__).resolve().parents[1]
WRITE = SCRIPTS / "write_outputs.sh"
PUBLISH = SCRIPTS / "publish_outputs.sh"
GOOD = {
    "environment": {"value": "dev"},
    "workspaces": {"value": {"anl": {}}},
    "unity_catalog_storage": {"value": {"grp": {}}},
}
TERRAFORM = """#!/usr/bin/env bash
if [ "$*" = "-chdir=$FAKE_TF_DIR output -json" ]; then
  printf '%s' "$FAKE_TF_OUTPUT"
  exit 0
fi
exit 1
"""
AZ = """#!/usr/bin/env bash
printf '%s\\n' "$*" >> "$AZ_CALLS"
exit 0
"""


@pytest.fixture
def run(tmp_path):
    bindir = tmp_path / "bin"
    bindir.mkdir()
    for name, body in (("terraform", TERRAFORM), ("az", AZ)):
        tool = bindir / name
        tool.write_text(body)
        tool.chmod(tool.stat().st_mode | stat.S_IEXEC)

    def go(script, output, **env):
        base = {
            "ENVIRONMENT": "dev",
            "TF_WORKING_DIR": "infra/20-platform-services",
            "FILE_PREFIX": "platform",
            "REQUIRED_OUTPUTS": "workspaces unity_catalog_storage",
            "ENVIRONMENT_OUTPUT_CHECK": "true",
            "FAKE_TF_DIR": "infra/20-platform-services",
            "FAKE_TF_OUTPUT": json.dumps(output),
            "AZ_CALLS": str(tmp_path / "az-calls.txt"),
        }
        return subprocess.run(
            ["bash", str(script)],
            cwd=tmp_path,
            capture_output=True,
            text=True,
            env={**os.environ, "PATH": f"{bindir}:{os.environ['PATH']}", **base, **env},
        )

    return go, tmp_path


def test_writes_the_outputs_into_handoff_outputs(run):
    go, tmp = run
    result = go(WRITE, GOOD)
    assert result.returncode == 0, result.stderr
    written = json.loads((tmp / "handoff-outputs" / "platform-dev.json").read_text())
    assert written == GOOD
    assert "Wrote handoff-outputs/platform-dev.json" in result.stdout


def test_never_calls_the_azure_cli(run):
    go, tmp = run
    assert go(WRITE, GOOD).returncode == 0
    assert not (tmp / "az-calls.txt").exists()


def test_empty_output_fails(run):
    go, _ = run
    result = go(WRITE, {})
    assert result.returncode != 0
    assert "empty" in result.stderr


def test_wrong_environment_fails(run):
    go, _ = run
    result = go(WRITE, {**GOOD, "environment": {"value": "tst"}})
    assert result.returncode != 0
    assert "'tst'" in result.stderr and "'dev'" in result.stderr


def test_missing_required_output_fails(run):
    go, _ = run
    result = go(WRITE, {**GOOD, "workspaces": {"value": {}}})
    assert result.returncode != 0
    assert "'workspaces'" in result.stderr


def test_a_failing_terraform_fails_and_leaves_no_usable_outputs(run):
    go, tmp = run
    result = go(WRITE, GOOD, FAKE_TF_DIR="somewhere/else")
    assert result.returncode != 0
    written = tmp / "handoff-outputs" / "platform-dev.json"
    assert not written.exists() or written.read_text() == ""
    assert "Wrote" not in result.stdout


def test_publish_writes_the_outputs_and_uploads_nothing(run):
    go, tmp = run
    result = go(PUBLISH, GOOD, STATE_STORAGE_ACCOUNT="acct", OUTPUTS_CONTAINER="outputs")
    assert result.returncode == 0, result.stderr
    assert json.loads((tmp / "handoff-outputs" / "platform-dev.json").read_text()) == GOOD
    assert not (tmp / "az-calls.txt").exists()
