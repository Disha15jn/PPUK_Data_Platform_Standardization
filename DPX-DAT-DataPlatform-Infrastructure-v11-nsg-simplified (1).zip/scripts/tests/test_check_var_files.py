"""Tests for check_var_files.py.

Each check is proven to fail on the input it exists to catch, and to pass on a
clean one. Files are written into tmp_path, so no test fixture is ever tracked.
"""

import subprocess
import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import check_var_files  # noqa: E402

CONTRACT = """\
roots:
  infra/20-platform-services:
    upstream:
      network: network and security state
      entities: config/entities.yaml
    identifiers:
      subscription_id: environment
      tenant_id: tier
  databricks:
    upstream:
      workspace_id: 20-platform-services output
    identifiers:
      databricks_account_id: tier
"""

CLEAN_VARS = """\
environment = "dev"
location    = "germanywestcentral"

common_tags = {
  Project = "data-platform"
}
"""


def write(base: Path, relative: str, content: str) -> Path:
    path = base / relative
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(content)
    return path


@pytest.fixture
def tree(tmp_path: Path) -> Path:
    write(tmp_path, "config/upstream-contract.yaml", CONTRACT)
    return tmp_path


def run_checks(tree: Path, *relative: str) -> list[str]:
    contract = check_var_files.load_contract(tree / "config/upstream-contract.yaml")
    return check_var_files.check_files(tree, [tree / r for r in relative], contract)


def test_clean_var_file_passes(tree: Path) -> None:
    write(tree, "infra/20-platform-services/environments/dev.tfvars", CLEAN_VARS)

    assert run_checks(tree, "infra/20-platform-services/environments/dev.tfvars") == []


def test_guid_in_var_file_is_rejected_without_printing_it(tree: Path) -> None:
    guid = "0f1e2d3c-4b5a-6978-8a9b-0c1d2e3f4a5b"
    write(
        tree,
        "databricks/environments/dev-anl.tfvars",
        f'environment = "dev"\nnote = "{guid}"\n',
    )

    errors = run_checks(tree, "databricks/environments/dev-anl.tfvars")

    assert errors == ["databricks/environments/dev-anl.tfvars:2: a GUID-shaped value; identifiers never go in var files"]
    assert guid not in "".join(errors)


def test_backend_file_is_rejected(tree: Path) -> None:
    write(tree, "databricks/environments/dev-anl.tfbackend", 'key = "dev-anl.tfstate"\n')

    errors = run_checks(tree, "databricks/environments/dev-anl.tfbackend")

    assert errors == ["databricks/environments/dev-anl.tfbackend: backend files are never tracked; track a .tfbackend.template instead"]


def test_backend_template_is_allowed(tree: Path) -> None:
    write(tree, "databricks/environments/dev-anl.tfbackend.template", 'key = "dev-anl.tfstate"\n')

    assert run_checks(tree, "databricks/environments/dev-anl.tfbackend.template") == []


def test_upstream_variable_in_var_file_is_rejected(tree: Path) -> None:
    write(
        tree,
        "infra/20-platform-services/environments/dev.tfvars",
        CLEAN_VARS + '\nnetwork = {\n  virtual_network_id = "x"\n}\n',
    )

    errors = run_checks(tree, "infra/20-platform-services/environments/dev.tfvars")

    assert errors == [
        "infra/20-platform-services/environments/dev.tfvars:8: sets upstream variable 'network'; "
        "upstream values come only from upstream.tfvars.json"
    ]


def test_identifier_variable_in_var_file_is_rejected(tree: Path) -> None:
    write(
        tree,
        "databricks/environments/common-anl.tfvars",
        'workspace_type = "analytical"\ndatabricks_account_id = "placeholder"\n',
    )

    errors = run_checks(tree, "databricks/environments/common-anl.tfvars")

    assert errors == [
        "databricks/environments/common-anl.tfvars:2: sets identifier variable 'databricks_account_id'; "
        "identifiers come from the pipeline's variable groups, this one from the tier's"
    ]


def test_a_subscription_in_a_var_file_is_sent_to_the_environment_s_group(tree: Path) -> None:
    write(tree, "infra/20-platform-services/environments/dev.tfvars", CLEAN_VARS + 'subscription_id = "placeholder"\n')

    errors = run_checks(tree, "infra/20-platform-services/environments/dev.tfvars")

    assert errors == [
        "infra/20-platform-services/environments/dev.tfvars:7: sets identifier variable 'subscription_id'; "
        "identifiers come from the pipeline's variable groups, this one from the environment's"
    ]


def test_the_contract_sets_the_subscription_per_environment() -> None:
    contract = check_var_files.load_contract(Path(__file__).resolve().parents[2] / "config/upstream-contract.yaml")

    assert contract["infra/20-platform-services"].identifiers["subscription_id"] == "environment"


@pytest.mark.parametrize(
    "identifiers",
    ["      - subscription_id\n", "      subscription_id: region\n"],
    ids=["no scope", "unknown scope"],
)
def test_an_identifier_needs_an_environment_or_tier_scope(tmp_path: Path, identifiers: str) -> None:
    write(
        tmp_path,
        "config/upstream-contract.yaml",
        "roots:\n  infra/20-platform-services:\n    upstream: {}\n    identifiers:\n" + identifiers,
    )

    with pytest.raises(check_var_files.ContractError, match=r"infra/20-platform-services.*environment or tier"):
        check_var_files.load_contract(tmp_path / "config/upstream-contract.yaml")


def test_main_reports_a_bad_contract(tmp_path: Path, capsys: pytest.CaptureFixture[str]) -> None:
    write(
        tmp_path,
        "config/upstream-contract.yaml",
        "roots:\n  databricks:\n    identifiers:\n      databricks_account_id: account\n",
    )

    assert check_var_files.main(["--root", str(tmp_path), str(tmp_path / "config/upstream-contract.yaml")]) == 1
    assert "config/upstream-contract.yaml" in capsys.readouterr().out


def test_nested_key_with_an_upstream_name_is_not_an_assignment(tree: Path) -> None:
    write(
        tree,
        "databricks/environments/dev-anl.tfvars",
        'warehouses = {\n  workspace_id = "not the upstream variable"\n}\n',
    )

    assert run_checks(tree, "databricks/environments/dev-anl.tfvars") == []


def test_var_file_rules_apply_only_to_environments(tree: Path) -> None:
    write(tree, "databricks/tests/fixtures/example.tfvars", 'workspace_id = "123"\n')

    assert run_checks(tree, "databricks/tests/fixtures/example.tfvars") == []


def test_var_file_in_an_unknown_root_is_rejected(tree: Path) -> None:
    write(tree, "infra/99-unknown/environments/dev.tfvars", CLEAN_VARS)

    errors = run_checks(tree, "infra/99-unknown/environments/dev.tfvars")

    assert errors == ["infra/99-unknown/environments/dev.tfvars: var file outside a root named in config/upstream-contract.yaml"]


def test_discovery_finds_tracked_and_new_files_but_not_ignored_ones(tree: Path) -> None:
    subprocess.run(["git", "init", "-q", str(tree)], check=True)
    write(tree, ".gitignore", "*.tfbackend\n")
    write(tree, "databricks/environments/local.tfbackend", "ignored locally\n")
    new = write(tree, "databricks/environments/dev-anl.tfvars", CLEAN_VARS)

    found = check_var_files.discover(tree)

    assert new in found
    assert tree / "databricks/environments/local.tfbackend" not in found


def test_main_exits_non_zero_on_any_error(tree: Path, capsys: pytest.CaptureFixture[str]) -> None:
    write(tree, "databricks/environments/dev-anl.tfbackend", "x\n")

    code = check_var_files.main(["--root", str(tree), str(tree / "databricks/environments/dev-anl.tfbackend")])

    assert code == 1
    assert "backend files are never tracked" in capsys.readouterr().out


def test_main_exits_zero_when_clean(tree: Path) -> None:
    write(tree, "databricks/environments/dev-anl.tfvars", CLEAN_VARS)

    assert check_var_files.main(["--root", str(tree), str(tree / "databricks/environments/dev-anl.tfvars")]) == 0
