"""Tests for output_mapping.py, which reads published outputs through a mapping.

Published outputs are written in `terraform output -json` form. Every value here
is invented.
"""

import sys
from pathlib import Path

import pytest
import yaml

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import output_mapping  # noqa: E402
import resolve_upstream  # noqa: E402

CONFIG = Path(__file__).resolve().parents[2] / "config"
SOURCE = Path("network-dev.json")


def outputs(values: dict) -> dict:
    """Shape plain values as `terraform output -json` does."""
    return {name: {"sensitive": False, "type": "dynamic", "value": value} for name, value in values.items()}


def write_mapping(tmp_path: Path, network: object, placeholders: dict | None = None) -> Path:
    path = tmp_path / "landing-zone-outputs.yaml"
    data = {"environment": "environment", "placeholders": placeholders or {"workspace": ["anl", "ops"]}, "network": network}
    path.write_text(yaml.safe_dump(data))
    return path


def resolve(tmp_path: Path, network: object, published: dict, placeholders: dict | None = None) -> dict:
    mapping = output_mapping.load(write_mapping(tmp_path, network, placeholders))
    return output_mapping.resolve(mapping, outputs(published), SOURCE)


# --- the committed mapping ---------------------------------------------------


def test_the_committed_mapping_loads() -> None:
    output_mapping.load(CONFIG / "landing-zone-outputs.yaml")


def test_the_mapping_repeats_over_every_track() -> None:
    mapping = output_mapping.load(CONFIG / "landing-zone-outputs.yaml")

    assert mapping.placeholders["workspace"] == resolve_upstream.TRACKS


# --- reading values ----------------------------------------------------------


def test_a_path_of_one_segment_reads_a_whole_output(tmp_path: Path) -> None:
    assert resolve(tmp_path, {"vnet": "virtual_network_id"}, {"virtual_network_id": "v1"}) == {"vnet": "v1"}


def test_a_path_reads_keys_inside_an_outputs_value(tmp_path: Path) -> None:
    published = {"network": {"vnet": {"id": "v1"}}}

    assert resolve(tmp_path, {"vnet": "network/vnet/id"}, published) == {"vnet": "v1"}


def test_a_placeholder_key_repeats_its_entry_for_every_value(tmp_path: Path) -> None:
    network = {"subnets": {"{workspace}": {"id": "net/subnets/{workspace}"}}}
    published = {"net": {"subnets": {"anl": "a", "ops": "o"}}}

    assert resolve(tmp_path, network, published) == {"subnets": {"anl": {"id": "a"}, "ops": {"id": "o"}}}


def test_a_key_with_dots_is_one_segment(tmp_path: Path) -> None:
    zone = "privatelink.blob.core.windows.net"
    network = {"zones": {"{zone}": "net/zones/{zone}"}}

    resolved = resolve(tmp_path, network, {"net": {"zones": {zone: "z"}}}, {"zone": [zone]})

    assert resolved == {"zones": {zone: "z"}}


def test_values_the_mapping_does_not_name_are_ignored(tmp_path: Path) -> None:
    network = {"subnets": {"{workspace}": "net/subnets/{workspace}"}}
    published = {"net": {"subnets": {"anl": "a", "ops": "o", "extra": "x"}}, "unrelated": "u"}

    assert resolve(tmp_path, network, published) == {"subnets": {"anl": "a", "ops": "o"}}


# --- loud failures -----------------------------------------------------------


def test_a_missing_output_fails_naming_path_file_and_attribute(tmp_path: Path) -> None:
    with pytest.raises(
        output_mapping.MappingError,
        match=r"^upstream output 'net/vnet' is missing from network-dev\.json, wanted for network\.vnet$",
    ):
        resolve(tmp_path, {"vnet": "net/vnet"}, {})


def test_a_missing_workspace_fails_naming_where_it_stopped(tmp_path: Path) -> None:
    network = {"subnets": {"{workspace}": "net/subnets/{workspace}"}}

    with pytest.raises(
        output_mapping.MappingError,
        match=r"'net/subnets/ops' is missing from network-dev\.json \(no 'ops' under 'net/subnets'\), wanted for network\.subnets\.ops$",
    ):
        resolve(tmp_path, network, {"net": {"subnets": {"anl": "a"}}})


@pytest.mark.parametrize(("value", "kind"), [("v1", "str"), (None, "null"), (["a"], "list")])
def test_reading_through_a_value_that_is_not_an_object_fails(tmp_path: Path, value: object, kind: str) -> None:
    with pytest.raises(
        output_mapping.MappingError,
        match=rf"'net/vnet/id' cannot be read from network-dev\.json: 'net/vnet' is a {kind}, not an object",
    ):
        resolve(tmp_path, {"vnet": "net/vnet/id"}, {"net": {"vnet": value}})


@pytest.mark.parametrize("empty", [None, "", {}, []])
def test_a_null_or_empty_value_fails(tmp_path: Path, empty: object) -> None:
    with pytest.raises(
        output_mapping.MappingError, match=r"'net/vnet' is (null|empty) in network-dev\.json, wanted for network\.vnet$"
    ):
        resolve(tmp_path, {"vnet": "net/vnet"}, {"net": {"vnet": empty}})


# --- the mapping file itself -------------------------------------------------


def test_a_missing_mapping_file_fails(tmp_path: Path) -> None:
    with pytest.raises(output_mapping.MappingError, match=r"landing-zone-outputs\.yaml is missing"):
        output_mapping.load(tmp_path / "landing-zone-outputs.yaml")


def test_an_unquoted_placeholder_key_fails_with_advice(tmp_path: Path) -> None:
    path = tmp_path / "landing-zone-outputs.yaml"
    path.write_text("placeholders:\n  workspace: [anl]\nnetwork:\n  subnets:\n    {workspace}: net/subnets/{workspace}\n")

    with pytest.raises(output_mapping.MappingError, match=r'not valid YAML .*quote keys such as "\{workspace\}"'):
        output_mapping.load(path)


def test_the_mapping_needs_exactly_its_keys(tmp_path: Path) -> None:
    path = tmp_path / "landing-zone-outputs.yaml"
    path.write_text(yaml.safe_dump({"network": {"vnet": "net/vnet"}}))

    with pytest.raises(output_mapping.MappingError, match=r"needs exactly the keys environment, network, placeholders$"):
        output_mapping.load(path)


def test_a_placeholder_needs_a_list_of_names(tmp_path: Path) -> None:
    with pytest.raises(output_mapping.MappingError, match="each placeholder needs a non-empty list of names"):
        output_mapping.load(write_mapping(tmp_path, {"vnet": "net/vnet"}, {"workspace": []}))


def test_an_undeclared_placeholder_fails(tmp_path: Path) -> None:
    with pytest.raises(output_mapping.MappingError, match=r"network\.subnets: unknown placeholder 'tier'$"):
        output_mapping.load(write_mapping(tmp_path, {"subnets": {"{tier}": "net/{tier}"}}))


def test_a_placeholder_used_outside_its_key_fails(tmp_path: Path) -> None:
    with pytest.raises(output_mapping.MappingError, match=r"network\.vnet: '\{workspace\}' used outside a \"\{workspace\}\" key"):
        output_mapping.load(write_mapping(tmp_path, {"vnet": "net/{workspace}"}))


def test_a_placeholder_key_beside_other_keys_fails(tmp_path: Path) -> None:
    network = {"subnets": {"{workspace}": "net/{workspace}", "shared": "net/shared"}}

    with pytest.raises(output_mapping.MappingError, match=r"network\.subnets: a \"\{workspace\}\" key must be the only key at its level"):
        output_mapping.load(write_mapping(tmp_path, network))


def test_a_key_that_is_not_text_fails(tmp_path: Path) -> None:
    # YAML reads an unquoted `on` as true.
    path = tmp_path / "landing-zone-outputs.yaml"
    path.write_text("environment: environment\nplaceholders:\n  workspace: [anl]\nnetwork:\n  on: net/vnet\n")

    with pytest.raises(output_mapping.MappingError, match=r"network: key True must be text; quote it"):
        output_mapping.load(path)


@pytest.mark.parametrize("leaf", [None, 1, "", "net//vnet", ["net/vnet"], {}])
def test_a_leaf_that_is_not_a_path_fails(tmp_path: Path, leaf: object) -> None:
    with pytest.raises(output_mapping.MappingError, match=r"network\.vnet must be a path such as 'network/virtual_network_id'"):
        output_mapping.load(write_mapping(tmp_path, {"vnet": leaf}))


def test_the_environment_is_read_from_its_path(tmp_path: Path) -> None:
    path = write_mapping(tmp_path, {"vnet": "net/vnet"})
    data = yaml.safe_load(path.read_text())
    data["environment"] = "net/published_by"
    path.write_text(yaml.safe_dump(data))
    mapping = output_mapping.load(path)

    published = outputs({"net": {"published_by": "dev"}})

    assert output_mapping.published_environment(mapping, published, SOURCE) == "dev"


@pytest.mark.parametrize("environment", [None, "", {"a": "b"}, "net/{workspace}"])
def test_the_environment_must_be_a_plain_path(tmp_path: Path, environment: object) -> None:
    path = write_mapping(tmp_path, {"vnet": "net/vnet"})
    data = yaml.safe_load(path.read_text())
    data["environment"] = environment
    path.write_text(yaml.safe_dump(data))

    with pytest.raises(output_mapping.MappingError, match=r"environment must be a path with no placeholder"):
        output_mapping.load(path)
