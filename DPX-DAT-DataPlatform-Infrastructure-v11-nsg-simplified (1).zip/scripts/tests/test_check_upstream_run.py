"""Tests for check_upstream_run.py.

The script fails unless the outputs a pipeline downloaded came from the newest
completed run of the upstream pipeline on a branch, and fails while a run is
queued or in progress. Each rule is proven on the run list it exists to catch.
The Azure DevOps API is replaced by a fake that records the request, so no
test needs a network or a token.
"""

import io
import json
import sys
import urllib.error
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import check_upstream_run  # noqa: E402
from check_upstream_run import UpstreamRunError, check, fetch_runs, main  # noqa: E402

ARGS = ["--definition-id", "2267", "--branch", "refs/heads/main", "--source-run-id", "108364"]
LATEST_AVAILABLE = ["--mode", "latest-available"]


def run(run_id, status="completed", result="succeeded", sha="a" * 40, finish="2026-10-22T06:06:19Z"):
    return {
        "id": run_id,
        "status": status,
        "result": result,
        "sourceBranch": "refs/heads/main",
        "sourceVersion": sha,
        "finishTime": finish,
    }


class FakeResponse(io.BytesIO):
    def __enter__(self):
        return self

    def __exit__(self, *exc):
        return False


def fake_opener(runs, seen=None):
    def opener(request, **_kwargs):
        if seen is not None:
            seen.append(request)
        return FakeResponse(json.dumps({"value": runs}).encode())

    return opener


def environment(monkeypatch, token="t0ken"):
    monkeypatch.setenv("SYSTEM_COLLECTIONURI", "https://dev.azure.com/example-org/")
    monkeypatch.setenv("SYSTEM_TEAMPROJECT", "Example Project")
    if token is None:
        monkeypatch.delenv("SYSTEM_ACCESSTOKEN", raising=False)
    else:
        monkeypatch.setenv("SYSTEM_ACCESSTOKEN", token)


def test_newest_completed_run_passes_and_says_where_it_came_from():
    line = check(108364, [run(108364, result="failed", sha="1e4a4cb2d0" + "0" * 30), run(108311)])
    assert "108364" in line and "1e4a4cb" in line and "failed" in line


def test_newest_run_without_the_file_fails():
    with pytest.raises(UpstreamRunError, match="108400"):
        check(108364, [run(108400, result="failed"), run(108364)])


def test_active_run_fails():
    with pytest.raises(UpstreamRunError, match="inProgress"):
        check(108364, [run(108401, status="inProgress", result=None), run(108364)])


def test_cancelled_newest_run_fails():
    with pytest.raises(UpstreamRunError, match="canceled"):
        check(108364, [run(108400, result="canceled"), run(108364)])


def test_no_completed_runs_fails():
    with pytest.raises(UpstreamRunError, match="read"):
        check(108364, [])


def test_fetch_runs_asks_for_this_pipeline_and_branch():
    seen = []
    runs = fetch_runs(
        "https://dev.azure.com/example-org/",
        "Example Project",
        2267,
        "refs/heads/main",
        "t0ken",
        opener=fake_opener([run(1)], seen),
    )
    assert runs == [run(1)]
    (request,) = seen
    assert request.full_url.startswith("https://dev.azure.com/example-org/Example%20Project/_apis/build/builds?")
    for part in ("definitions=2267", "branchName=refs%2Fheads%2Fmain", "statusFilter=all", "api-version=7.1"):
        assert part in request.full_url
    assert request.get_header("Authorization") == "Bearer t0ken"


def test_main_passes_and_prints_provenance(monkeypatch, capsys):
    environment(monkeypatch)
    monkeypatch.setattr(check_upstream_run.urllib.request, "urlopen", fake_opener([run(108364), run(108311)]))
    assert main(ARGS) == 0
    assert "Using run 108364" in capsys.readouterr().out


def test_main_fails_closed_when_the_source_is_not_the_newest(monkeypatch, capsys):
    environment(monkeypatch)
    monkeypatch.setattr(check_upstream_run.urllib.request, "urlopen", fake_opener([run(108400), run(108364)]))
    assert main(ARGS) == 1
    assert "##vso[task.logissue type=error]" in capsys.readouterr().out


def test_http_error_names_the_permission(monkeypatch, capsys):
    environment(monkeypatch)

    def refuse(request, **_kwargs):
        raise urllib.error.HTTPError(request.full_url, 403, "Forbidden", {}, None)

    monkeypatch.setattr(check_upstream_run.urllib.request, "urlopen", refuse)
    assert main(ARGS) == 2
    out = capsys.readouterr().out
    assert "##vso[task.logissue type=error]" in out and "403" in out and "2267" in out


def test_unexpanded_run_id_is_rejected(monkeypatch, capsys):
    environment(monkeypatch)
    args = ARGS[:-1] + ["$(OutputsRunId)"]
    assert main(args) == 2
    out = capsys.readouterr().out
    assert "##vso[task.logissue type=error]" in out and "OutputsRunId" in out


def test_missing_token_is_rejected(monkeypatch, capsys):
    environment(monkeypatch, token=None)
    assert main(ARGS) == 2
    assert "System.AccessToken" in capsys.readouterr().out


def test_latest_available_accepts_a_run_that_is_not_the_newest_and_says_so():
    runs = [run(108457), run(108434), run(108364, sha="1e4a4cb2d0" + "0" * 30)]
    line = check(108364, runs, allow_older=True)
    assert "Using run 108364" in line and "1e4a4cb" in line
    assert "2 newer" in line and "108457" in line


def test_latest_available_accepts_a_run_while_another_is_active():
    line = check(108364, [run(108401, status="inProgress", result=None), run(108364)], allow_older=True)
    assert "Using run 108364" in line


def test_latest_available_still_needs_the_run_to_be_a_completed_one():
    with pytest.raises(UpstreamRunError, match="108364"):
        check(108364, [run(108400)], allow_older=True)


def test_latest_available_says_nothing_extra_for_the_newest_run():
    line = check(108364, [run(108364), run(108311)], allow_older=True)
    assert "newer" not in line


def test_main_latest_available_passes_for_an_older_run(monkeypatch, capsys):
    environment(monkeypatch)
    monkeypatch.setattr(check_upstream_run.urllib.request, "urlopen", fake_opener([run(108400), run(108364)]))
    assert main([*ARGS, *LATEST_AVAILABLE]) == 0
    assert "Using run 108364" in capsys.readouterr().out


def test_main_defaults_to_the_newest_run_rule(monkeypatch):
    environment(monkeypatch)
    monkeypatch.setattr(check_upstream_run.urllib.request, "urlopen", fake_opener([run(108400), run(108364)]))
    assert main(ARGS) == 1


def test_main_rejects_an_unexpanded_mode():
    with pytest.raises(SystemExit):
        main([*ARGS, "--mode", "${{ parameters.networkOutputs }}"])
