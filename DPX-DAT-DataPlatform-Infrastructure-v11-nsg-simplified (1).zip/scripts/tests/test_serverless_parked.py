"""Serverless compute is parked.

Doubtless infrastructure security have not yet approved serverless compute:
even behind private endpoints it runs, and processes our data, on
Databricks-managed infrastructure. Until they do, the Databricks root declares
nothing that sets serverless compute up or runs on it. The code is commented
out, not deleted; when serverless is approved, restore it and retire this test
in the same change.
"""

import re
from pathlib import Path

import pytest

DATABRICKS = Path(__file__).resolve().parents[2] / "databricks"

# Resource and data source types that exist only for serverless compute.
PARKED_TYPES = [
    "databricks_mws_network_connectivity_config",
    "databricks_mws_ncc_binding",
    "databricks_mws_ncc_private_endpoint_rule",
    "databricks_budget_policy",
]

# A parked line starts with '#', so it never matches.
BLOCK = re.compile(r'^(?:resource|data)\s+"(?P<type>\w+)"', re.MULTILINE)


def configuration() -> dict[str, str]:
    return {path.name: path.read_text() for path in sorted(DATABRICKS.glob("*.tf"))}


@pytest.mark.parametrize("block_type", PARKED_TYPES)
def test_declares_no_serverless_object(block_type: str) -> None:
    declared = {match["type"] for text in configuration().values() for match in BLOCK.finditer(text)}

    assert block_type not in declared


SERVERLESS_WAREHOUSE = re.compile(r"^\s*enable_serverless_compute\s*=\s*true\b", re.MULTILINE)


def test_builds_no_serverless_warehouse() -> None:
    assert [name for name, text in configuration().items() if SERVERLESS_WAREHOUSE.search(text)] == []


# A warehouse that omits the flag can default to serverless on some workspaces,
# so each live warehouse must say false outright.
WAREHOUSE_BLOCK = re.compile(r'^resource\s+"databricks_sql_endpoint"\s+"(?P<name>\w+)"\s*\{\n(?P<body>.*?)^\}', re.MULTILINE | re.DOTALL)
EXPLICITLY_CLASSIC = re.compile(r"^\s*enable_serverless_compute\s*=\s*false\b", re.MULTILINE)


def test_every_warehouse_says_classic_outright() -> None:
    warehouses = [
        (name, match["name"], match["body"])
        for name, text in configuration().items()
        for match in WAREHOUSE_BLOCK.finditer(text)
    ]

    assert warehouses, "expected the classic warehouses to be declared"
    assert [(file, name) for file, name, body in warehouses if not EXPLICITLY_CLASSIC.search(body)] == []


# Other routes onto serverless compute: pipelines and similar resources take a
# `serverless` flag.
SERVERLESS_FLAG = re.compile(r"^\s*serverless\s*=\s*true\b", re.MULTILINE)


def test_sets_no_serverless_flag() -> None:
    assert [name for name, text in configuration().items() if SERVERLESS_FLAG.search(text)] == []
