"""The dev platform pipeline.

pipelines/20-Platform.dev.yml plans infra/20-platform-services and, on a manual
run from main, applies the saved plan behind the dev deployment environment. It
takes the landing zone's network outputs from the handoff-outputs artifact of
the landing-zone pipeline, through a run-time parameter that says which run:
newest-run (the default, strict) or latest-available (the newest run that
published them, for use while the landing zone is not yet applying cleanly).
These tests hold the shape of that pipeline: what runs in what order, that a
failed plan can never be applied, and that the outputs are written, checked and
saved as an artifact, never uploaded to the outputs container.
"""

from pathlib import Path

import pytest
import yaml

REPO = Path(__file__).resolve().parents[2]
PIPELINE = REPO / "pipelines" / "20-Platform.dev.yml"
MODE = "--mode ${{ parameters.networkOutputs }}"
SCAN_CONDITION = (
    "and(succeeded(), eq(dependencies.Build.outputs['TerraformPlan.tfPlanResult.changeDetected'], 'true'), "
    "eq('${{ parameters.runCheckov }}', 'true'))"
)
APPLY_CONDITION = (
    "and(succeeded('Build'), in(dependencies.Scan.result, 'Succeeded', 'SucceededWithIssues', 'Skipped'), "
    "eq(variables['Build.Reason'], 'Manual'), eq(variables['Build.SourceBranch'], 'refs/heads/main'))"
)
PUBLISH_PLAN_TASKS = {"PublishPipelineArtifact@1", "ecdc45f6-832d-4ad9-b52b-ee49e94659be@1"}


@pytest.fixture(scope="module")
def pipeline():
    return yaml.safe_load(PIPELINE.read_text())


def stage(doc, name):
    return next(item for item in doc["stages"] if item["stage"] == name)


def build_steps(doc):
    (job,) = stage(doc, "Build")["jobs"]
    return job["steps"]


def apply_steps(doc):
    (job,) = stage(doc, "Apply")["jobs"]
    return job["strategy"]["runOnce"]["deploy"]["steps"]


def script_step(steps, needle):
    return next(step for step in steps if needle in step.get("inputs", {}).get("script", ""))


def task_step(steps, task, **inputs):
    return next(
        step
        for step in steps
        if step.get("task") == task and all(step["inputs"].get(k) == v for k, v in inputs.items())
    )


def variable(doc, name):
    return next(entry["value"] for entry in doc["variables"] if entry.get("name") == name)


def test_network_outputs_default_to_the_strict_rule(pipeline):
    (parameter,) = [item for item in pipeline["parameters"] if item["name"] == "networkOutputs"]
    assert parameter["type"] == "string"
    assert parameter["default"] == "newest-run"
    assert parameter["values"] == ["newest-run", "latest-available"]


def test_both_scripts_get_the_chosen_mode(pipeline):
    steps = build_steps(pipeline)
    picker = script_step(steps, "scripts/select_outputs_run.py")
    checker = script_step(steps, "scripts/check_upstream_run.py")
    for step in (picker, checker):
        assert MODE in step["inputs"]["script"]
        assert step["env"]["SYSTEM_ACCESSTOKEN"] == "$(System.AccessToken)"
    assert "--source-run-id $(OutputsRunId)" in checker["inputs"]["script"]
    assert "--artifact-name handoff-outputs" in picker["inputs"]["script"]


def test_build_order(pipeline):
    steps = build_steps(pipeline)
    chosen = [
        script_step(steps, "scripts/select_outputs_run.py"),
        task_step(steps, "DownloadPipelineArtifact@2"),
        script_step(steps, "scripts/check_upstream_run.py"),
        script_step(steps, "scripts/resolve_upstream.py"),
        task_step(steps, "TerraformCLI@1", command="init"),
        task_step(steps, "TerraformCLI@1", command="validate"),
        task_step(steps, "TerraformCLI@1", command="plan"),
        next(
            step
            for step in steps
            if step.get("task") in PUBLISH_PLAN_TASKS and "tfplan" in str(step["inputs"])
        ),
    ]
    positions = [steps.index(step) for step in chosen]
    assert positions == sorted(positions)


def test_reads_no_storage_for_the_network():
    text = PIPELINE.read_text()
    for forbidden in ("fetch_network_outputs.sh", "fetch_upstream.sh"):
        assert forbidden not in text, forbidden


def test_download_is_exactly_the_chosen_run(pipeline):
    step = task_step(build_steps(pipeline), "DownloadPipelineArtifact@2")
    assert step["inputs"] == {
        "buildType": "specific",
        "project": "$(System.TeamProject)",
        "definition": "$(LandingZonePipelineId)",
        "buildVersionToDownload": "specific",
        "pipelineId": "$(OutputsRunId)",
        "allowPartiallySucceededBuilds": True,
        "allowFailedBuilds": True,
        "artifactName": "handoff-outputs",
        "targetPath": "$(Agent.TempDirectory)/handoff",
    }


def test_the_landing_zone_pipeline_is_defined_once(pipeline):
    assert variable(pipeline, "LandingZonePipelineId") == "2267"


def test_resolves_the_downloaded_file_into_the_upstream_tfvars(pipeline):
    step = script_step(build_steps(pipeline), "scripts/resolve_upstream.py")
    assert step["env"]["NETWORK_OUTPUTS"] == "$(Agent.TempDirectory)/handoff/network-dev.json"
    assert step["env"]["UPSTREAM_TFVARS"].endswith("$(TerraformWorkingDirectory)/upstream.tfvars.json")
    plan = task_step(build_steps(pipeline), "TerraformCLI@1", command="plan")
    assert plan["inputs"]["commandOptions"].endswith("--var-file=upstream.tfvars.json")


def test_a_failed_plan_stops_the_apply(pipeline):
    apply = stage(pipeline, "Apply")
    assert apply["dependsOn"] == ["Build", "Scan"]
    assert apply["condition"] == APPLY_CONDITION


def test_apply_applies_the_saved_plan_behind_the_environment(pipeline):
    (job,) = stage(pipeline, "Apply")["jobs"]
    assert job["environment"]["name"] == "$(PipelineEnvironment)"
    assert variable(pipeline, "PipelineEnvironment") == "dpx-dat-dev_deployment"
    steps = apply_steps(pipeline)
    assert task_step(steps, "DownloadPipelineArtifact@2")["inputs"]["artifact"] == "tfplan"
    apply = task_step(steps, "TerraformCLI@1", command="apply")
    assert apply["inputs"]["commandOptions"] == "$(Build.BuildId).tfplan"


def test_uploads_nothing_to_the_outputs_container(pipeline):
    text = PIPELINE.read_text()
    for forbidden in ("publish_outputs.sh", "OUTPUTS_CONTAINER", "storage blob upload"):
        assert forbidden not in text, forbidden


def test_writes_and_checks_the_outputs_after_the_apply(pipeline):
    steps = apply_steps(pipeline)
    write = next(
        step for step in steps if str(step.get("inputs", {}).get("scriptPath", "")).endswith("/pattern/scripts/write_outputs.sh")
    )
    assert write["task"] == "AzureCLI@2"
    assert write["inputs"]["azureSubscription"] == "$(EnvironmentServiceConnection)"
    assert write["env"] == {
        "ENVIRONMENT": "dev",
        "TF_WORKING_DIR": "infra/20-platform-services",
        "FILE_PREFIX": "platform",
        "REQUIRED_OUTPUTS": "workspaces unity_catalog_storage",
        "ENVIRONMENT_OUTPUT_CHECK": "true",
        "ARM_USE_CLI": "true",
        "ARM_USE_AZUREAD": "true",
    }
    assert "continueOnError" not in write and "condition" not in write
    assert steps.index(write) > steps.index(task_step(steps, "TerraformCLI@1", command="apply"))


def test_saves_the_outputs_as_the_handoff_artifact(pipeline):
    steps = apply_steps(pipeline)
    artifact = task_step(steps, "PublishPipelineArtifact@1", artifact="handoff-outputs")
    assert artifact["inputs"]["targetPath"] == "$(Pipeline.Workspace)/pattern/handoff-outputs"
    assert "condition" not in artifact and "continueOnError" not in artifact
    write = next(step for step in steps if str(step.get("inputs", {}).get("scriptPath", "")).endswith("write_outputs.sh"))
    assert steps.index(artifact) > steps.index(write)


@pytest.mark.parametrize("where", ["build", "apply"])
def test_installs_unzip_before_terraform_in_both_jobs(pipeline, where):
    steps = build_steps(pipeline) if where == "build" else apply_steps(pipeline)
    installer = task_step(steps, "TerraformInstaller@1")
    unzip = next(
        step for step in steps if step.get("task") == "CmdLine@2" and "unzip" in step["inputs"]["script"]
    )
    assert steps.index(unzip) < steps.index(installer)


def test_state_key_and_identifiers_are_the_real_ones(pipeline):
    assert variable(pipeline, "StateFileName") == "platform-services/dev.tfstate"
    groups = [entry["group"] for entry in pipeline["variables"] if "group" in entry]
    assert groups == ["TF-Backend-GWC", "ADO-SSH", "TF-Identifiers-dev"]


def test_readiness_report_never_fails_the_run(pipeline):
    steps = build_steps(pipeline)
    report = next(
        step for step in steps if "apply_readiness.sh" in str(step.get("inputs", {}).get("scriptPath", ""))
    )
    assert report["task"] == "AzureCLI@2"
    assert report["continueOnError"] is True
    assert report["inputs"]["azureSubscription"] == "$(EnvironmentServiceConnection)"
    assert report["env"]["SUBSCRIPTION_ID"] == "$(subscription_id)"
    assert report["env"]["UPSTREAM_FILE"].endswith("$(TerraformWorkingDirectory)/upstream.tfvars.json")
    assert steps.index(report) > steps.index(task_step(steps, "TerraformCLI@1", command="plan"))
    assert steps.index(report) > steps.index(script_step(steps, "scripts/resolve_upstream.py"))


def test_the_plan_records_which_landing_zone_run_it_used(pipeline):
    steps = build_steps(pipeline)
    record = script_step(steps, "outputs-run.txt")
    assert "$(OutputsRunId)" in record["inputs"]["script"]
    assert "$(Build.ArtifactStagingDirectory)/outputs-run.txt" in record["inputs"]["script"]
    publish = task_step(steps, "PublishPipelineArtifact@1", artifact="outputs-run")
    assert publish["inputs"]["targetPath"] == "$(Build.ArtifactStagingDirectory)/outputs-run.txt"
    assert steps.index(record) < steps.index(publish)
    assert steps.index(record) > steps.index(script_step(steps, "scripts/check_upstream_run.py"))


def test_apply_rechecks_the_landing_zone_run_before_applying(pipeline):
    steps = apply_steps(pipeline)
    plan_download = task_step(steps, "DownloadPipelineArtifact@2", artifact="tfplan")
    run_download = task_step(steps, "DownloadPipelineArtifact@2", artifact="outputs-run")
    recheck = script_step(steps, "scripts/check_upstream_run.py")
    apply = task_step(steps, "TerraformCLI@1", command="apply")
    script = recheck["inputs"]["script"]
    for arg in ("--definition-id $(LandingZonePipelineId)", "--branch refs/heads/main", MODE):
        assert arg in script
    assert recheck["env"]["OUTPUTS_RUN_FILE"] == "$(Pipeline.Workspace)/outputs-run/outputs-run.txt"
    assert 'read -r OUTPUTS_RUN_ID < "$OUTPUTS_RUN_FILE"' in script
    assert '--source-run-id "$OUTPUTS_RUN_ID"' in script
    assert "$(" not in script.replace("$(LandingZonePipelineId)", ""), "no shell substitution Azure DevOps could read as a macro"
    assert recheck["env"]["SYSTEM_ACCESSTOKEN"] == "$(System.AccessToken)"
    positions = [steps.index(step) for step in (plan_download, run_download, recheck, apply)]
    assert positions == sorted(positions)
    assert "continueOnError" not in recheck and "condition" not in recheck


def test_the_scan_runs_when_the_plan_has_changes(pipeline):
    scan = stage(pipeline, "Scan")
    assert scan["condition"] == SCAN_CONDITION
    assert scan["dependsOn"] == ["Build"]


def test_a_failed_or_cancelled_scan_stops_the_apply(pipeline):
    condition = stage(pipeline, "Apply")["condition"]
    allowed = condition.split("dependencies.Scan.result,")[1].split(")")[0]
    assert "Failed" not in allowed and "Canceled" not in allowed


def test_the_scan_installs_unzip_before_terraform(pipeline):
    (job,) = stage(pipeline, "Scan")["jobs"]
    steps = job["steps"]
    installer = task_step(steps, "TerraformInstaller@1")
    unzip = next(
        step for step in steps if step.get("task") == "CmdLine@2" and "unzip" in step["inputs"]["script"]
    )
    assert steps.index(unzip) < steps.index(installer)


def test_the_scan_is_off_until_the_agent_pool_can_install_checkov(pipeline):
    (parameter,) = [item for item in pipeline["parameters"] if item["name"] == "runCheckov"]
    assert parameter["type"] == "boolean" and parameter["default"] is False
