"""check_avm_conformance.py: every Azure resource under infra/ comes from a Verified Module."""
import subprocess
import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import check_avm_conformance as check  # noqa: E402

REPO = Path(__file__).resolve().parents[2]


def make_root(tmp_path, files):
    """A git repository holding the given relative files, so discover() lists them."""
    subprocess.run(["git", "init", "-q"], cwd=tmp_path, check=True)
    for relative, text in files.items():
        path = tmp_path / relative
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(text)
    return tmp_path


ALLOWED_FILE, ALLOWED_ADDRESS = next(iter(check.ALLOWED)).split(":", 1)
ALLOWED_TYPE, ALLOWED_NAME = ALLOWED_ADDRESS.split(".", 1)


def test_the_real_tree_passes():
    assert check.main(["--root", str(REPO)]) == 0


def test_a_plain_resource_under_infra_fails(tmp_path, capsys):
    root = make_root(tmp_path, {"infra/modules/x/main.tf": 'resource "azurerm_storage_container" "this" {\n}\n'})
    assert check.main(["--root", str(root)]) == 1
    assert "infra/modules/x/main.tf:azurerm_storage_container.this" in capsys.readouterr().out


def test_an_azapi_resource_under_infra_fails(tmp_path):
    root = make_root(tmp_path, {"infra/20-platform-services/main.tf": 'resource "azapi_resource" "pe" {}\n'})
    assert check.main(["--root", str(root)]) == 1


def test_a_module_call_and_a_data_source_pass(tmp_path):
    root = make_root(tmp_path, {
        "infra/modules/x/main.tf": 'module "x" {\n  source = "Azure/avm-res-x/azurerm"\n}\n\ndata "azapi_resource" "w" {}\n\nresource "terraform_data" "ready" {}\n',
    })
    assert check.main(["--root", str(root)]) == 0


def test_the_allowlisted_resource_passes(tmp_path):
    root = make_root(tmp_path, {ALLOWED_FILE: f'resource "{ALLOWED_TYPE}" "{ALLOWED_NAME}" {{\n}}\n'})
    assert check.main(["--root", str(root)]) == 0


def test_a_stale_allowlist_entry_fails(tmp_path, capsys):
    root = make_root(tmp_path, {ALLOWED_FILE: 'module "only" {\n  source = "Azure/avm-res-x/azurerm"\n}\n'})
    assert check.main(["--root", str(root)]) == 1
    assert "no such resource exists" in capsys.readouterr().out


def test_an_azure_resource_in_the_databricks_root_fails(tmp_path, capsys):
    root = make_root(tmp_path, {"databricks/extra.tf": 'resource "azurerm_role_assignment" "x" {}\n'})
    assert check.main(["--root", str(root)]) == 1
    assert "creates no Azure resource" in capsys.readouterr().out


def test_files_outside_the_checked_directories_are_ignored(tmp_path):
    root = make_root(tmp_path, {"scripts/example.tf": 'resource "azurerm_thing" "x" {}\n', "infra/x/README.md": 'resource "azurerm_thing" "x" {}\n'})
    assert check.main(["--root", str(root)]) == 0


@pytest.mark.parametrize("line", ['resource "azurerm_private_endpoint" "a" {', '  resource "azapi_resource" "b-2" {'])
def test_the_pattern_reads_a_resource_header(line):
    assert check.find_resources("f.tf", line) == [f"f.tf:{line.split(chr(34))[1]}.{line.split(chr(34))[3]}"]


def test_every_allowlist_entry_carries_a_reason():
    assert all(reason.strip() for reason in check.ALLOWED.values())
