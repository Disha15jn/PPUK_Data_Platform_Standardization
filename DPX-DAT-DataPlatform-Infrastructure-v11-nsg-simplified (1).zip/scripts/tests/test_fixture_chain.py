"""The upstream chain runs end to end on the committed test fixtures.

Each root's unit tests run against an upstream fixture. These tests prove that
each fixture is exactly what the resolve step produces from the upstream root's
published outputs, so the Terraform tests exercise the real contract:

  network outputs  --resolve-->  infra/20-platform-services upstream fixture
  20's outputs     --resolve-->  databricks upstream fixtures
"""

import json
import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import resolve_upstream  # noqa: E402

ROOT = Path(__file__).resolve().parents[2]
CONFIG = ROOT / "config"
PLATFORM = ROOT / "infra/20-platform-services/tests/fixtures"
DATABRICKS = ROOT / "databricks/tests/fixtures"


def load(path: Path) -> dict:
    return json.loads(path.read_text())


@pytest.mark.parametrize("environment", ["dev", "tst", "stg", "prd"])
def test_platform_services_fixture_is_what_the_resolver_writes(environment: str) -> None:
    resolved = resolve_upstream.resolve_platform_services(CONFIG, environment, PLATFORM / f"network-outputs-{environment}.json")

    assert resolved == load(PLATFORM / f"upstream-{environment}.json")


@pytest.mark.parametrize(
    ("instance", "environment", "workspace"),
    [
        ("dev-anl", "dev", "anl"),
        ("dev-ops", "dev", "ops"),
        ("tst-ops", "tst", "ops"),
        ("stg-ops", "stg", "ops"),
        ("prd-anl", "prd", "anl"),
        ("prd-ops", "prd", "ops"),
    ],
)
def test_databricks_fixture_is_what_the_resolver_writes(instance: str, environment: str, workspace: str) -> None:
    resolved = resolve_upstream.resolve_databricks(
        CONFIG, environment, workspace, DATABRICKS / f"platform-outputs-{environment}.json"
    )

    assert resolved == load(DATABRICKS / f"upstream-{instance}.json")
