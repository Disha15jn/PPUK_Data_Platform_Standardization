"""Tests for select_outputs_run.py.

The script chooses which run of the upstream pipeline to download an artifact
from. In "newest-run" mode it takes the newest completed run and fails if that
run published no artifact. In "latest-available" mode it walks back to the
newest completed run that did, and says how many newer runs it passed over. The
Azure DevOps API is replaced by a fake that records each request, so no test
needs a network or a token.
"""

import io
import json
import sys
import urllib.error
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from select_outputs_run import OutputsRunError, has_artifact, main, select  # noqa: E402

ARGS = ["--definition-id", "2267", "--branch", "refs/heads/main", "--artifact-name", "handoff-outputs"]


def run(run_id, status="completed", result="failed", sha="a" * 40, finish="2026-10-22T06:06:19Z"):
    return {
        "id": run_id,
        "status": status,
        "result": result,
        "sourceBranch": "refs/heads/main",
        "sourceVersion": sha,
        "finishTime": finish,
    }


# The run list the 22 October failure left: the newest run published nothing.
RUNS = [run(108457), run(108434), run(108364, sha="1e4a4cb" + "0" * 33), run(108311)]
PUBLISHED = {108364}


def published(run_id):
    return run_id in PUBLISHED


def test_newest_run_mode_takes_the_newest_completed_run_when_it_published():
    chosen, skipped = select("newest-run", RUNS, lambda run_id: run_id == 108457)
    assert chosen["id"] == 108457
    assert skipped == []


def test_newest_run_mode_fails_when_the_newest_run_published_nothing():
    with pytest.raises(OutputsRunError, match="108457") as error:
        select("newest-run", RUNS, published)
    assert "latest-available" in str(error.value)


def test_latest_available_skips_newer_runs_that_published_nothing():
    chosen, skipped = select("latest-available", RUNS, published)
    assert chosen["id"] == 108364
    assert [found["id"] for found in skipped] == [108457, 108434]


def test_latest_available_takes_the_newest_run_when_it_published():
    chosen, skipped = select("latest-available", RUNS, lambda run_id: True)
    assert chosen["id"] == 108457
    assert skipped == []


def test_latest_available_ignores_a_run_still_in_progress():
    runs = [run(108500, status="inProgress", result=None), *RUNS]
    chosen, skipped = select("latest-available", runs, published)
    assert chosen["id"] == 108364
    assert 108500 not in [found["id"] for found in skipped]


def test_latest_available_fails_when_no_run_published():
    with pytest.raises(OutputsRunError, match="no completed run"):
        select("latest-available", RUNS, lambda run_id: False)


def test_no_completed_runs_fails_in_both_modes():
    for mode in ("newest-run", "latest-available"):
        with pytest.raises(OutputsRunError, match="no completed runs"):
            select(mode, [run(1, status="inProgress", result=None)], published)


def test_unknown_mode_is_refused():
    with pytest.raises(ValueError):
        select("newest", RUNS, published)


class FakeResponse(io.BytesIO):
    def __enter__(self):
        return self

    def __exit__(self, *exc):
        return False


def fake_opener(runs, artifacts, seen=None):
    """Answer the builds list, and the artifact lookup with 200 or 404 per run."""

    def opener(request, **_kwargs):
        if seen is not None:
            seen.append(request.full_url)
        if "/artifacts" in request.full_url:
            run_id = int(request.full_url.split("/builds/")[1].split("/")[0])
            if run_id in artifacts:
                return FakeResponse(json.dumps({"name": "handoff-outputs"}).encode())
            raise urllib.error.HTTPError(request.full_url, 404, "Not Found", {}, io.BytesIO(b"{}"))
        return FakeResponse(json.dumps({"value": runs}).encode())

    return opener


def test_has_artifact_asks_for_the_named_artifact_of_that_run():
    seen = []
    opener = fake_opener(RUNS, PUBLISHED, seen)
    assert has_artifact("https://dev.azure.com/example-org/", "Example Project", 108364, "handoff-outputs", "t0ken", opener)
    assert not has_artifact("https://dev.azure.com/example-org/", "Example Project", 108457, "handoff-outputs", "t0ken", opener)
    assert "/Example%20Project/_apis/build/builds/108364/artifacts" in seen[0]
    assert "artifactName=handoff-outputs" in seen[0]


def test_has_artifact_does_not_treat_other_errors_as_missing():
    def opener(request, **_kwargs):
        raise urllib.error.HTTPError(request.full_url, 403, "Forbidden", {}, io.BytesIO(b"{}"))

    with pytest.raises(urllib.error.HTTPError):
        has_artifact("https://dev.azure.com/example-org/", "P", 1, "handoff-outputs", "t0ken", opener)


def environment(monkeypatch, token="t0ken"):
    monkeypatch.setenv("SYSTEM_COLLECTIONURI", "https://dev.azure.com/example-org/")
    monkeypatch.setenv("SYSTEM_TEAMPROJECT", "Example Project")
    if token is None:
        monkeypatch.delenv("SYSTEM_ACCESSTOKEN", raising=False)
    else:
        monkeypatch.setenv("SYSTEM_ACCESSTOKEN", token)


def patch_api(monkeypatch, runs, artifacts):
    import select_outputs_run

    opener = fake_opener(runs, artifacts)
    monkeypatch.setattr(select_outputs_run.urllib.request, "urlopen", opener)


def test_main_sets_the_run_variable_and_warns_that_it_is_not_the_newest(monkeypatch, capsys):
    environment(monkeypatch)
    patch_api(monkeypatch, RUNS, PUBLISHED)
    assert main([*ARGS, "--mode", "latest-available"]) == 0
    out = capsys.readouterr().out
    assert "##vso[task.setvariable variable=OutputsRunId]108364" in out
    assert "##vso[task.logissue type=warning]" in out
    assert "108457" in out and "108434" in out


def test_main_newest_run_mode_sets_the_variable_without_a_warning(monkeypatch, capsys):
    environment(monkeypatch)
    patch_api(monkeypatch, RUNS, {108457})
    assert main([*ARGS, "--mode", "newest-run"]) == 0
    out = capsys.readouterr().out
    assert "##vso[task.setvariable variable=OutputsRunId]108457" in out
    assert "task.logissue type=warning" not in out


def test_main_newest_run_mode_fails_closed_and_sets_no_variable(monkeypatch, capsys):
    environment(monkeypatch)
    patch_api(monkeypatch, RUNS, PUBLISHED)
    assert main([*ARGS, "--mode", "newest-run"]) == 1
    out = capsys.readouterr().out
    assert "task.logissue type=error" in out
    assert "setvariable" not in out


def test_main_requires_a_mode():
    with pytest.raises(SystemExit):
        main(ARGS)


def test_main_rejects_an_unexpanded_mode():
    with pytest.raises(SystemExit):
        main([*ARGS, "--mode", "${{ parameters.networkOutputs }}"])


def test_main_missing_token_is_rejected(monkeypatch, capsys):
    environment(monkeypatch, token=None)
    assert main([*ARGS, "--mode", "newest-run"]) == 2
    assert "SYSTEM_ACCESSTOKEN" in capsys.readouterr().out


def test_main_http_error_names_the_permission(monkeypatch, capsys):
    environment(monkeypatch)
    import select_outputs_run

    def opener(request, **_kwargs):
        raise urllib.error.HTTPError(request.full_url, 403, "Forbidden", {}, io.BytesIO(b"{}"))

    monkeypatch.setattr(select_outputs_run.urllib.request, "urlopen", opener)
    assert main([*ARGS, "--mode", "newest-run"]) == 2
    assert "403" in capsys.readouterr().out
