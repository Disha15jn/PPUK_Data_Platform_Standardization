"""Tests for sanitisation_sweep.py.

The patterns used here are invented canaries. The real patterns name another
organisation's identifiers and live only in a secure file, never in this
repository.
"""

import subprocess
import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import sanitisation_sweep  # noqa: E402

PATTERNS = """\
# label  mode    regex
Z	zero	(?i)\\bcanary-7f3a\\b
R	review	(?i)parentco

"""


def write(base: Path, relative: str, content: str | bytes) -> Path:
    path = base / relative
    path.parent.mkdir(parents=True, exist_ok=True)
    if isinstance(content, bytes):
        path.write_bytes(content)
    else:
        path.write_text(content)
    return path


@pytest.fixture
def repo(tmp_path: Path) -> Path:
    root = tmp_path / "repo"
    root.mkdir()
    subprocess.run(["git", "init", "-q", str(root)], check=True)
    return root


@pytest.fixture
def patterns(tmp_path: Path) -> Path:
    return write(tmp_path, "outside/patterns.txt", PATTERNS)


def sweep(repo: Path, patterns: Path) -> int:
    return sanitisation_sweep.main(["--root", str(repo), "--patterns", str(patterns)])


def test_clean_tree_passes(repo: Path, patterns: Path, capsys: pytest.CaptureFixture[str]) -> None:
    write(repo, "main.tf", 'resource "x" "y" {}\n')

    assert sweep(repo, patterns) == 0
    assert "Z: 0" in capsys.readouterr().out


def test_zero_rule_hit_fails_and_reports_file_and_line_only(
    repo: Path, patterns: Path, capsys: pytest.CaptureFixture[str]
) -> None:
    write(repo, "infra/main.tf", "# fine\nname = \"Canary-7F3A-thing\"\n")

    code = sweep(repo, patterns)
    out = capsys.readouterr().out

    assert code == 1
    assert "Z infra/main.tf:2" in out
    assert "Canary-7F3A" not in out


def test_matched_text_is_never_printed(repo: Path, patterns: Path, capsys: pytest.CaptureFixture[str]) -> None:
    write(repo, "README.md", "see canary-7f3a here\n")

    sweep(repo, patterns)

    assert "canary-7f3a" not in capsys.readouterr().out.lower()


def test_review_rule_hit_is_reported_but_passes(repo: Path, patterns: Path, capsys: pytest.CaptureFixture[str]) -> None:
    write(repo, "README.md", "Owned by the ParentCo platform team.\n")

    code = sweep(repo, patterns)
    out = capsys.readouterr().out

    assert code == 0
    assert "R README.md:1 (review)" in out


def test_ignored_files_are_not_swept(repo: Path, patterns: Path) -> None:
    write(repo, ".gitignore", "local/\n")
    write(repo, "local/notes.txt", "canary-7f3a\n")

    assert sweep(repo, patterns) == 0


def test_binary_files_are_skipped(repo: Path, patterns: Path) -> None:
    write(repo, "image.png", b"\x89PNG\r\n\x1a\n\xff\xfe canary-7f3a")

    assert sweep(repo, patterns) == 0


def test_missing_patterns_file_fails_with_instructions(
    repo: Path, monkeypatch: pytest.MonkeyPatch, capsys: pytest.CaptureFixture[str]
) -> None:
    monkeypatch.delenv("SWEEP_PATTERNS_FILE", raising=False)

    code = sanitisation_sweep.main(["--root", str(repo)])

    assert code == 2
    assert "SWEEP_PATTERNS_FILE" in capsys.readouterr().err


def test_patterns_file_is_read_from_the_environment(
    repo: Path, patterns: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    monkeypatch.setenv("SWEEP_PATTERNS_FILE", str(patterns))
    write(repo, "main.tf", "canary-7f3a\n")

    assert sanitisation_sweep.main(["--root", str(repo)]) == 1


def test_malformed_pattern_line_fails_naming_the_line(
    repo: Path, tmp_path: Path, capsys: pytest.CaptureFixture[str]
) -> None:
    bad = write(tmp_path, "outside/bad.txt", "Z\tzero\t(unclosed\n")

    code = sanitisation_sweep.main(["--root", str(repo), "--patterns", str(bad)])

    assert code == 2
    assert "line 1" in capsys.readouterr().err


def test_rules_sharing_a_label_are_reported_once(
    repo: Path, tmp_path: Path, capsys: pytest.CaptureFixture[str]
) -> None:
    shared = write(tmp_path, "outside/shared.txt", "D\tzero\tcanary-one\nD\tzero\tcanary-two\n")
    write(repo, "main.tf", "canary-one\n")

    code = sanitisation_sweep.main(["--root", str(repo), "--patterns", str(shared)])
    out = capsys.readouterr().out

    assert code == 1
    assert out.count("D main.tf:1") == 1
    assert "Summary: D: 1\n" in out


def test_a_label_with_two_modes_is_rejected(repo: Path, tmp_path: Path, capsys: pytest.CaptureFixture[str]) -> None:
    mixed = write(tmp_path, "outside/mixed.txt", "D\tzero\ta\nD\treview\tb\n")

    assert sanitisation_sweep.main(["--root", str(repo), "--patterns", str(mixed)]) == 2
    assert "line 2" in capsys.readouterr().err


def test_unknown_mode_fails(repo: Path, tmp_path: Path, capsys: pytest.CaptureFixture[str]) -> None:
    bad = write(tmp_path, "outside/bad.txt", "Z\tsometimes\tx\n")

    assert sanitisation_sweep.main(["--root", str(repo), "--patterns", str(bad)]) == 2
    assert "mode" in capsys.readouterr().err
