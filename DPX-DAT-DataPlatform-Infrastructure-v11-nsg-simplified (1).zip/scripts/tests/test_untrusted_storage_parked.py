"""Untrusted storage is parked.

The security team want the untrusted account in a separate subscription with
its own rules, and that subscription is not built yet. Until it is, the
platform root creates no untrusted account. The code is commented out, not
deleted; when the account returns, restore it and retire this test in the same
change.
"""

import re
from pathlib import Path

import pytest

PLATFORM = Path(__file__).resolve().parents[2] / "infra" / "20-platform-services"

# A parked line starts with '#', so a live-line pattern never matches it.
DECLARATIONS = {
    "module": re.compile(r'^module\s+"untrusted_storage"', re.MULTILINE),
    "variable": re.compile(r'^variable\s+"untrusted_storage"', re.MULTILINE),
    "output": re.compile(r'^output\s+"untrusted_storage_account_name"', re.MULTILINE),
    "local": re.compile(r"^\s*untrusted_containers\s*=", re.MULTILINE),
}


def configuration() -> dict[str, str]:
    return {path.name: path.read_text() for path in sorted(PLATFORM.glob("*.tf"))}


@pytest.mark.parametrize("kind", sorted(DECLARATIONS))
def test_declares_no_untrusted_storage(kind: str) -> None:
    hits = [name for name, text in configuration().items() if DECLARATIONS[kind].search(text)]

    assert hits == []


def test_no_var_file_sets_untrusted_storage() -> None:
    setting = re.compile(r"^untrusted_storage\s*=", re.MULTILINE)

    hits = [path.name for path in sorted((PLATFORM / "environments").glob("*.tfvars")) if setting.search(path.read_text())]

    assert hits == []


def test_no_live_test_refers_to_untrusted_storage() -> None:
    live = re.compile(r"^(?!\s*#).*untrusted_storage", re.MULTILINE)

    hits = [
        str(path.relative_to(PLATFORM))
        for path in sorted((PLATFORM / "tests").glob("*/*.tftest.hcl"))
        if live.search(path.read_text())
    ]

    assert hits == []
