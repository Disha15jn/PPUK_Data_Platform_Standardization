"""Tests for check_standalone.py.

Each kind of outside reference is proven to fail, and the text that must stay
(public links, the reference platform, SKUs, versions) to pass. Files are
written into tmp_path, so no test fixture is ever tracked.
"""

import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import check_standalone  # noqa: E402


def findings(tmp_path: Path, text: str, name: str = "main.tf") -> list[str]:
    path = tmp_path / name
    path.write_text(text)
    return check_standalone.check_files(tmp_path, [path])


@pytest.mark.parametrize("reference", ["D36", "A13", "Q11", "A9", "D1"])
def test_a_decision_agreed_item_or_question_id_fails(tmp_path: Path, reference: str) -> None:
    errors = findings(tmp_path, f"# Only dev-anl owns the NCC ({reference}).\n")

    assert errors == [f"main.tf:1: design reference '{reference}'"]


@pytest.mark.parametrize("reference", ["F21", "B9", "M5"])
def test_a_finding_or_risk_id_fails(tmp_path: Path, reference: str) -> None:
    errors = findings(tmp_path, f"description = \"Renaming a subnet replaces the workspace ({reference}).\"\n")

    assert errors == [f"main.tf:1: design reference '{reference}'"]


def test_an_id_in_a_range_fails_at_both_ends(tmp_path: Path) -> None:
    errors = findings(tmp_path, "# Restated as A9–A35.\n")

    assert errors == ["main.tf:1: design reference 'A9'", "main.tf:1: design reference 'A35'"]


@pytest.mark.parametrize("text", ["# See 06 §4.5.\n", "# The order (§3.4).\n"])
def test_a_document_section_fails(tmp_path: Path, text: str) -> None:
    assert any("document section" in e for e in findings(tmp_path, text))


@pytest.mark.parametrize(
    "text",
    ["# As 05 'Environment Structure' says.\n", "# The spec is 07.\n", "# The build record (07).\n", "# Kept from 04 and 06.\n"],
)
def test_a_design_document_number_fails(tmp_path: Path, text: str) -> None:
    assert any("design document" in e for e in findings(tmp_path, text))


@pytest.mark.parametrize(
    "text",
    ["See docs/platform-design/06-terraform-build-design.md.\n", "The rules are in CLAUDE.md.\n"],
)
def test_a_path_outside_this_directory_fails(tmp_path: Path, text: str) -> None:
    assert any("outside this directory" in e for e in findings(tmp_path, text, "README.md"))


@pytest.mark.parametrize(
    "text",
    [
        "# Microsoft Learn, https://learn.microsoft.com/en-us/azure/databricks/admin/system-tables/\n",
        "| [x](https://registry.terraform.io/providers/databricks/databricks/latest/docs/resources/grant) | resource |\n",
        "# Kept in the reference platform's shape.\n",
        'node_type_id = "Standard_D4ds_v5"\n',
        'version = "0.5.1"\n',
        'id = "0f1e2d3c-4b5a-6978-8a9b-0c1d2e3f4a5b"\n',
        "# Pinned to azurerm ~> 4.81 and Terraform 1.16.4.\n",
        "# Retention of 90 days, 30 characters at most, 2026.\n",
        "# In prd, the 06:00 job.\n",
    ],
)
def test_public_links_and_ordinary_text_pass(tmp_path: Path, text: str) -> None:
    assert findings(tmp_path, text) == []


def test_every_file_type_is_checked(tmp_path: Path) -> None:
    for name in ("variables.tf", "dev.tfvars", "x.tftest.hcl", "README.md", "resolve.py", "config.yaml", "Makefile"):
        assert findings(tmp_path, "# (D36)\n", name) == [f"{name}:1: design reference 'D36'"]


def test_binary_files_are_skipped(tmp_path: Path) -> None:
    path = tmp_path / "logo.png"
    path.write_bytes(b"\x89PNG\r\n\x1a\n\xff\xfe D36")

    assert check_standalone.check_files(tmp_path, [path]) == []


def test_the_check_does_not_flag_its_own_files(tmp_path: Path) -> None:
    scripts = tmp_path / "scripts" / "tests"
    scripts.mkdir(parents=True)
    own = [tmp_path / "scripts" / "check_standalone.py", scripts / "test_check_standalone.py"]
    for path in own:
        path.write_text("# D36, 06 §4.5, docs/\n")

    assert check_standalone.check_files(tmp_path, own) == []


def test_main_reports_each_reference_and_fails(tmp_path: Path, capsys: pytest.CaptureFixture[str]) -> None:
    (tmp_path / "main.tf").write_text("# Clean.\n# One NCC per tier (D37).\n")

    code = check_standalone.main(["--root", str(tmp_path), str(tmp_path / "main.tf")])

    assert code == 1
    assert "main.tf:2: design reference 'D37'" in capsys.readouterr().out


def test_main_passes_a_clean_file(tmp_path: Path) -> None:
    (tmp_path / "main.tf").write_text("# One NCC per tier: dev, tst and stg share one.\n")

    assert check_standalone.main(["--root", str(tmp_path), str(tmp_path / "main.tf")]) == 0


def test_files_outside_the_directory_are_not_checked(tmp_path: Path) -> None:
    # Pre-commit runs from the repository root and passes every staged file,
    # the design documents included; they may cite what they like.
    root = tmp_path / "doubtless-terraform"
    root.mkdir()
    outside = tmp_path / "docs" / "06-design.md"
    outside.parent.mkdir()
    outside.write_text("As D36 says (06 §4.5).\n")
    inside = root / "main.tf"
    inside.write_text("# Clean.\n")

    assert check_standalone.check_files(root, [outside, inside]) == []
