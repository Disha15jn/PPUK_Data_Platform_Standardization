"""List the files the repository would carry: tracked files plus new files git does not ignore."""

from __future__ import annotations

import subprocess
from pathlib import Path


def discover(root: Path) -> list[Path]:
    """Every tracked file under root, plus every new file git does not ignore."""
    listed = subprocess.run(
        ["git", "ls-files", "--cached", "--others", "--exclude-standard", "-z"],
        cwd=root,
        check=True,
        capture_output=True,
        text=True,
    ).stdout
    return [root / name for name in listed.split("\0") if name]
