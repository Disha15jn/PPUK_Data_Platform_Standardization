#!/usr/bin/env python3
"""Sweep this directory for another organisation's identifiers.

The patterns are not in this repository. They name the identifiers the sweep
exists to keep out, so committing them would put those identifiers here.
They are read from a file outside the repository: locally, the path in
$SWEEP_PATTERNS_FILE; in CI, a secure file.

Pattern file format, one rule per line; blank lines and '#' comments ignored:

    <label> <mode> <regex>

separated by tabs or spaces. <mode> is 'zero' (any hit fails the sweep) or
'review' (hits are reported for a person to read, and do not fail it). The
regex is a Python regular expression.

Every file git tracks under the root, and every new file it does not ignore, is
swept. Hits are reported as '<label> <file>:<line>'. The matched text is never
printed, so the sweep's own output cannot leak what it looks for.

Usage:
  sanitisation_sweep.py [--root DIR] [--patterns FILE]
"""

from __future__ import annotations

import argparse
import os
import re
import sys
from dataclasses import dataclass
from pathlib import Path

from repo_files import discover

MODES = ("zero", "review")


@dataclass(frozen=True)
class Rule:
    label: str
    mode: str
    pattern: re.Pattern[str]


class PatternFileError(Exception):
    pass


def load_rules(path: Path) -> list[Rule]:
    """Read the rules. Several rules may share a label, but only with one mode."""
    rules = []
    modes: dict[str, str] = {}
    for number, raw in enumerate(path.read_text().splitlines(), start=1):
        line = raw.strip()
        if not line or line.startswith("#"):
            continue
        parts = line.split(None, 2)
        if len(parts) != 3:
            raise PatternFileError(f"line {number}: expected '<label> <mode> <regex>'")
        label, mode, regex = parts
        if mode not in MODES:
            raise PatternFileError(f"line {number}: mode must be one of {', '.join(MODES)}")
        if modes.setdefault(label, mode) != mode:
            raise PatternFileError(f"line {number}: label {label} already has mode {modes[label]}")
        try:
            rules.append(Rule(label, mode, re.compile(regex)))
        except re.error as error:
            raise PatternFileError(f"line {number}: invalid regular expression ({error})") from None
    if not rules:
        raise PatternFileError("no rules found")
    return rules


def sweep(root: Path, files: list[Path], rules: list[Rule]) -> dict[str, list[str]]:
    hits: dict[str, list[str]] = {rule.label: [] for rule in rules}
    for path in files:
        try:
            text = path.read_text()
        except (UnicodeDecodeError, IsADirectoryError, FileNotFoundError):
            continue
        relative = path.relative_to(root).as_posix()
        for number, line in enumerate(text.splitlines(), start=1):
            for rule in rules:
                if rule.pattern.search(line):
                    hits[rule.label].append(f"{relative}:{number}")
    return hits


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("--root", type=Path, default=Path(__file__).resolve().parents[1])
    parser.add_argument("--patterns", type=Path, default=None)
    args = parser.parse_args(argv)

    patterns = args.patterns or (Path(os.environ["SWEEP_PATTERNS_FILE"]) if os.environ.get("SWEEP_PATTERNS_FILE") else None)
    if patterns is None or not patterns.is_file():
        print(
            "The sweep needs its pattern file. Set SWEEP_PATTERNS_FILE to its path.\n"
            "It lives outside the repository: locally, wherever Cynozure keep it; in CI,\n"
            "the pipeline's secure file. Never add the patterns to this repository.",
            file=sys.stderr,
        )
        return 2

    try:
        rules = load_rules(patterns)
    except PatternFileError as error:
        print(f"Pattern file {patterns}: {error}", file=sys.stderr)
        return 2

    root = args.root.resolve()
    files = [f for f in discover(root) if f.resolve() != patterns.resolve()]
    hits = sweep(root, files, rules)

    # One entry per label, in the order labels first appear.
    labels = {rule.label: rule.mode for rule in rules}
    failed = False
    for label, mode in labels.items():
        found = sorted(set(hits[label]), key=hits[label].index)
        hits[label] = found
        suffix = " (review)" if mode == "review" else ""
        for location in found:
            print(f"{label} {location}{suffix}")
        if mode == "zero" and found:
            failed = True
    print("Summary: " + ", ".join(f"{label}: {len(hits[label])}" for label in labels))
    if failed:
        print("Sweep FAILED: a 'zero' rule matched. Remove the identifier; do not add an exception.")
        return 1
    print("Sweep passed. Read every '(review)' line above.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
