#!/usr/bin/env bash
# Platform root: fetch network-<env>.json and resolve it. Wrapper over fetch_upstream.sh.
set -euo pipefail
export FILE_PREFIX=network
export ROOT=infra/20-platform-services
exec bash "$(dirname "$0")/fetch_upstream.sh"
