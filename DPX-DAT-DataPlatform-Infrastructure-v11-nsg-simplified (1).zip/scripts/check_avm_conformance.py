#!/usr/bin/env python3
"""Check that every Azure resource in the infra roots is created by an Azure Verified Module.

The platform root, infra/20-platform-services, calls one wrapper module per
service, and each wrapper calls one Azure Verified Module. A plain azurerm or
azapi resource beside those calls bypasses the module catalogue and its
standard interfaces, so this check fails on any `resource "azurerm_*"` or
`resource "azapi_*"` block under infra/ that is not on the allowlist below,
and on an allowlist entry that no longer exists. Each entry carries the reason
the Verified Module cannot express it.

The Databricks root creates no Azure resource: it uses the Databricks provider
only. Any azurerm or azapi resource under databricks/ fails.

Data sources are not resources and are not checked.

Usage:
  check_avm_conformance.py [--root DIR] [FILE ...]

With no FILE arguments, every Terraform file git tracks under DIR, plus every
new file git does not ignore, is checked. Pre-commit passes the staged files
instead; any outside DIR are skipped.
"""

from __future__ import annotations

import argparse
import re
import sys
from pathlib import Path

from repo_files import discover

# The Azure resources no Verified Module creates, as "path:type.name" => reason.
ALLOWED = {
    "infra/modules/databricks-workspace/main.tf:azurerm_private_endpoint.workspace_storage_unmanaged_dns": (
        "the private endpoint Verified Module cannot ignore a DNS zone group that "
        "Landing Zone policy adds; this block carries the lifecycle rule for that case"
    ),
}

RESOURCE = re.compile(r'^\s*resource\s+"((?:azurerm|azapi)_[A-Za-z0-9_]+)"\s+"([A-Za-z0-9_-]+)"')
CHECKED_DIRS = ("infra/", "databricks/")


def find_resources(relative: str, text: str) -> list[str]:
    """Every azurerm or azapi resource address in one file, as path:type.name."""
    found = []
    for line in text.splitlines():
        match = RESOURCE.match(line)
        if match:
            found.append(f"{relative}:{match.group(1)}.{match.group(2)}")
    return found


def check_files(root: Path, files: list[Path]) -> list[str]:
    errors = []
    seen = set()
    for path in files:
        try:
            relative = path.resolve().relative_to(root.resolve()).as_posix()
        except ValueError:
            continue
        if not relative.startswith(CHECKED_DIRS) or not relative.endswith(".tf") or not path.is_file():
            continue
        for address in find_resources(relative, path.read_text(encoding="utf-8")):
            seen.add(address)
            if relative.startswith("databricks/"):
                errors.append(f"{address}: the Databricks root creates no Azure resource")
            elif address not in ALLOWED:
                errors.append(f"{address}: not created by an Azure Verified Module, and not on the allowlist with a reason")
    return errors


def stale_entries(root: Path, files: list[Path]) -> list[str]:
    """Allowlist entries whose file is checked but no longer holds the resource."""
    checked = {}
    for path in files:
        try:
            relative = path.resolve().relative_to(root.resolve()).as_posix()
        except ValueError:
            continue
        if relative.startswith(CHECKED_DIRS) and relative.endswith(".tf") and path.is_file():
            checked[relative] = set(find_resources(relative, path.read_text(encoding="utf-8")))
    return [
        f"{address}: on the allowlist, but no such resource exists; remove the entry"
        for address in ALLOWED
        if address.split(":", 1)[0] in checked and address not in checked[address.split(":", 1)[0]]
    ]


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("--root", type=Path, default=Path(__file__).resolve().parents[1])
    parser.add_argument("files", nargs="*", type=Path)
    args = parser.parse_args(argv)

    root = args.root.resolve()
    files = [f.resolve() for f in args.files] if args.files else discover(root)
    errors = check_files(root, files) + stale_entries(root, files)
    for error in errors:
        print(error)
    if errors:
        print(f"{len(errors)} Azure resources outside the Verified Modules. Use the module's interface, or allowlist it with a reason.")
    return 1 if errors else 0


if __name__ == "__main__":
    sys.exit(main())
