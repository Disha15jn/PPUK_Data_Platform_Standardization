#!/usr/bin/env bash
# Report what a plan cannot see, before a platform apply. It reports and never fails:
# every line starts OK, PROBLEM or UNKNOWN, and the exit code is always 0.
#   1. the resource providers our root does not register are registered on the subscription
#   2. no rule at priority 100 sits on a workspace NSG (Databricks adds its own VNet rules there
#      when it creates a workspace, and an NSG cannot hold two rules with the same priority and
#      direction)
#   3. the pipeline identity holds a role on each private DNS zone (to write zone groups), on the
#      subscription (to create role assignments) and on the Log Analytics workspace (to send
#      diagnostic settings to it)
# Run inside an AzureCLI@2 task on the environment's service connection, from the repo root, after
# the resolve step has written upstream.tfvars.json. A role check lists the identity's own assignments,
# inherited ones included. It cannot see a custom role's actions, a condition on a role, or a role
# granted through an Entra group, so a PROBLEM there means "none of the usual roles held directly",
# to be read with the roles printed beside it.
#
# Required env: SUBSCRIPTION_ID
# Optional env: UPSTREAM_FILE (default: infra/20-platform-services/upstream.tfvars.json),
#               PROVIDERS (space-separated namespaces)
# No -e: the report must never fail. pipefail is needed: the checks read az's exit status through a pipe.
set -uo pipefail

UPSTREAM_FILE="${UPSTREAM_FILE:-infra/20-platform-services/upstream.tfvars.json}"
PROVIDERS="${PROVIDERS:-Microsoft.Databricks Microsoft.Storage Microsoft.KeyVault Microsoft.ManagedIdentity Microsoft.Insights}"

ok() { echo "OK       $*"; }
problem() { echo "PROBLEM  $*"; }
unknown() { echo "UNKNOWN  $*"; }

if [ -z "${SUBSCRIPTION_ID:-}" ]; then
  unknown "SUBSCRIPTION_ID is not set, so nothing was checked."
  exit 0
fi
if [ ! -f "$UPSTREAM_FILE" ]; then
  unknown "The upstream file $UPSTREAM_FILE is missing, so the subnets, zones and workspace were not checked."
fi

# 1. Resource providers
for namespace in $PROVIDERS; do
  state="$(az provider show --namespace "$namespace" --subscription "$SUBSCRIPTION_ID" --query registrationState -o tsv </dev/null 2>/dev/null)" \
    || { unknown "Could not read the registration of $namespace."; continue; }
  if [ "$state" = "Registered" ]; then ok "$namespace is registered."; else problem "$namespace is $state on the subscription: our provider block registers none."; fi
done

# What the resolved network holds: kind, label, id.
facts=""
if [ -f "$UPSTREAM_FILE" ]; then
  facts="$(python3 - "$UPSTREAM_FILE" <<'PY'
import json, sys
network = json.load(open(sys.argv[1]))["network"]
for workspace, subnets in sorted(network["databricks_subnets"].items()):
    for role in ("host", "container"):
        print("subnet", f"{workspace}-{role}", subnets[role]["id"], sep="\t")
for zone, zone_id in sorted(network["private_dns_zone_ids"].items()):
    print("zone", zone, zone_id, sep="\t")
print("law", "log-analytics", network["log_analytics_workspace_id"], sep="\t")
PY
)" || { unknown "Could not read the network from $UPSTREAM_FILE."; facts=""; }
fi

# 2. Priority 100 on the workspace NSGs
nsgs=""
while IFS=$'\t' read -r kind label id; do
  [ "$kind" = "subnet" ] || continue
  nsg_id="$(az network vnet subnet show --ids "$id" --query networkSecurityGroup.id -o tsv </dev/null 2>/dev/null)" \
    || { unknown "Could not read the NSG of subnet $label."; continue; }
  [ -n "$nsg_id" ] && nsgs="$nsgs$nsg_id"$'\n'
done <<< "$facts"
while IFS= read -r nsg_id; do
  [ -n "$nsg_id" ] || continue
  name="${nsg_id##*/}"
  rules="$(az network nsg show --ids "$nsg_id" --query 'securityRules[?priority==`100`].name' -o tsv </dev/null 2>/dev/null)" \
    || { unknown "Could not read the rules of $name."; continue; }
  # Databricks' own worker-to-worker rules sit at 100 once a workspace exists. They are not a clash.
  held="$(printf '%s\n' "$rules" | grep -v '^Microsoft.Databricks-workspaces_UseOnly_' | grep -v '^$' | tr '\n' ',' | sed 's/,$//')"
  if [ -n "$held" ]; then problem "$name holds rule(s) at priority 100: $held. Databricks adds its own VNet rules at 100 when it creates a workspace."
  else ok "$name holds no rule at priority 100 other than Databricks' own."; fi
done < <(printf '%s' "$nsgs" | sort -u)

# 3. The pipeline identity's roles
# The identity's object ID comes from the access token's claims. az role assignment list --assignee
# takes the application ID the login reports and resolves it through Microsoft Graph, which a pipeline
# identity often cannot read, so it would list nothing. The token is never printed.
identity=""
token="$(az account get-access-token --resource https://management.azure.com/ --query accessToken -o tsv </dev/null 2>/dev/null)" \
  && identity="$(printf '%s' "$token" | python3 -c '
import base64, json, sys
part = sys.stdin.read().strip().split(".")[1]
print(json.loads(base64.urlsafe_b64decode(part + "=" * (-len(part) % 4))).get("oid", ""))
' 2>/dev/null)"
token=""
check_roles() { # label scope regex what
  local label="$1" scope="$2" regex="$3" what="$4" roles
  if [ -z "$identity" ]; then unknown "$label: could not read the pipeline identity's object ID from its token."; return; fi
  roles="$(az role assignment list --assignee-object-id "$identity" --scope "$scope" --include-inherited --query '[].roleDefinitionName' -o tsv </dev/null 2>/dev/null | sort -u | tr '\n' ',' | sed 's/,$//')"
  if [ "${PIPESTATUS[0]}" -ne 0 ]; then unknown "$label: could not list the role assignments at $scope."
  elif printf '%s' "$roles" | grep -Eqi "$regex"; then ok "$label: $what (holds: $roles)."
  else problem "$label: none of the usual roles for $what (holds: ${roles:-nothing}). A custom role may still cover it."; fi
}
while IFS=$'\t' read -r kind label id; do
  [ "$kind" = "zone" ] && check_roles "DNS zone $label" "$id" 'Owner|Contributor' "writing zone groups"
  [ "$kind" = "law" ] && check_roles "Log Analytics workspace" "$id" 'Owner|Contributor' "sending diagnostic settings"
done <<< "$facts"
check_roles "Subscription role assignment" "/subscriptions/$SUBSCRIPTION_ID" 'Owner|User Access Administrator|Role Based Access Control Administrator' "creating role assignments"
exit 0
