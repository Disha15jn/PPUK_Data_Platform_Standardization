#!/usr/bin/env bash
# Landing zone: publish network-<env>.json. Wrapper over publish_outputs.sh.
set -euo pipefail
export TF_WORKING_DIR="${TF_WORKING_DIR:-infra/10-landing-zone}"
export FILE_PREFIX=network
export REQUIRED_OUTPUTS="network"
export ENVIRONMENT_OUTPUT_CHECK=true
exec bash "$(dirname "$0")/publish_outputs.sh"
