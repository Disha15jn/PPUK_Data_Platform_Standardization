#!/usr/bin/env python3
"""Check that this directory stands alone: nothing in it cites the design documents.

This directory is handed over on its own, without the design documents it was
built from, so every comment, description, error message and README must make
sense by itself. The check fails on:

1. A design reference: a decision, agreed-item or question ID, or a finding or
   risk ID, written as one of the letters A, B, D, F, M or Q and one or two
   digits.
2. A document section: any section sign.
3. A design document's number: 00 to 07, followed by a section, a quoted
   heading, a design reference or the end of a clause.
4. A path outside this directory: into docs/, or CLAUDE.md.

Public links (Microsoft Learn, the provider documentation, the Terraform
Registry) and mentions of the reference platform are fine. State why a setting
exists in the comment itself.

Usage:
  check_standalone.py [--root DIR] [FILE ...]

With no FILE arguments, every file git tracks under DIR, plus every new file git
does not ignore, is checked. Pre-commit passes the staged files instead; any
outside DIR are skipped.
"""

from __future__ import annotations

import argparse
import re
import sys
from pathlib import Path

from repo_files import discover

CHECKS = [
    ("design reference", re.compile(r"(?<![A-Za-z0-9_./:-])[ABDFMQ][0-9]{1,2}(?![A-Za-z0-9_])")),
    ("document section", re.compile(r"§\s*[0-9A-Za-z.]*")),
    ("design document", re.compile(r"(?<![\w.:/-])0[0-7](?=\s*(?:§|'|’|[ABDFMQ][0-9]|\)|,|;|\.(?:\s|$)| and\b| to\b)|$)", re.M)),
    ("path outside this directory", re.compile(r"(?<![\w/.-])(?:docs/[^\s)`'\"]*|CLAUDE\.md)")),
]

# This check and its tests spell out what they look for.
OWN_FILES = {"scripts/check_standalone.py", "scripts/tests/test_check_standalone.py"}
SKIPPED_SUFFIXES = (".terraform.lock.hcl",)


def check_text(relative: str, text: str) -> list[str]:
    errors = []
    for number, line in enumerate(text.splitlines(), start=1):
        for kind, pattern in CHECKS:
            for match in pattern.finditer(line):
                errors.append(f"{relative}:{number}: {kind} '{match.group(0).strip()}'")
    return errors


def check_files(root: Path, files: list[Path]) -> list[str]:
    errors = []
    for path in files:
        try:
            relative = path.resolve().relative_to(root.resolve()).as_posix()
        except ValueError:
            # Outside this directory: the design documents may cite what they like.
            continue
        if relative in OWN_FILES or relative.endswith(SKIPPED_SUFFIXES) or not path.is_file():
            continue
        try:
            text = path.read_text(encoding="utf-8")
        except UnicodeDecodeError:
            continue
        errors.extend(check_text(relative, text))
    return errors


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("--root", type=Path, default=Path(__file__).resolve().parents[1])
    parser.add_argument("files", nargs="*", type=Path)
    args = parser.parse_args(argv)

    root = args.root.resolve()
    files = [f.resolve() for f in args.files] if args.files else discover(root)
    errors = check_files(root, files)
    for error in errors:
        print(error)
    if errors:
        print(f"{len(errors)} references to documents outside this directory. State the reason in the text instead.")
    return 1 if errors else 0


if __name__ == "__main__":
    sys.exit(main())
