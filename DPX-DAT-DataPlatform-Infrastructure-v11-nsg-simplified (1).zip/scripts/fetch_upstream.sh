#!/usr/bin/env bash
# Download the upstream root's published outputs and resolve them into the
# downstream root's upstream.tfvars.json. Run before `terraform init`, from the repo root.
#
# Required env: ENVIRONMENT, STATE_STORAGE_ACCOUNT, FILE_PREFIX, ROOT
#   FILE_PREFIX  the upstream blob is <FILE_PREFIX>-<ENVIRONMENT>.json (network, platform)
#   ROOT         infra/20-platform-services or databricks
# Optional env:
#   OUTPUTS_CONTAINER (default: outputs)
#   WORKSPACE         anl or ops (required for the databricks root)
#   SINGLETONS_ONLY   "true" adds --singletons-only (prd-anl's first apply only)
# Auth: the pipeline identity's az login (Storage Blob Data Reader on the container).
set -euo pipefail

: "${ENVIRONMENT:?set ENVIRONMENT}"
: "${STATE_STORAGE_ACCOUNT:?set STATE_STORAGE_ACCOUNT}"
: "${FILE_PREFIX:?set FILE_PREFIX}"
: "${ROOT:?set ROOT}"
CONTAINER="${OUTPUTS_CONTAINER:-outputs}"
BLOB="${FILE_PREFIX}-${ENVIRONMENT}.json"

az storage blob download \
  --auth-mode login \
  --account-name "$STATE_STORAGE_ACCOUNT" \
  --container-name "$CONTAINER" \
  --name "$BLOB" \
  --file "$BLOB" \
  --no-progress

python3 -c "import yaml" 2>/dev/null || pip3 install --user PyYAML==6.0.3

ARGS=(--root "$ROOT" --environment "$ENVIRONMENT" --upstream-outputs "$BLOB" --out "$ROOT/upstream.tfvars.json")
if [ -n "${WORKSPACE:-}" ]; then ARGS+=(--workspace "$WORKSPACE"); fi
if [ "${SINGLETONS_ONLY:-false}" = "true" ]; then ARGS+=(--singletons-only); fi
python3 scripts/resolve_upstream.py "${ARGS[@]}"
