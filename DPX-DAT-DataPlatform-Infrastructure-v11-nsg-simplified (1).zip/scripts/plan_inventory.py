#!/usr/bin/env python3
"""Turn a printed Terraform plan into a resource inventory in Markdown.

`scripts/terraform_plan.sh` saves `terraform test -verbose` output, which holds a
human-readable plan. This reads that text and writes a table of every resource
address with its type, action and name, then a count by type, so a plan can be
read against a design and a missing resource stands out.

For an azapi resource the type column shows the Azure resource type it manages
(for example `Microsoft.Storage/storageAccounts@2023-05-01`), because every
azapi resource has the same Terraform type.

Values come from mock providers, so anything Azure computes reads 'unknown'.

Usage:
  plan_inventory.py plans/databricks-dev-anl.txt [more.txt ...]

Each input `X.txt` is written to `X.md` beside it.
"""

from __future__ import annotations

import argparse
import re
import sys
from collections import Counter
from dataclasses import dataclass
from pathlib import Path

HEADER = re.compile(r"^  # (?P<address>.*?) (?P<verb>will be .+|must be .+)$")
DECLARATION = re.compile(r'^\s+(?:[+~<=>-]+\s+)?(?P<kind>resource|data) "(?P<type>[^"]+)" "[^"]+" \{')
ATTRIBUTE = re.compile(r"^ {6}[+~<=>-]+ (?P<key>\w+)\s+= (?P<value>.*)$")
SUMMARY = re.compile(r"^Plan: .*$", re.MULTILINE)

ACTIONS = {
    "will be created": "create",
    "will be read during apply": "read",
    "will be updated in-place": "update",
    "will be destroyed": "destroy",
    "must be replaced": "replace",
    "will be imported": "import",
}
# Attributes that identify a resource to a reader, in the order they are tried.
NAME_KEYS = ("name", "display_name", "user_name", "group_name", "catalog_name")
UNKNOWN = "(known after apply)"


@dataclass
class Resource:
    address: str
    kind: str
    type: str
    action: str
    name: str


def action_for(verb: str) -> str:
    for phrase, action in ACTIONS.items():
        if verb.startswith(phrase):
            return action
    return verb


def clean(value: str) -> str:
    value = value.strip()
    if value == UNKNOWN:
        return "unknown"
    return value.strip('"')


def parse_plan(text: str) -> list[Resource]:
    """Every resource block in the plan, in the order Terraform printed them."""
    resources: list[Resource] = []
    current: Resource | None = None
    attributes: dict[str, str] = {}

    def finish() -> None:
        if current is None:
            return
        if current.type.startswith("azapi_") and "type" in attributes:
            current.type = clean(attributes["type"])
        for key in NAME_KEYS:
            if key in attributes:
                current.name = clean(attributes[key])
                break
        resources.append(current)

    for line in text.splitlines():
        header = HEADER.match(line)
        if header:
            finish()
            current = Resource(header["address"], "", "", action_for(header["verb"]), "")
            attributes = {}
            continue
        if current is None:
            continue
        if not current.type:
            declaration = DECLARATION.match(line)
            if declaration:
                current.kind = declaration["kind"]
                current.type = declaration["type"]
            continue
        attribute = ATTRIBUTE.match(line)
        if attribute:
            attributes.setdefault(attribute["key"], attribute["value"])
    finish()
    return resources


def cell(value: str) -> str:
    return (value or "").replace("|", "\\|")


def render(title: str, text: str, resources: list[Resource]) -> str:
    summary = SUMMARY.search(text)
    counts = Counter((r.type, r.action) for r in resources)
    lines = [
        f"# Plan inventory: {title}",
        "",
        "Made under mock providers: it shows what the code declares, not what Azure",
        "would do. Computed values read 'unknown'; lookups, drift and provider or",
        "permission errors are not visible.",
        "",
        summary.group(0) if summary else "No plan summary line was found.",
        f"{len(resources)} resource blocks.",
        "",
        "## Resources",
        "",
        "| Address | Type | Action | Name |",
        "|---|---|---|---|",
    ]
    for r in sorted(resources, key=lambda r: r.address):
        lines.append(f"| `{cell(r.address)}` | `{cell(r.type)}` | {r.action} | {cell(r.name)} |")
    lines += ["", "## Count by type", "", "| Type | Action | Count |", "|---|---|---|"]
    for (type_, action), count in sorted(counts.items()):
        lines.append(f"| `{cell(type_)}` | {action} | {count} |")
    return "\n".join(lines) + "\n"


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__.split("\n")[0])
    parser.add_argument("plans", nargs="+", type=Path, help="printed plans, X.txt")
    args = parser.parse_args(argv)
    for path in args.plans:
        text = path.read_text()
        resources = parse_plan(text)
        if not resources:
            print(f"{path}: no resources found in the plan", file=sys.stderr)
            return 1
        out = path.with_suffix(".md")
        out.write_text(render(path.stem, text, resources))
        print(f"   wrote {out.name}: {len(resources)} resources")
    return 0


if __name__ == "__main__":
    sys.exit(main())
