"""Read a root's published outputs into a variable, through a mapping file.

The mapping is a tree in the shape of the variable it builds. Each leaf is a
path into the published `terraform output -json`: the first segment names an
output and the rest are keys inside that output's value, separated by '/', so
a key may contain dots, as private DNS zone names do. A key written "{name}"
repeats its entry once for each value listed under `placeholders`, and "{name}"
in a path below it is replaced by that value. `environment` is the path to the name of
the environment that published the file.

Every value is read with loud failures: a missing key, a value that is not an
object where the path needs one, or a null or empty value fails, naming the
path, the file and the attribute it was wanted for. Nothing falls back to a
default, and anything the mapping does not name is ignored.

This module knows nothing about any one root. resolve_upstream.py uses it for
the landing zone's outputs, through config/landing-zone-outputs.yaml.
"""

from __future__ import annotations

import re
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import yaml

SEPARATOR = "/"
KEYS = ("environment", "network", "placeholders")
PLACEHOLDER_KEY = re.compile(r"^\{([a-z_]+)\}$")
PLACEHOLDER_IN_PATH = re.compile(r"\{([a-z_]+)\}")


class MappingError(Exception):
    """The mapping file is unusable, or a value it names is missing, null or empty."""


@dataclass(frozen=True)
class Mapping:
    """A checked mapping file."""

    source: Path
    placeholders: dict[str, tuple[str, ...]]
    environment: str
    network: dict[str, Any]


def load(path: Path) -> Mapping:
    """Read a mapping file and check its shape."""
    try:
        data = yaml.safe_load(path.read_text())
    except FileNotFoundError:
        raise MappingError(f"{path} is missing") from None
    except yaml.YAMLError as error:
        first_line = str(error).splitlines()[0]
        raise MappingError(f'{path}: not valid YAML ({first_line}); quote keys such as "{{workspace}}"') from None
    if not isinstance(data, dict) or sorted(data, key=str) != sorted(KEYS):
        raise MappingError(f"{path}: needs exactly the keys {', '.join(sorted(KEYS))}")
    placeholders = data["placeholders"]
    if not isinstance(placeholders, dict) or not all(
        isinstance(name, str) and isinstance(values, list) and values and all(isinstance(v, str) and v for v in values)
        for name, values in placeholders.items()
    ):
        raise MappingError(f"{path}: each placeholder needs a non-empty list of names")
    environment = data["environment"]
    if not _is_path(environment) or PLACEHOLDER_IN_PATH.search(environment):
        raise MappingError(f"{path}: environment must be a path with no placeholder, such as 'environment'")
    mapping = Mapping(path, {name: tuple(values) for name, values in placeholders.items()}, environment, data["network"])
    _check(mapping, mapping.network, "network", frozenset())
    return mapping


def _is_path(node: Any) -> bool:
    return isinstance(node, str) and all(node.split(SEPARATOR))


def _check(mapping: Mapping, node: Any, label: str, bound: frozenset[str]) -> None:
    if _is_path(node):
        for name in PLACEHOLDER_IN_PATH.findall(node):
            if name not in bound:
                raise MappingError(f'{mapping.source}: {label}: \'{{{name}}}\' used outside a "{{{name}}}" key')
        return
    if not isinstance(node, dict) or not node:
        raise MappingError(
            f"{mapping.source}: {label} must be a path such as 'network/virtual_network_id', "
            "or a non-empty mapping of them"
        )
    for key, child in node.items():
        if not isinstance(key, str):
            raise MappingError(f"{mapping.source}: {label}: key {key!r} must be text; quote it")
        match = PLACEHOLDER_KEY.match(key)
        if not match:
            _check(mapping, child, f"{label}.{key}", bound)
            continue
        name = match.group(1)
        if name not in mapping.placeholders:
            raise MappingError(f"{mapping.source}: {label}: unknown placeholder '{name}'")
        if len(node) > 1:
            raise MappingError(f'{mapping.source}: {label}: a "{key}" key must be the only key at its level')
        _check(mapping, child, f"{label}.{key}", bound | {name})


def resolve(mapping: Mapping, outputs: dict[str, Any], source: Path) -> dict[str, Any]:
    """The `network` tree with every leaf read from `outputs`, a `terraform output -json` dict."""
    return _build(mapping, mapping.network, outputs, source, "network", {})


def published_environment(mapping: Mapping, outputs: dict[str, Any], source: Path) -> Any:
    """The environment that published `outputs`, read from the mapping's `environment` path."""
    return read(outputs, mapping.environment, source, "the environment check")


def _build(mapping: Mapping, node: Any, outputs: dict[str, Any], source: Path, label: str, bound: dict[str, str]) -> Any:
    if isinstance(node, str):
        path = PLACEHOLDER_IN_PATH.sub(lambda match: bound[match.group(1)], node)
        return read(outputs, path, source, label)
    built: dict[str, Any] = {}
    for key, child in node.items():
        match = PLACEHOLDER_KEY.match(key)
        if match:
            name = match.group(1)
            return {
                value: _build(mapping, child, outputs, source, f"{label}.{value}", {**bound, name: value})
                for value in mapping.placeholders[name]
            }
        built[key] = _build(mapping, child, outputs, source, f"{label}.{key}", bound)
    return built


def read(outputs: dict[str, Any], path: str, source: Path, wanted_for: str) -> Any:
    """One value from a `terraform output -json` dict, by path, with loud failures."""
    output, *keys = path.split(SEPARATOR)
    if output not in outputs:
        raise MappingError(f"upstream output '{path}' is missing from {source}, wanted for {wanted_for}")
    value = outputs[output]["value"]
    walked = output
    for key in keys:
        if not isinstance(value, dict):
            kind = "null" if value is None else type(value).__name__
            raise MappingError(
                f"upstream output '{path}' cannot be read from {source}: '{walked}' is a {kind}, "
                f"not an object, wanted for {wanted_for}"
            )
        if key not in value:
            raise MappingError(
                f"upstream output '{path}' is missing from {source} (no '{key}' under '{walked}'), "
                f"wanted for {wanted_for}"
            )
        value = value[key]
        walked = f"{walked}{SEPARATOR}{key}"
    if value is None:
        raise MappingError(f"upstream output '{path}' is null in {source}, wanted for {wanted_for}")
    if value in ("", {}, []):
        raise MappingError(f"upstream output '{path}' is empty in {source}, wanted for {wanted_for}")
    return value
