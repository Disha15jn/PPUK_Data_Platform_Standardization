#!/usr/bin/env python3
"""Choose which run of an upstream pipeline to download its published outputs from.

Two modes:

  newest-run        The newest completed run on the branch. Fails if that run
                    published no artifact, because then its apply did not finish
                    and any older file describes a network that may no longer be
                    what is deployed. This is the safe default.
  latest-available  The newest completed run that did publish the artifact,
                    passing over newer runs that did not. A warning names each
                    run passed over. Use it while the upstream pipeline is not
                    yet applying cleanly, and drop it once it is.

On success it sets the pipeline variable OutputsRunId to the chosen run's ID, for
the download step that follows. Run check_upstream_run.py afterwards with the
same mode: it reports which run, commit and finish time were used.

Usage:
  select_outputs_run.py --definition-id ID --branch REF --artifact-name NAME --mode MODE

It reads SYSTEM_COLLECTIONURI and SYSTEM_TEAMPROJECT, which Azure Pipelines sets,
and SYSTEM_ACCESSTOKEN, which the step must map from $(System.AccessToken). It
uses only the standard library, so it runs before any package is installed.

Exit codes: 0 a run was chosen; 1 no run can be used; 2 the arguments, the
environment or the API call are wrong.
"""

import argparse
import os
import urllib.error
import urllib.parse
import urllib.request

from check_upstream_run import fetch_runs

ERROR = "##vso[task.logissue type=error]"
WARNING = "##vso[task.logissue type=warning]"
MODES = ("newest-run", "latest-available")


class OutputsRunError(Exception):
    """No run of the upstream pipeline can supply the outputs in this mode."""


def has_artifact(collection_uri, project, run_id, artifact_name, token, opener=None):
    """Return whether the run published the named artifact. A 404 means it did not."""
    opener = opener or urllib.request.urlopen
    query = urllib.parse.urlencode({"artifactName": artifact_name, "api-version": "7.1"})
    url = (
        f"{collection_uri.rstrip('/')}/{urllib.parse.quote(project)}"
        f"/_apis/build/builds/{run_id}/artifacts?{query}"
    )
    request = urllib.request.Request(url, headers={"Authorization": f"Bearer {token}"})
    try:
        with opener(request, timeout=30):
            return True
    except urllib.error.HTTPError as error:
        if error.code == 404:
            return False
        raise


def select(mode, runs, published):
    """Return (chosen run, completed runs newer than it), or raise.

    `published` takes a run ID and says whether that run published the artifact.
    """
    if mode not in MODES:
        raise ValueError(f"mode must be one of {MODES}, not {mode!r}")
    completed = sorted(
        (found for found in runs if found["status"] == "completed"),
        key=lambda found: found["id"],
        reverse=True,
    )
    if not completed:
        raise OutputsRunError(
            "The upstream pipeline has no completed runs on this branch, or the build service "
            "cannot read its runs."
        )
    if mode == "newest-run":
        newest = completed[0]
        if not published(newest["id"]):
            raise OutputsRunError(
                f"The newest completed run, {newest['id']} (result {newest['result']}), published "
                "no outputs, so its apply did not finish. Fix the upstream pipeline and re-run it, "
                "or choose latest-available to plan against the last outputs that were published."
            )
        return newest, []
    skipped = []
    for found in completed:
        if published(found["id"]):
            return found, skipped
        skipped.append(found)
    raise OutputsRunError(
        f"None of the {len(completed)} most recent completed runs published the artifact, so "
        "there is no completed run to take outputs from."
    )


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("--definition-id", required=True)
    parser.add_argument("--branch", required=True)
    parser.add_argument("--artifact-name", required=True)
    parser.add_argument("--mode", required=True, choices=MODES)
    args = parser.parse_args(argv)

    def refuse(message, code):
        print(f"{ERROR}{message}")
        return code

    token = os.environ.get("SYSTEM_ACCESSTOKEN", "")
    if not token:
        return refuse("SYSTEM_ACCESSTOKEN is not set: map System.AccessToken into the step's env.", 2)
    try:
        collection_uri = os.environ["SYSTEM_COLLECTIONURI"]
        project = os.environ["SYSTEM_TEAMPROJECT"]
        runs = fetch_runs(collection_uri, project, args.definition_id, args.branch, token)

        def published(run_id):
            return has_artifact(collection_uri, project, run_id, args.artifact_name, token)

        try:
            chosen, skipped = select(args.mode, runs, published)
        except OutputsRunError as error:
            return refuse(str(error), 1)
    except KeyError as missing:
        return refuse(f"{missing.args[0]} is not set; this script runs inside an Azure Pipelines job.", 2)
    except urllib.error.HTTPError as error:
        return refuse(
            f"Azure DevOps returned {error.code} reading pipeline {args.definition_id}. "
            "The project's build service identity needs permission to view that pipeline.",
            2,
        )
    except urllib.error.URLError as error:
        return refuse(f"Could not reach Azure DevOps: {error.reason}", 2)
    for found in skipped:
        print(
            f"{WARNING}Passed over run {found['id']} (commit {found['sourceVersion'][:7]}, "
            f"result {found['result']}): it published no outputs."
        )
    if skipped:
        print(
            f"{WARNING}Using run {chosen['id']}, which is not the newest. The network it describes "
            "may differ from what the newest landing-zone run left deployed."
        )
    print(f"##vso[task.setvariable variable=OutputsRunId]{chosen['id']}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
