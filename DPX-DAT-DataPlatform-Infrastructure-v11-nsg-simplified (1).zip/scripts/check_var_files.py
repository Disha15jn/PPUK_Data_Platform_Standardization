#!/usr/bin/env python3
"""Check that tracked configuration carries no identifiers and no upstream values.

Four checks:

1. No GUID-shaped value in any root's environments/*.tfvars. Subscription,
   tenant and metastore IDs come from the pipeline's variable groups.
2. No *.tfbackend file is tracked. Only *.tfbackend.template files are.
3. No var file we maintain sets an upstream variable. Upstream values come only
   from the generated upstream.tfvars.json, so a var file that set one would be
   silently overridden, or worse, would win.
4. No var file sets an identifier variable.

The upstream and identifier variable names are read from
config/upstream-contract.yaml, the one place the contract is written down. Each
identifier there is scoped to the variable group it comes from: the
environment's (the subscription: each environment has its own) or the
tier's (everything else).

Usage:
  check_var_files.py [--root DIR] [FILE ...]

With no FILE arguments, every file git tracks under DIR, plus every new file git
does not ignore, is checked. Pre-commit passes the staged files instead.
Findings are reported as file:line only; a matched identifier is never printed.
"""

from __future__ import annotations

import argparse
import re
import sys
from collections.abc import Mapping
from dataclasses import dataclass
from pathlib import Path

import yaml

from repo_files import discover

GUID = re.compile(r"[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}")
# A top-level assignment. `terraform fmt` puts top-level arguments at column 0
# and indents everything nested, so an indented key is never a variable.
TOP_LEVEL_ASSIGNMENT = re.compile(r"^([A-Za-z_][A-Za-z0-9_-]*)\s*=")


SCOPES = ("environment", "tier")


class ContractError(Exception):
    pass


@dataclass(frozen=True)
class RootContract:
    upstream: frozenset[str]
    # Identifier name -> the variable group it comes from, one of SCOPES.
    identifiers: Mapping[str, str]


def load_contract(path: Path) -> dict[str, RootContract]:
    data = yaml.safe_load(path.read_text())
    contract = {}
    for root, spec in data["roots"].items():
        identifiers = spec.get("identifiers") or {}
        if not isinstance(identifiers, dict) or any(scope not in SCOPES for scope in identifiers.values()):
            raise ContractError(
                f"{path}: every identifier of {root} needs a scope, environment or tier: "
                "the variable group it comes from"
            )
        contract[root] = RootContract(
            upstream=frozenset((spec.get("upstream") or {}).keys()),
            identifiers=dict(identifiers),
        )
    return contract


def owning_root(relative: str, contract: dict[str, RootContract]) -> str | None:
    for name in contract:
        if relative.startswith(name + "/"):
            return name
    return None


def is_environment_var_file(relative: str) -> bool:
    parts = relative.split("/")
    return relative.endswith(".tfvars") and len(parts) >= 2 and parts[-2] == "environments"


def check_var_file(path: Path, relative: str, rules: RootContract) -> list[str]:
    errors = []
    for number, line in enumerate(path.read_text().splitlines(), start=1):
        if GUID.search(line):
            errors.append(f"{relative}:{number}: a GUID-shaped value; identifiers never go in var files")
        match = TOP_LEVEL_ASSIGNMENT.match(line)
        if not match:
            continue
        name = match.group(1)
        if name in rules.upstream:
            errors.append(
                f"{relative}:{number}: sets upstream variable '{name}'; "
                "upstream values come only from upstream.tfvars.json"
            )
        if name in rules.identifiers:
            errors.append(
                f"{relative}:{number}: sets identifier variable '{name}'; "
                f"identifiers come from the pipeline's variable groups, this one from the {rules.identifiers[name]}'s"
            )
    return errors


def check_files(root: Path, files: list[Path], contract: dict[str, RootContract]) -> list[str]:
    errors = []
    for path in files:
        relative = path.resolve().relative_to(root.resolve()).as_posix()
        if relative.endswith(".tfbackend"):
            errors.append(f"{relative}: backend files are never tracked; track a .tfbackend.template instead")
            continue
        if not is_environment_var_file(relative):
            continue
        name = owning_root(relative, contract)
        if name is None:
            errors.append(f"{relative}: var file outside a root named in config/upstream-contract.yaml")
            continue
        errors.extend(check_var_file(path, relative, contract[name]))
    return errors


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("--root", type=Path, default=Path(__file__).resolve().parents[1])
    parser.add_argument("files", nargs="*", type=Path)
    args = parser.parse_args(argv)

    root = args.root.resolve()
    try:
        contract = load_contract(root / "config" / "upstream-contract.yaml")
    except ContractError as error:
        print(error)
        return 1
    files = [f.resolve() for f in args.files] if args.files else discover(root)
    # Pre-commit runs from the repository root and passes paths relative to it,
    # which may lie outside this directory; only files under root are ours.
    files = [f for f in files if f.is_relative_to(root) and f.is_file()]

    errors = check_files(root, files, contract)
    for error in errors:
        print(error)
    return 1 if errors else 0


if __name__ == "__main__":
    sys.exit(main())
