# TFLint configuration for every root and module in this directory.
#
# One file for everything. The azurerm ruleset only inspects azurerm resources,
# so enabling it in the Databricks root is harmless.

config {
  # Inspect calls to local modules as well as the calling root.
  call_module_type = "local"
}

plugin "terraform" {
  enabled = true
  preset  = "recommended"
}

plugin "azurerm" {
  enabled = true
  version = "0.32.0"
  source  = "github.com/terraform-linters/tflint-ruleset-azurerm"
}

# Every variable and output carries a description and a type.
rule "terraform_documented_variables" {
  enabled = true
}

rule "terraform_documented_outputs" {
  enabled = true
}

rule "terraform_typed_variables" {
  enabled = true
}

# Lowercase names with underscores (HashiCorp style guide).
rule "terraform_naming_convention" {
  enabled = true
}
