# Doubtless Group data platform: Terraform

Infrastructure as code for the Doubtless Group data platform: Azure, Azure Databricks and Unity
Catalog, deployed through Azure DevOps.

This directory is self-contained. It is written to become the root of the repository it is exported
to, so every path below is relative to it. It is a **first draft**: every root formats, validates,
lints and passes its unit tests locally, but nothing has yet been planned against a real
environment. What remains to do, and who does it, is in [Open items](#open-items) and in the
network root's README, which is the handover document for Hexaware.

## Roots

| Root | Owner | State instances | What it builds |
|---|---|---|---|
| `infra/10-landing-zone` | Hexaware | per environment | Network and security. Hexaware write and apply it; our roots read only its published outputs. Its README states the contract and holds the Hexaware handover notes |
| `infra/20-platform-services` | Cynozure | `dev`, `tst`, `stg`, `prd` | Resource groups, Key Vaults, the `trusted` storage account, Access Connectors, workload identities and the Databricks workspaces, on Azure Verified Modules |
| `databricks` | Cynozure | `dev-anl`, `dev-ops`, `tst-anl`, `tst-ops`, `stg-anl`, `stg-ops`, `prd-anl`, `prd-ops` | Everything inside Databricks, kept in the shape of the reference platform it derives from |

Each root has its own README, which says in plain terms what it builds. `infra/modules/` holds
the wrapper modules `20-platform-services` calls, one per service, each with a generated README.

## How values flow between roots

```mermaid
graph LR
    network["infra/10-landing-zone (Hexaware)"]
    resolve_platform["scripts/resolve_upstream.py"]
    platform["infra/20-platform-services"]
    resolve_databricks["scripts/resolve_upstream.py"]
    databricks["databricks"]
    entities["config/entities.yaml"]
    mapping["config/landing-zone-outputs.yaml"]
    entities_and_groups["config/entities.yaml and config/entra-groups.yaml"]

    network -->|terraform output -json| resolve_platform
    entities --> resolve_platform
    mapping --> resolve_platform
    resolve_platform -->|upstream.tfvars.json| platform
    platform -->|terraform output -json| resolve_databricks
    entities_and_groups --> resolve_databricks
    resolve_databricks -->|upstream.tfvars.json| databricks
```

Each root's published outputs go through the resolve step, which adds what `config/` holds and
writes the next root's `upstream.tfvars.json`.

Every root takes values from three places, and `config/upstream-contract.yaml` says which
variable comes from where:

- **Upstream values**, which another root owns. `scripts/resolve_upstream.py` reads that root's
  published `terraform output -json`, adds what `config/` holds, and writes `upstream.tfvars.json`,
  which is passed as the last `-var-file` so that it wins. It fails, and writes nothing, if an
  output is missing, null or empty, or if the outputs were published by another environment. The
  landing zone's outputs are read through `config/landing-zone-outputs.yaml`, so a change in the
  shape Hexaware publish is a change to that file, not to the script. Nobody types an upstream value, and no root reads another's state directly.
- **Identifiers** (subscription, tenant, account and principal IDs): `TF_VAR_*` from the
  pipeline's variable groups. Never tracked. Each is scoped in the contract to the group it comes
  from: `subscription_id` to the environment's, since each environment has its own subscription and
  each holds both of its workspaces; the rest to the tier's. The Databricks root takes its
  subscription from `20-platform-services`' outputs instead.
- **Our configuration**: each root's `environments/*.tfvars`, tracked, with no identifiers.

`scripts/check_var_files.py` rejects a GUID, an upstream variable or an identifier variable in any
var file we maintain, and any tracked `*.tfbackend`, in pre-commit and in CI.

`config/entities.yaml` lists the entities on the platform (today `grp`, the shared group entity, and
`duk`, Doubtless UK). Adding one is data only: a key here and a Reader and Contributor group in
`config/entra-groups.yaml` yield its containers, Access Connector, storage credential, catalogues,
warehouse and grants. The Azure names in the var files and the Entra display names in
`config/entra-groups.yaml` are the ones the Calandra team agreed. Two things are still marked `tbc`:
the values of the five optional tags, and the two storage account names, which had to lose `gdp`
to fit Azure's 24 characters and which Calandra are yet to confirm.

## Set up a machine

macOS, with Homebrew. Windows engineers need WSL: the Makefile and the scripts assume a Unix
shell. From this directory:

```bash
brew bundle --file=Brewfile   # tenv, tflint, terraform-docs, gitleaks, python@3.12
tenv tf install               # installs exactly the Terraform version in .terraform-version
make setup                    # creates .venv, installs the Python tools and the tflint plugins
make hooks                    # installs the pre-commit hooks
```

The tools: [tflint](https://github.com/terraform-linters/tflint) lints the Terraform,
[checkov](https://www.checkov.io/) scans it for insecure settings, [gitleaks](https://github.com/gitleaks/gitleaks)
scans for secrets, and [pre-commit](https://pre-commit.com/) runs the fast checks before each commit.

`Brewfile` is the list of command-line tools, installed by `brew bundle`. Terraform is not among
them: it left Homebrew's main repository after HashiCorp [changed its licence](https://www.hashicorp.com/license-faq),
and a Homebrew formula could not pin a version anyway. [tenv](https://github.com/tofuutils/tenv), which is a
formula, installs the exact version in `.terraform-version`, and `make versions` fails if the
installed one differs. `make setup` uses `GITHUB_TOKEN`, or the GitHub CLI's token if it is signed
in, for `tflint --init`, because GitHub's anonymous rate limit is easily exhausted.

## Check your work

`Makefile` is the one entry point for local checks and for CI. `make <target>` runs the named
recipe; none of the targets produces a file, so every run repeats the work rather than skipping
what looks up to date. `make help` lists them.

```bash
make check    # formatting, validation, linting, unit tests, checkov, var-file and standalone checks, gitleaks
make ci       # make check, then the sanitisation sweep (needs SWEEP_PATTERNS_FILE)
```

- `make test` runs [`terraform test`](https://developer.hashicorp.com/terraform/language/tests) once per state instance, each with that instance's tracked var
  files and a hand-written upstream fixture, then pytest for the scripts. Every test runs in plan
  mode with mocked providers: no credentials, and no network beyond the registries. Each root's
  README says what its tests cover.
- `make scan` runs checkov. It has no Databricks checks, so for `databricks/` the unit tests are the
  security check.
- `make checks` runs the var-file checks and the standalone check. This directory is complete in
  itself, so the standalone check fails if a comment, description or README cites a document from
  outside it. Write the reason into the text instead; public links, such as Microsoft Learn pages,
  are fine.
- `make sweep` checks for another organisation's identifiers left over from the reference
  platform. Its patterns are never stored in any repository: set `SWEEP_PATTERNS_FILE` to the file
  Cynozure keep, or leave the sweep to CI, where a secure file supplies them.
- `make lock` regenerates each root's [dependency lock file](https://developer.hashicorp.com/terraform/language/files/dependency-lock)
  with hashes for Linux, macOS (both architectures) and Windows
  ([`terraform providers lock`](https://developer.hashicorp.com/terraform/cli/commands/providers/lock)).
  The lock files are committed, so plan and apply run the provider builds the tests ran.
- `make docs` regenerates the inputs and outputs tables in each README from the variable and
  output descriptions, with [terraform-docs](https://terraform-docs.io/). Edit the descriptions,
  never the tables.

`pipelines/validate.yml` runs `make ci` on a hosted agent, with no service connection, because
nothing in it touches a cloud. Azure Repos ignores a YAML pull-request trigger
([Build Azure Repos Git repositories](https://learn.microsoft.com/en-us/azure/devops/pipelines/repos/azure-repos-git),
checked 30 September 2026), so it gates pull
requests only once it is added as a Build validation branch policy on `development`, `production`
and `main`. The plan and apply pipelines are Hexaware's, and are described in the network root's
README.

## Read the plan

```bash
make plan     # about ten seconds; writes plans/, which is gitignored
```

`make plan` prints what each state would create, so that a plan can be read against a design and a
missing resource stands out. It runs `terraform test -verbose` once per state instance listed in
the Makefile (all four environments for `infra/20-platform-services`; dev-anl, dev-ops, tst-ops,
stg-ops, prd-anl and prd-ops for `databricks`) using the
instance's tracked var files and fixtures, then summarises each plan. Nothing stubs a Verified
Module, so the plan lists every resource those modules create: storage accounts, Key Vaults,
workspaces and private endpoints as well as our own role assignments and containers.

For each instance `plans/` holds two files:

- `<root>-<instance>.md`: a table of every resource address with its type, action and name, then a
  count by type. Read this against the design. An azapi resource shows the Azure resource type it
  manages, because every azapi resource has the same Terraform type.
- `<root>-<instance>.txt`: the full printed plan, with every attribute.

Make repeats the whole run each time, because the plan depends on every file in the roots and the
target produces no file for Make to compare. It deletes the old `plans/` files first, so none is
stale.

**What it cannot show.** It is a plan against mock providers, with no credentials and no network.
Values Azure computes read 'unknown'. The group and metastore lookups return the fixtures' values. Drift, provider errors and missing permissions appear only in a real plan. So a
resource missing here is a real gap, but one present here can still fail against Azure.

## A local dry-run

The option is kept open, with no code of its own. To plan a root against a sandbox subscription:

1. Add a `backend_override.tf` (gitignored) with `terraform { backend "local" {} }`. Terraform
   merges [override files](https://developer.hashicorp.com/terraform/language/files/override) over
   the configuration, so the tracked backend stub is left alone.
2. Export the root's identifier variables as `TF_VAR_*`.
3. Produce `upstream.tfvars.json` with `scripts/resolve_upstream.py` from real upstream outputs.
   `20-platform-services` needs a network shaped like `infra/10-landing-zone`'s contract.
4. `terraform init`, then `terraform plan`, with the root's var files and the upstream file last.

## First deployment

Each state reads only its own environment's published outputs. Serverless compute, and with it
each tier's NCC, is parked: see the Databricks root's README. **Dev needs nothing from
production**, so it can be deployed first and used on its own. Before any Databricks plan, both
pipeline identities must be account admins and members of the Databricks admin group (see the
Databricks root's README).
The region's metastore is shared with other programmes, and its automatic assignment of new
workspaces must stay on: every Databricks state stops at plan time if its workspace is not
attached to it.

**Before the first Databricks apply in each tier, check the names.** Catalogues, storage
credentials and external locations are unique across the shared metastore. From any workspace
already on it, run `databricks catalogs list`, `databricks storage-credentials list` and
`databricks external-locations list`, and confirm none uses a name this platform creates
(`<env>_<entity>`, `<env>-<entity>-unity-catalog-credential`, `<env>_<entity>_landing`, `_export`
and `_storage`). A clash would fail our apply; it would not touch the other programme's object.
If `<env>-anl` fails on a name clash, do not run `<env>-ops`: it binds `<env>_<entity>` by name, and
would then try to bind the other programme's catalogue to our workspace.

**Browser sign-in fails until the web-auth workspace exists.** With public access off, a browser
needs the region's one `browser_authentication` private endpoint, which belongs to a dedicated
web-auth workspace in the hub that Hexaware build (see the network root's README). Nothing in our
roots creates it. The REST API, Terraform and the pipelines do not need it, so the first
deployment can proceed without it, but no one can sign in to the UI until it is in place.

1. **`10-landing-zone`**, per environment, by Hexaware.
2. **`20-platform-services`** for the environment.
3. **`dev-anl`**, then **`dev-ops`**, which binds `dev_grp` and `dev_duk`. The NCC, its rules and
   their endpoint approvals come back with serverless compute.
4. **`tst-anl` then `tst-ops`, `stg-anl` then `stg-ops`**, once their own `20-platform-services`
   states exist. Each operational state binds its environment's catalogues, so it follows its
   analytical state.
5. **`prd-anl`**, then **`prd-ops`**, which binds `prd_grp` and `prd_duk`. `--singletons-only`,
   which writes the entity lists and the connectors empty, existed to create the production NCC
   before production's catalogues; it has nothing to create while serverless compute is parked.
6. **The masking functions:** run the job in the `masking_functions_job_id` output of each
   analytical state, then set `enable_masking_policies = true`.
7. **Close serverless compute** in each workspace after its first apply, as the Databricks root's
   operating notes describe.

**Reading production from lower environments** is off until it is needed, and its network
provision is parked with serverless compute. Restored, it is in `prd-anl`: set
`enable_prd_storage_on_nonprod_ncc = true`, apply, and approve the two new endpoints on
production's trusted account, in production's subscription. Serverless
compute in dev, tst and stg then has a route to production's storage. The read itself also needs a
read-only binding of production's catalogues to the lower workspace (`catalog_reader_workspace_ids`)
and the users' grants. Classic clusters are not covered, with serverless compute parked or not:
they need Hexaware to route the lower environment's network to production's storage endpoints.

**What the first real plan and apply must prove.** The unit tests run against mocks, so these are
the points to watch when the roots first meet Azure and Databricks:

- `azure-cli` authentication for the Databricks provider across a long run.
- Automatic identity management group lookups, and which entitlements `sp-databricks` needs for
  its members' jobs to run.
- That each new workspace is listed against the metastore, and that the metastore's Permissions
  tab shows a `_workspace_admins_` entry for it: every state creates its Unity Catalog objects
  through the privileges that entry carries.
- That membership of the Databricks admin group gives the pipeline identity what it needs once
  ownership of each object passes to that group.
- That every environment's pipeline identity creates catalogues, credentials and locations with the
  metastore privileges workspace admins get from automatic enablement: the shared metastore has no
  owner of ours.
- The secret scope with its vault's public network access disabled: that Azure Databricks creates
  the scope and a cluster reads a secret through the trusted services bypass. Microsoft's Key Vault
  documentation says the bypass survives disabled public access; the secret scope documentation
  still describes public access from selected networks.
- A cluster start and a browser sign-in from the hub, which together prove the private endpoint
  layout.
- The workspace storage firewall: that Azure Databricks gives the workspace's storage connector
  access to the account itself, that the account's `blob` and `dfs` endpoints approve (they may
  need approving on the account), and that the workspace reports the account's name where the
  wrapper reads it, `properties.parameters.storageAccountName`.
- Applying the `class.*` governed tags: granting `APPLY` on them is not expressed here.

## Secrets in state

None, in either root. No resource here creates a secret, and the Databricks secret scope stores
only its vault's reference.

## Design decisions

The decisions the code rests on, as agreed between Cynozure, Doubtless and the Calandra Platform
team during September 2026. Where the code seems odd, the reason is usually here.

**Roots and ownership**

- Three roots, each with its own state. Network and security are Hexaware's; the platform services
  and the Databricks configuration are ours. State storage and build agents belong to the Doubtless
  data team and Hexaware; the Entra groups are created by hand by the Calandra team. None of those
  is Terraform in this repository.
- Roots pass values through published outputs and the resolve step, never by reading each other's
  state or by retyping values. The Entra groups (by display name), the metastore (by region)
  and, once serverless compute is restored, the tier's NCC (by name) are looked up.
- Var files are tracked, so that configuration is reviewable, and carry no identifiers or secrets.
- The code follows the [HashiCorp style guide](https://developer.hashicorp.com/terraform/language/style),
  including where the reference platform departs from it.
- The Databricks root keeps the reference platform's flat shape, file layout, resource addresses
  and variable names, so that a diff against it stays readable and its patterns carry across. Its
  'opco' is 'entity' here. Features Doubtless do not use are pruned; additions go in new files.
  Compute policies and masking follow the reference configuration as it stands.
- The platform root composes one wrapper module per service around an exact
  [Azure Verified Module](https://azure.github.io/Azure-Verified-Modules/) version. The wrappers fix
  the security settings, so no var file can relax them. Every Azure resource comes from a Verified
  Module, with one documented exception, and `scripts/check_avm_conformance.py` enforces it; the
  platform root's README lists each resource and its module. The Databricks root creates no Azure
  resource.
- Version pins: Terraform `~> 1.16` (1.16.4 in `.terraform-version`), `databricks ~> 1.133`,
  `azurerm ~> 4.81` and `azapi ~> 2.12`. The Verified Modules still constrain azurerm below 5.0.
  Lock files are committed.
- Branching, once the code is in the client's Azure DevOps organisation: a long-lived `development`
  branch deploys dev, tst and stg, and `production` deploys prd, with environment approvals before
  each gated environment. `main` is the default branch only until then.
- One pipeline identity per tier, non-production and production, planning and applying both of our
  roots, from a private agent pool per tier.

**Subscriptions, network and region**

- Germany West Central is the only region.
- One subscription per environment: dev, tst, stg and prd, each holding both of its workspaces.
  The Databricks root takes its subscription from the platform root's outputs.
- Two workspaces in every environment, analytical and operational, each with its own host,
  container and private endpoint subnets inside the environment's VNet. The storage accounts, Key
  Vaults and resource groups are shared by the two. Four settings the reference platform's
  landing-zone plan asks for are deliberately not adopted, because the wrappers fix the security
  posture: storage soft delete stays on, key-based storage authentication stays off, Access
  Connectors are assigned per container rather than through groups, and the private DNS zones
  stay central rather than per workload.
- Every workspace is VNet-injected into the network root's VNet, with secure cluster connectivity
  and public network access off, and is reached through one `databricks_ui_api` private endpoint
  in its own VNet. Each workspace's endpoints sit in its own workload's private endpoint subnet;
  the storage accounts' and Key Vaults' sit in the subnet the network root publishes for shared
  resources. All register in the central private DNS zones. Anything that must share the VNet's subscription is
  rejected at plan if it does not.
- Browser sign-in goes through the region's one `browser_authentication` endpoint, which belongs
  to a web-auth workspace Hexaware build in the hub. Nothing of ours creates one; the tests assert
  it.
- Parked with serverless compute: two Network Connectivity Configurations, one per tier, where the
  reference platform has one.
  `dev-anl` owns the non-production NCC, `prd-anl` the production one, and each analytical state
  adds the rules for its own storage. A development merge therefore cannot change production's
  network, and dev depends on nothing in production.
- Lower environments may read production's catalogues, but the serverless network route (parked
  with serverless compute) is a switch in `prd-anl` that is off until it is needed, and the read
  itself is a read-only catalogue binding plus grants.
- Dev is deployed first and must work exactly as the other environments will.
- Diagnostic settings go to the Landing Zone's central Log Analytics workspace. We create none.

**Storage**

- Three resource groups per environment, by type of resource: `storage`, `databricks` and `ops`.
  `ops` holds the two Key Vaults.
- One ADLS Gen2 account, `trusted`. Each entity has three containers in it: `-uc`, `-landing` and
  `-export`, which serve both workspaces.
- An `untrusted` account for third-party data is parked (2026-10-14): security want it in a separate
  subscription with its own rules, and that subscription is not built yet. The code is commented out
  under an `UNTRUSTED STORAGE PARKED` note in `infra/20-platform-services` (`main.tf`, `locals.tf`,
  `variables.tf`, `outputs.tf`, the four var files and the tests). To restore it, delete the note
  and the blank line after it, strip one leading `# ` from each parked line, run `terraform fmt`,
  widen the narrowed test lines back to both accounts, along with `tests/gen_overrides.py`,
  `tests/agreed_names.py`, the `entities` description and the `main.tf` header (the parking commit,
  found with `git log --grep "Park the untrusted"`, shows every line), add
  `untrusted_storage_account_name` back to the four Databricks fixtures, and retire
  `scripts/tests/test_untrusted_storage_parked.py`. It may be better restored as its own root in the
  new subscription.
- One Access Connector per entity, with *Storage Blob Data Contributor* on that entity's containers
  only and *Storage Blob Delegator* on the account, so no single identity can reach every entity's
  data. The reference platform shared one connector.
- Containers are created by the platform root through Resource Manager, not by the Databricks root
  through the storage data plane, which private networking blocks.
- Locally redundant storage outside production, zone-redundant in production, for `trusted` and each
  workspace's own storage account. The wrappers allow only those two.
- Microsoft-managed keys with infrastructure encryption; customer-managed keys only by exception.
- Two Key Vaults per environment: the platform's, in Azure RBAC mode, and a separate access-policy
  vault for the Databricks secret scope, because Key Vault-backed scopes support only the
  access-policy model. Neither has public network access.
- Delete locks on the storage accounts and Key Vaults in production only, to start.
- Each workspace's own storage account, which Azure creates in the managed resource group for the
  DBFS root, job output and system data, has its firewall on. By default it accepts authenticated
  connections from any network, which would leave one account in each workspace outside the
  private design. Azure Databricks reaches it through an Access Connector of the workspace's own,
  and the VNet through a `blob` and a `dfs` endpoint.

**Identity and access**

- Entra groups are created by hand by the Calandra team and reach Databricks through automatic
  identity management, not SCIM. The Databricks root looks each one up by display name, from
  `config/entra-groups.yaml`, and creates none.
- Two admin groups: the Databricks admin group, which is workspace admin and owns everything the
  Databricks root creates, and the platform admin group, for the Azure data services. This repository does not give it the
  Databricks account-admin role: the account is shared.
- Two personas, engineers and analysts, carry workspace entitlements and compute rights and never a
  data grant, or a persona could read every entity's data.
- Two data groups per entity, a Reader and a Contributor. Readers read in every environment.
  Contributors also write in dev and tst; in staging and production only workloads write, and a
  commented-out var-file override would let Contributors write there if that is ever wanted.
- Workloads act through one `sp-databricks` Entra group per tier, never one by one. The workload
  identities are user-assigned managed identities, one per entity, created by the platform root
  and added to the group by the Calandra team.
- The platform admin group's Azure roles are assigned by the platform root only if the Calandra
  privileged-access process does not cover them. The input is empty by default.

**Databricks configuration**

- Two entities from the first deployment, `grp` and `duk`, each with one catalogue per
  environment, `<env>_<entity>`, bound to both of the environment's workspaces, its own storage
  credential, external locations, warehouse and grants. `grp` plays the reference platform's shared
  domain: its catalogue holds the `governance` schema and the masking functions.
- The reference platform gave its operational workspace catalogues of its own. Here each
  environment has one catalogue per entity instead: Doubtless's central data team supports every
  part of the platform, so one owner per entity's data is easier to manage, and governance stays
  tight through the grants. The analytical state creates the catalogues and owns every grant; the
  operational state binds them. Either workspace can be made read-only with `catalog_binding_type`.
- Terraform creates only the `landing` and `export` schemas and their volumes. Bronze, silver and
  gold belong to the bundles, as on the reference platform.
- The region's metastore and the Databricks account are shared with other programmes' workspaces,
  and this repository changes nothing that already exists in them. The account-admin role, the
  system schemas and access to system tables reach every workspace in the account, so they are left
  to whoever runs it. What this platform adds at account level is its own: (once serverless compute
  is restored) the two NCCs, their rules and workspace bindings, its usage policies, and its
  workspaces' group assignments.
  Anything this platform finds by name (the NCCs) is named for the project, and so are the usage
  policies; the catalogues, credentials and locations it only creates keep their agreed names,
  because a clash fails our apply and leaves the other programme's object alone.
- Masking is on by default for every catalogue, in both workspaces, with the
  PII-authorised group excepted. Enabling it takes two changes: create the functions with the job,
  then switch the policies on.
- Classic PRO SQL warehouses while serverless compute is parked: one automation warehouse for
  workloads and one per entity for its data groups.
- Parked with serverless compute: a serverless usage policy per workspace carrying the mandatory
  tags, so that serverless compute is attributed.
- Serverless compute is parked until Doubtless infrastructure security approve it: nothing sets it
  up or runs on it, and predictive optimisation is off on our catalogues.
- Four mandatory tags, `Project`, `Environment`, `WorkspaceType` and `ManagedBy`, plus five optional
  ones carried as `tbc`: `CostCentre`, `BusinessEntity`, `Application`, `Owner` and
  `DataClassification`.
- Azure resource names are the ones the Calandra team agreed, set in each root's var files and held
  once for the tests in `infra/20-platform-services/tests/agreed_names.py`. There is no naming
  module.
- No Power BI or dbt service principals for now.

## Open items

Nothing here blocks the first dev deployment except the first three Hexaware items. Each is with
its owner.

**With Hexaware** (the network root's README has the detail)

- Publish the network root's outputs after every apply, as its README's outputs contract states, and decide where the resolve step reads them from. Until the `outputs` container exists, the dev platform pipeline reads them from the landing-zone pipeline's `handoff-outputs` artifact.
- Deploy the shared web-auth workspace, in the hub, from the network root. It holds the region's one
  `browser_authentication` endpoint and sits in a subscription other than the environments' own, which is
  still to be confirmed. Until it exists no one can sign in to a workspace through a browser.
- Confirm six subnets per environment, three per workload (host, container and private
  endpoint), published as `databricks_subnets` and `private_endpoint_subnets` in the `network`
  output (`infra/20-platform-services/tests/fixtures/network-outputs-dev.json` shows the shape). Host and
  container are force-new on the workspace, so this is needed before dev is applied. Each
  environment has ten private endpoints: seven in the analytical workload's endpoint subnet (the
  two storage endpoints, the two Key Vault endpoints and the analytical workspace's three) and
  three in the operational workload's, so please size the two subnets for them. The operational
  workload's host and container subnets must reach the analytical workload's endpoint subnet,
  where the shared storage and Key Vault endpoints sit, so per-workload NSGs and route tables must
  not isolate the two workloads.
- Say whether Landing Zone policy creates the private endpoints' DNS zone groups. If it does, each
  wrapper's `private_endpoint.manage_dns_zone_group` input is set to `false`.
- The plan and apply pipelines, the private agent pools, the service connections and the runbooks.

**With the Calandra Platform team**

- Confirm the two storage account names with `gdp` dropped, which was needed to fit Azure's 24
  characters.
- Confirm the spelling and the values of the five optional tags.
- Say whether a Landing Zone policy already deploys diagnostic settings to the central Log
  Analytics workspace for these resource types. If it does, either our resource groups are excluded
  from it or we drop ours: a second setting sending the same category to the same workspace is
  rejected.
- Grant each tier's pipeline identity the right to use the central Log Analytics workspace as a
  diagnostic destination, and confirm the workspace's access mode.
- Create the Entra groups, add each workload identity to its tier's `sp-databricks` group.

**With Doubtless and Cynozure**

- When to switch on lower environments reading production, and which workspaces bind.
- Whether either workspace should be read-only for the shared catalogues (`catalog_binding_type`).
  Both are read-write today; the answer depends on what the operational workspace is for.
- Whether Power BI or dbt need service principals later. The Power BI service would also need a
  data gateway to reach the workspace storage accounts, whose firewalls are on.
- Serverless compute is parked until Doubtless infrastructure security approve it (work item
  107902). Until then, serverless notebooks, jobs and pipelines stay open in each workspace unless
  closed by hand, because the provider cannot manage the two default serverless compute objects.
  Revisit when the provider can, or when serverless is approved.
- Parking serverless compute loses functionality: predictive optimisation (automatic
  `OPTIMIZE`, `VACUUM` and `ANALYZE`) runs only on serverless, so table maintenance is manual
  until a scheduled job on classic compute is built or serverless is approved. Warehouses also
  start in minutes, not seconds. See the Databricks root's README for the full list.

**With the security team**

- Where the `untrusted` account will live, in the separate subscription, and what copies third-party
  data from it into the trusted landing containers. There is no use case yet, so this is scaffolding.
