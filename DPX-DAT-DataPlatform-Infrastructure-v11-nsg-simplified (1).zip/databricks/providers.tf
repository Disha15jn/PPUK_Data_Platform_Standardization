################ Databricks Account Provider ###############
# Account-level operations: group lookups, workspace assignment and the
# metastore lookup. The NCC and the usage policy, parked with serverless
# compute, use it too.

provider "databricks" {
  alias      = "account"
  host       = "https://accounts.azuredatabricks.net"
  account_id = var.databricks_account_id
}

################ Databricks Workspace Provider ###############
# Workspace-level operations: catalogs, grants, compute, secret scopes.

provider "databricks" {
  host = local.workspace_url
}

# Neither provider holds a credential. In the pipeline, DATABRICKS_AUTH_TYPE is
# azure-cli, inside an Azure CLI task on the tier's service connection, so the
# provider takes tokens from the federated sign-in.
