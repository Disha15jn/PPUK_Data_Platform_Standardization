/**
 * Unity Catalog Configuration
 *
 * Manages the per-entity storage credentials, the catalogs, their workspace
 * bindings and the catalog-level grants that are not per entity data group.
 * Only the analytical state creates them; the operational state binds.
 */

################ Unity Catalog - Storage Credentials ###############

# One storage credential per entity, on that entity's Access Connector,
# which has rights on the entity's own containers only. The reference platform
# shared one credential across every entity, so one identity could reach every
# entity's container.
resource "databricks_storage_credential" "catalog_storage" {
  for_each     = local.owns_catalogs ? local.business_domain_catalogs : {}
  name         = "${local.metastore_object_name_prefix}-${lower(each.key)}-unity-catalog-credential"
  comment      = "Storage credential for ${var.environment} ${var.workspace_type} ${each.key} catalog storage"
  owner        = try(local.platform_admins.display_name, null)
  force_update = true # Allow updating the access connector even with dependent locations

  azure_managed_identity {
    access_connector_id = var.access_connectors[each.key].id
  }
}

################ Storage Credential Permissions ###############

# The reference platform's explicit rights for the pipeline identity on the
# credentials it creates. They cannot keep it from being locked out when
# ownership passes to the Databricks admin group: from then on the identity can
# grant on a credential only as a member of that group, which owns the
# credentials. That membership is a prerequisite of this root (README), and while
# it holds these grants are redundant.
# MANAGE: update and manage the credential itself
# CREATE_EXTERNAL_LOCATION: create external locations using it
# READ_FILES, WRITE_FILES: read and write through it
resource "databricks_grants" "catalog_storage_credential" {
  for_each           = databricks_storage_credential.catalog_storage
  storage_credential = each.value.id

  grant {
    principal  = var.service_principal_application_id
    privileges = ["MANAGE", "CREATE_EXTERNAL_LOCATION", "READ_FILES", "WRITE_FILES"]
  }
}

################ Unity Catalog - Catalogs ###############

# One catalog per entity per environment, bound to both of its workspaces. The
# shared entity's also holds the governance schema and masking functions.
resource "databricks_catalog" "business_domain" {
  for_each       = local.owns_catalogs ? local.business_domain_catalogs : {}
  name           = each.value.name
  comment        = "${each.key} business domain data for ${var.environment}"
  owner          = try(local.platform_admins.display_name, null)
  force_destroy  = false
  isolation_mode = "ISOLATED" # Only visible to explicitly bound workspaces
  storage_root   = databricks_external_location.business_domain_storage[each.key].url

  # Serverless compute is parked (see sql-warehouses.tf). Predictive
  # optimisation runs OPTIMIZE, VACUUM and ANALYZE on serverless compute and is
  # on by default for the account, so it is off on our catalogues, and their
  # schemas and tables inherit that. To restore, set this to "INHERIT" and apply:
  # the attribute is computed, so deleting the line alone would leave DISABLE
  # in state.
  enable_predictive_optimization = "DISABLE"

  properties = {
    environment     = var.environment
    tenant          = var.tenant
    data_class      = var.data_classification
    business_domain = each.value.business_domain
    requires_rls    = each.value.requires_rls
    managed_by      = "terraform"
    cost_center     = "data-platform"
  }
}

################ Catalog Workspace Bindings ###############

# Bind each entity catalog to this workspace, in both tracks. The analytical
# state binds the catalogs it creates; the operational state binds the same
# catalogs by name, so <env>-anl applies first. binding_type is the switch for
# making one workspace read-only.
resource "databricks_workspace_binding" "business_domain" {
  for_each       = var.create_business_domain_catalogs ? local.business_domain_catalogs : {}
  securable_name = each.value.name
  workspace_id   = var.workspace_id
  binding_type   = var.catalog_binding_type

  depends_on = [databricks_catalog.business_domain]
}

# Read-only bindings for other environments' workspaces, from
# catalog_reader_workspace_ids, on the catalogs this state creates.
resource "databricks_workspace_binding" "business_domain_readers" {
  for_each = {
    for pair in setproduct(keys(databricks_catalog.business_domain), tolist(var.catalog_reader_workspace_ids)) :
    "${pair[0]}-${pair[1]}" => {
      catalog      = pair[0]
      workspace_id = pair[1]
    }
  }
  securable_name = databricks_catalog.business_domain[each.value.catalog].name
  workspace_id   = each.value.workspace_id
  binding_type   = "BINDING_TYPE_READ_ONLY"
}

################ Catalog Permissions ###############

# The reference platform's explicit catalog rights for the pipeline identity.
# As with the credentials, applying them already needs membership of the
# Databricks admin group, which owns the catalogs and gives every right.
# MANAGE: read and manage workspace bindings, grants and volume metadata
# USE_CATALOG, USE_SCHEMA: catalog and schema access
# CREATE_SCHEMA: create landing, export and governance
resource "databricks_grant" "sp_catalog_usage" {
  for_each   = databricks_catalog.business_domain
  catalog    = each.value.name
  principal  = var.service_principal_application_id
  privileges = ["MANAGE", "USE_CATALOG", "USE_SCHEMA", "CREATE_SCHEMA"]
}

# The Databricks admin group, in lookup mode. It owns the catalogs too; the
# explicit grant keeps the reference platform's shape.
resource "databricks_grant" "env_platform_admins_catalog" {
  for_each   = local.has_group.platform_admins ? databricks_catalog.business_domain : {}
  catalog    = each.value.name
  principal  = local.platform_admins.display_name
  privileges = ["ALL_PRIVILEGES", "MANAGE"]
}

# Personas get no catalog grants. In lookup mode the reference
# platform gave its environment-wide role keys the entity privileges on every
# catalog; with those keys now personas, that would let a persona member read
# every entity's data without its data group.

################ Shared Catalog - Governance Schema ###############

# The governance schema, for the masking functions, in the shared catalog.
# Analytical workspaces only: the operational workspace reaches it through the
# binding.
resource "databricks_schema" "shared_governance" {
  count        = local.owns_catalogs && contains(keys(databricks_catalog.business_domain), local.shared_business_domain) ? 1 : 0
  catalog_name = databricks_catalog.business_domain[local.shared_business_domain].name
  name         = "governance"
  comment      = "Data governance functions - PII masking and compliance utilities"
  owner        = try(local.platform_admins.display_name, null)

  properties = {
    managed_by = "terraform"
    purpose    = "data governance and compliance"
  }
}

################ Shared Catalog Permissions ###############

# The operational state grants nothing here or anywhere: the analytical state
# owns every grant, which holds across the metastore. databricks_grant is
# authoritative for one principal on one securable, so a grant from a second
# state would overwrite it on every apply.

# Every other entity's Contributor group may use the masking functions in the shared
# catalog, and nothing more: no SELECT on the shared entity's data.
# The shared entity's own group has EXECUTE in its catalog grant instead. The
# Readers' equivalent is in entity-readers.tf.
resource "databricks_grant" "entity_engineers_shared_catalog" {
  for_each = local.owns_catalogs && contains(keys(databricks_catalog.business_domain), local.shared_business_domain) ? {
    for entity, group in local.all_entity_engineers : entity => group if entity != local.shared_business_domain
  } : {}

  catalog    = databricks_catalog.business_domain[local.shared_business_domain].name
  principal  = each.value.display_name
  privileges = ["USE_CATALOG", "USE_SCHEMA", "EXECUTE"]
}
