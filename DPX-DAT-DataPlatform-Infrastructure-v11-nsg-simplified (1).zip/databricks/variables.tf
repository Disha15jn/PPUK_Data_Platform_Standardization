# Variables keep the reference platform's names, so its patterns carry
# across. Each comes from one of three places (config/upstream-contract.yaml):
#
#   Identifiers  TF_VAR_* from the tier's variable group. Never tracked. The
#                subscription is upstream: 20 publishes the one it deployed into.
#   Upstream     upstream.tfvars.json, written by scripts/resolve_upstream.py from
#                infra/20-platform-services's outputs and config/. Never set in a
#                var file we maintain; scripts/check_var_files.py rejects them.
#   Our configuration
#                environments/common-{anl,ops}.tfvars and environments/<instance>.tfvars.

################ Identifiers ###############

variable "databricks_account_id" {
  description = "Identifier. The Databricks account ID. From the tier's variable group."
  type        = string

  validation {
    condition     = can(regex("^[0-9a-f]{8}-([0-9a-f]{4}-){3}[0-9a-f]{12}$", var.databricks_account_id))
    error_message = "databricks_account_id must be a lower-case GUID."
  }
}

variable "service_principal_application_id" {
  description = "Identifier. Application ID of the tier's pipeline identity, which deploys this root and keeps explicit grants on what it creates. From the tier's variable group."
  type        = string

  validation {
    condition     = can(regex("^[0-9a-f]{8}-([0-9a-f]{4}-){3}[0-9a-f]{12}$", var.service_principal_application_id))
    error_message = "service_principal_application_id must be a lower-case GUID."
  }
}

################ Upstream: infra/20-platform-services ###############

variable "access_connectors" {
  description = "Upstream. Each entity's Access Connector: its resource ID and its identity's principal ID. Replaces the reference platform's single metastore Access Connector: each entity's storage credential uses its own."
  type = map(object({
    id           = string
    principal_id = string
  }))
  nullable = false

  validation {
    condition     = alltrue([for connector in values(var.access_connectors) : can(regex("(?i)^/subscriptions/[^/]+/resourceGroups/[^/]+/providers/Microsoft\\.Databricks/accessConnectors/[^/]+$", connector.id))])
    error_message = "Each access connector ID must be an Azure Databricks Access Connector resource ID."
  }

  validation {
    condition = var.workspace_type != "analytical" || !var.create_business_domain_catalogs || alltrue([
      for entity in var.business_domains : contains(keys(var.access_connectors), entity)
    ])
    error_message = "Every entity needs its Access Connector in access_connectors: the analytical state creates each entity's storage credential on it."
  }
}

variable "key_vault_name" {
  description = "Upstream. Name of the secret scope's Key Vault: the access-policy vault, not the platform's."
  type        = string
}

variable "resource_group_name" {
  description = "Upstream. Resource group of the secret scope's Key Vault."
  type        = string
}

variable "storage_account_name" {
  description = "Upstream. The trusted storage account, which holds each entity's landing and export containers."
  type        = string
}

variable "subscription_id" {
  description = "Upstream. The subscription infra/20-platform-services deployed this environment into, which holds the secret scope's Key Vault; the vault's resource ID is built from it. Each environment has its own, which both of its states share."
  type        = string

  validation {
    condition     = can(regex("^[0-9a-f]{8}-([0-9a-f]{4}-){3}[0-9a-f]{12}$", var.subscription_id))
    error_message = "subscription_id must be a lower-case GUID."
  }
}

variable "unity_catalog_storage" {
  description = "Upstream. The trusted storage account, which holds each entity's Unity Catalog managed storage container."
  type        = string
}

variable "workspace_id" {
  description = "Upstream. The workspace's numeric ID in the Databricks control plane."
  type        = string

  validation {
    condition     = can(regex("^[0-9]+$", var.workspace_id))
    error_message = "workspace_id must be the numeric workspace ID."
  }
}

variable "workspace_name" {
  description = "Upstream. Name of the Azure Databricks workspace."
  type        = string
}

variable "workspace_region_number" {
  description = "Upstream. The number in the workspace URL, adb-<workspace_id>.<number>.azuredatabricks.net."
  type        = string

  validation {
    condition     = can(regex("^[0-9]+$", var.workspace_region_number))
    error_message = "workspace_region_number must be a number."
  }
}

variable "workspace_track" {
  description = "Upstream. The track the resolve step ran for, 'anl' or 'ops'. It must match workspace_type: a mismatch means the upstream file was resolved for the other workspace, and the state would bind and assign that workspace instead of its own."
  type        = string

  validation {
    condition     = contains(["anl", "ops"], var.workspace_track)
    error_message = "workspace_track must be anl or ops."
  }

  validation {
    condition     = (var.workspace_track == "ops") == (var.workspace_type == "operational")
    error_message = "workspace_track must match workspace_type: the upstream file was resolved for the other workspace."
  }
}

# Serverless compute is parked: see network-connectivity.tf. Nothing reads this
# variable while it is, but it stays declared because the resolve step still
# writes it, and an undeclared value would warn on every plan.
# tflint-ignore: terraform_unused_declarations
variable "ncc_private_endpoint_rules" {
  description = "Upstream. NCC private endpoint rules for this environment's own trusted storage, blob and dfs, which an analytical state adds to its NCC. Empty in every operational state, which shares its environment's account."
  type = list(object({
    name        = string
    resource_id = string
    group_id    = string
  }))
  default  = []
  nullable = false

  validation {
    condition     = alltrue([for rule in var.ncc_private_endpoint_rules : contains(["blob", "dfs"], rule.group_id)])
    error_message = "Each NCC private endpoint rule targets blob or dfs."
  }

  # Each environment's storage is in its own subscription.
  validation {
    condition     = alltrue([for rule in var.ncc_private_endpoint_rules : lower(try(split("/", rule.resource_id)[2], "")) == lower(var.subscription_id)])
    error_message = "Each NCC private endpoint rule targets this environment's own storage, in var.subscription_id: a state adds no rules for another environment's."
  }
}

################ Upstream: config/ ###############

variable "business_domains" {
  description = "Upstream, from config/entities.yaml. The entity keys. Each has one catalog per environment, {env}_{entity}: the analytical state creates it and the operational state binds it."
  type        = list(string)
  default     = []
  nullable    = false
}

variable "external_group_names" {
  description = <<-EOT
    Upstream, from config/entra-groups.yaml. Role key => Entra group display name, looked
    up in the Databricks account. Keys:
    - platform_admins: the Databricks admin group. Workspace ADMIN; owns catalogs,
      credentials and locations.
    - engineers, analysts, scientists: personas. Entitlements and compute, never data.
    - sp_databricks: the tier's workload group. All workload access.
    - pii_authorized: excepted from every masking policy.
  EOT
  type        = map(string)
  default     = {}
  nullable    = false

  validation {
    condition     = alltrue([for key in keys(var.external_group_names) : contains(["platform_admins", "engineers", "scientists", "analysts", "sp_databricks", "pii_authorized"], key)])
    error_message = "external_group_names keys must be platform_admins, engineers, scientists, analysts, sp_databricks or pii_authorized."
  }

  validation {
    condition     = contains(keys(var.external_group_names), "platform_admins")
    error_message = "external_group_names must name the Databricks admin group as platform_admins."
  }
}

variable "external_entity_group_names" {
  description = "Upstream, from config/entra-groups.yaml. Per entity, its Contributor group under the key 'engineers', which the reference platform's writing catalog, warehouse and volume grants hang off, and its Reader group under 'analysts'. 'scientists' is left unset."
  type        = map(map(string))
  default     = {}
  nullable    = false

  validation {
    condition     = alltrue([for roles in values(var.external_entity_group_names) : alltrue([for key in keys(roles) : contains(["engineers", "scientists", "analysts"], key)])])
    error_message = "Each entity's groups may use only the keys engineers (the Contributor), analysts (the Reader) and scientists: any other key would be ignored without warning."
  }

  validation {
    condition     = alltrue([for roles in values(var.external_entity_group_names) : length(values(roles)) == length(distinct(values(roles)))])
    error_message = "An entity's groups must be different groups: two grants for one group on the same catalog would overwrite each other."
  }

  validation {
    condition     = alltrue([for entity in keys(var.external_entity_group_names) : contains(var.business_domains, entity)])
    error_message = "Every entity in external_entity_group_names must be one of business_domains: the grants index the catalogs by entity."
  }
}

variable "shared_business_domain_name" {
  description = "Upstream, from config/entities.yaml. The entity that plays the shared domain: grp. Its analytical catalog also holds the governance schema and the masking functions."
  type        = string

  validation {
    condition     = length(var.business_domains) == 0 || contains(var.business_domains, var.shared_business_domain_name)
    error_message = "shared_business_domain_name must be one of business_domains."
  }
}

################ Our configuration ###############

variable "common_tags" {
  description = "Tags for everything this root tags: the warehouses and the masking-functions job, and the usage policy once serverless compute is restored. Project, Environment, WorkspaceType and ManagedBy are mandatory; Environment and WorkspaceType must match this state instance."
  type        = map(string)
  nullable    = false

  validation {
    condition     = alltrue([for key in ["Project", "Environment", "WorkspaceType", "ManagedBy"] : contains(keys(var.common_tags), key)])
    error_message = "common_tags must include Project, Environment, WorkspaceType and ManagedBy."
  }

  validation {
    condition     = lookup(var.common_tags, "Environment", "") == var.environment && lookup(var.common_tags, "WorkspaceType", "") == var.workspace_type
    error_message = "The Environment and WorkspaceType tags must match var.environment and var.workspace_type."
  }
}

variable "data_classification" {
  description = "Data classification recorded in each catalog's properties."
  type        = string
}

variable "environment" {
  description = "The environment: dev, tst, stg or prd."
  type        = string

  validation {
    condition     = contains(["dev", "tst", "stg", "prd"], var.environment)
    error_message = "environment must be dev, tst, stg or prd."
  }
}

variable "region" {
  description = "The Azure region of the workspace and the metastore, for the metastore lookup and, once serverless compute is restored, the NCC: germanywestcentral."
  type        = string
}

variable "tenant" {
  description = "Tenant recorded in each catalog's properties."
  type        = string
}

variable "workspace_type" {
  description = "'analytical' or 'operational'. Each environment has one state of each."
  type        = string

  validation {
    condition     = contains(["analytical", "operational"], var.workspace_type)
    error_message = "workspace_type must be either 'analytical' or 'operational'."
  }
}

################ Unity Catalog ###############

variable "catalog_binding_type" {
  description = "How this workspace is bound to each of its environment's catalogs. BINDING_TYPE_READ_WRITE leaves the grants to decide who writes; BINDING_TYPE_READ_ONLY caps every principal in this workspace at reading, workloads included, whatever its grants. Both workspaces are read-write until Doubtless decide otherwise; this is the switch."
  type        = string
  default     = "BINDING_TYPE_READ_WRITE"
  nullable    = false

  validation {
    condition     = contains(["BINDING_TYPE_READ_WRITE", "BINDING_TYPE_READ_ONLY"], var.catalog_binding_type)
    error_message = "catalog_binding_type must be BINDING_TYPE_READ_WRITE or BINDING_TYPE_READ_ONLY."
  }
}

variable "catalog_privileges_entity_analysts" {
  description = "Catalog privileges for each entity's analysts key, which holds its Reader group. Read only, in every environment: only read privileges are accepted."
  type        = list(string)
  default     = ["USE_CATALOG", "BROWSE", "USE_SCHEMA"]
  nullable    = false

  validation {
    condition     = alltrue([for privilege in var.catalog_privileges_entity_analysts : contains(["USE_CATALOG", "BROWSE", "USE_SCHEMA", "SELECT", "EXECUTE", "READ_VOLUME"], privilege)])
    error_message = "The Reader group may hold only read privileges on a catalog: USE_CATALOG, BROWSE, USE_SCHEMA, SELECT, EXECUTE or READ_VOLUME."
  }
}

variable "catalog_privileges_entity_engineers" {
  description = "Catalog privileges for each entity's Contributor group (the engineers key) on its own catalogs. People write in dev and tst and read in stg and prd, so each environment's var file sets this."
  type        = list(string)
  nullable    = false
}

variable "catalog_privileges_entity_scientists" {
  description = "Catalog privileges for each entity's scientists key. Unset for Doubtless."
  type        = list(string)
  default     = ["USE_CATALOG", "BROWSE", "CREATE_SCHEMA", "USE_SCHEMA"]
  nullable    = false
}

variable "catalog_privileges_sp_databricks" {
  description = "Catalog privileges for the tier's sp-databricks group on every entity's catalogs. Workloads write in every environment of their tier; in production they are the only principals that can."
  type        = list(string)
  nullable    = false
}

variable "catalog_reader_workspace_ids" {
  description = "Workspace IDs given read-only bindings to the catalogs this state creates, for reading across environments (production into a lower workspace). Never this state's own workspace, and never the other workspace of the same environment: that workspace binds the catalogs itself."
  type        = set(string)
  default     = []
  nullable    = false

  validation {
    condition     = !contains(var.catalog_reader_workspace_ids, var.workspace_id)
    error_message = "catalog_reader_workspace_ids lists other environments' workspaces: this state already binds its own, and a second binding on the same pair would clash."
  }
}

variable "create_business_domain_catalogs" {
  description = "Whether this state takes part in the entity catalogs: the analytical state creates them, their storage and their grants; the operational state binds them. The singletons-only prd-anl apply leaves it true: resolve_upstream.py --singletons-only empties the entity lists instead."
  type        = bool
  default     = true
  nullable    = false
}

variable "create_external_locations" {
  description = "Whether to create each entity's landing and export external locations."
  type        = bool
  default     = true
  nullable    = false
}

variable "create_volumes" {
  description = "Whether to create each entity's landing and export external volumes."
  type        = bool
  default     = true
  nullable    = false
}

variable "volume_privileges_entity_analysts" {
  description = "Volume privileges for each entity's Reader group on its landing and export volumes. Read only, in every environment."
  type        = list(string)
  default     = ["READ_VOLUME"]
  nullable    = false

  validation {
    condition     = alltrue([for privilege in var.volume_privileges_entity_analysts : privilege == "READ_VOLUME"])
    error_message = "The Reader group may hold only READ_VOLUME on a volume."
  }
}

variable "volume_privileges_entity_engineers" {
  description = "Volume privileges for each entity's Contributor group on its landing and export volumes. Read and write in dev and tst; read only in stg and prd."
  type        = list(string)
  nullable    = false
}

variable "volume_privileges_sp_databricks" {
  description = "Volume privileges for the tier's sp-databricks group on every entity's landing and export volumes."
  type        = list(string)
  default     = ["READ_VOLUME", "WRITE_VOLUME"]
  nullable    = false
}

################ Compute ###############

variable "create_cluster_policies" {
  description = "Whether to create the four cluster policies."
  type        = bool
  default     = true
  nullable    = false
}

variable "create_sql_warehouse" {
  description = "Whether to create the automation warehouse and the entity warehouses."
  type        = bool
  default     = true
  nullable    = false
}

# Was enable_serverless_warehouses. Serverless compute is parked: see
# sql-warehouses.tf.
variable "enable_entity_warehouses" {
  description = "Whether to create a SQL warehouse per entity. Classic while serverless compute is parked."
  type        = bool
  default     = true
  nullable    = false
}

variable "entity_warehouse_scaling" {
  description = "Minimum and maximum clusters per entity warehouse, overriding the defaults: { entity = { min = 1, max = 3 } }."
  type = map(object({
    min = number
    max = number
  }))
  default  = {}
  nullable = false
}

variable "entity_warehouse_sizes" {
  description = "Warehouse size per entity, overriding sql_warehouse_size."
  type        = map(string)
  default     = {}
  nullable    = false
}

variable "sql_warehouse_auto_stop_mins" {
  description = "Minutes of idleness before a warehouse stops: 0 for never, otherwise at least 10, the least a classic warehouse accepts."
  type        = number
  default     = 15
  nullable    = false

  validation {
    condition     = var.sql_warehouse_auto_stop_mins == 0 || var.sql_warehouse_auto_stop_mins >= 10
    error_message = "sql_warehouse_auto_stop_mins must be 0 (never stop) or at least 10: a classic warehouse accepts no less."
  }
}

variable "sql_warehouse_max_num_clusters" {
  description = "Default maximum number of clusters for an entity warehouse."
  type        = number
  default     = 1
  nullable    = false
}

variable "sql_warehouse_min_num_clusters" {
  description = "Default minimum number of clusters for an entity warehouse."
  type        = number
  default     = 1
  nullable    = false
}

variable "sql_warehouse_size" {
  description = "Default entity warehouse size: 2X-Small to 4X-Large."
  type        = string
  default     = "X-Small"
  nullable    = false
}

################ Secrets ###############

variable "create_secret_scope" {
  description = "Whether to create the Key Vault-backed secret scope on the access-policy vault."
  type        = bool
  default     = true
  nullable    = false
}

variable "secret_scope_name" {
  description = "Secret scope name. Defaults to 'azure_keyvault'."
  type        = string
  default     = null
}

# Serverless compute is parked: see network-connectivity.tf.
# ################ Network connectivity ###############
#
# variable "enable_ncc" {
#   description = "Whether this workspace binds to its tier's Network Connectivity Configuration, so that serverless compute reaches private storage."
#   type        = bool
#   default     = true
#   nullable    = false
# }
#
# variable "enable_prd_storage_on_nonprod_ncc" {
#   description = "Whether prd-anl also adds production's trusted-storage rules, blob and dfs, to the non-production NCC, so that serverless compute in the non-production workspaces has a network route to production's storage. The network provision only: a lower environment reads a production catalogue only through a read-only binding (catalog_reader_workspace_ids) and its users' grants. prd-anl only; off by default."
#   type        = bool
#   default     = false
#   nullable    = false
#
#   validation {
#     condition     = !var.enable_prd_storage_on_nonprod_ncc || (var.environment == "prd" && var.workspace_type == "analytical")
#     error_message = "Only prd-anl adds production's storage to the non-production NCC."
#   }
# }
#
# variable "manage_shared_ncc" {
#   description = "Whether this state creates its tier's NCC: the non-production one in dev-anl, the production one in prd-anl. Every other state looks its tier's NCC up by name."
#   type        = bool
#   default     = false
#   nullable    = false
#
#   validation {
#     condition     = !var.manage_shared_ncc || (var.workspace_type == "analytical" && contains(["dev", "prd"], var.environment))
#     error_message = "Only dev-anl and prd-anl own an NCC, one per tier."
#   }
# }

################ Masking ###############

variable "enable_masking_policies" {
  description = "Whether to create the masking policies. They call functions in the shared catalog's governance schema, which the masking-functions job creates after an apply, so they are switched on in a later change, once the functions exist."
  type        = bool
  default     = false
  nullable    = false

  validation {
    condition     = !var.enable_masking_policies || contains(keys(var.external_group_names), "pii_authorized")
    error_message = "Masking policies except the PII-authorised group, so external_group_names must name it as pii_authorized."
  }
}
