# prd-anl: production compute.

mock_provider "databricks" {
  source = "./tests/mocks/workspace"
}

mock_provider "databricks" {
  alias  = "account"
  source = "./tests/mocks/account"
}

run "production_gets_the_interactive_prod_policy" {
  command = plan

  assert {
    condition     = length(databricks_cluster_policy.interactive_prod) == 1 && length(databricks_cluster_policy.interactive_dev) == 0
    error_message = "prd uses the interactive prod policy, and only prd."
  }
}

run "people_do_not_run_jobs_in_production" {
  command = plan

  assert {
    condition = !contains(
      [for ac in databricks_permissions.job_compute_policy[0].access_control : ac.group_name],
      "PG-DPX-DAT-RBAC-Engineer",
    )
    error_message = "In production, jobs run as workloads: the engineering persona has no job policy."
  }

  assert {
    condition     = toset([for ac in databricks_permissions.interactive_prod_policy[0].access_control : ac.group_name]) == toset(["PG-DPX-DAT-RBAC-Engineer"])
    error_message = "Engineers keep interactive production compute, for reading."
  }
}
