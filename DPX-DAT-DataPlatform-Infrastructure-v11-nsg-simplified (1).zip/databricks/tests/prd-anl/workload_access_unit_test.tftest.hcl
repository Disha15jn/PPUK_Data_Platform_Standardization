# prd-anl: in production only workloads write.

mock_provider "databricks" {
  source = "./tests/mocks/workspace"
}

mock_provider "databricks" {
  alias  = "account"
  source = "./tests/mocks/account"
}

run "only_the_prod_workload_group_writes_production" {
  command = plan

  assert {
    condition = alltrue([
      for g in values(databricks_grant.sp_databricks_catalog) :
      g.principal == "PG-DPX-DAT-RBAC-ServicePrincipals-Prod" && contains(g.privileges, "MODIFY") && startswith(g.catalog, "prd_")
    ])
    error_message = "The production sp-databricks group writes the production catalogs, the only principal that can."
  }

  assert {
    condition = alltrue(flatten([
      for grants in [databricks_grant.account_entity_engineers_catalog, databricks_grant.account_entity_analysts_catalog, databricks_grant.entity_analysts_shared_catalog, databricks_grant.env_platform_admins_catalog] : [
        for g in values(grants) : !contains(g.privileges, "MODIFY") || g.principal == "PG-DPX-DAT-RBAC-Databricks-Administrator"
      ]
    ]))
    error_message = "No person-facing group except the Databricks admins holds MODIFY in production."
  }
}
