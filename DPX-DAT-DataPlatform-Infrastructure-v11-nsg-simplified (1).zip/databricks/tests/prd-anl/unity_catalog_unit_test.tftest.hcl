# prd-anl: in production, people read and only workloads write.

mock_provider "databricks" {
  source = "./tests/mocks/workspace"
}

mock_provider "databricks" {
  alias  = "account"
  source = "./tests/mocks/account"
}

run "data_groups_only_read_in_production" {
  command = plan

  assert {
    condition = alltrue([
      for g in values(databricks_grant.account_entity_engineers_catalog) :
      !contains(g.privileges, "MODIFY") && !contains(g.privileges, "CREATE_SCHEMA") && contains(g.privileges, "SELECT")
    ])
    error_message = "Production data groups read (SELECT) and never write (no MODIFY, no CREATE_SCHEMA)."
  }

  assert {
    condition = alltrue(concat(
      [for g in values(databricks_grant.entity_engineers_landing_volume) : toset(g.privileges) == toset(["READ_VOLUME"])],
      [for g in values(databricks_grant.entity_engineers_export_volume) : toset(g.privileges) == toset(["READ_VOLUME"])],
    ))
    error_message = "Production data groups only read their volumes."
  }
}

run "readers_only_read_in_production" {
  command = plan

  assert {
    condition = alltrue([
      for g in values(databricks_grant.account_entity_analysts_catalog) :
      contains(g.privileges, "SELECT") && !contains(g.privileges, "MODIFY") && !contains(g.privileges, "CREATE_SCHEMA")
    ])
    error_message = "Production Readers read (SELECT) and never write, as in every environment."
  }

  assert {
    condition = alltrue(concat(
      [for g in values(databricks_grant.entity_analysts_landing_volume) : toset(g.privileges) == toset(["READ_VOLUME"])],
      [for g in values(databricks_grant.entity_analysts_export_volume) : toset(g.privileges) == toset(["READ_VOLUME"])],
    ))
    error_message = "Production Readers only read their volumes."
  }
}

run "production_catalogs_are_named_for_prd" {
  command = plan

  assert {
    condition     = toset([for c in values(databricks_catalog.business_domain) : c.name]) == toset(["prd_grp", "prd_duk"])
    error_message = "prd-anl's catalogs are prd_grp and prd_duk."
  }
}

# The singletons-only first apply, exactly as the pipeline produces it:
# `resolve_upstream.py --singletons-only` empties the entity lists and the
# connectors, and the tracked var files are unchanged. It exists to create the
# production NCC before production's catalogues; with serverless compute parked
# there is nothing to create first, but the resolve mode stays and must plan.
run "a_singletons_only_plan_creates_no_entity_object" {
  command = plan

  variables {
    business_domains            = []
    external_entity_group_names = {}
    access_connectors           = {}
  }

  assert {
    condition = alltrue([
      length(databricks_catalog.business_domain) == 0,
      length(databricks_storage_credential.catalog_storage) == 0,
      length(databricks_external_location.business_domain_storage) == 0,
      length(databricks_schema.shared_governance) == 0,
      length(databricks_job.masking_functions) == 0,
      length(databricks_sql_endpoint.entity_warehouses) == 0,
    ])
    error_message = "A singletons-only plan creates no entity object."
  }

  # Serverless compute is parked: see network-connectivity.tf.
  #   assert {
  #     condition = alltrue([
  #       length(databricks_mws_network_connectivity_config.this) == 1,
  #       length(databricks_mws_ncc_private_endpoint_rule.this) == 2,
  #     ])
  #     error_message = "A singletons-only plan still creates the production NCC and its rules."
  #   }
}

# An empty entity map must plan.
run "plans_with_no_entities" {
  command = plan

  variables {
    business_domains                = []
    external_entity_group_names     = {}
    access_connectors               = {}
    create_business_domain_catalogs = false
  }

  assert {
    condition     = length(databricks_catalog.business_domain) == 0 && length(databricks_storage_credential.catalog_storage) == 0
    error_message = "With no entities, no catalog or credential is planned."
  }
}

# Serverless compute is parked (see sql-warehouses.tf). Predictive optimisation
# runs on serverless compute, so it is off on every catalogue this state creates.
run "every_catalogue_turns_predictive_optimisation_off" {
  command = plan

  assert {
    condition = length(databricks_catalog.business_domain) > 0 && alltrue([
      for c in values(databricks_catalog.business_domain) : c.enable_predictive_optimization == "DISABLE"
    ])
    error_message = "Predictive optimisation runs on serverless compute, so it is off on every catalogue while serverless is parked."
  }
}
