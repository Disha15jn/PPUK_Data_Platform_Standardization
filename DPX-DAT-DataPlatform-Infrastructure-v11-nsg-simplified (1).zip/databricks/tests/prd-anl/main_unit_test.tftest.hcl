# prd-anl: production names and derived values.

mock_provider "databricks" {
  source = "./tests/mocks/workspace"
}

mock_provider "databricks" {
  alias  = "account"
  source = "./tests/mocks/account"
}

run "production_names" {
  command = plan

  assert {
    condition     = local.is_prod && local.metastore_object_name_prefix == "prd"
    error_message = "prd-anl is production, with the object prefix prd."
  }

  assert {
    condition     = { for key, catalog in local.business_domain_catalogs : key => catalog.name } == { grp = "prd_grp", duk = "prd_duk" }
    error_message = "Production analytical catalogs are prd_{entity}."
  }
}

run "the_secret_scope_vault_is_in_production_s_subscription" {
  command = plan

  assert {
    condition     = startswith(local.key_vault_resource_id, "/subscriptions/00000000-0000-0000-0000-000000000004/resourceGroups/")
    error_message = "Both production workspaces sit in production's subscription: the secret scope vault's ID must be built from the subscription 20 published for prd."
  }
}
