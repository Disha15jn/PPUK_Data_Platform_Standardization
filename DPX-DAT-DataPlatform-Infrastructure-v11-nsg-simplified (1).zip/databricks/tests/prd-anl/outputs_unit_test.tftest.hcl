# prd-anl: production outputs.

mock_provider "databricks" {
  source = "./tests/mocks/workspace"
}

mock_provider "databricks" {
  alias  = "account"
  source = "./tests/mocks/account"
}

run "production_outputs" {
  command = plan

  assert {
    condition     = output.cluster_policies.interactive.name == "prd-interactive"
    error_message = "In production the interactive output names the prod policy."
  }

  assert {
    condition     = output.metastore_id == "00000000-0000-0000-0000-0000000000aa"
    error_message = "metastore_id is the metastore this workspace is attached to, which the guard checks against the regional lookup."
  }
}
