# ---------------------------------------------------------------------------
# SERVERLESS COMPUTE PARKED (2026-10-13, Azure DevOps work item 107902)
#
# Doubtless infrastructure security have not yet approved serverless compute.
# A Network Connectivity Configuration would give it a private route to our
# storage, but serverless compute still runs, and processes our data, on
# Databricks-managed infrastructure outside our network. Until that is
# understood and approved, the initial deployment builds nothing that sets up
# serverless compute or runs on it. The code is commented out, not deleted,
# so that it can be restored as it was: each parked line is the original line
# behind a leading "# ", and each blank line is a bare "#". To strip
# the prefix: sed -E 's/^# ?//'.
#
# Parked here: this instance's NCC tests.
# To restore: strip the leading "# " from every line below this note,
# retire the matching case in scripts/tests/test_serverless_parked.py, and work
# through "Serverless compute is parked" in this root's README for the rest.
# ---------------------------------------------------------------------------
# # prd-anl owns the production NCC, which both production workspaces bind to, and
# # adds the private endpoint rules for production's trusted storage.
#
# mock_provider "databricks" {
#   source = "./tests/mocks/workspace"
# }
#
# mock_provider "databricks" {
#   alias  = "account"
#   source = "./tests/mocks/account"
# }
#
# run "prd_anl_owns_the_production_ncc" {
#   command = plan
#
#   assert {
#     condition = (
#       databricks_mws_network_connectivity_config.this[0].region == "germanywestcentral"
#       && databricks_mws_network_connectivity_config.this[0].name == "dpx-dat-gwc-prod-ncc"
#       && length(data.databricks_mws_network_connectivity_config.this) == 0
#       && databricks_mws_ncc_binding.workspace[0].network_connectivity_config_id == "ncc-11111111"
#     )
#     error_message = "prd-anl creates the production NCC in the platform's region, from a variable, and binds to it."
#   }
# }
#
# run "prd_anl_adds_the_rules_for_production_s_trusted_storage" {
#   command = plan
#
#   assert {
#     condition     = toset(keys(databricks_mws_ncc_private_endpoint_rule.this)) == toset(["prd-trusted-blob", "prd-trusted-dfs"])
#     error_message = "prd-anl adds one blob and one dfs rule for production's trusted account, and no other environment's."
#   }
#
#   assert {
#     condition = alltrue([
#       for name, rule in databricks_mws_ncc_private_endpoint_rule.this :
#       rule.group_id == split("-", name)[2] && endswith(rule.resource_id, "/storageAccounts/dpxdattrsprdintgwcst001")
#     ])
#     error_message = "Each rule targets production's trusted account, on its own subresource."
#   }
# }
#
# run "prd_anl_binds_its_workspace" {
#   command = plan
#
#   assert {
#     condition     = tostring(databricks_mws_ncc_binding.workspace[0].workspace_id) == var.workspace_id
#     error_message = "Every workspace binds to the NCC, prd-anl's included."
#   }
# }
#
# # The network provision for reading production's catalogues from lower
# # environments. Off by default: non-production workspaces have no route
# # to production's storage.
# run "production_storage_stays_off_the_non_production_ncc_by_default" {
#   command = plan
#
#   assert {
#     condition = (
#       length(data.databricks_mws_network_connectivity_config.nonprod) == 0
#       && length(databricks_mws_ncc_private_endpoint_rule.prd_storage_on_nonprod_ncc) == 0
#     )
#     error_message = "prd-anl adds nothing to the non-production NCC unless enable_prd_storage_on_nonprod_ncc is set."
#   }
# }
#
# run "prd_anl_can_add_production_storage_to_the_non_production_ncc" {
#   command = plan
#
#   variables {
#     enable_prd_storage_on_nonprod_ncc = true
#   }
#
#   assert {
#     condition = (
#       data.databricks_mws_network_connectivity_config.nonprod[0].name == "dpx-dat-gwc-nonprod-ncc"
#       && toset(keys(databricks_mws_ncc_private_endpoint_rule.prd_storage_on_nonprod_ncc)) == toset(["prd-trusted-blob", "prd-trusted-dfs"])
#       && alltrue([
#         for name, rule in databricks_mws_ncc_private_endpoint_rule.prd_storage_on_nonprod_ncc :
#         rule.network_connectivity_config_id == "ncc-00000000"
#         && rule.group_id == split("-", name)[2]
#         && endswith(rule.resource_id, "/storageAccounts/dpxdattrsprdintgwcst001")
#       ])
#     )
#     error_message = "With the provision on, prd-anl adds production's blob and dfs rules to the non-production NCC, which it looks up by name."
#   }
#
#   assert {
#     condition = (
#       length(databricks_mws_ncc_private_endpoint_rule.this) == 2
#       && alltrue([for rule in databricks_mws_ncc_private_endpoint_rule.this : rule.network_connectivity_config_id == "ncc-11111111"])
#       && databricks_mws_ncc_binding.workspace[0].network_connectivity_config_id == "ncc-11111111"
#     )
#     error_message = "The production NCC keeps production's own rules, and prd-anl stays bound to it."
#   }
# }
