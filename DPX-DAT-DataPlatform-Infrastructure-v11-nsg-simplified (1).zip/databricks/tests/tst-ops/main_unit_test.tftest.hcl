# tst-ops: a smoke test that the operational state binds the environment's
# catalogs (its NCC binding is parked with serverless compute: see
# network-connectivity.tf). The full operational suite runs as dev-ops; the two
# states differ only in environment token and privileges.

mock_provider "databricks" {
  source = "./tests/mocks/workspace"
}

mock_provider "databricks" {
  alias  = "account"
  source = "./tests/mocks/account"
}

run "binds_the_environments_catalogs_and_owns_none" {
  command = plan

  assert {
    condition     = { for entity, b in databricks_workspace_binding.business_domain : entity => b.securable_name } == { grp = "tst_grp", duk = "tst_duk" }
    error_message = "tst-ops binds tst_grp and tst_duk, which tst-anl creates."
  }

  assert {
    condition     = !local.owns_catalogs && length(databricks_catalog.business_domain) == 0 && local.shared_catalog_name == "tst_grp"
    error_message = "tst-ops creates no catalog; the masking functions are in tst-anl's tst_grp."
  }
}

# Serverless compute is parked: see network-connectivity.tf.
# run "binds_the_nonprod_ncc_and_adds_no_rules" {
#   command = plan
#
#   assert {
#     condition = (
#       length(databricks_mws_network_connectivity_config.this) == 0
#       && data.databricks_mws_network_connectivity_config.this[0].name == "dpx-dat-gwc-nonprod-ncc"
#       && length(databricks_mws_ncc_private_endpoint_rule.this) == 0
#     )
#     error_message = "tst-ops looks the non-production NCC up by name, binds to it and adds no rules; tst-anl adds tst's."
#   }
# }
