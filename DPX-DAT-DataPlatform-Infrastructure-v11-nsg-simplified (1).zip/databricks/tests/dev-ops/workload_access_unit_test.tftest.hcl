# dev-ops: the non-production workload group is assigned to this workspace and
# writes dev's catalogs through dev-anl's grants, which hold in the metastore.

mock_provider "databricks" {
  source = "./tests/mocks/workspace"
}

mock_provider "databricks" {
  alias  = "account"
  source = "./tests/mocks/account"
}

run "workload_group_is_assigned_here_and_granted_by_dev_anl" {
  command = plan

  assert {
    condition     = length(databricks_mws_permission_assignment.sp_databricks) == 1 && length(databricks_entitlements.sp_databricks) == 1
    error_message = "The workload group is assigned to the operational workspace with its entitlements."
  }

  assert {
    condition     = length(databricks_grant.sp_databricks_catalog) == 0 && length(databricks_grant.sp_databricks_landing_volume) == 0 && length(databricks_grant.sp_databricks_export_volume) == 0
    error_message = "Its catalog and volume grants are dev-anl's: a grant here would overwrite them."
  }

  assert {
    condition     = length(databricks_permissions.automation_warehouse) == 1
    error_message = "The automation warehouse is per workspace, so its permissions are set here."
  }
}
