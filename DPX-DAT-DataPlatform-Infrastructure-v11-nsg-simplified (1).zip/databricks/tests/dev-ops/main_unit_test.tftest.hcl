# dev-ops: the operational workspace shares dev's catalogs. The lower twin of
# prd-ops: what is rehearsed here is what production's operational state will do.

mock_provider "databricks" {
  source = "./tests/mocks/workspace"
}

mock_provider "databricks" {
  alias  = "account"
  source = "./tests/mocks/account"
}

run "catalogs_are_the_environments_not_the_workspaces" {
  command = plan

  assert {
    condition     = { for key, catalog in local.business_domain_catalogs : key => catalog.name } == { grp = "dev_grp", duk = "dev_duk" }
    error_message = "One catalog per environment per entity, {env}_{entity}, in both workspaces: ${jsonencode(local.business_domain_catalogs)}"
  }
}

run "the_operational_state_owns_no_metastore_object" {
  command = plan

  assert {
    condition     = !local.owns_catalogs && local.metastore_object_name_prefix == "dev"
    error_message = "dev-anl creates the catalogs, credentials and locations; dev-ops binds them. Names carry the environment only."
  }
}

run "containers_match_the_platform_services_names" {
  command = plan

  assert {
    condition = local.catalog_containers == {
      grp = { uc = "grp-uc", landing = "grp-landing", export = "grp-export" }
      duk = { uc = "duk-uc", landing = "duk-landing", export = "duk-export" }
    }
    error_message = "One container set per entity serves both workspaces."
  }
}

run "shared_catalog_is_the_group_entity" {
  command = plan

  assert {
    condition     = local.shared_catalog_name == "dev_grp"
    error_message = "The masking functions are in dev_grp, which dev-anl creates, so dev-anl applies first."
  }
}

run "rejects_an_upstream_file_resolved_for_the_analytical_track" {
  command = plan

  variables {
    workspace_track = "anl"
  }

  expect_failures = [var.workspace_track]
}

run "the_secret_scope_vault_is_in_dev_s_subscription" {
  command = plan

  assert {
    condition     = startswith(local.key_vault_resource_id, "/subscriptions/00000000-0000-0000-0000-000000000001/resourceGroups/")
    error_message = "Both of dev's workspaces sit in dev's subscription: the secret scope vault's ID must be built from the subscription 20 published for dev."
  }
}
