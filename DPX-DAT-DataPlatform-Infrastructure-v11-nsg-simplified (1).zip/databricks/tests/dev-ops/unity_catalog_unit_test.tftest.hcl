# dev-ops: binds dev's catalogs to the operational workspace and owns nothing
# in the metastore. Its production twin is prd-ops; the two suites are kept in step.

mock_provider "databricks" {
  source = "./tests/mocks/workspace"
}

mock_provider "databricks" {
  alias  = "account"
  source = "./tests/mocks/account"
}

# Declared so that the run blocks below can derive values from what the var files
# supply. The root's own declaration still checks the type.
variable "business_domains" {}

variable "external_entity_group_names" {}

run "binds_both_entity_catalogs_read_write_to_this_workspace" {
  command = plan

  assert {
    condition     = { for entity, b in databricks_workspace_binding.business_domain : entity => b.securable_name } == { grp = "dev_grp", duk = "dev_duk" }
    error_message = "dev-ops binds dev_grp and dev_duk, the catalogs dev-anl creates."
  }

  assert {
    condition = alltrue([
      for b in values(databricks_workspace_binding.business_domain) :
      tostring(b.workspace_id) == "1234567890123422" && b.binding_type == "BINDING_TYPE_READ_WRITE"
    ])
    error_message = "Each binding is to this workspace, read-write by default."
  }

  assert {
    condition     = length(databricks_workspace_binding.business_domain_readers) == 0
    error_message = "Cross-environment reader bindings hang off the catalogs a state creates; dev-ops creates none."
  }
}

run "a_read_only_workspace_is_one_var_file_line" {
  command = plan

  variables {
    catalog_binding_type = "BINDING_TYPE_READ_ONLY"
  }

  assert {
    condition     = alltrue([for b in values(databricks_workspace_binding.business_domain) : b.binding_type == "BINDING_TYPE_READ_ONLY"])
    error_message = "catalog_binding_type switches every binding of this workspace."
  }
}

run "rejects_an_unknown_binding_type" {
  command = plan

  variables {
    catalog_binding_type = "READ_ONLY"
  }

  expect_failures = [var.catalog_binding_type]
}

run "creates_no_catalog_credential_location_schema_or_volume" {
  command = plan

  assert {
    condition = alltrue([
      length(databricks_catalog.business_domain) == 0,
      length(databricks_storage_credential.catalog_storage) == 0,
      length(databricks_external_location.business_domain_storage) == 0,
      length(databricks_external_location.landing) == 0,
      length(databricks_external_location.export) == 0,
      length(databricks_schema.landing) == 0,
      length(databricks_schema.export) == 0,
      length(databricks_schema.shared_governance) == 0,
      length(databricks_volume.landing) == 0,
      length(databricks_volume.export) == 0,
    ])
    error_message = "Every metastore-level object belongs to dev-anl; dev-ops only binds."
  }
}

# databricks_grant is authoritative for one principal on one securable, so a
# second state granting the same pair overwrites the first on every apply.
# dev-anl owns every grant; its grants hold across the metastore and so in this
# workspace. Every grant on a catalog, volume, location or credential is listed.
run "grants_nothing_dev_anl_owns_every_grant" {
  command = plan

  assert {
    condition = length(concat(
      keys(databricks_grant.account_entity_engineers_catalog),
      keys(databricks_grant.account_entity_scientists_catalog),
      keys(databricks_grant.account_entity_analysts_catalog),
      keys(databricks_grant.sp_catalog_usage),
      keys(databricks_grant.env_platform_admins_catalog),
      keys(databricks_grant.entity_engineers_shared_catalog),
      keys(databricks_grant.entity_analysts_shared_catalog),
      keys(databricks_grant.sp_databricks_catalog),
      keys(databricks_grant.business_domain_storage_sp),
      keys(databricks_grant.business_domain_storage_platform_admins),
      keys(databricks_grant.entity_engineers_landing_volume),
      keys(databricks_grant.entity_engineers_export_volume),
      keys(databricks_grant.entity_analysts_landing_volume),
      keys(databricks_grant.entity_analysts_export_volume),
      keys(databricks_grant.sp_databricks_landing_volume),
      keys(databricks_grant.sp_databricks_export_volume),
    )) == 0 && length(databricks_grant.sp_governance_schema) == 0 && length(databricks_grants.catalog_storage_credential) == 0
    error_message = "dev-ops must hold no databricks_grant or databricks_grants on a catalog, volume, location or credential: dev-anl's are authoritative per principal and securable."
  }
}

run "binds_without_any_access_connector" {
  command = plan

  variables {
    access_connectors = {}
  }

  assert {
    condition     = length(databricks_workspace_binding.business_domain) == 2
    error_message = "The operational state needs no Access Connector: it creates no storage credential."
  }
}

run "a_third_entity_gets_a_binding" {
  command = plan

  variables {
    business_domains            = concat(var.business_domains, ["zzz"])
    external_entity_group_names = merge(var.external_entity_group_names, { zzz = { engineers = "PLACEHOLDER-dbx-data-zzz" } })
  }

  assert {
    condition     = databricks_workspace_binding.business_domain["zzz"].securable_name == "dev_zzz"
    error_message = "One more entity key must yield its binding here, as it yields its catalog in dev-anl."
  }
}

# The operational state binds dev's catalogs itself
# (databricks_workspace_binding.business_domain); a read-only binding to its
# own workspace would be a second binding on the same pair.
run "rejects_a_read_only_binding_to_this_workspace" {
  command = plan

  variables {
    catalog_reader_workspace_ids = ["1234567890123422"]
  }

  expect_failures = [var.catalog_reader_workspace_ids]
}
