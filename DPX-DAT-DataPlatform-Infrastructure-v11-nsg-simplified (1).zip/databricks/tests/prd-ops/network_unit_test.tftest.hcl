# ---------------------------------------------------------------------------
# SERVERLESS COMPUTE PARKED (2026-10-13, Azure DevOps work item 107902)
#
# Doubtless infrastructure security have not yet approved serverless compute.
# A Network Connectivity Configuration would give it a private route to our
# storage, but serverless compute still runs, and processes our data, on
# Databricks-managed infrastructure outside our network. Until that is
# understood and approved, the initial deployment builds nothing that sets up
# serverless compute or runs on it. The code is commented out, not deleted,
# so that it can be restored as it was: each parked line is the original line
# behind a leading "# ", and each blank line is a bare "#". To strip
# the prefix: sed -E 's/^# ?//'.
#
# Parked here: this instance's NCC tests.
# To restore: strip the leading "# " from every line below this note,
# retire the matching case in scripts/tests/test_serverless_parked.py, and work
# through "Serverless compute is parked" in this root's README for the rest.
# ---------------------------------------------------------------------------
# # prd-ops binds to the NCC and adds no rules: it shares production's trusted
# # account, whose rules prd-anl adds.
#
# mock_provider "databricks" {
#   source = "./tests/mocks/workspace"
# }
#
# mock_provider "databricks" {
#   alias  = "account"
#   source = "./tests/mocks/account"
# }
#
# run "prd_ops_looks_up_the_ncc_and_binds_to_it" {
#   command = plan
#
#   assert {
#     condition = (
#       length(databricks_mws_network_connectivity_config.this) == 0
#       && data.databricks_mws_network_connectivity_config.this[0].name == "dpx-dat-gwc-prod-ncc"
#       && databricks_mws_ncc_binding.workspace[0].network_connectivity_config_id == "ncc-00000000"
#     )
#     error_message = "prd-ops looks the production NCC up by name and binds to it."
#   }
# }
#
# # Only dev-anl and prd-anl own an NCC, one per tier.
# run "rejects_ncc_ownership_outside_dev_anl_and_prd_anl" {
#   command = plan
#
#   variables {
#     manage_shared_ncc = true
#   }
#
#   expect_failures = [var.manage_shared_ncc]
# }
#
# # Rules given to the operational state must still create nothing, or production's
# # trusted account would get a second pair of endpoints on the same NCC.
# run "prd_ops_adds_no_rules_even_if_given_some" {
#   command = plan
#
#   variables {
#     ncc_private_endpoint_rules = [{
#       name        = "prd-trusted-blob"
#       resource_id = "/subscriptions/00000000-0000-0000-0000-000000000004/resourceGroups/dpx-dat-sto-prd-int-gwc-rg-001/providers/Microsoft.Storage/storageAccounts/dpxdattrsprdintgwcst001"
#       group_id    = "blob"
#     }]
#   }
#
#   assert {
#     condition     = length(databricks_mws_ncc_private_endpoint_rule.this) == 0
#     error_message = "Only analytical states add NCC rules; prd-anl adds production's."
#   }
# }
#
# # Only prd-anl adds production's storage to the non-production NCC.
# run "rejects_the_lower_environment_provision_in_prd_ops" {
#   command = plan
#
#   variables {
#     enable_prd_storage_on_nonprod_ncc = true
#   }
#
#   expect_failures = [var.enable_prd_storage_on_nonprod_ncc]
# }
