# prd-ops: the outputs name the catalogs this workspace binds and nothing it
# does not own.

mock_provider "databricks" {
  source = "./tests/mocks/workspace"
}

mock_provider "databricks" {
  alias  = "account"
  source = "./tests/mocks/account"
}

run "outputs_name_the_bound_catalogs_and_no_storage" {
  command = plan

  assert {
    condition     = output.catalogs == { grp = "prd_grp", duk = "prd_duk" }
    error_message = "catalogs maps each entity to the environment catalog bound here."
  }

  assert {
    condition = alltrue([
      length(output.external_locations.storage) == 0,
      length(output.external_locations.landing) == 0,
      length(output.external_locations.export) == 0,
      length(output.volumes) == 0,
      length(output.storage_credential_names) == 0,
    ])
    error_message = "Storage outputs are empty: prd-anl owns the credentials, locations and volumes."
  }

  assert {
    condition     = output.workspace_track == "ops"
    error_message = "The state names the track it configures."
  }

  assert {
    condition     = output.masking_functions_job_id == null
    error_message = "The masking job is prd-anl's."
  }

  assert {
    condition     = output.cluster_policies.interactive.name == "prd-interactive"
    error_message = "The interactive policy output is set in an operational workspace too."
  }
}
