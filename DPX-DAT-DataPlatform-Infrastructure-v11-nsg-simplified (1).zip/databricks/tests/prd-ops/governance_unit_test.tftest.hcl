# prd-ops: masking is prd-anl's. A policy sits on the catalog, so prd-anl's
# sixteen hold in this workspace too; this state creates none.

mock_provider "databricks" {
  source = "./tests/mocks/workspace"
}

mock_provider "databricks" {
  alias  = "account"
  source = "./tests/mocks/account"
}

run "creates_no_masking_policy_function_or_job" {
  command = plan

  variables {
    enable_masking_policies = true
  }

  assert {
    condition     = length(databricks_policy_info.pii_mask) == 0 && length(databricks_job.masking_functions) == 0 && length(databricks_workspace_file.masking_functions) == 0
    error_message = "prd-anl's policies on prd_grp and prd_duk already cover this workspace; a second set here would be a second owner."
  }
}
