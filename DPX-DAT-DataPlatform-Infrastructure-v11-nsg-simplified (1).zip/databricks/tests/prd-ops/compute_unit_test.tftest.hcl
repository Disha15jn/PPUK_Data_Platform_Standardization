# prd-ops: production compute, as in prd-anl. People do not run jobs in
# production; workloads do.

mock_provider "databricks" {
  source = "./tests/mocks/workspace"
}

mock_provider "databricks" {
  alias  = "account"
  source = "./tests/mocks/account"
}

variables {
  engineers     = "PG-DPX-DAT-RBAC-Engineer"
  sp_databricks = "PG-DPX-DAT-RBAC-ServicePrincipals-Prod"
}

run "production_gets_the_interactive_prod_policy" {
  command = plan

  assert {
    condition     = length(databricks_cluster_policy.interactive_prod) == 1 && length(databricks_cluster_policy.interactive_dev) == 0
    error_message = "prd uses the interactive prod policy, and only prd."
  }
}

run "people_do_not_run_jobs_in_production" {
  command = plan

  assert {
    condition = alltrue([
      for permissions in [databricks_permissions.job_compute_policy[0], databricks_permissions.dlt_pipeline_policy[0]] :
      contains([for ac in permissions.access_control : ac.group_name], var.sp_databricks)
      && !contains([for ac in permissions.access_control : ac.group_name], var.engineers)
    ])
    error_message = "In production, jobs and pipelines run as workloads: sp-databricks holds the policies and the engineering persona does not."
  }

  assert {
    condition     = toset([for ac in databricks_permissions.interactive_prod_policy[0].access_control : ac.group_name]) == toset([var.engineers])
    error_message = "Engineers keep interactive production compute, for reading."
  }
}

run "warehouses_reuse_the_environment_name" {
  command = plan

  assert {
    condition = (
      databricks_sql_endpoint.automation[0].name == "prd-automation-classic"
      && databricks_sql_endpoint.entity_warehouses["grp"].name == "prd-grp-warehouse-classic"
    )
    error_message = "Warehouses are workspace-scoped, so the operational workspace reuses the environment's names without clashing with prd-anl's."
  }
}
