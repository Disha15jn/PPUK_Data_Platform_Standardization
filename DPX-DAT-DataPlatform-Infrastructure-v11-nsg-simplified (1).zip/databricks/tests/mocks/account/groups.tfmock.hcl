# Mocked values for the account-level Databricks provider. Databricks group and
# principal IDs are numeric.
mock_data "databricks_group" {
  defaults = {
    id               = "1111"
    acl_principal_id = "groups/1111"
  }
}

# Serverless compute is parked: see network-connectivity.tf.
# # An NCC a state looks up, and one it creates, have different IDs, so tests can
# # tell which one a state binds to.
# mock_data "databricks_mws_network_connectivity_config" {
#   defaults = {
#     network_connectivity_config_id = "ncc-00000000"
#   }
# }
#
# mock_resource "databricks_mws_network_connectivity_config" {
#   override_during = plan
#   defaults = {
#     network_connectivity_config_id = "ncc-11111111"
#   }
# }

mock_data "databricks_metastore" {
  defaults = {
    id   = "00000000-0000-0000-0000-0000000000aa"
    name = "metastore_azure_germanywestcentral"
    metastore_info = [{
      name         = "metastore_azure_germanywestcentral"
      metastore_id = "00000000-0000-0000-0000-0000000000aa"
      region       = "germanywestcentral"
    }]
  }
}
