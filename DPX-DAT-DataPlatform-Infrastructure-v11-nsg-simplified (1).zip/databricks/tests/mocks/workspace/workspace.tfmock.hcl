# Mocked values for the workspace-level Databricks provider.
mock_data "databricks_group" {
  defaults = {
    id               = "1111"
    acl_principal_id = "groups/1111"
  }
}

# The metastore the workspace is attached to: the regional one, as the
# account-level lookup returns it.
mock_data "databricks_current_metastore" {
  defaults = {
    id = "00000000-0000-0000-0000-0000000000aa"
  }
}
