# dev-anl: the workspace must be attached to the regional metastore, which this
# root reads and never changes. The same check runs in every state.

mock_provider "databricks" {
  source = "./tests/mocks/workspace"
}

mock_provider "databricks" {
  alias  = "account"
  source = "./tests/mocks/account"
}

run "the_workspace_is_attached_to_the_regional_metastore" {
  command = plan

  assert {
    condition     = output.metastore_id == data.databricks_metastore.this.id
    error_message = "metastore_id is the metastore this workspace is attached to: the regional one."
  }
}

run "stops_when_the_workspace_has_no_metastore" {
  command = plan

  override_data {
    target = data.databricks_current_metastore.this
    values = {
      id = "no_metastore"
    }
  }

  expect_failures = [data.databricks_current_metastore.this]
}

# Workspaces attach only to a metastore in their own region, so this is the
# unlikely case, but the guard compares IDs and this pins that comparison: a
# check for "no_metastore" alone would let it through.
run "stops_when_the_workspace_is_attached_elsewhere" {
  command = plan

  override_data {
    target = data.databricks_current_metastore.this
    values = {
      id = "00000000-0000-0000-0000-0000000000bb"
    }
  }

  expect_failures = [data.databricks_current_metastore.this]
}
