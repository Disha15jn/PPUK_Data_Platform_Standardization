# dev-anl: the names and derived values main.tf builds from its inputs.

mock_provider "databricks" {
  source = "./tests/mocks/workspace"
}

mock_provider "databricks" {
  alias  = "account"
  source = "./tests/mocks/account"
}

# Declared so that the run blocks below can derive values from what the var files
# supply. The root's own declaration still checks the type.
variable "common_tags" {}

run "catalogs_follow_the_reference_naming" {
  command = plan

  assert {
    condition     = local.owns_catalogs
    error_message = "The analytical state creates the catalogues."
  }

  assert {
    condition     = { for key, catalog in local.business_domain_catalogs : key => catalog.name } == { grp = "dev_grp", duk = "dev_duk" }
    error_message = "Analytical catalogs are {env}_{entity}: ${jsonencode(local.business_domain_catalogs)}"
  }
}

run "every_entity_keeps_its_data_catalog" {
  command = plan

  assert {
    condition     = toset(keys(local.entity_catalogs)) == toset(["grp", "duk"])
    error_message = "grp is the shared domain and an entity with data, so it must stay in entity_catalogs."
  }
}

run "shared_catalog_is_the_group_entity" {
  command = plan

  assert {
    condition     = local.shared_catalog_name == "dev_grp"
    error_message = "The shared catalog is grp's analytical catalog."
  }
}

run "containers_match_the_platform_services_names" {
  command = plan

  assert {
    condition = local.catalog_containers == {
      grp = { uc = "grp-uc", landing = "grp-landing", export = "grp-export" }
      duk = { uc = "duk-uc", landing = "duk-landing", export = "duk-export" }
    }
    error_message = "Container names must match infra/20-platform-services's trusted_containers."
  }
}

run "derived_values" {
  command = plan

  assert {
    condition     = local.workspace_url == "https://adb-1234567890123411.7.azuredatabricks.net"
    error_message = "The workspace URL is built from its ID and region number: ${local.workspace_url}"
  }

  assert {
    condition     = local.key_vault_resource_id == "/subscriptions/00000000-0000-0000-0000-000000000001/resourceGroups/dpx-dat-ops-dev-int-gwc-rg-002/providers/Microsoft.KeyVault/vaults/dpxdatdbxdevintgwckv002"
    error_message = "The secret scope vault's ID is built from the subscription dev deployed into (20-platform-services' subscription_id output), its resource group and its name."
  }

  assert {
    condition     = !local.is_prod && local.metastore_object_name_prefix == "dev"
    error_message = "dev is not production, and its object prefix is its environment."
  }
}

run "rejects_an_unknown_environment" {
  command = plan

  variables {
    environment = "staging"
  }

  expect_failures = [var.environment]
}

run "rejects_an_unknown_workspace_type" {
  command = plan

  variables {
    workspace_type = "gold"
  }

  expect_failures = [var.workspace_type]
}

# The resolve step's --workspace must match the state instance. Fed the
# operational workspace's values, an analytical state would repoint its
# bindings and assignments at the other workspace.
run "rejects_an_upstream_file_resolved_for_the_operational_track" {
  command = plan

  variables {
    workspace_track = "ops"
  }

  expect_failures = [var.workspace_track]
}

run "rejects_an_unknown_track" {
  command = plan

  variables {
    workspace_track = "operational"
  }

  expect_failures = [var.workspace_track]
}

run "rejects_a_missing_mandatory_tag" {
  command = plan

  variables {
    common_tags = { for key, value in var.common_tags : key => value if key != "Project" }
  }

  expect_failures = [var.common_tags]
}

run "rejects_a_shared_domain_that_is_not_an_entity" {
  command = plan

  variables {
    shared_business_domain_name = "nope"
  }

  expect_failures = [var.shared_business_domain_name]
}
