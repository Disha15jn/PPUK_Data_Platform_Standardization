# dev-anl: workload access through the tier's sp-databricks group.
# Workloads never act one by one: no Terraform resource names a workload
# identity, only the group.

mock_provider "databricks" {
  source = "./tests/mocks/workspace"
}

mock_provider "databricks" {
  alias  = "account"
  source = "./tests/mocks/account"
}

variables {
  sp_databricks = "PG-DPX-DAT-RBAC-ServicePrincipals-NonProd"
  write_set     = ["USE_CATALOG", "BROWSE", "CREATE_SCHEMA", "USE_SCHEMA", "SELECT", "MODIFY"]
}

# Declared so that the run blocks below can derive values from what the var files
# supply. The root's own declaration still checks the type.
variable "external_group_names" {}

run "sp_databricks_writes_every_entity_catalog_in_its_tier" {
  command = plan

  assert {
    condition = alltrue([
      for entity, g in databricks_grant.sp_databricks_catalog :
      g.principal == var.sp_databricks && g.catalog == "dev_${entity}"
      && toset(g.privileges) == toset(entity == "grp" ? concat(var.write_set, ["EXECUTE"]) : var.write_set)
    ])
    error_message = "The non-production sp-databricks group writes every dev catalog, with EXECUTE on the shared one."
  }

  assert {
    condition     = toset(keys(databricks_grant.sp_databricks_catalog)) == toset(["grp", "duk"])
    error_message = "sp-databricks reaches every entity's catalog in its environment."
  }
}

run "sp_databricks_holds_nothing_outside_its_environment" {
  command = plan

  assert {
    condition = alltrue(concat(
      [for g in values(databricks_grant.sp_databricks_catalog) : startswith(g.catalog, "dev_")],
      [for g in values(databricks_grant.sp_databricks_landing_volume) : startswith(g.volume, "dev_")],
      [for g in values(databricks_grant.sp_databricks_export_volume) : startswith(g.volume, "dev_")],
    ))
    error_message = "The non-production group must hold nothing on production catalogs."
  }
}

run "sp_databricks_uses_every_entity_volume" {
  command = plan

  assert {
    condition = alltrue([
      for entity in ["grp", "duk"] :
      databricks_grant.sp_databricks_landing_volume[entity].volume == "dev_${entity}.landing.landing_volume"
      && databricks_grant.sp_databricks_export_volume[entity].volume == "dev_${entity}.export.export_volume"
      && toset(databricks_grant.sp_databricks_landing_volume[entity].privileges) == toset(["READ_VOLUME", "WRITE_VOLUME"])
    ])
    error_message = "Workloads read and write every entity's landing and export volumes."
  }
}

run "sp_databricks_is_assigned_with_entitlements_but_no_cluster_creation" {
  command = plan

  assert {
    condition     = toset(databricks_mws_permission_assignment.sp_databricks[0].permissions) == toset(["USER"])
    error_message = "sp-databricks is assigned to the workspace as USER."
  }

  assert {
    condition = (
      databricks_entitlements.sp_databricks[0].workspace_access
      && databricks_entitlements.sp_databricks[0].databricks_sql_access
      && !databricks_entitlements.sp_databricks[0].allow_cluster_create
    )
    error_message = "Workloads get workspace and SQL access; they create compute through policies, not freely."
  }
}

run "no_workload_access_without_the_group" {
  command = plan

  variables {
    external_group_names = { for key, name in var.external_group_names : key => name if key != "sp_databricks" }
  }

  assert {
    condition     = length(databricks_grant.sp_databricks_catalog) == 0 && length(databricks_mws_permission_assignment.sp_databricks) == 0
    error_message = "Without an sp_databricks group, no workload grants are planned."
  }
}
