# dev-anl: the outputs. The reference platform's outputs compared environment
# names as strings and went null outside dev.

mock_provider "databricks" {
  source = "./tests/mocks/workspace"
}

mock_provider "databricks" {
  alias  = "account"
  source = "./tests/mocks/account"
}

# Declared so that the run blocks below can derive values from what the var files
# supply. The root's own declaration still checks the type.
variable "common_tags" {}

run "outputs_name_the_catalogs_and_the_interactive_policy" {
  command = plan

  assert {
    condition     = output.catalogs == { grp = "dev_grp", duk = "dev_duk" }
    error_message = "catalogs maps each entity to its catalog."
  }

  assert {
    condition     = output.cluster_policies.interactive.name == "dev-interactive" && output.cluster_policies.job_compute.name == "dev-job-compute"
    error_message = "cluster_policies names the interactive policy the environment has."
  }

  assert {
    condition     = output.volumes["duk"].landing == "dev_duk.landing.landing_volume"
    error_message = "volumes gives each entity's volume names."
  }

  assert {
    condition     = output.external_locations.landing["grp"] == "dev_grp_landing"
    error_message = "external_locations names each entity's locations."
  }
}

run "the_interactive_policy_output_is_set_in_stg_too" {
  command = plan

  # As stg-anl. (It would also look up the non-production NCC that dev-anl owns:
  # serverless compute is parked, see network-connectivity.tf.)
  variables {
    environment = "stg"
    common_tags = merge(var.common_tags, { Environment = "stg" })
    # manage_shared_ncc = false
  }

  assert {
    condition     = output.cluster_policies.interactive.name == "stg-interactive"
    error_message = "The interactive policy output must not go null outside dev."
  }
}
