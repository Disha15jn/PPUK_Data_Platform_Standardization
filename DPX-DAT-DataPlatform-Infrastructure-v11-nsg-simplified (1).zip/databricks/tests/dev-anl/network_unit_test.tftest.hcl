# dev-anl: the variable that carries dev's NCC rules, and the secret scope on
# the access-policy vault. The NCC tests are parked with serverless compute:
# see network-connectivity.tf.

mock_provider "databricks" {
  source = "./tests/mocks/workspace"
}

mock_provider "databricks" {
  alias  = "account"
  source = "./tests/mocks/account"
}

# Serverless compute is parked: see network-connectivity.tf.
# run "dev_anl_owns_the_non_production_ncc_and_binds_to_it" {
#   command = plan
#
#   assert {
#     condition = (
#       databricks_mws_network_connectivity_config.this[0].name == "dpx-dat-gwc-nonprod-ncc"
#       && databricks_mws_network_connectivity_config.this[0].region == "germanywestcentral"
#       && length(data.databricks_mws_network_connectivity_config.this) == 0
#       && databricks_mws_ncc_binding.workspace[0].network_connectivity_config_id == "ncc-11111111"
#     )
#     error_message = "dev-anl creates the non-production NCC, within the 30-character name limit, and binds dev to it."
#   }
# }

# Serverless compute is parked: see network-connectivity.tf.
# # tst-anl and stg-anl: a non-production state that does not own the NCC.
# run "tst_and_stg_look_up_the_non_production_ncc_and_add_their_own_rules" {
#   command = plan
#
#   variables {
#     manage_shared_ncc = false
#   }
#
#   assert {
#     condition = (
#       length(databricks_mws_network_connectivity_config.this) == 0
#       && data.databricks_mws_network_connectivity_config.this[0].name == "dpx-dat-gwc-nonprod-ncc"
#       && databricks_mws_ncc_binding.workspace[0].network_connectivity_config_id == "ncc-00000000"
#       && length(databricks_mws_ncc_private_endpoint_rule.this) == 2
#       && alltrue([for rule in databricks_mws_ncc_private_endpoint_rule.this : rule.network_connectivity_config_id == "ncc-00000000"])
#     )
#     error_message = "A non-production state that does not own the NCC looks it up by name, binds to it and adds its own rules to it."
#   }
# }

# Serverless compute is parked: see network-connectivity.tf.
# run "dev_adds_the_rules_for_its_own_trusted_storage" {
#   command = plan
#
#   assert {
#     condition     = toset(keys(databricks_mws_ncc_private_endpoint_rule.this)) == toset(["dev-trusted-blob", "dev-trusted-dfs"])
#     error_message = "dev-anl adds one blob and one dfs rule for dev's trusted account, and no other environment's."
#   }
#
#   assert {
#     condition = alltrue([
#       for name, rule in databricks_mws_ncc_private_endpoint_rule.this :
#       rule.group_id == split("-", name)[2]
#       && endswith(rule.resource_id, "/storageAccounts/dpxdattrsdevintgwcst001")
#       && rule.network_connectivity_config_id == "ncc-11111111"
#     ])
#     error_message = "Each rule targets dev's trusted account, on its own subresource, in the NCC dev binds to."
#   }
# }

# A state adds rules only for its own environment's storage, which is in that
# environment's own subscription: production's storage never reaches it this way.
run "rejects_a_rule_for_another_environments_storage" {
  command = plan

  variables {
    ncc_private_endpoint_rules = [{
      name        = "prd-trusted-blob"
      resource_id = "/subscriptions/00000000-0000-0000-0000-000000000004/resourceGroups/dpx-dat-sto-prd-int-gwc-rg-001/providers/Microsoft.Storage/storageAccounts/dpxdattrsprdintgwcst001"
      group_id    = "blob"
    }]
  }

  expect_failures = [var.ncc_private_endpoint_rules]
}

# Serverless compute is parked: see network-connectivity.tf.
# # Only prd-anl adds production's storage to the non-production NCC.
# run "rejects_the_lower_environment_provision_outside_prd_anl" {
#   command = plan
#
#   variables {
#     enable_prd_storage_on_nonprod_ncc = true
#   }
#
#   expect_failures = [var.enable_prd_storage_on_nonprod_ncc]
# }

run "the_secret_scope_uses_the_access_policy_vault" {
  command = plan

  assert {
    condition = (
      databricks_secret_scope.key_vault[0].name == "azure_keyvault"
      && databricks_secret_scope.key_vault[0].keyvault_metadata[0].resource_id == "/subscriptions/00000000-0000-0000-0000-000000000001/resourceGroups/dpx-dat-ops-dev-int-gwc-rg-002/providers/Microsoft.KeyVault/vaults/dpxdatdbxdevintgwckv002"
      && databricks_secret_scope.key_vault[0].keyvault_metadata[0].dns_name == "https://dpxdatdbxdevintgwckv002.vault.azure.net/"
    )
    error_message = "The Key Vault-backed secret scope must use the secret scope's access-policy vault."
  }
}
