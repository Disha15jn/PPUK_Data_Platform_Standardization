# dev-anl: governance. The masking functions deploy into the shared catalog's
# governance schema; the masking policies follow once they exist.

mock_provider "databricks" {
  source = "./tests/mocks/workspace"
}

mock_provider "databricks" {
  alias  = "account"
  source = "./tests/mocks/account"
}

variables {
  pii_group = "PG-DPX-DAT-RBAC-PiiAuthorised-Reader"
}

# Declared so that the run blocks below can derive values from what the var files
# supply. The root's own declaration still checks the type.
variable "external_group_names" {}

run "the_masking_functions_are_rendered_for_the_shared_catalog" {
  command = plan

  assert {
    condition = alltrue([
      for fn in ["mask_email", "mask_name", "mask_phone", "mask_credit_card", "mask_ssn", "mask_dob", "mask_address", "mask_ip"] :
      strcontains(base64decode(databricks_workspace_file.masking_functions[0].content_base64), "CREATE OR REPLACE FUNCTION dev_grp.governance.${fn}(")
    ])
    error_message = "All eight masking functions must be rendered into dev_grp.governance."
  }
}

run "a_job_on_the_automation_warehouse_deploys_them" {
  command = plan

  assert {
    condition = (
      databricks_job.masking_functions[0].task[0].sql_task[0].file[0].path == databricks_workspace_file.masking_functions[0].path
      && databricks_job.masking_functions[0].task[0].sql_task[0].file[0].source == "WORKSPACE"
    )
    error_message = "The masking-functions job runs the rendered file as a SQL task."
  }

  assert {
    condition = (
      databricks_grant.sp_governance_schema[0].schema == "dev_grp.governance"
      && contains(databricks_grant.sp_governance_schema[0].privileges, "CREATE_FUNCTION")
    )
    error_message = "The pipeline identity, which the job runs as, may create functions in the governance schema."
  }
}

run "masking_policies_wait_until_the_functions_exist" {
  command = plan

  assert {
    condition     = length(databricks_policy_info.pii_mask) == 0
    error_message = "Masking policies are off by default: they land in a later change, once the functions exist."
  }
}

run "every_catalog_gets_a_policy_for_every_pii_class" {
  command = plan

  variables {
    enable_masking_policies = true
  }

  assert {
    condition     = length(databricks_policy_info.pii_mask) == 16
    error_message = "Eight PII classes on each of the two catalogs."
  }

  assert {
    condition = alltrue([
      for policy in values(databricks_policy_info.pii_mask) :
      tolist(policy.except_principals) == tolist([var.pii_group])
      && tolist(policy.to_principals) == tolist(["account users"])
      && policy.policy_type == "POLICY_TYPE_COLUMN_MASK"
      && startswith(policy.column_mask.function_name, "dev_grp.governance.mask_")
      && contains(["dev_grp", "dev_duk"], policy.on_securable_fullname)
      && startswith(policy.match_columns[0].condition, "hasTag('class.")
    ])
    error_message = "Every policy masks by default, excepts only the PII-authorised group, and calls the shared catalog's functions."
  }
}

run "masking_needs_the_pii_authorised_group" {
  command = plan

  variables {
    enable_masking_policies = true
    external_group_names    = { for key, name in var.external_group_names : key => name if key != "pii_authorized" }
  }

  expect_failures = [var.enable_masking_policies]
}
