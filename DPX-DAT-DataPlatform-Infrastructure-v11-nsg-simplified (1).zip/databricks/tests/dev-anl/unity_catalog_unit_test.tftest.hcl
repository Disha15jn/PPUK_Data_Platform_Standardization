# dev-anl: Unity Catalog, storage and the grants on them, against the
# platform's access matrix. The expected values are written out here from the
# agreed matrix, never generated from the locals that create
# the grants, and every positive assertion has a 'holds nothing' partner.

mock_provider "databricks" {
  source = "./tests/mocks/workspace"
}

mock_provider "databricks" {
  alias  = "account"
  source = "./tests/mocks/account"
}

variables {
  grp_data  = "PG-DPX-DAT-RBAC-GroupShared-Contributor"
  duk_data  = "PG-DPX-DAT-RBAC-DoubtlessUK-Contributor"
  admins    = "PG-DPX-DAT-RBAC-Databricks-Administrator"
  write_set = ["USE_CATALOG", "BROWSE", "CREATE_SCHEMA", "USE_SCHEMA", "SELECT", "MODIFY"]

  grp_reader = "PG-DPX-DAT-RBAC-GroupShared-Reader"
  duk_reader = "PG-DPX-DAT-RBAC-DoubtlessUK-Reader"
  read_set   = ["USE_CATALOG", "BROWSE", "USE_SCHEMA", "SELECT"]
}

# --- Each entity's data group reaches its own catalog, and no other -----------

# Declared so that the run blocks below can derive values from what the var files
# supply. The root's own declaration still checks the type.
variable "access_connectors" {}

variable "business_domains" {}

variable "external_entity_group_names" {}

run "grp_data_group_writes_its_catalog_and_can_execute_the_masking_functions" {
  command = plan

  assert {
    condition = (
      databricks_grant.account_entity_engineers_catalog["grp"].catalog == "dev_grp"
      && databricks_grant.account_entity_engineers_catalog["grp"].principal == var.grp_data
      && toset(databricks_grant.account_entity_engineers_catalog["grp"].privileges) == toset(concat(var.write_set, ["EXECUTE"]))
    )
    error_message = "grp's data group writes dev_grp, with EXECUTE merged in because dev_grp is the shared catalog."
  }
}

run "duk_data_group_writes_its_catalog" {
  command = plan

  assert {
    condition = (
      databricks_grant.account_entity_engineers_catalog["duk"].catalog == "dev_duk"
      && databricks_grant.account_entity_engineers_catalog["duk"].principal == var.duk_data
      && toset(databricks_grant.account_entity_engineers_catalog["duk"].privileges) == toset(var.write_set)
    )
    error_message = "duk's data group writes dev_duk in dev."
  }
}

run "duk_data_group_gets_only_the_shared_grant_on_grp" {
  command = plan

  assert {
    condition = (
      databricks_grant.entity_engineers_shared_catalog["duk"].catalog == "dev_grp"
      && toset(databricks_grant.entity_engineers_shared_catalog["duk"].privileges) == toset(["USE_CATALOG", "USE_SCHEMA", "EXECUTE"])
    )
    error_message = "On grp's catalog, duk's data group gets only USE_CATALOG, USE_SCHEMA and EXECUTE, for the masking functions."
  }

  assert {
    condition     = !contains(keys(databricks_grant.entity_engineers_shared_catalog), "grp")
    error_message = "grp's own data group already holds its catalog; a second grant on the same catalog would fight it."
  }
}

run "no_data_group_holds_anything_on_another_entitys_objects" {
  command = plan

  assert {
    condition = alltrue(flatten([
      for entity, group in { grp = var.grp_data, duk = var.duk_data } : [
        for securable in concat(
          [for g in values(databricks_grant.account_entity_engineers_catalog) : g.catalog if g.principal == group],
          [for g in values(databricks_grant.entity_engineers_landing_volume) : g.volume if g.principal == group],
          [for g in values(databricks_grant.entity_engineers_export_volume) : g.volume if g.principal == group],
        ) : startswith(securable, "dev_${entity}")
      ]
    ]))
    error_message = "A data group's catalog and volume grants must all be on its own entity's objects."
  }

  assert {
    condition     = !anytrue([for g in values(databricks_grant.entity_engineers_shared_catalog) : contains(g.privileges, "SELECT") || contains(g.privileges, "MODIFY")])
    error_message = "The shared-catalog grant must never carry SELECT or MODIFY on grp's data."
  }
}

run "data_groups_read_and_write_their_own_volumes" {
  command = plan

  assert {
    condition = alltrue([
      for entity in ["grp", "duk"] :
      databricks_grant.entity_engineers_landing_volume[entity].volume == "dev_${entity}.landing.landing_volume"
      && databricks_grant.entity_engineers_export_volume[entity].volume == "dev_${entity}.export.export_volume"
      && toset(databricks_grant.entity_engineers_landing_volume[entity].privileges) == toset(["READ_VOLUME", "WRITE_VOLUME"])
    ])
    error_message = "Each data group reads and writes its own landing and export volumes in dev."
  }
}

# --- Each entity's Reader reads its own catalog and volumes --------------------

run "readers_read_their_own_catalog" {
  command = plan

  assert {
    condition = (
      databricks_grant.account_entity_analysts_catalog["duk"].catalog == "dev_duk"
      && databricks_grant.account_entity_analysts_catalog["duk"].principal == var.duk_reader
      && toset(databricks_grant.account_entity_analysts_catalog["duk"].privileges) == toset(var.read_set)
    )
    error_message = "duk's Reader reads dev_duk and holds no write privilege."
  }

  assert {
    condition = (
      databricks_grant.account_entity_analysts_catalog["grp"].catalog == "dev_grp"
      && databricks_grant.account_entity_analysts_catalog["grp"].principal == var.grp_reader
      && toset(databricks_grant.account_entity_analysts_catalog["grp"].privileges) == toset(concat(var.read_set, ["EXECUTE"]))
    )
    error_message = "grp's Reader reads dev_grp, with EXECUTE merged in because dev_grp is the shared catalog."
  }
}

run "duk_reader_gets_only_the_shared_grant_on_grp" {
  command = plan

  assert {
    condition = (
      databricks_grant.entity_analysts_shared_catalog["duk"].catalog == "dev_grp"
      && databricks_grant.entity_analysts_shared_catalog["duk"].principal == var.duk_reader
      && toset(databricks_grant.entity_analysts_shared_catalog["duk"].privileges) == toset(["USE_CATALOG", "USE_SCHEMA", "EXECUTE"])
    )
    error_message = "On grp's catalog, duk's Reader gets only USE_CATALOG, USE_SCHEMA and EXECUTE, for the masking functions."
  }

  assert {
    condition     = !contains(keys(databricks_grant.entity_analysts_shared_catalog), "grp")
    error_message = "grp's own Reader already holds its catalog; a second grant on the same catalog would fight it."
  }
}

run "readers_only_read_their_own_volumes" {
  command = plan

  assert {
    condition = alltrue([
      for entity in ["grp", "duk"] :
      databricks_grant.entity_analysts_landing_volume[entity].volume == "dev_${entity}.landing.landing_volume"
      && databricks_grant.entity_analysts_export_volume[entity].volume == "dev_${entity}.export.export_volume"
      && toset(databricks_grant.entity_analysts_landing_volume[entity].privileges) == toset(["READ_VOLUME"])
      && toset(databricks_grant.entity_analysts_export_volume[entity].privileges) == toset(["READ_VOLUME"])
    ])
    error_message = "Each Reader reads, and only reads, its own landing and export volumes, in every environment."
  }
}

run "no_reader_holds_anything_on_another_entitys_objects" {
  command = plan

  assert {
    condition = alltrue(flatten([
      for entity, group in { grp = var.grp_reader, duk = var.duk_reader } : [
        for securable in concat(
          [for g in values(databricks_grant.account_entity_analysts_catalog) : g.catalog if g.principal == group],
          [for g in values(databricks_grant.entity_analysts_landing_volume) : g.volume if g.principal == group],
          [for g in values(databricks_grant.entity_analysts_export_volume) : g.volume if g.principal == group],
        ) : startswith(securable, "dev_${entity}")
      ]
    ]))
    error_message = "A Reader's catalog and volume grants must all be on its own entity's objects."
  }
}

# --- The two groups of an entity are configured safely -----------------------

run "rejects_an_unknown_group_key_for_an_entity" {
  command = plan

  variables {
    external_entity_group_names = merge(var.external_entity_group_names, { duk = { engineers = var.duk_data, readers = var.duk_reader } })
  }

  expect_failures = [var.external_entity_group_names]
}

run "rejects_one_group_as_both_reader_and_contributor" {
  command = plan

  variables {
    external_entity_group_names = merge(var.external_entity_group_names, { duk = { engineers = var.duk_data, analysts = var.duk_data } })
  }

  expect_failures = [var.external_entity_group_names]
}

run "rejects_a_reader_catalog_privilege_that_writes" {
  command = plan

  variables {
    catalog_privileges_entity_analysts = ["USE_CATALOG", "SELECT", "MODIFY"]
  }

  expect_failures = [var.catalog_privileges_entity_analysts]
}

run "rejects_a_reader_volume_privilege_that_writes" {
  command = plan

  variables {
    volume_privileges_entity_analysts = ["READ_VOLUME", "WRITE_VOLUME"]
  }

  expect_failures = [var.volume_privileges_entity_analysts]
}

# --- Personas and special groups hold no data rights ---------------

run "personas_and_the_pii_group_hold_nothing" {
  command = plan

  assert {
    condition = length(setintersection(
      toset(concat(
        [for g in values(databricks_grant.account_entity_engineers_catalog) : g.principal],
        [for g in values(databricks_grant.env_platform_admins_catalog) : g.principal],
        [for g in values(databricks_grant.entity_engineers_shared_catalog) : g.principal],
        [for g in values(databricks_grant.entity_engineers_landing_volume) : g.principal],
        [for g in values(databricks_grant.entity_engineers_export_volume) : g.principal],
        [for g in values(databricks_grant.business_domain_storage_platform_admins) : g.principal],
        [for g in values(databricks_grant.sp_databricks_catalog) : g.principal],
        [for g in values(databricks_grant.sp_databricks_landing_volume) : g.principal],
        [for g in values(databricks_grant.sp_databricks_export_volume) : g.principal],
      )),
      toset(["PG-DPX-DAT-RBAC-Engineer", "PG-DPX-DAT-RBAC-Analyst", "PG-DPX-DAT-RBAC-PiiAuthorised-Reader", "PG-DPX-DAT-RBAC-Platform-Administrator"]),
    )) == 0
    error_message = "Personas, the PII-authorised group and the platform admin group must hold no catalog, volume or location grant."
  }
}

# --- The Databricks admin group, in lookup mode -------------------------------

run "databricks_admins_own_and_administer" {
  command = plan

  assert {
    condition     = toset(databricks_mws_permission_assignment.platform_admins[0].permissions) == toset(["ADMIN"])
    error_message = "The Databricks admin group is workspace ADMIN."
  }

  assert {
    condition = alltrue(concat(
      [for c in values(databricks_catalog.business_domain) : c.owner == var.admins],
      [for c in values(databricks_storage_credential.catalog_storage) : c.owner == var.admins],
      [for l in values(databricks_external_location.business_domain_storage) : l.owner == var.admins],
      [for l in values(databricks_external_location.landing) : l.owner == var.admins],
    ))
    error_message = "The Databricks admin group owns catalogs, storage credentials and external locations."
  }

  assert {
    condition     = toset(keys(databricks_grant.business_domain_storage_platform_admins)) == toset(["grp", "duk"])
    error_message = "Lookup mode must still give the admin group its external-location grants: the reference platform gave them only in create mode."
  }
}

# --- Storage: one credential per entity, on its own connector -----------

run "each_entity_has_its_own_credential_and_connector" {
  command = plan

  assert {
    condition = alltrue([
      for entity in ["grp", "duk"] :
      databricks_storage_credential.catalog_storage[entity].azure_managed_identity[0].access_connector_id == var.access_connectors[entity].id
    ])
    error_message = "Each entity's storage credential must use that entity's Access Connector."
  }

  assert {
    condition = alltrue(concat(
      [for entity, l in databricks_external_location.business_domain_storage : l.credential_name == databricks_storage_credential.catalog_storage[entity].name],
      [for entity, l in databricks_external_location.landing : l.credential_name == databricks_storage_credential.catalog_storage[entity].name],
      [for entity, l in databricks_external_location.export : l.credential_name == databricks_storage_credential.catalog_storage[entity].name],
    ))
    error_message = "Every external location must use its own entity's credential, never another's."
  }
}

run "storage_paths_match_the_platform_services_containers" {
  command = plan

  assert {
    condition = alltrue([
      for entity in ["grp", "duk"] :
      databricks_external_location.business_domain_storage[entity].url == "abfss://${entity}-uc@dpxdattrsdevintgwcst001.dfs.core.windows.net/"
      && databricks_external_location.landing[entity].url == "abfss://${entity}-landing@dpxdattrsdevintgwcst001.dfs.core.windows.net/"
      && databricks_external_location.export[entity].url == "abfss://${entity}-export@dpxdattrsdevintgwcst001.dfs.core.windows.net/"
      && databricks_volume.landing[entity].storage_location == databricks_external_location.landing[entity].url
    ])
    error_message = "Paths must name the containers infra/20-platform-services creates in the trusted account."
  }

  assert {
    condition     = toset([for l in values(databricks_external_location.landing) : l.name]) == toset(["dev_grp_landing", "dev_duk_landing"])
    error_message = "Analytical external locations are {env}_{entity}_{purpose}."
  }
}

# --- Schemas, bindings and the shared catalog ----------------------

run "every_entity_gets_landing_and_export_and_only_grp_governance" {
  command = plan

  assert {
    condition     = toset(keys(databricks_schema.landing)) == toset(["grp", "duk"]) && toset(keys(databricks_schema.export)) == toset(["grp", "duk"])
    error_message = "Terraform creates landing and export in every entity catalog, grp's included."
  }

  assert {
    condition     = databricks_schema.shared_governance[0].catalog_name == "dev_grp" && databricks_schema.shared_governance[0].name == "governance"
    error_message = "The governance schema lives in grp's catalog."
  }
}

run "catalogs_are_isolated_and_bound_to_this_workspace" {
  command = plan

  assert {
    condition = alltrue([
      for c in values(databricks_catalog.business_domain) : c.isolation_mode == "ISOLATED" && c.force_destroy == false
    ])
    error_message = "Catalogs are ISOLATED and never force-destroyed."
  }

  assert {
    condition     = toset([for b in values(databricks_workspace_binding.business_domain) : b.securable_name]) == toset(["dev_grp", "dev_duk"])
    error_message = "Each catalog is bound to this workspace once."
  }

  assert {
    condition = alltrue([
      for b in values(databricks_workspace_binding.business_domain) :
      tostring(b.workspace_id) == "1234567890123411" && b.binding_type == "BINDING_TYPE_READ_WRITE"
    ])
    error_message = "dev-anl binds its catalogs to its own workspace, read-write by default; dev-ops binds the same catalogs itself."
  }
}

run "no_two_grants_share_a_principal_and_securable" {
  command = plan

  assert {
    condition = alltrue([
      for pair, copies in {
        for pair in concat(
          [for g in values(databricks_grant.account_entity_engineers_catalog) : "catalog ${g.catalog} ${g.principal}"],
          [for g in values(databricks_grant.account_entity_scientists_catalog) : "catalog ${g.catalog} ${g.principal}"],
          [for g in values(databricks_grant.account_entity_analysts_catalog) : "catalog ${g.catalog} ${g.principal}"],
          [for g in values(databricks_grant.sp_catalog_usage) : "catalog ${g.catalog} ${g.principal}"],
          [for g in values(databricks_grant.env_platform_admins_catalog) : "catalog ${g.catalog} ${g.principal}"],
          [for g in values(databricks_grant.entity_engineers_shared_catalog) : "catalog ${g.catalog} ${g.principal}"],
          [for g in values(databricks_grant.entity_analysts_shared_catalog) : "catalog ${g.catalog} ${g.principal}"],
          [for g in values(databricks_grant.business_domain_storage_sp) : "location ${g.external_location} ${g.principal}"],
          [for g in values(databricks_grant.business_domain_storage_platform_admins) : "location ${g.external_location} ${g.principal}"],
          [for g in values(databricks_grant.entity_engineers_landing_volume) : "volume ${g.volume} ${g.principal}"],
          [for g in values(databricks_grant.entity_engineers_export_volume) : "volume ${g.volume} ${g.principal}"],
          [for g in values(databricks_grant.entity_analysts_landing_volume) : "volume ${g.volume} ${g.principal}"],
          [for g in values(databricks_grant.entity_analysts_export_volume) : "volume ${g.volume} ${g.principal}"],
          [for g in values(databricks_grant.sp_databricks_catalog) : "catalog ${g.catalog} ${g.principal}"],
          [for g in values(databricks_grant.sp_databricks_landing_volume) : "volume ${g.volume} ${g.principal}"],
          [for g in values(databricks_grant.sp_databricks_export_volume) : "volume ${g.volume} ${g.principal}"],
        ) : pair => pair...
      } : length(copies) == 1
    ])
    error_message = "Two singular grants on the same principal and securable fight each other on every plan."
  }
}

# --- A new entity is data only: one more key in config/entities.yaml ---------

run "a_third_entity_fans_out_in_full" {
  command = plan

  variables {
    business_domains            = concat(var.business_domains, ["zzz"])
    external_entity_group_names = merge(var.external_entity_group_names, { zzz = { engineers = "PLACEHOLDER-dbx-data-zzz" } })
    access_connectors           = merge(var.access_connectors, { zzz = { id = "/subscriptions/00000000-0000-0000-0000-000000000000/resourceGroups/rg/providers/Microsoft.Databricks/accessConnectors/dbac-zzz", principal_id = "00000000-0000-0000-0000-000000000009" } })
  }

  assert {
    condition = (
      databricks_catalog.business_domain["zzz"].name == "dev_zzz"
      && databricks_storage_credential.catalog_storage["zzz"].azure_managed_identity[0].access_connector_id == var.access_connectors["zzz"].id
      && databricks_external_location.landing["zzz"].url == "abfss://zzz-landing@dpxdattrsdevintgwcst001.dfs.core.windows.net/"
      && contains(keys(databricks_volume.export), "zzz")
      && databricks_grant.account_entity_engineers_catalog["zzz"].principal == "PLACEHOLDER-dbx-data-zzz"
    )
    error_message = "One more entity key must yield its catalog, credential, locations, volumes and grants."
  }
}

# --- Upstream consistency is validated ----------------------------------------

run "rejects_a_data_group_for_an_entity_without_a_catalog" {
  command = plan

  variables {
    external_entity_group_names = merge(var.external_entity_group_names, { nope = { engineers = "PLACEHOLDER-dbx-data-nope" } })
  }

  expect_failures = [var.external_entity_group_names]
}

run "rejects_an_entity_without_an_access_connector" {
  command = plan

  variables {
    access_connectors = { for key, connector in var.access_connectors : key => connector if key != "duk" }
  }

  expect_failures = [var.access_connectors]
}

# Serverless compute is parked (see sql-warehouses.tf). Predictive optimisation
# runs on serverless compute, so it is off on every catalogue this state creates.
run "every_catalogue_turns_predictive_optimisation_off" {
  command = plan

  assert {
    condition = length(databricks_catalog.business_domain) > 0 && alltrue([
      for c in values(databricks_catalog.business_domain) : c.enable_predictive_optimization == "DISABLE"
    ])
    error_message = "Predictive optimisation runs on serverless compute, so it is off on every catalogue while serverless is parked."
  }
}
