# ---------------------------------------------------------------------------
# SERVERLESS COMPUTE PARKED (2026-10-13, Azure DevOps work item 107902)
#
# Doubtless infrastructure security have not yet approved serverless compute.
# A Network Connectivity Configuration would give it a private route to our
# storage, but serverless compute still runs, and processes our data, on
# Databricks-managed infrastructure outside our network. Until that is
# understood and approved, the initial deployment builds nothing that sets up
# serverless compute or runs on it. The code is commented out, not deleted,
# so that it can be restored as it was: each parked line is the original line
# behind a leading "# ", and each blank line is a bare "#". To strip
# the prefix: sed -E 's/^# ?//'.
#
# Parked here: this instance's usage policy tests.
# To restore: strip the leading "# " from every line below this note,
# retire the matching case in scripts/tests/test_serverless_parked.py, and work
# through "Serverless compute is parked" in this root's README for the rest.
# ---------------------------------------------------------------------------
# # dev-anl: the serverless usage policy. Its tags reach only the principals
# # assigned to it, so the assignment is tested as well as the tags.
#
# mock_provider "databricks" {
#   source = "./tests/mocks/workspace"
# }
#
# mock_provider "databricks" {
#   alias  = "account"
#   source = "./tests/mocks/account"
# }
#
# override_data {
#   target = data.databricks_group.external_engineers[0]
#   values = {
#     id               = "2001"
#     acl_principal_id = "groups/persona-engineers"
#   }
# }
#
# override_data {
#   target = data.databricks_group.external_analysts[0]
#   values = {
#     id               = "2002"
#     acl_principal_id = "groups/persona-analysts"
#   }
# }
#
# override_data {
#   target = data.databricks_group.external_sp_databricks[0]
#   values = {
#     id               = "2003"
#     acl_principal_id = "groups/sp-databricks"
#   }
# }
#
# # Declared so that the run blocks below can derive values from what the var files
# # supply. The root's own declaration still checks the type.
# variable "common_tags" {}
#
# run "one_usage_policy_bound_to_this_workspace" {
#   command = plan
#
#   assert {
#     condition = (
#       databricks_budget_policy.workspace.policy_name == "dpx-dat-dev-analytical-usage-policy"
#       && length(databricks_budget_policy.workspace.binding_workspace_ids) == 1
#       && databricks_budget_policy.workspace.binding_workspace_ids[0] == 1234567890123411
#     )
#     error_message = "One usage policy per workspace, bound to it alone."
#   }
# }
#
# run "usage_policy_carries_the_mandatory_tags" {
#   command = plan
#
#   assert {
#     condition = tomap({
#       for tag in databricks_budget_policy.workspace.custom_tags : tag.key => tag.value
#     }) == tomap(var.common_tags)
#     error_message = "The usage policy carries common_tags, so serverless usage is attributed."
#   }
# }
#
# run "personas_and_workloads_are_assigned_to_the_policy" {
#   command = plan
#
#   assert {
#     condition = toset(flatten([
#       for rule in databricks_access_control_rule_set.usage_policy[0].grant_rules :
#       rule.principals if rule.role == "roles/budgetPolicy.user"
#     ])) == toset(["groups/persona-engineers", "groups/persona-analysts", "groups/sp-databricks"])
#     error_message = "Both personas and sp-databricks must be users of the policy, or its tags never reach their compute."
#   }
# }
#
# run "usage_policy_carries_the_optional_tags" {
#   command = plan
#
#   assert {
#     condition     = alltrue([for key in ["Application", "BusinessEntity", "CostCentre", "DataClassification", "Owner"] : contains([for tag in databricks_budget_policy.workspace.custom_tags : tag.key], key)])
#     error_message = "The usage policy carries the optional tags the var file sets, so serverless cost can be attributed by business entity and cost centre."
#   }
# }
#
# run "optional_tags_are_not_required" {
#   command = plan
#
#   variables {
#     common_tags = { for key, value in var.common_tags : key => value if contains(["Project", "Environment", "WorkspaceType", "ManagedBy"], key) }
#   }
#
#   assert {
#     condition     = length(databricks_budget_policy.workspace.custom_tags) == 4
#     error_message = "With only the mandatory tags set, the plan still succeeds and the usage policy carries just those four."
#   }
# }
