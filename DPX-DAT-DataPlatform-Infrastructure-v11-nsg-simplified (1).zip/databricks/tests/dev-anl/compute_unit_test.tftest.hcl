# dev-anl: compute. The reference platform's four cluster policies and its
# warehouses, with their permissions on personas and workloads.

mock_provider "databricks" {
  source = "./tests/mocks/workspace"
}

mock_provider "databricks" {
  alias  = "account"
  source = "./tests/mocks/account"
}

variables {
  engineers     = "PG-DPX-DAT-RBAC-Engineer"
  analysts      = "PG-DPX-DAT-RBAC-Analyst"
  sp_databricks = "PG-DPX-DAT-RBAC-ServicePrincipals-NonProd"
  admins        = "PG-DPX-DAT-RBAC-Databricks-Administrator"
  data_groups = [
    "PG-DPX-DAT-RBAC-GroupShared-Contributor", "PG-DPX-DAT-RBAC-GroupShared-Reader",
    "PG-DPX-DAT-RBAC-DoubtlessUK-Contributor", "PG-DPX-DAT-RBAC-DoubtlessUK-Reader",
  ]
  entity_groups = {
    grp = ["PG-DPX-DAT-RBAC-GroupShared-Contributor", "PG-DPX-DAT-RBAC-GroupShared-Reader"]
    duk = ["PG-DPX-DAT-RBAC-DoubtlessUK-Contributor", "PG-DPX-DAT-RBAC-DoubtlessUK-Reader"]
  }
}

# Declared so that the run blocks below can derive values from what the var files
# supply. The root's own declaration still checks the type.
variable "common_tags" {}

run "non_production_gets_the_four_policies" {
  command = plan

  assert {
    condition = (
      databricks_cluster_policy.job_compute[0].name == "dev-job-compute"
      && databricks_cluster_policy.dlt_pipeline[0].name == "dev-dlt-pipeline"
      && databricks_cluster_policy.interactive_dev[0].name == "dev-interactive"
      && length(databricks_cluster_policy.interactive_prod) == 0
    )
    error_message = "dev gets job, pipeline and the interactive dev policy, named {env}-*."
  }
}

run "every_environment_gets_an_interactive_policy" {
  command = plan

  # As stg-anl. (It would also look up the non-production NCC that dev-anl owns:
  # serverless compute is parked, see network-connectivity.tf.)
  variables {
    environment = "stg"
    common_tags = merge(var.common_tags, { Environment = "stg" })
    # manage_shared_ncc = false
  }

  assert {
    condition     = length(databricks_cluster_policy.interactive_dev) == 1
    error_message = "stg must get an interactive policy: the reference compared environment names as strings, so tst and stg got none."
  }
}

run "the_business_domain_tag_allows_every_entity" {
  command = plan

  assert {
    condition = (
      jsondecode(databricks_cluster_policy.interactive_dev[0].definition)["custom_tags.business_domain"]["values"] == ["grp", "duk"]
      && jsondecode(databricks_cluster_policy.interactive_dev[0].definition)["custom_tags.business_domain"]["defaultValue"] == "grp"
    )
    error_message = "The business_domain tag allows every entity, the shared one included, and defaults to the shared entity."
  }
}

run "job_and_pipeline_policies_go_to_workloads_and_engineers" {
  command = plan

  assert {
    condition = alltrue([
      for permissions in [databricks_permissions.job_compute_policy[0], databricks_permissions.dlt_pipeline_policy[0]] :
      toset([for ac in permissions.access_control : coalesce(ac.group_name, ac.service_principal_name)]) == toset([
        "00000000-0000-0000-0000-000000000000", var.sp_databricks, var.engineers,
      ])
    ])
    error_message = "Job and pipeline policies: the pipeline identity, sp-databricks, and in non-production the engineering persona."
  }
}

run "interactive_policy_goes_to_the_engineering_persona" {
  command = plan

  assert {
    condition     = toset([for ac in databricks_permissions.interactive_dev_policy[0].access_control : ac.group_name]) == toset([var.engineers])
    error_message = "Only the engineering persona uses the interactive policy (analysts work in SQL)."
  }
}

run "data_groups_hold_no_policy_permission" {
  command = plan

  assert {
    condition = length(setintersection(toset(var.data_groups), toset(flatten([
      for permissions in concat(databricks_permissions.job_compute_policy, databricks_permissions.dlt_pipeline_policy, databricks_permissions.interactive_dev_policy) :
      [for ac in permissions.access_control : coalesce(ac.group_name, ac.service_principal_name)]
    ])))) == 0
    error_message = "Policy permissions go to personas and workloads, not to data groups."
  }
}

run "one_classic_warehouse_per_entity_plus_automation" {
  command = plan

  assert {
    condition = (
      databricks_sql_endpoint.automation[0].name == "dev-automation-classic"
      && toset([for w in values(databricks_sql_endpoint.entity_warehouses) : w.name]) == toset(["dev-grp-warehouse-classic", "dev-duk-warehouse-classic"])
    )
    error_message = "A classic warehouse per entity, plus the automation warehouse."
  }

  # Serverless compute is parked: see sql-warehouses.tf.
  assert {
    condition = alltrue([
      for w in concat(databricks_sql_endpoint.automation, values(databricks_sql_endpoint.entity_warehouses)) :
      !w.enable_serverless_compute && w.warehouse_type == "PRO"
    ])
    error_message = "Every warehouse is a classic PRO warehouse while serverless compute is parked."
  }
}

run "each_data_group_uses_only_its_own_warehouse" {
  command = plan

  assert {
    condition = alltrue([
      for entity, permissions in databricks_permissions.sql_warehouse_entity_engineers :
      toset([for ac in permissions.access_control : ac.group_name if ac.permission_level == "CAN_USE"]) == toset(var.entity_groups[entity])
    ])
    error_message = "Each entity's warehouse is usable by that entity's Contributor and Reader groups only."
  }
}

run "databricks_admins_manage_every_warehouse_in_lookup_mode" {
  command = plan

  assert {
    condition = alltrue([
      for permissions in concat(values(databricks_permissions.sql_warehouse_entity_engineers), databricks_permissions.automation_warehouse) :
      contains([for ac in permissions.access_control : ac.group_name if ac.permission_level == "CAN_MANAGE"], var.admins)
    ])
    error_message = "The Databricks admin group manages every warehouse; the reference gated this on create mode."
  }
}

run "workloads_use_the_automation_warehouse" {
  command = plan

  assert {
    condition     = contains([for ac in databricks_permissions.automation_warehouse[0].access_control : ac.group_name if ac.permission_level == "CAN_USE"], var.sp_databricks)
    error_message = "The automation warehouse is for workloads."
  }
}

run "warehouses_carry_the_mandatory_tags" {
  command = plan

  assert {
    condition = alltrue([
      for w in concat(databricks_sql_endpoint.automation, values(databricks_sql_endpoint.entity_warehouses)) :
      alltrue([for key in ["Project", "Environment", "WorkspaceType", "ManagedBy"] : contains([for t in w.tags[0].custom_tags : t.key], key)])
    ])
    error_message = "Every warehouse carries the mandatory tags."
  }

  assert {
    condition = alltrue([
      for w in values(databricks_sql_endpoint.entity_warehouses) :
      contains([for t in w.tags[0].custom_tags : "${t.key}=${t.value}"], "ComputeType=Classic")
    ])
    error_message = "Each entity warehouse is tagged as classic compute."
  }
}

# A classic warehouse stops after at least 10 idle minutes, or never.
run "rejects_an_auto_stop_a_classic_warehouse_cannot_take" {
  command = plan

  variables {
    sql_warehouse_auto_stop_mins = 5
  }

  expect_failures = [var.sql_warehouse_auto_stop_mins]
}
