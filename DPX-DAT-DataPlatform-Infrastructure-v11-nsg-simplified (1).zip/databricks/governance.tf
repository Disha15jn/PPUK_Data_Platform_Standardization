/**
 * Governance (Doubtless addition)
 *
 * The reference platform ran governance through post-apply Python scripts that
 * reported success on failure. Here it is provider
 * resources:
 *
 * - The masking functions: the reference platform's eight, adopted as they are,
 *   rendered for the shared catalog and run by a job on the automation
 *   warehouse. Analytical workspaces only: <env>-ops reaches <env>_grp's
 *   through the catalog binding.
 * - The masking policies: one per catalog per PII class, from the analytical
 *   state. A policy sits on the catalog, so it holds in both workspaces. They
 *   mask by default and except the PII-authorised group.
 *   They call the functions, so they are switched on (enable_masking_policies)
 *   in a later change, once a job run has created them.
 *
 * Applying governed tags is not granted here: see the handover notes.
 */

################ Masking Functions ###############

locals {
  # The functions live in the shared catalog's governance schema, created by
  # an analytical workspace (unity-catalog.tf).
  deploy_masking_functions = length(databricks_schema.shared_governance) > 0 && var.create_sql_warehouse
}

resource "databricks_workspace_file" "masking_functions" {
  count = local.deploy_masking_functions ? 1 : 0
  path  = "/Shared/data-platform/governance/pii_masking_functions.sql"
  content_base64 = base64encode(templatefile("${path.module}/resources/pii_masking_functions.sql.tftpl", {
    catalog_name = databricks_schema.shared_governance[0].catalog_name
  }))
}

# The job runs as its owner, the pipeline identity, which needs to create
# functions in the governance schema.
resource "databricks_grant" "sp_governance_schema" {
  count      = local.deploy_masking_functions ? 1 : 0
  schema     = "${databricks_schema.shared_governance[0].catalog_name}.${databricks_schema.shared_governance[0].name}"
  principal  = var.service_principal_application_id
  privileges = ["USE_SCHEMA", "CREATE_FUNCTION", "EXECUTE"]
}

# Creates or replaces the functions. Terraform defines the job; running it after
# an apply is a pipeline step, or a one-off manual run (handover notes).
resource "databricks_job" "masking_functions" {
  count = local.deploy_masking_functions ? 1 : 0
  name  = "${var.environment}-deploy-masking-functions"
  tags  = var.common_tags

  task {
    task_key = "create_masking_functions"

    sql_task {
      warehouse_id = databricks_sql_endpoint.automation[0].id

      file {
        path   = databricks_workspace_file.masking_functions[0].path
        source = "WORKSPACE"
      }
    }
  }

  depends_on = [databricks_grant.sp_governance_schema]
}

################ Masking Policies ###############

locals {
  # The reference platform's PII classes: its policy name suffix, the Unity
  # Catalog classification tag it matches, and its masking function.
  pii_masks = {
    email       = { sql_tag = "class.email_address", function = "mask_email", description = "email addresses" }
    name        = { sql_tag = "class.name", function = "mask_name", description = "person names" }
    phone       = { sql_tag = "class.phone_number", function = "mask_phone", description = "phone numbers" }
    ssn         = { sql_tag = "class.us_ssn", function = "mask_ssn", description = "national identifiers" }
    dob         = { sql_tag = "class.date_of_birth", function = "mask_dob", description = "dates of birth" }
    credit_card = { sql_tag = "class.credit_card", function = "mask_credit_card", description = "card numbers" }
    address     = { sql_tag = "class.location", function = "mask_address", description = "physical addresses" }
    ip          = { sql_tag = "class.ip_address", function = "mask_ip", description = "IP addresses" }
  }

  masking_policies = var.enable_masking_policies ? {
    for pair in setproduct(keys(databricks_catalog.business_domain), keys(local.pii_masks)) :
    "${pair[0]}-${pair[1]}" => { entity = pair[0], mask = pair[1] }
  } : {}
}

resource "databricks_policy_info" "pii_mask" {
  for_each = local.masking_policies

  name                  = "${databricks_catalog.business_domain[each.value.entity].name}_mask_${each.value.mask}_policy"
  comment               = "Masks ${local.pii_masks[each.value.mask].description} in columns tagged ${local.pii_masks[each.value.mask].sql_tag}"
  on_securable_type     = "CATALOG"
  on_securable_fullname = databricks_catalog.business_domain[each.value.entity].name
  policy_type           = "POLICY_TYPE_COLUMN_MASK"
  for_securable_type    = "TABLE"
  to_principals         = ["account users"]
  except_principals     = [local.pii_authorized.display_name]

  match_columns = [{
    condition = "hasTag('${local.pii_masks[each.value.mask].sql_tag}')"
    alias     = "m"
  }]

  column_mask = {
    function_name = "${local.shared_catalog_name}.governance.${local.pii_masks[each.value.mask].function}"
    on_column     = "m"
  }
}
