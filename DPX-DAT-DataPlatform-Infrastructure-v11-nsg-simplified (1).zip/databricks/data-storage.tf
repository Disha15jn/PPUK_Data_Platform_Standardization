/**
 * Data Storage Configuration
 *
 * External locations, the landing and export schemas, and their external
 * volumes. Each entity has its own containers in the trusted account:
 * {entity}-uc, -landing and -export, which serve both workspaces.
 * infra/20-platform-services creates them, through Resource Manager;
 * this root only points at them. Only the analytical state creates these.
 *
 * Only the reference platform's container-per-catalog pattern is kept. Its
 * single-container branches, the storage subdirectory scripts and the fact and
 * dim schemas are not.
 */

################ External Locations ###############

# Landing zone external locations: one per entity, on its own container.
resource "databricks_external_location" "landing" {
  for_each        = var.create_external_locations && local.owns_catalogs ? local.entity_catalogs : {}
  name            = "${local.metastore_object_name_prefix}_${lower(each.key)}_landing"
  url             = "abfss://${local.catalog_containers[each.key].landing}@${var.storage_account_name}.dfs.core.windows.net/"
  credential_name = databricks_storage_credential.catalog_storage[each.key].name
  owner           = try(local.platform_admins.display_name, null)
  comment         = "Landing zone for ${var.environment} ${each.key} data ingestion"
}

# Export zone external locations: one per entity, on its own container.
resource "databricks_external_location" "export" {
  for_each        = var.create_external_locations && local.owns_catalogs ? local.entity_catalogs : {}
  name            = "${local.metastore_object_name_prefix}_${lower(each.key)}_export"
  url             = "abfss://${local.catalog_containers[each.key].export}@${var.storage_account_name}.dfs.core.windows.net/"
  credential_name = databricks_storage_credential.catalog_storage[each.key].name
  owner           = try(local.platform_admins.display_name, null)
  comment         = "Export zone for ${var.environment} ${each.key} data delivery"
}

# Catalog storage: each entity's managed storage, on its own {entity}-uc
# container.
resource "databricks_external_location" "business_domain_storage" {
  for_each        = local.owns_catalogs ? local.business_domain_catalogs : {}
  name            = "${local.metastore_object_name_prefix}_${lower(each.key)}_storage"
  url             = "abfss://${local.catalog_containers[each.key].uc}@${var.unity_catalog_storage}.dfs.core.windows.net/"
  credential_name = databricks_storage_credential.catalog_storage[each.key].name
  owner           = try(local.platform_admins.display_name, null)
  comment         = "Storage location for ${var.environment} ${each.key} catalog"
  skip_validation = false
}

################ External Location Permissions ###############

# The reference platform's explicit rights for the pipeline identity on the
# catalog storage locations. As with the credentials, applying them already
# needs membership of the Databricks admin group, which owns the locations.
resource "databricks_grant" "business_domain_storage_sp" {
  for_each = var.create_external_locations ? databricks_external_location.business_domain_storage : {}

  external_location = each.value.name
  principal         = var.service_principal_application_id
  privileges        = ["ALL_PRIVILEGES"]
}

# The Databricks admin group, for administration and troubleshooting. The
# reference platform gated this on create mode, so in lookup mode admins got
# nothing.
resource "databricks_grant" "business_domain_storage_platform_admins" {
  for_each = var.create_external_locations && local.has_group.platform_admins ? databricks_external_location.business_domain_storage : {}

  external_location = each.value.name
  principal         = local.platform_admins.display_name
  privileges        = ["CREATE_MANAGED_STORAGE", "READ_FILES", "WRITE_FILES", "MANAGE"]
}

################ Schemas ###############

# Terraform creates only landing and export, in every entity catalog.
# The bundles create bronze, silver and gold.
resource "databricks_schema" "landing" {
  for_each     = local.owns_catalogs ? local.entity_catalogs : {}
  catalog_name = databricks_catalog.business_domain[each.key].name
  name         = "landing"
  comment      = "Schema for ${each.key} landing zone external volumes - ${var.environment}"
  owner        = try(local.platform_admins.display_name, null)

  properties = {
    environment     = var.environment
    business_domain = each.key
    purpose         = "external_data_ingestion"
    managed_by      = "terraform"
  }
}

resource "databricks_schema" "export" {
  for_each     = local.owns_catalogs ? local.entity_catalogs : {}
  catalog_name = databricks_catalog.business_domain[each.key].name
  name         = "export"
  comment      = "Schema for ${each.key} export zone external volumes - ${var.environment}"
  owner        = try(local.platform_admins.display_name, null)

  properties = {
    environment     = var.environment
    business_domain = each.key
    purpose         = "external_data_export"
    managed_by      = "terraform"
  }
}

################ Volumes ###############

# Each entity's landing and export volumes, at the root of its own container.
resource "databricks_volume" "landing" {
  for_each         = var.create_volumes && local.owns_catalogs && var.create_external_locations ? local.entity_catalogs : {}
  name             = "landing_volume"
  catalog_name     = databricks_catalog.business_domain[each.key].name
  schema_name      = databricks_schema.landing[each.key].name
  volume_type      = "EXTERNAL"
  storage_location = databricks_external_location.landing[each.key].url
  comment          = "Landing zone volume for ${each.key} raw file uploads - ${var.environment}"
}

resource "databricks_volume" "export" {
  for_each         = var.create_volumes && local.owns_catalogs && var.create_external_locations ? local.entity_catalogs : {}
  name             = "export_volume"
  catalog_name     = databricks_catalog.business_domain[each.key].name
  schema_name      = databricks_schema.export[each.key].name
  volume_type      = "EXTERNAL"
  storage_location = databricks_external_location.export[each.key].url
  comment          = "Export zone volume for ${each.key} external data delivery - ${var.environment}"
}

################ Volume Permissions ###############

# Each entity's Contributor group on its own landing and export volumes: read
# and write in dev and tst, read in stg and prd. The Reader's are in
# entity-readers.tf. Personas get no volume rights: direct file access bypasses
# tagging and masking.
#
# The volume name is built from the configured catalog, schema and volume names,
# not the volume's computed id, so it is known at plan time and still waits for
# the volume to exist.
resource "databricks_grant" "entity_engineers_landing_volume" {
  for_each   = var.create_volumes && var.create_external_locations && local.owns_catalogs ? local.all_entity_engineers : {}
  volume     = "${databricks_volume.landing[each.key].catalog_name}.${databricks_volume.landing[each.key].schema_name}.${databricks_volume.landing[each.key].name}"
  principal  = each.value.display_name
  privileges = var.volume_privileges_entity_engineers
}

resource "databricks_grant" "entity_engineers_export_volume" {
  for_each   = var.create_volumes && var.create_external_locations && local.owns_catalogs ? local.all_entity_engineers : {}
  volume     = "${databricks_volume.export[each.key].catalog_name}.${databricks_volume.export[each.key].schema_name}.${databricks_volume.export[each.key].name}"
  principal  = each.value.display_name
  privileges = var.volume_privileges_entity_engineers
}
