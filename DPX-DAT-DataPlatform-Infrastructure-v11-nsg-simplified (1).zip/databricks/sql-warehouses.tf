/**
 * SQL Warehouse Configuration
 *
 * A classic automation warehouse for workloads, and a classic warehouse per
 * entity for its data group, both PRO. Classic warehouses run in the
 * workspace's own network, like clusters.
 */

# ---------------------------------------------------------------------------
# SERVERLESS COMPUTE PARKED (2026-10-13, Azure DevOps work item 107902)
#
# Doubtless infrastructure security have not yet approved serverless compute.
# A Network Connectivity Configuration would give it a private route to our
# storage, but serverless compute still runs, and processes our data, on
# Databricks-managed infrastructure outside our network. Until that is
# understood and approved, the initial deployment builds nothing that sets up
# serverless compute or runs on it. The code is commented out, not deleted,
# so that it can be restored as it was: each parked line is the original line
# behind a leading "# ", and each blank line is a bare "#". To strip
# the prefix: sed -E 's/^# ?//'.
#
# Parked here: these warehouses were serverless. Each line that made them so is
# kept, commented out, above the classic line that replaces it. The resource
# addresses lost their _serverless suffix, so restoring needs no moved blocks.
# To restore: in each warehouse and in the entity tags, uncomment the serverless
# lines and delete the classic lines beneath them, then run terraform fmt;
# restore the variable and output names noted in variables.tf and outputs.tf
# (the auto-stop validation there can go too, as serverless accepts under 10
# minutes); rename the warehouses in the tests and put the READMEs' wording
# back,
# retire the matching case in scripts/tests/test_serverless_parked.py, and work
# through "Serverless compute is parked" in this root's README for the rest.
# ---------------------------------------------------------------------------

################ Locals ###############

locals {
  # One warehouse per entity data group.
  entity_warehouse_configs = var.create_sql_warehouse && length(local.all_entity_engineers) > 0 ? {
    for entity, group in local.all_entity_engineers : entity => {
      size         = lookup(var.entity_warehouse_sizes, entity, var.sql_warehouse_size)
      min_clusters = lookup(var.entity_warehouse_scaling, entity, null) != null ? var.entity_warehouse_scaling[entity].min : var.sql_warehouse_min_num_clusters
      max_clusters = lookup(var.entity_warehouse_scaling, entity, null) != null ? var.entity_warehouse_scaling[entity].max : var.sql_warehouse_max_num_clusters
    }
  } : {}

  # Warehouse tags: the mandatory common_tags, plus the reference platform's own.
  automation_warehouse_tags = merge({ Purpose = "Automation" }, var.common_tags)
  entity_warehouse_tags = {
    for entity in keys(local.entity_warehouse_configs) :
    # entity => merge({ Entity = entity, workload = entity, ComputeType = "Serverless" }, var.common_tags)
    entity => merge({ Entity = entity, workload = entity, ComputeType = "Classic" }, var.common_tags)
  }
}

################ SQL Warehouses ###############

# Classic SQL warehouse for automation: the masking-functions job and other
# workload tasks. It takes minutes to start, where a serverless one started
# almost at once.
resource "databricks_sql_endpoint" "automation" {
  count = var.create_sql_warehouse ? 1 : 0
  # name                      = "${var.environment}-automation-serverless"
  name             = "${var.environment}-automation-classic"
  cluster_size     = "2X-Small"
  auto_stop_mins   = var.sql_warehouse_auto_stop_mins
  min_num_clusters = 1
  max_num_clusters = 1
  # enable_serverless_compute = true
  enable_serverless_compute = false
  warehouse_type            = "PRO"

  tags {
    dynamic "custom_tags" {
      for_each = local.automation_warehouse_tags
      content {
        key   = custom_tags.key
        value = custom_tags.value
      }
    }
  }
}

# One classic warehouse per entity, for usage tracking and isolation.
resource "databricks_sql_endpoint" "entity_warehouses" {
  for_each = var.enable_entity_warehouses ? local.entity_warehouse_configs : {}
  # name                      = "${var.environment}-${lower(each.key)}-warehouse-serverless"
  name             = "${var.environment}-${lower(each.key)}-warehouse-classic"
  cluster_size     = each.value.size
  auto_stop_mins   = var.sql_warehouse_auto_stop_mins
  min_num_clusters = each.value.min_clusters
  max_num_clusters = each.value.max_clusters
  # enable_serverless_compute = true
  enable_serverless_compute = false
  warehouse_type            = "PRO"

  tags {
    dynamic "custom_tags" {
      for_each = local.entity_warehouse_tags[each.key]
      content {
        key   = custom_tags.key
        value = custom_tags.value
      }
    }
  }
}

################ Warehouse Permissions ###############

# Each entity's warehouse: its Contributor and Reader groups may use it; the Databricks admin
# group manages it. The reference platform gated CAN_MANAGE on create mode, so
# in lookup mode admins managed no warehouse.
resource "databricks_permissions" "sql_warehouse_entity_engineers" {
  for_each        = var.enable_entity_warehouses ? local.entity_warehouse_configs : {}
  sql_endpoint_id = databricks_sql_endpoint.entity_warehouses[each.key].id

  access_control {
    group_name       = local.all_entity_engineers[each.key].display_name
    permission_level = "CAN_USE"
  }

  dynamic "access_control" {
    for_each = contains(keys(local.all_entity_scientists), each.key) ? [local.all_entity_scientists[each.key].display_name] : []
    content {
      group_name       = access_control.value
      permission_level = "CAN_USE"
    }
  }

  dynamic "access_control" {
    for_each = contains(keys(local.all_entity_analysts), each.key) ? [local.all_entity_analysts[each.key].display_name] : []
    content {
      group_name       = access_control.value
      permission_level = "CAN_USE"
    }
  }

  dynamic "access_control" {
    for_each = local.platform_admins != null ? [local.platform_admins.display_name] : []
    content {
      group_name       = access_control.value
      permission_level = "CAN_MANAGE"
    }
  }
}

# The automation warehouse: the tier's workloads may use it; the Databricks
# admin group manages it. The reference platform set no permissions on it.
resource "databricks_permissions" "automation_warehouse" {
  count           = var.create_sql_warehouse && (local.sp_databricks != null || local.platform_admins != null) ? 1 : 0
  sql_endpoint_id = databricks_sql_endpoint.automation[0].id

  dynamic "access_control" {
    for_each = local.sp_databricks != null ? [local.sp_databricks.display_name] : []
    content {
      group_name       = access_control.value
      permission_level = "CAN_USE"
    }
  }

  dynamic "access_control" {
    for_each = local.platform_admins != null ? [local.platform_admins.display_name] : []
    content {
      group_name       = access_control.value
      permission_level = "CAN_MANAGE"
    }
  }
}
