/**
 * Terraform Outputs
 *
 * Organised by resource category. None compares environment names as strings
 * or depends on create mode, as the reference platform's did.
 */

################ Workspace Outputs ###############

output "environment" {
  description = "Environment name."
  value       = var.environment
}

output "workspace_id" {
  description = "Databricks workspace ID."
  value       = var.workspace_id
}

output "workspace_name" {
  description = "Name of the Azure Databricks workspace this state configures."
  value       = var.workspace_name
}

output "workspace_track" {
  description = "Which workspace this state configures: anl or ops."
  value       = var.workspace_track
}

output "workspace_url" {
  description = "Databricks workspace URL."
  value       = local.workspace_url
}

################ Unity Catalog Outputs ###############

output "catalogs" {
  description = "Each entity's catalog, bound to this workspace. The same names in both of an environment's workspaces."
  value       = { for domain, binding in databricks_workspace_binding.business_domain : lower(domain) => binding.securable_name }
}

output "external_locations" {
  description = "Each entity's external location names: catalog storage, landing and export. Empty in an operational workspace, which creates none."
  value = {
    storage = { for domain, location in databricks_external_location.business_domain_storage : domain => location.name }
    landing = { for domain, location in databricks_external_location.landing : domain => location.name }
    export  = { for domain, location in databricks_external_location.export : domain => location.name }
  }
}

output "metastore_id" {
  description = "The Unity Catalog metastore this workspace is attached to, checked against the regional one."
  value       = data.databricks_current_metastore.this.id
}

output "storage_credential_names" {
  description = "Each entity's storage credential name."
  value       = { for domain, credential in databricks_storage_credential.catalog_storage : domain => credential.name }
}

output "volumes" {
  description = "Each entity's landing and export volume names."
  value = {
    for domain in keys(databricks_volume.landing) : lower(domain) => {
      landing = "${databricks_volume.landing[domain].catalog_name}.${databricks_volume.landing[domain].schema_name}.${databricks_volume.landing[domain].name}"
      export  = "${databricks_volume.export[domain].catalog_name}.${databricks_volume.export[domain].schema_name}.${databricks_volume.export[domain].name}"
    }
  }
}

################ Compute Outputs ###############

output "automation_warehouse_id" {
  description = "ID of the automation warehouse, classic while serverless compute is parked."
  value       = one(databricks_sql_endpoint.automation[*].id)
}

output "cluster_policies" {
  description = "The cluster policies' IDs and names. 'interactive' is the one this environment has: dev in dev, tst and stg, prod in prd."
  value = var.create_cluster_policies ? {
    job_compute = {
      id   = databricks_cluster_policy.job_compute[0].id
      name = databricks_cluster_policy.job_compute[0].name
    }
    dlt_pipeline = {
      id   = databricks_cluster_policy.dlt_pipeline[0].id
      name = databricks_cluster_policy.dlt_pipeline[0].name
    }
    interactive = {
      id   = local.is_prod ? databricks_cluster_policy.interactive_prod[0].id : databricks_cluster_policy.interactive_dev[0].id
      name = local.is_prod ? databricks_cluster_policy.interactive_prod[0].name : databricks_cluster_policy.interactive_dev[0].name
    }
  } : null
}

# Was entity_sql_warehouses_serverless. Serverless compute is parked: see
# sql-warehouses.tf.
output "entity_sql_warehouses" {
  description = "Each entity's SQL warehouse, classic while serverless compute is parked: its ID, name and HTTP path."
  value = {
    for entity, warehouse in databricks_sql_endpoint.entity_warehouses : entity => {
      id        = warehouse.id
      name      = warehouse.name
      http_path = "/sql/1.0/warehouses/${warehouse.id}"
    }
  }
}

# Serverless compute is parked: see network-connectivity.tf.
# ################ Network Outputs ###############
#
# output "ncc_binding_id" {
#   description = "NCC binding ID for this workspace."
#   value       = one(databricks_mws_ncc_binding.workspace[*].id)
# }
#
# output "ncc_id" {
#   description = "The ID of this tier's Network Connectivity Configuration, which the workspace binds to."
#   value       = local.ncc_id
# }
#
# output "nonprod_ncc_prd_storage_rule_ids" {
#   description = "NCC private endpoint rule IDs for production's trusted storage on the non-production NCC, by rule name, when prd-anl's lower-environment provision is on. Each needs approving on production's storage within 14 days."
#   value       = { for name, rule in databricks_mws_ncc_private_endpoint_rule.prd_storage_on_nonprod_ncc : name => rule.rule_id }
# }
#
# output "ncc_private_endpoint_rule_ids" {
#   description = "NCC private endpoint rule IDs, by rule name: this environment's trusted storage, in analytical states. Each needs approving on the storage side within 14 days."
#   value       = { for name, rule in databricks_mws_ncc_private_endpoint_rule.this : name => rule.rule_id }
# }

################ Governance, Secrets and Cost Outputs ###############

output "masking_functions_job_id" {
  description = "ID of the job that creates the masking functions, in an analytical workspace. Run it after an apply that changes them, before enabling the masking policies."
  value       = one(databricks_job.masking_functions[*].id)
}

output "secret_scope_name" {
  description = "Secret scope name."
  value       = one(databricks_secret_scope.key_vault[*].name)
}

# Serverless compute is parked: see usage-policies.tf.
# output "usage_policy_id" {
#   description = "ID of this workspace's serverless usage policy."
#   value       = databricks_budget_policy.workspace.policy_id
# }
