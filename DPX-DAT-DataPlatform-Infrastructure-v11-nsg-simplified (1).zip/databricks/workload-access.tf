/**
 * Workload Access (Doubtless addition)
 *
 * Workload identities (managed identities and service principals) act through
 * one sp-databricks Entra group per tier, never one by one. Azure
 * Databricks provisions a service principal only on first use, so no resource
 * here names an identity: an identity inherits the group's rights when it
 * first authenticates. The Calandra team add each identity to its group; the
 * principal IDs are outputs of infra/20-platform-services.
 *
 * This replaces the reference platform's managed_identity_service_principals,
 * which registered identities one by one, and its reuse of the environment-wide
 * 'engineers' key, which is now the engineering persona.
 *
 * The job and pipeline policy CAN_USE, and the automation warehouse CAN_USE,
 * are in cluster-policies.tf and sql-warehouses.tf, because each object's
 * permissions are one authoritative resource.
 */

data "databricks_group" "external_sp_databricks" {
  count        = local.has_group.sp_databricks ? 1 : 0
  provider     = databricks.account
  display_name = var.external_group_names["sp_databricks"]
}

locals {
  sp_databricks = local.has_group.sp_databricks ? {
    id               = data.databricks_group.external_sp_databricks[0].id
    display_name     = data.databricks_group.external_sp_databricks[0].display_name
    acl_principal_id = data.databricks_group.external_sp_databricks[0].acl_principal_id
  } : null
}

################ Workspace Assignment and Entitlements ###############

resource "databricks_mws_permission_assignment" "sp_databricks" {
  count        = local.has_group.sp_databricks ? 1 : 0
  provider     = databricks.account
  workspace_id = var.workspace_id
  principal_id = local.sp_databricks.id
  permissions  = ["USER"]
}

# Which entitlements a workload group needs for its members' jobs to run is to
# be confirmed on the platform: it is not yet verified. Jobs create their compute
# through the job and pipeline policies, so cluster creation stays off.
#
# depends_on: entitlements can only be set once the group is assigned to the
# workspace, which Terraform cannot see from the references.
resource "databricks_entitlements" "sp_databricks" {
  count                      = local.has_group.sp_databricks ? 1 : 0
  group_id                   = local.sp_databricks.id
  allow_cluster_create       = false
  allow_instance_pool_create = false
  databricks_sql_access      = true
  workspace_access           = true

  depends_on = [databricks_mws_permission_assignment.sp_databricks]
}

################ Catalog and Volume Grants ###############

# Workloads write every entity's catalogs in their tier, from either workspace;
# in production they are the only principals that can. Granted from the
# analytical state. EXECUTE is merged into the shared catalog's grant, for the
# masking functions.
resource "databricks_grant" "sp_databricks_catalog" {
  for_each  = local.has_group.sp_databricks ? databricks_catalog.business_domain : {}
  catalog   = each.value.name
  principal = local.sp_databricks.display_name
  privileges = (
    each.value.name == local.shared_catalog_name
    ? distinct(concat(var.catalog_privileges_sp_databricks, ["EXECUTE"]))
    : var.catalog_privileges_sp_databricks
  )
}

resource "databricks_grant" "sp_databricks_landing_volume" {
  for_each   = local.has_group.sp_databricks ? databricks_volume.landing : {}
  volume     = "${each.value.catalog_name}.${each.value.schema_name}.${each.value.name}"
  principal  = local.sp_databricks.display_name
  privileges = var.volume_privileges_sp_databricks
}

resource "databricks_grant" "sp_databricks_export_volume" {
  for_each   = local.has_group.sp_databricks ? databricks_volume.export : {}
  volume     = "${each.value.catalog_name}.${each.value.schema_name}.${each.value.name}"
  principal  = local.sp_databricks.display_name
  privileges = var.volume_privileges_sp_databricks
}
