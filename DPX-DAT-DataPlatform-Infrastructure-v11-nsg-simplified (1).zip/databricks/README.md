# databricks

Everything inside Databricks for one workspace: who can get in and what they may do, Unity
Catalog, storage, compute (classic only, while serverless compute is parked), secrets and data
masking. It runs
on the Azure resources `infra/20-platform-services` provides and creates no Azure resources of
its own: the Databricks provider only.

**Owner:** Cynozure build it; Hexaware run its pipeline.
**State instances:** `dev-anl`, `dev-ops`, `tst-anl`, `tst-ops`, `stg-anl`, `stg-ops`, `prd-anl`
and `prd-ops`: one per workspace, an analytical and an operational one in every environment. The
six non-production states apply from the `development` branch; `prd-anl` and `prd-ops` from
`production`.

## Serverless compute is parked

Doubtless infrastructure security have not yet approved serverless compute (Azure DevOps work
item 107902, 13 October 2026). A Network Connectivity Configuration would give it a private route
to our storage, but serverless compute still runs, and processes our data, on Databricks-managed
infrastructure outside our network. Until that is understood and approved, this root builds
nothing that sets up serverless compute or runs on it. The code is commented out, not deleted,
under a `SERVERLESS COMPUTE PARKED` note that says how to restore it:

- `network-connectivity.tf`: the NCCs, their workspace bindings and private endpoint rules, with
  their outputs, switches and tests. The resolve step still writes `ncc_private_endpoint_rules`, so
  that variable stays declared, unused.
- `usage-policies.tf`: the serverless usage policy, its rule set, output and tests.
- `sql-warehouses.tf`: classic PRO warehouses (`<env>-automation-classic`,
  `<env>-<entity>-warehouse-classic`) in place of serverless ones, with the serverless lines kept
  beside their replacements. They run in the workspace's own network, like clusters, and take
  minutes rather than seconds to start. "Classic PRO" means
  PRO warehouses on non-serverless compute (`warehouse_type = "PRO"`, `enable_serverless_compute = false`),
  not the legacy `CLASSIC` type.
- `unity-catalog.tf`: predictive optimisation is off on every catalogue this root creates, because
  it runs `OPTIMIZE`, `VACUUM` and `ANALYZE` on serverless compute and is on by default for the
  account.

There is no account-wide switch this repository may use: serverless is on by default for every
Unity Catalog workspace, and the account is shared with other programmes. Inside our workspaces,
serverless notebooks, jobs and pipelines stay open to every user until a workspace admin closes
them by hand (see [Operating notes](#operating-notes)), because the provider cannot yet manage the
objects that control them. Only workspace admins can create a warehouse. Without an NCC,
serverless compute has no route to the trusted storage account, whose public access is disabled.

### What parking serverless costs us

- **No automatic table maintenance.** Predictive optimisation, which runs `OPTIMIZE`, `VACUUM` and
  `ANALYZE` on managed tables, runs only on serverless compute for jobs. With it off, nothing
  compacts files, removes unreferenced files, collects statistics at write time or chooses
  clustering keys automatically. The same commands run on classic compute, so a scheduled job
  could restore the function, but it would act on a schedule and not on the tables that would
  benefit, and nothing builds it yet. Until it exists, table maintenance is manual, and large
  tables may slow down and use more storage over time.
- **Slower warehouses.** Classic warehouses take minutes to start where serverless ones took
  seconds, so ad hoc queries and the masking job wait longer, and an idle warehouse costs more to
  keep warm.
- **No serverless notebooks, jobs or pipelines**, once a workspace admin has closed them (see
  [Operating notes](#operating-notes)). Users start classic clusters under the cluster policies
  instead.
- **Features that run on serverless only** are unavailable until it is approved.

`../scripts/tests/test_serverless_parked.py` fails if a parked object comes back unannounced. To
restore serverless once it is approved, in one change:

- unpark each block and its tests;
- swap each warehouse's serverless lines back;
- set `enable_predictive_optimization` to `"INHERIT"` on the catalogues and apply (the attribute is computed, so deleting the line alone leaves `DISABLE` in state);
- reopen the two default serverless compute objects;
- retire that test.

## What it configures

- **Groups.** Every group is an Entra group, created by hand by the Calandra team and brought into
  the Databricks account by [automatic identity management](https://learn.microsoft.com/en-us/azure/databricks/admin/users-groups/automatic-identity-management/)
  (checked 30 September 2026), so there is no SCIM. This root looks each one up by display name,
  from `config/entra-groups.yaml`, assigns it to the workspace and gives it its entitlements. It
  creates no group and adds no member.
- **Unity Catalog.** The regional metastore is shared with other programmes' workspaces. This
  root looks it up by region and never changes it. Each workspace attaches through the
  metastore's automatic assignment, and every state checks at plan time that its workspace is
  attached to the regional metastore. Each entity gets a storage credential on its own Access Connector, a
  catalogue per environment named for the environment and the entity (`dev_grp`, `prd_duk`), and
  external locations on its own `-uc`, `-landing` and `-export` containers in the trusted storage
  account. The analytical state creates all of that. The catalogue is bound to both of the
  environment's workspaces, the operational state binding it by name, and `catalog_binding_type`
  (read-write in both until Doubtless decide otherwise) sets how. Terraform creates two schemas per catalogue, `landing` and `export`, each with an
  external volume over the matching container. Bronze, silver and gold are the bundles' to create.
  The shared entity's catalogue also holds the `governance` schema.
- **Grants.** Who may see and change what, set out in [Who gets what](#who-gets-what). Grants are
  metastore-level, so the analytical state's hold in both workspaces; the operational state grants
  nothing. Each data grant
  is one `databricks_grant` per group and securable, so a plan shows exactly what a group has.
- **Compute.** Four cluster policies from the reference platform: job compute, pipeline compute,
  and an interactive policy for people, one for dev, tst and stg and one for prd.
  Classic PRO SQL warehouses while serverless compute is parked: one automation warehouse for
  workloads and one per entity for its data groups. The serverless usage policy is parked with them.
- **Private connectivity for serverless. Parked with serverless compute.** Restored, serverless
  compute reaches the trusted storage account
  through a Network Connectivity Configuration on the Databricks account. There is one per tier:
  `dev-anl` creates the non-production NCC, which all six non-production states bind to; `prd-anl`
  creates the production one, which both production workspaces bind to. They are named
  `dpx-dat-gwc-nonprod-ncc` and `dpx-dat-gwc-prod-ncc`, not for the region alone, because the account
  is shared and every other state finds its NCC by name. Each analytical state adds
  the private endpoint rules for its own environment's trusted storage, which the operational state
  shares and which must then be approved on the
  storage account within 14 days ([Manage private endpoint rules](https://learn.microsoft.com/en-us/azure/databricks/security/network/serverless-network-security/manage-private-endpoint-rules),
  checked 30 September 2026). A switch in `prd-anl`, off by default, adds production's storage to
  the non-production NCC when lower environments need to read production.
- **Secrets.** One Azure Key Vault-backed secret scope, on the environment's access-policy vault.
  It stores only the vault's reference; no secret value passes through Terraform.
- **Governance.** Each analytical workspace has eight masking functions in the shared catalogue's
  `governance` schema, created by a job on the automation warehouse, and a masking policy per
  catalogue per PII class that calls them, masking by default and excepting the PII-authorised
  group. A policy sits on the catalogue, so it holds in both workspaces.

## Files

This root keeps the reference platform's flat shape, file layout, resource addresses and variable
names, so its patterns carry across and a diff against it stays readable. Its 'opco' is 'entity'
here. Features Doubtless do not use are pruned, and Doubtless additions are in files of their own:

| File | From | What it holds |
|---|---|---|
| `terraform.tf`, `providers.tf` | the reference `providers.tf` | Versions, backend stub, account and workspace providers |
| `variables.tf`, `main.tf` | the reference | Inputs and the shared locals |
| `account-groups.tf` | the reference | Group lookups, workspace assignment, persona entitlements, data-group catalogue grants |
| `unity-catalog.tf` | the reference | Per-entity storage credentials, catalogues, bindings (both tracks), catalogue grants, the governance schema |
| `data-storage.tf` | the reference | External locations, landing and export schemas and volumes, their grants |
| `cluster-policies.tf`, `sql-warehouses.tf` | the reference | The four policies, the automation and per-entity classic warehouses, their permissions |
| `network-connectivity.tf`, `secret-scopes.tf` | the reference | The tier's NCC, its binding and rules (parked); the Key Vault-backed secret scope |
| `outputs.tf` | the reference | Outputs |
| `entity-readers.tf` | new | Each entity's Reader group: the grants the reference platform's per-entity key lacked |
| `workload-access.tf` | new | Everything the tier's `sp-databricks` group may do |
| `metastore.tf` | new | The regional metastore's lookup, and the check that the workspace is attached to it |
| `usage-policies.tf` | new | The serverless usage policy and who may use it (parked) |
| `governance.tf` | new | The masking functions and job, the masking policies |

## Who gets what

Groups are looked up by the display names in `config/entra-groups.yaml`, which the resolve step
maps onto the reference platform's role keys below.

| Key | Group | Gets |
|---|---|---|
| `external_group_names.platform_admins` | Databricks admin group | Workspace `ADMIN`; owns the catalogues, credentials and locations; `CAN_MANAGE` on every warehouse |
| `external_group_names.engineers`, `.analysts` | The two personas | Workspace entitlements and `CAN_USE` on compute. Never a data grant, or a persona could read every entity's data |
| `external_group_names.sp_databricks` | The tier's workload group | Write on every catalogue in its tier, the job and pipeline policies, the automation warehouse |
| `external_group_names.pii_authorized` | PII-authorised group | Excepted from every masking policy |
| `external_entity_group_names.<entity>.engineers` | That entity's Contributor group | Its own catalogue, volumes and warehouse: read and write in dev and tst; read only in stg and prd |
| `external_entity_group_names.<entity>.analysts` | That entity's Reader group | Its own catalogue, volumes and warehouse: read only, in every environment |

The Contributor sits under the reference platform's `engineers` key because that is where its
writing grants hang; the Reader sits under `analysts`. The `stg-anl`, `stg-ops`, `prd-anl` and
`prd-ops` var files carry a commented-out override that would let Contributors write there, should
that ever be wanted.

`manage_shared_ncc` is parked with serverless compute. Restored, it is true in `dev-anl` and
`prd-anl`, one per tier, and validation rejects it in any other state.

## Configuration

Var files layer `environments/common-{anl,ops}.tfvars`, then `environments/<instance>.tfvars`,
then the generated `upstream.tfvars.json`, last so that it wins. As
`../config/upstream-contract.yaml` sets out:

- **Upstream**: the workspace's ID, region number and name, the storage and vault names, the
  subscription, the Access Connectors and this environment's NCC rules (unused while serverless
  compute is parked), all from
  `infra/20-platform-services`' published outputs for the same environment, plus the entity list
  and the group names from `config/`. `scripts/resolve_upstream.py` writes them and refuses
  outputs published by another environment's state.
- **Identifiers**: `databricks_account_id` and `service_principal_application_id`, as `TF_VAR_*`
  from the tier's variable group.
- **Our configuration**: privileges, policy limits, warehouse sizes, tags and the feature switches,
  in the tracked var files.

The pins are Terraform `~> 1.16` and [`databricks ~> 1.133`](https://registry.terraform.io/providers/databricks/databricks/latest/docs).
No azurerm: containers, role assignments and Key Vault writes live in the infra roots.

## Operating notes

- **In each environment, apply `<env>-anl` before `<env>-ops`.** The operational state binds
  the catalogues the analytical state creates, by name.
- **Making a workspace read-only** is one line: `catalog_binding_type = "BINDING_TYPE_READ_ONLY"` in
  that track's `common-anl.tfvars` or `common-ops.tfvars`. It caps every principal in that
  workspace, workloads included, whatever their grants.
- **Masking takes two changes.** Apply, then run the job in the `masking_functions_job_id` output
  to create the functions, then set `enable_masking_policies = true` and apply again.
- **Close serverless compute in each workspace after its first apply**, while it is parked. As a
  workspace admin: Compute, the Serverless tab, then for both **Default Interactive Compute** and
  **Default Automated Compute**, Edit permissions and remove **All Users**. Workspace admins keep
  Can Manage, which still lets them run serverless workloads. The provider cannot manage these
  objects yet ([Manage serverless compute](https://learn.microsoft.com/en-us/azure/databricks/compute/serverless/manage-serverless-compute),
  checked 13 October 2026). It does not cover serverless SQL warehouses, model serving or apps.
- **Parked with serverless compute: NCC private endpoint rules need approving** on the storage
  side within 14 days of the apply that adds them, each in its own environment's subscription. The
  rules `enable_prd_storage_on_nonprod_ncc` adds are approved on production's storage.
- **Parked with serverless compute: production's NCC** is created by `prd-anl`. To create it
  before production's catalogues, resolve with `--singletons-only`, apply, then resolve and apply
  again without it. With the NCC parked there is nothing to create first, but the resolve mode
  stays and must plan.
- **The pipeline identities must be account admins and members of the Databricks admin group.**
  The group owns everything this root creates, and ownership passes to it as each
  object is created, so from then on an identity can manage the object only through that
  membership. The explicit grants kept from the reference platform cannot stand in for it: applying
  them already needs the rights they grant. Without the membership the first apply fails, which is
  why the handover asks for an `identity-preflight` step.
- **A group lookup fails if the group has not reached the account yet.** Terraform sees only
  groups that automatic identity management has already brought in.

## Testing

```bash
make test   # from the directory above
```

Plan-mode unit tests ([Terraform tests](https://developer.hashicorp.com/terraform/language/tests),
with [mocked providers](https://developer.hashicorp.com/terraform/language/tests/mocking)) run for
`dev-anl`, `dev-ops`, `prd-anl` and `prd-ops` in `tests/<instance>/`, and a smoke test for `tst-ops`
and `stg-ops`, each with that instance's tracked var files
and an upstream fixture that `scripts/resolve_upstream.py` generated from outputs shaped like
`infra/20-platform-services`'. The mocks are in `tests/mocks/`. The tests write out the access
matrix above and check it both ways (what each group gets, and what it must not get), the traps
the reference platform's code falls into, that every warehouse is classic and predictive
optimisation is off, and a fictitious third entity, to prove that adding an entity is data only. checkov has no Databricks checks, so these
tests are this root's security scan. `make plan` prints the full plan for the same six
instances. `dev-ops` is `prd-ops`' lower twin: the operational configuration is rehearsed in dev
before it reaches production.

## Secrets in state

None. No resource here creates or reads a secret value; the secret scope holds only its vault's
reference.

<!-- BEGIN_TF_DOCS -->
Doubtless Group data platform: Databricks workspace configuration.

Configures one workspace: its group assignments, compute, secrets and
connectivity and, in an analytical workspace, its entities' catalogs, storage
and governance, on the Azure resources that infra/20-platform-services
provisions. One state per workspace, two per environment: dev-anl, dev-ops,
tst-anl, tst-ops, stg-anl, stg-ops, prd-anl and prd-ops. The operational state
binds the environment's catalogs and creates nothing in the metastore. It
creates no Azure resources: the Databricks provider only.

The root keeps the reference platform's flat shape, file layout, resource
addresses and variable names. Doubtless additions are in their own files:
workload-access.tf, metastore.tf, usage-policies.tf (parked with serverless
compute) and governance.tf.

## Requirements

| Name | Version |
| ---- | ------- |
| terraform | ~> 1.16 |
| databricks | ~> 1.133 |

## Providers

| Name | Version |
| ---- | ------- |
| databricks | ~> 1.133 |
| databricks.account | ~> 1.133 |

## Resources

| Name | Type |
| ---- | ---- |
| [databricks_catalog.business_domain](https://registry.terraform.io/providers/databricks/databricks/latest/docs/resources/catalog) | resource |
| [databricks_cluster_policy.dlt_pipeline](https://registry.terraform.io/providers/databricks/databricks/latest/docs/resources/cluster_policy) | resource |
| [databricks_cluster_policy.interactive_dev](https://registry.terraform.io/providers/databricks/databricks/latest/docs/resources/cluster_policy) | resource |
| [databricks_cluster_policy.interactive_prod](https://registry.terraform.io/providers/databricks/databricks/latest/docs/resources/cluster_policy) | resource |
| [databricks_cluster_policy.job_compute](https://registry.terraform.io/providers/databricks/databricks/latest/docs/resources/cluster_policy) | resource |
| [databricks_entitlements.env_analysts](https://registry.terraform.io/providers/databricks/databricks/latest/docs/resources/entitlements) | resource |
| [databricks_entitlements.env_engineers](https://registry.terraform.io/providers/databricks/databricks/latest/docs/resources/entitlements) | resource |
| [databricks_entitlements.env_scientists](https://registry.terraform.io/providers/databricks/databricks/latest/docs/resources/entitlements) | resource |
| [databricks_entitlements.sp_databricks](https://registry.terraform.io/providers/databricks/databricks/latest/docs/resources/entitlements) | resource |
| [databricks_external_location.business_domain_storage](https://registry.terraform.io/providers/databricks/databricks/latest/docs/resources/external_location) | resource |
| [databricks_external_location.export](https://registry.terraform.io/providers/databricks/databricks/latest/docs/resources/external_location) | resource |
| [databricks_external_location.landing](https://registry.terraform.io/providers/databricks/databricks/latest/docs/resources/external_location) | resource |
| [databricks_grant.account_entity_analysts_catalog](https://registry.terraform.io/providers/databricks/databricks/latest/docs/resources/grant) | resource |
| [databricks_grant.account_entity_engineers_catalog](https://registry.terraform.io/providers/databricks/databricks/latest/docs/resources/grant) | resource |
| [databricks_grant.account_entity_scientists_catalog](https://registry.terraform.io/providers/databricks/databricks/latest/docs/resources/grant) | resource |
| [databricks_grant.business_domain_storage_platform_admins](https://registry.terraform.io/providers/databricks/databricks/latest/docs/resources/grant) | resource |
| [databricks_grant.business_domain_storage_sp](https://registry.terraform.io/providers/databricks/databricks/latest/docs/resources/grant) | resource |
| [databricks_grant.entity_analysts_export_volume](https://registry.terraform.io/providers/databricks/databricks/latest/docs/resources/grant) | resource |
| [databricks_grant.entity_analysts_landing_volume](https://registry.terraform.io/providers/databricks/databricks/latest/docs/resources/grant) | resource |
| [databricks_grant.entity_analysts_shared_catalog](https://registry.terraform.io/providers/databricks/databricks/latest/docs/resources/grant) | resource |
| [databricks_grant.entity_engineers_export_volume](https://registry.terraform.io/providers/databricks/databricks/latest/docs/resources/grant) | resource |
| [databricks_grant.entity_engineers_landing_volume](https://registry.terraform.io/providers/databricks/databricks/latest/docs/resources/grant) | resource |
| [databricks_grant.entity_engineers_shared_catalog](https://registry.terraform.io/providers/databricks/databricks/latest/docs/resources/grant) | resource |
| [databricks_grant.env_platform_admins_catalog](https://registry.terraform.io/providers/databricks/databricks/latest/docs/resources/grant) | resource |
| [databricks_grant.sp_catalog_usage](https://registry.terraform.io/providers/databricks/databricks/latest/docs/resources/grant) | resource |
| [databricks_grant.sp_databricks_catalog](https://registry.terraform.io/providers/databricks/databricks/latest/docs/resources/grant) | resource |
| [databricks_grant.sp_databricks_export_volume](https://registry.terraform.io/providers/databricks/databricks/latest/docs/resources/grant) | resource |
| [databricks_grant.sp_databricks_landing_volume](https://registry.terraform.io/providers/databricks/databricks/latest/docs/resources/grant) | resource |
| [databricks_grant.sp_governance_schema](https://registry.terraform.io/providers/databricks/databricks/latest/docs/resources/grant) | resource |
| [databricks_grants.catalog_storage_credential](https://registry.terraform.io/providers/databricks/databricks/latest/docs/resources/grants) | resource |
| [databricks_job.masking_functions](https://registry.terraform.io/providers/databricks/databricks/latest/docs/resources/job) | resource |
| [databricks_mws_permission_assignment.entity_analysts](https://registry.terraform.io/providers/databricks/databricks/latest/docs/resources/mws_permission_assignment) | resource |
| [databricks_mws_permission_assignment.entity_engineers](https://registry.terraform.io/providers/databricks/databricks/latest/docs/resources/mws_permission_assignment) | resource |
| [databricks_mws_permission_assignment.entity_scientists](https://registry.terraform.io/providers/databricks/databricks/latest/docs/resources/mws_permission_assignment) | resource |
| [databricks_mws_permission_assignment.env_analysts](https://registry.terraform.io/providers/databricks/databricks/latest/docs/resources/mws_permission_assignment) | resource |
| [databricks_mws_permission_assignment.env_engineers](https://registry.terraform.io/providers/databricks/databricks/latest/docs/resources/mws_permission_assignment) | resource |
| [databricks_mws_permission_assignment.env_scientists](https://registry.terraform.io/providers/databricks/databricks/latest/docs/resources/mws_permission_assignment) | resource |
| [databricks_mws_permission_assignment.platform_admins](https://registry.terraform.io/providers/databricks/databricks/latest/docs/resources/mws_permission_assignment) | resource |
| [databricks_mws_permission_assignment.sp_databricks](https://registry.terraform.io/providers/databricks/databricks/latest/docs/resources/mws_permission_assignment) | resource |
| [databricks_permissions.automation_warehouse](https://registry.terraform.io/providers/databricks/databricks/latest/docs/resources/permissions) | resource |
| [databricks_permissions.dlt_pipeline_policy](https://registry.terraform.io/providers/databricks/databricks/latest/docs/resources/permissions) | resource |
| [databricks_permissions.interactive_dev_policy](https://registry.terraform.io/providers/databricks/databricks/latest/docs/resources/permissions) | resource |
| [databricks_permissions.interactive_prod_policy](https://registry.terraform.io/providers/databricks/databricks/latest/docs/resources/permissions) | resource |
| [databricks_permissions.job_compute_policy](https://registry.terraform.io/providers/databricks/databricks/latest/docs/resources/permissions) | resource |
| [databricks_permissions.sql_warehouse_entity_engineers](https://registry.terraform.io/providers/databricks/databricks/latest/docs/resources/permissions) | resource |
| [databricks_policy_info.pii_mask](https://registry.terraform.io/providers/databricks/databricks/latest/docs/resources/policy_info) | resource |
| [databricks_schema.export](https://registry.terraform.io/providers/databricks/databricks/latest/docs/resources/schema) | resource |
| [databricks_schema.landing](https://registry.terraform.io/providers/databricks/databricks/latest/docs/resources/schema) | resource |
| [databricks_schema.shared_governance](https://registry.terraform.io/providers/databricks/databricks/latest/docs/resources/schema) | resource |
| [databricks_secret_scope.key_vault](https://registry.terraform.io/providers/databricks/databricks/latest/docs/resources/secret_scope) | resource |
| [databricks_sql_endpoint.automation](https://registry.terraform.io/providers/databricks/databricks/latest/docs/resources/sql_endpoint) | resource |
| [databricks_sql_endpoint.entity_warehouses](https://registry.terraform.io/providers/databricks/databricks/latest/docs/resources/sql_endpoint) | resource |
| [databricks_storage_credential.catalog_storage](https://registry.terraform.io/providers/databricks/databricks/latest/docs/resources/storage_credential) | resource |
| [databricks_volume.export](https://registry.terraform.io/providers/databricks/databricks/latest/docs/resources/volume) | resource |
| [databricks_volume.landing](https://registry.terraform.io/providers/databricks/databricks/latest/docs/resources/volume) | resource |
| [databricks_workspace_binding.business_domain](https://registry.terraform.io/providers/databricks/databricks/latest/docs/resources/workspace_binding) | resource |
| [databricks_workspace_binding.business_domain_readers](https://registry.terraform.io/providers/databricks/databricks/latest/docs/resources/workspace_binding) | resource |
| [databricks_workspace_file.masking_functions](https://registry.terraform.io/providers/databricks/databricks/latest/docs/resources/workspace_file) | resource |
| [databricks_current_metastore.this](https://registry.terraform.io/providers/databricks/databricks/latest/docs/data-sources/current_metastore) | data source |
| [databricks_group.external_analysts](https://registry.terraform.io/providers/databricks/databricks/latest/docs/data-sources/group) | data source |
| [databricks_group.external_engineers](https://registry.terraform.io/providers/databricks/databricks/latest/docs/data-sources/group) | data source |
| [databricks_group.external_entity_analysts](https://registry.terraform.io/providers/databricks/databricks/latest/docs/data-sources/group) | data source |
| [databricks_group.external_entity_engineers](https://registry.terraform.io/providers/databricks/databricks/latest/docs/data-sources/group) | data source |
| [databricks_group.external_entity_scientists](https://registry.terraform.io/providers/databricks/databricks/latest/docs/data-sources/group) | data source |
| [databricks_group.external_pii_authorized](https://registry.terraform.io/providers/databricks/databricks/latest/docs/data-sources/group) | data source |
| [databricks_group.external_platform_admins](https://registry.terraform.io/providers/databricks/databricks/latest/docs/data-sources/group) | data source |
| [databricks_group.external_scientists](https://registry.terraform.io/providers/databricks/databricks/latest/docs/data-sources/group) | data source |
| [databricks_group.external_sp_databricks](https://registry.terraform.io/providers/databricks/databricks/latest/docs/data-sources/group) | data source |
| [databricks_metastore.this](https://registry.terraform.io/providers/databricks/databricks/latest/docs/data-sources/metastore) | data source |

## Inputs

| Name | Description | Type | Default | Required |
| ---- | ----------- | ---- | ------- | :------: |
| access\_connectors | Upstream. Each entity's Access Connector: its resource ID and its identity's principal ID. Replaces the reference platform's single metastore Access Connector: each entity's storage credential uses its own. | <pre>map(object({<br/>    id           = string<br/>    principal_id = string<br/>  }))</pre> | n/a | yes |
| catalog\_privileges\_entity\_engineers | Catalog privileges for each entity's Contributor group (the engineers key) on its own catalogs. People write in dev and tst and read in stg and prd, so each environment's var file sets this. | `list(string)` | n/a | yes |
| catalog\_privileges\_sp\_databricks | Catalog privileges for the tier's sp-databricks group on every entity's catalogs. Workloads write in every environment of their tier; in production they are the only principals that can. | `list(string)` | n/a | yes |
| common\_tags | Tags for everything this root tags: the warehouses and the masking-functions job, and the usage policy once serverless compute is restored. Project, Environment, WorkspaceType and ManagedBy are mandatory; Environment and WorkspaceType must match this state instance. | `map(string)` | n/a | yes |
| data\_classification | Data classification recorded in each catalog's properties. | `string` | n/a | yes |
| databricks\_account\_id | Identifier. The Databricks account ID. From the tier's variable group. | `string` | n/a | yes |
| environment | The environment: dev, tst, stg or prd. | `string` | n/a | yes |
| key\_vault\_name | Upstream. Name of the secret scope's Key Vault: the access-policy vault, not the platform's. | `string` | n/a | yes |
| region | The Azure region of the workspace and the metastore, for the metastore lookup and, once serverless compute is restored, the NCC: germanywestcentral. | `string` | n/a | yes |
| resource\_group\_name | Upstream. Resource group of the secret scope's Key Vault. | `string` | n/a | yes |
| service\_principal\_application\_id | Identifier. Application ID of the tier's pipeline identity, which deploys this root and keeps explicit grants on what it creates. From the tier's variable group. | `string` | n/a | yes |
| shared\_business\_domain\_name | Upstream, from config/entities.yaml. The entity that plays the shared domain: grp. Its analytical catalog also holds the governance schema and the masking functions. | `string` | n/a | yes |
| storage\_account\_name | Upstream. The trusted storage account, which holds each entity's landing and export containers. | `string` | n/a | yes |
| subscription\_id | Upstream. The subscription infra/20-platform-services deployed this environment into, which holds the secret scope's Key Vault; the vault's resource ID is built from it. Each environment has its own, which both of its states share. | `string` | n/a | yes |
| tenant | Tenant recorded in each catalog's properties. | `string` | n/a | yes |
| unity\_catalog\_storage | Upstream. The trusted storage account, which holds each entity's Unity Catalog managed storage container. | `string` | n/a | yes |
| volume\_privileges\_entity\_engineers | Volume privileges for each entity's Contributor group on its landing and export volumes. Read and write in dev and tst; read only in stg and prd. | `list(string)` | n/a | yes |
| workspace\_id | Upstream. The workspace's numeric ID in the Databricks control plane. | `string` | n/a | yes |
| workspace\_name | Upstream. Name of the Azure Databricks workspace. | `string` | n/a | yes |
| workspace\_region\_number | Upstream. The number in the workspace URL, adb-<workspace\_id>.<number>.azuredatabricks.net. | `string` | n/a | yes |
| workspace\_track | Upstream. The track the resolve step ran for, 'anl' or 'ops'. It must match workspace\_type: a mismatch means the upstream file was resolved for the other workspace, and the state would bind and assign that workspace instead of its own. | `string` | n/a | yes |
| workspace\_type | 'analytical' or 'operational'. Each environment has one state of each. | `string` | n/a | yes |
| business\_domains | Upstream, from config/entities.yaml. The entity keys. Each has one catalog per environment, {env}\_{entity}: the analytical state creates it and the operational state binds it. | `list(string)` | `[]` | no |
| catalog\_binding\_type | How this workspace is bound to each of its environment's catalogs. BINDING\_TYPE\_READ\_WRITE leaves the grants to decide who writes; BINDING\_TYPE\_READ\_ONLY caps every principal in this workspace at reading, workloads included, whatever its grants. Both workspaces are read-write until Doubtless decide otherwise; this is the switch. | `string` | `"BINDING_TYPE_READ_WRITE"` | no |
| catalog\_privileges\_entity\_analysts | Catalog privileges for each entity's analysts key, which holds its Reader group. Read only, in every environment: only read privileges are accepted. | `list(string)` | <pre>[<br/>  "USE_CATALOG",<br/>  "BROWSE",<br/>  "USE_SCHEMA"<br/>]</pre> | no |
| catalog\_privileges\_entity\_scientists | Catalog privileges for each entity's scientists key. Unset for Doubtless. | `list(string)` | <pre>[<br/>  "USE_CATALOG",<br/>  "BROWSE",<br/>  "CREATE_SCHEMA",<br/>  "USE_SCHEMA"<br/>]</pre> | no |
| catalog\_reader\_workspace\_ids | Workspace IDs given read-only bindings to the catalogs this state creates, for reading across environments (production into a lower workspace). Never this state's own workspace, and never the other workspace of the same environment: that workspace binds the catalogs itself. | `set(string)` | `[]` | no |
| create\_business\_domain\_catalogs | Whether this state takes part in the entity catalogs: the analytical state creates them, their storage and their grants; the operational state binds them. The singletons-only prd-anl apply leaves it true: resolve\_upstream.py --singletons-only empties the entity lists instead. | `bool` | `true` | no |
| create\_cluster\_policies | Whether to create the four cluster policies. | `bool` | `true` | no |
| create\_external\_locations | Whether to create each entity's landing and export external locations. | `bool` | `true` | no |
| create\_secret\_scope | Whether to create the Key Vault-backed secret scope on the access-policy vault. | `bool` | `true` | no |
| create\_sql\_warehouse | Whether to create the automation warehouse and the entity warehouses. | `bool` | `true` | no |
| create\_volumes | Whether to create each entity's landing and export external volumes. | `bool` | `true` | no |
| enable\_entity\_warehouses | Whether to create a SQL warehouse per entity. Classic while serverless compute is parked. | `bool` | `true` | no |
| enable\_masking\_policies | Whether to create the masking policies. They call functions in the shared catalog's governance schema, which the masking-functions job creates after an apply, so they are switched on in a later change, once the functions exist. | `bool` | `false` | no |
| entity\_warehouse\_scaling | Minimum and maximum clusters per entity warehouse, overriding the defaults: { entity = { min = 1, max = 3 } }. | <pre>map(object({<br/>    min = number<br/>    max = number<br/>  }))</pre> | `{}` | no |
| entity\_warehouse\_sizes | Warehouse size per entity, overriding sql\_warehouse\_size. | `map(string)` | `{}` | no |
| external\_entity\_group\_names | Upstream, from config/entra-groups.yaml. Per entity, its Contributor group under the key 'engineers', which the reference platform's writing catalog, warehouse and volume grants hang off, and its Reader group under 'analysts'. 'scientists' is left unset. | `map(map(string))` | `{}` | no |
| external\_group\_names | Upstream, from config/entra-groups.yaml. Role key => Entra group display name, looked<br/>up in the Databricks account. Keys:<br/>- platform\_admins: the Databricks admin group. Workspace ADMIN; owns catalogs,<br/>  credentials and locations.<br/>- engineers, analysts, scientists: personas. Entitlements and compute, never data.<br/>- sp\_databricks: the tier's workload group. All workload access.<br/>- pii\_authorized: excepted from every masking policy. | `map(string)` | `{}` | no |
| ncc\_private\_endpoint\_rules | Upstream. NCC private endpoint rules for this environment's own trusted storage, blob and dfs, which an analytical state adds to its NCC. Empty in every operational state, which shares its environment's account. | <pre>list(object({<br/>    name        = string<br/>    resource_id = string<br/>    group_id    = string<br/>  }))</pre> | `[]` | no |
| secret\_scope\_name | Secret scope name. Defaults to 'azure\_keyvault'. | `string` | `null` | no |
| sql\_warehouse\_auto\_stop\_mins | Minutes of idleness before a warehouse stops: 0 for never, otherwise at least 10, the least a classic warehouse accepts. | `number` | `15` | no |
| sql\_warehouse\_max\_num\_clusters | Default maximum number of clusters for an entity warehouse. | `number` | `1` | no |
| sql\_warehouse\_min\_num\_clusters | Default minimum number of clusters for an entity warehouse. | `number` | `1` | no |
| sql\_warehouse\_size | Default entity warehouse size: 2X-Small to 4X-Large. | `string` | `"X-Small"` | no |
| volume\_privileges\_entity\_analysts | Volume privileges for each entity's Reader group on its landing and export volumes. Read only, in every environment. | `list(string)` | <pre>[<br/>  "READ_VOLUME"<br/>]</pre> | no |
| volume\_privileges\_sp\_databricks | Volume privileges for the tier's sp-databricks group on every entity's landing and export volumes. | `list(string)` | <pre>[<br/>  "READ_VOLUME",<br/>  "WRITE_VOLUME"<br/>]</pre> | no |

## Outputs

| Name | Description |
| ---- | ----------- |
| automation\_warehouse\_id | ID of the automation warehouse, classic while serverless compute is parked. |
| catalogs | Each entity's catalog, bound to this workspace. The same names in both of an environment's workspaces. |
| cluster\_policies | The cluster policies' IDs and names. 'interactive' is the one this environment has: dev in dev, tst and stg, prod in prd. |
| entity\_sql\_warehouses | Each entity's SQL warehouse, classic while serverless compute is parked: its ID, name and HTTP path. |
| environment | Environment name. |
| external\_locations | Each entity's external location names: catalog storage, landing and export. Empty in an operational workspace, which creates none. |
| masking\_functions\_job\_id | ID of the job that creates the masking functions, in an analytical workspace. Run it after an apply that changes them, before enabling the masking policies. |
| metastore\_id | The Unity Catalog metastore this workspace is attached to, checked against the regional one. |
| secret\_scope\_name | Secret scope name. |
| storage\_credential\_names | Each entity's storage credential name. |
| volumes | Each entity's landing and export volume names. |
| workspace\_id | Databricks workspace ID. |
| workspace\_name | Name of the Azure Databricks workspace this state configures. |
| workspace\_track | Which workspace this state configures: anl or ops. |
| workspace\_url | Databricks workspace URL. |
<!-- END_TF_DOCS -->
