################ Cluster Policies ###############

# Cluster policies control cluster creation and configuration, for cost,
# security and standardisation. The four policies and their values are the
# reference platform's; the proposal's stricter controls are not applied.
# What changes: the policies are chosen by a validated is_prod rather than by
# comparing environment names as strings, the business_domain tag defaults to
# the shared entity, and permissions go to personas and workloads.

locals {
  # Every entity, the shared one included, is a business domain for user
  # workloads: each carries data.
  user_business_domains = var.business_domains

  # Job compute policy - for automated workflows (bundle jobs)
  job_compute_policy = {
    "cluster_type" : {
      "type" : "fixed",
      "value" : "job"
    },
    "spark_version" : {
      "type" : "allowlist",
      "values" : [
        "auto:latest-lts",
        "auto:prev-lts"
      ],
      "defaultValue" : "auto:latest-lts"
    },
    "node_type_id" : {
      "type" : "allowlist",
      "values" : [
        "Standard_E4ds_v4",
        "Standard_E8ds_v4"
      ],
      "defaultValue" : "Standard_E4ds_v4"
    },
    "driver_node_type_id" : {
      "type" : "allowlist",
      "values" : [
        "Standard_E4ds_v4",
        "Standard_E8ds_v4"
      ],
      "defaultValue" : "Standard_E8ds_v4"
    },
    "autoscale.min_workers" : {
      "type" : "range",
      "minValue" : 2,
      "maxValue" : 10,
      "defaultValue" : 2
    },
    "autoscale.max_workers" : {
      "type" : "range",
      "minValue" : 2,
      "maxValue" : 10,
      "defaultValue" : 8
    },
    "azure_attributes.availability" : {
      "type" : "fixed",
      "value" : "SPOT_WITH_FALLBACK_AZURE"
    },
    "azure_attributes.spot_bid_max_price" : {
      "type" : "fixed",
      "value" : -1
    },
    "data_security_mode" : {
      "type" : "fixed",
      "value" : "USER_ISOLATION"
    },
    "custom_tags.workload" : {
      "type" : "fixed",
      "value" : "job"
    },
    "custom_tags.ManagedBy" : {
      "type" : "fixed",
      "value" : "AssetBundles"
    }
  }

  # Pipeline policy - for Lakeflow Declarative Pipelines.
  # Pipeline-compatible policies cannot include spark_version or cluster_type.
  dlt_pipeline_policy = {
    "node_type_id" : {
      "type" : "allowlist",
      "values" : [
        "Standard_E8ds_v4",
        "Standard_E16ds_v4",
        "Standard_E8ds_v5",
        "Standard_E16ds_v5"
      ],
      "defaultValue" : "Standard_E8ds_v4"
    },
    "driver_node_type_id" : {
      "type" : "allowlist",
      "values" : [
        "Standard_E8ds_v4",
        "Standard_E16ds_v4",
        "Standard_E8ds_v5",
        "Standard_E16ds_v5"
      ],
      "defaultValue" : "Standard_E8ds_v4"
    },
    "autoscale.min_workers" : {
      "type" : "range",
      "minValue" : 1,
      "maxValue" : 10,
      "defaultValue" : 2
    },
    "autoscale.max_workers" : {
      "type" : "range",
      "minValue" : 1,
      "maxValue" : 10,
      "defaultValue" : 5
    },
    "azure_attributes.availability" : {
      "type" : "allowlist",
      "values" : [
        "ON_DEMAND_AZURE",
        "SPOT_WITH_FALLBACK_AZURE"
      ],
      "defaultValue" : "ON_DEMAND_AZURE"
    },
    "azure_attributes.spot_bid_max_price" : {
      "type" : "fixed",
      "value" : -1
    },
    "data_security_mode" : {
      "type" : "fixed",
      "value" : "USER_ISOLATION"
    },
    "custom_tags.workload" : {
      "type" : "fixed",
      "value" : "dlt-pipeline"
    },
    "custom_tags.ManagedBy" : {
      "type" : "fixed",
      "value" : "AssetBundles"
    }
  }

  # Interactive dev policy - for development in dev, tst and stg
  interactive_dev_policy = {
    "cluster_type" : {
      "type" : "fixed",
      "value" : "all-purpose"
    },
    "spark_version" : {
      "type" : "allowlist",
      "values" : [
        "auto:latest-lts",
        "auto:prev-lts"
      ],
      "defaultValue" : "auto:latest-lts"
    },
    "node_type_id" : {
      "type" : "allowlist",
      "values" : [
        "Standard_E4ds_v4",
        "Standard_E8ds_v4",
        "Standard_E16ds_v4"
      ],
      "defaultValue" : "Standard_E4ds_v4"
    },
    "driver_node_type_id" : {
      "type" : "allowlist",
      "values" : [
        "Standard_E4ds_v4",
        "Standard_E8ds_v4"
      ],
      "defaultValue" : "Standard_E4ds_v4"
    },
    "autoscale.min_workers" : {
      "type" : "range",
      "minValue" : 1,
      "maxValue" : 8,
      "defaultValue" : 2
    },
    "autoscale.max_workers" : {
      "type" : "range",
      "minValue" : 1,
      "maxValue" : 8,
      "defaultValue" : 4
    },
    "autotermination_minutes" : {
      "type" : "range",
      "minValue" : 30,
      "maxValue" : 120,
      "defaultValue" : 60
    },
    "azure_attributes.availability" : {
      "type" : "fixed",
      "value" : "SPOT_WITH_FALLBACK_AZURE"
    },
    "azure_attributes.first_on_demand" : {
      "type" : "fixed",
      "value" : 2
    },
    "azure_attributes.spot_bid_max_price" : {
      "type" : "fixed",
      "value" : -1
    },
    "data_security_mode" : {
      "type" : "fixed",
      "value" : "USER_ISOLATION"
    },
    "custom_tags.environment" : {
      "type" : "fixed",
      "value" : var.environment
    },
    "custom_tags.workload" : {
      "type" : "fixed",
      "value" : "interactive"
    },
    "custom_tags.business_domain" : {
      "type" : "allowlist",
      "values" : local.user_business_domains,
      "defaultValue" : local.shared_business_domain
    }
  }

  # Interactive prod policy - for production data analysis
  interactive_prod_policy = {
    "cluster_type" : {
      "type" : "fixed",
      "value" : "all-purpose"
    },
    "spark_version" : {
      "type" : "allowlist",
      "values" : [
        "auto:latest-lts",
        "auto:prev-lts"
      ],
      "defaultValue" : "auto:latest-lts"
    },
    "node_type_id" : {
      "type" : "allowlist",
      "values" : [
        "Standard_E4ds_v4",
        "Standard_E8ds_v4"
      ],
      "defaultValue" : "Standard_E4ds_v4"
    },
    "driver_node_type_id" : {
      "type" : "allowlist",
      "values" : [
        "Standard_E4ds_v4",
        "Standard_E8ds_v4"
      ],
      "defaultValue" : "Standard_E4ds_v4"
    },
    "autoscale.min_workers" : {
      "type" : "range",
      "minValue" : 2,
      "maxValue" : 8,
      "defaultValue" : 2
    },
    "autoscale.max_workers" : {
      "type" : "range",
      "minValue" : 2,
      "maxValue" : 8,
      "defaultValue" : 4
    },
    "autotermination_minutes" : {
      "type" : "range",
      "minValue" : 30,
      "maxValue" : 90,
      "defaultValue" : 60
    },
    "azure_attributes.availability" : {
      "type" : "fixed",
      "value" : "SPOT_WITH_FALLBACK_AZURE"
    },
    "azure_attributes.first_on_demand" : {
      "type" : "fixed",
      "value" : 1
    },
    "azure_attributes.spot_bid_max_price" : {
      "type" : "fixed",
      "value" : -1
    },
    "data_security_mode" : {
      "type" : "fixed",
      "value" : "USER_ISOLATION"
    },
    "custom_tags.environment" : {
      "type" : "fixed",
      "value" : var.environment
    },
    "custom_tags.workload" : {
      "type" : "fixed",
      "value" : "analysis"
    },
    "custom_tags.business_domain" : {
      "type" : "allowlist",
      "values" : local.user_business_domains,
      "defaultValue" : local.shared_business_domain
    }
  }
}

################ Cluster Policy Resources ###############

resource "databricks_cluster_policy" "job_compute" {
  count = var.create_cluster_policies ? 1 : 0
  name  = "${var.environment}-job-compute"

  definition = jsonencode(local.job_compute_policy)
}

resource "databricks_cluster_policy" "dlt_pipeline" {
  count = var.create_cluster_policies ? 1 : 0
  name  = "${var.environment}-dlt-pipeline"

  definition = jsonencode(local.dlt_pipeline_policy)
}

# dev, tst and stg, where people build.
resource "databricks_cluster_policy" "interactive_dev" {
  count = var.create_cluster_policies && !local.is_prod ? 1 : 0
  name  = "${var.environment}-interactive"

  definition = jsonencode(local.interactive_dev_policy)
}

# prd only.
resource "databricks_cluster_policy" "interactive_prod" {
  count = var.create_cluster_policies && local.is_prod ? 1 : 0
  name  = "${var.environment}-interactive"

  definition = jsonencode(local.interactive_prod_policy)
}

################ Policy Permissions ###############

# Cluster policies support only CAN_USE. The Databricks admin group manages
# them as workspace ADMIN. Each policy's permissions are one authoritative
# resource. Data groups get none: they grant what can be seen, not what can be
# run.

locals {
  # Who may run jobs and pipelines: the pipeline identity (which deploys them),
  # the tier's workloads, and in non-production the engineering persona.
  job_policy_groups = compact([
    try(local.sp_databricks.display_name, null),
    local.is_prod ? null : try(local.env_engineers.display_name, null),
    local.is_prod ? null : try(local.env_scientists.display_name, null),
  ])

  # Who may start interactive compute: the engineering persona (and a data
  # science persona, if one is set). Analysts work through SQL warehouses.
  interactive_policy_groups = compact([
    try(local.env_engineers.display_name, null),
    try(local.env_scientists.display_name, null),
  ])
}

resource "databricks_permissions" "job_compute_policy" {
  count             = var.create_cluster_policies ? 1 : 0
  cluster_policy_id = databricks_cluster_policy.job_compute[0].id

  access_control {
    service_principal_name = var.service_principal_application_id
    permission_level       = "CAN_USE"
  }

  dynamic "access_control" {
    for_each = toset(local.job_policy_groups)
    content {
      group_name       = access_control.value
      permission_level = "CAN_USE"
    }
  }
}

resource "databricks_permissions" "dlt_pipeline_policy" {
  count             = var.create_cluster_policies ? 1 : 0
  cluster_policy_id = databricks_cluster_policy.dlt_pipeline[0].id

  access_control {
    service_principal_name = var.service_principal_application_id
    permission_level       = "CAN_USE"
  }

  dynamic "access_control" {
    for_each = toset(local.job_policy_groups)
    content {
      group_name       = access_control.value
      permission_level = "CAN_USE"
    }
  }
}

resource "databricks_permissions" "interactive_dev_policy" {
  count             = var.create_cluster_policies && !local.is_prod && length(local.interactive_policy_groups) > 0 ? 1 : 0
  cluster_policy_id = databricks_cluster_policy.interactive_dev[0].id

  dynamic "access_control" {
    for_each = toset(local.interactive_policy_groups)
    content {
      group_name       = access_control.value
      permission_level = "CAN_USE"
    }
  }
}

resource "databricks_permissions" "interactive_prod_policy" {
  count             = var.create_cluster_policies && local.is_prod && length(local.interactive_policy_groups) > 0 ? 1 : 0
  cluster_policy_id = databricks_cluster_policy.interactive_prod[0].id

  dynamic "access_control" {
    for_each = toset(local.interactive_policy_groups)
    content {
      group_name       = access_control.value
      permission_level = "CAN_USE"
    }
  }
}
