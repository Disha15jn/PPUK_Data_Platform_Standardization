# databricks: tst-anl.
#
# Layered after common-anl.tfvars. Our configuration only.

environment = "tst"

common_tags = {
  Project            = "doubtless-data-platform"
  Environment        = "tst"
  WorkspaceType      = "analytical"
  ManagedBy          = "terraform"
  Application        = "tbc"
  BusinessEntity     = "tbc"
  CostCentre         = "tbc"
  DataClassification = "tbc"
  Owner              = "tbc"
}

# Non-production: people read and write.
catalog_privileges_entity_engineers = ["USE_CATALOG", "BROWSE", "CREATE_SCHEMA", "USE_SCHEMA", "SELECT", "MODIFY"]
volume_privileges_entity_engineers  = ["READ_VOLUME", "WRITE_VOLUME"]

# Workloads write throughout their tier.
catalog_privileges_sp_databricks = ["USE_CATALOG", "BROWSE", "CREATE_SCHEMA", "USE_SCHEMA", "SELECT", "MODIFY"]
