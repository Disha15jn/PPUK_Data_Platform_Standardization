# databricks: stg-anl.
#
# Layered after common-anl.tfvars. Our configuration only.

environment = "stg"

common_tags = {
  Project            = "doubtless-data-platform"
  Environment        = "stg"
  WorkspaceType      = "analytical"
  ManagedBy          = "terraform"
  Application        = "tbc"
  BusinessEntity     = "tbc"
  CostCentre         = "tbc"
  DataClassification = "tbc"
  Owner              = "tbc"
}

# Staging: people read; only workload identities write. Contributors can be given
# write access with the override below.
catalog_privileges_entity_engineers = ["USE_CATALOG", "BROWSE", "USE_SCHEMA", "SELECT"]
volume_privileges_entity_engineers  = ["READ_VOLUME"]
#
# To let Contributors write here, replace both lists above with:
# catalog_privileges_entity_engineers = ["USE_CATALOG", "BROWSE", "CREATE_SCHEMA", "USE_SCHEMA", "SELECT", "MODIFY"]
# volume_privileges_entity_engineers  = ["READ_VOLUME", "WRITE_VOLUME"]

# Workloads write throughout their tier.
catalog_privileges_sp_databricks = ["USE_CATALOG", "BROWSE", "CREATE_SCHEMA", "USE_SCHEMA", "SELECT", "MODIFY"]
