# databricks: settings shared by every operational workspace: dev-ops, tst-ops, stg-ops and prd-ops.
#
# Our configuration only. Identifiers and upstream values never go here;
# scripts/check_var_files.py rejects them.

workspace_type = "operational"
region         = "germanywestcentral"

# Recorded in each catalog's properties.
tenant              = "doubtless-group"
data_classification = "insurance"

# Each entity's Reader group: read in every environment, production included.
catalog_privileges_entity_analysts = ["USE_CATALOG", "BROWSE", "USE_SCHEMA", "SELECT"]

# How this workspace is bound to its environment's catalogues. Read-write in both
# workspaces for now; set BINDING_TYPE_READ_ONLY here to make every principal in
# this workspace read-only, whatever its grants.
catalog_binding_type = "BINDING_TYPE_READ_WRITE"
