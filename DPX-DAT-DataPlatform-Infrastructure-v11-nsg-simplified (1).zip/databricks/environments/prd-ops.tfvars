# databricks: prd-ops.
#
# Layered after common-ops.tfvars. Our configuration only.

environment = "prd"

common_tags = {
  Project            = "doubtless-data-platform"
  Environment        = "prd"
  WorkspaceType      = "operational"
  ManagedBy          = "terraform"
  Application        = "tbc"
  BusinessEntity     = "tbc"
  CostCentre         = "tbc"
  DataClassification = "tbc"
  Owner              = "tbc"
}

# Production: people read; only workload identities write.
catalog_privileges_entity_engineers = ["USE_CATALOG", "BROWSE", "USE_SCHEMA", "SELECT"]
volume_privileges_entity_engineers  = ["READ_VOLUME"]
#
# To let Contributors write here (this departs from the rule that only workloads write in production), replace both lists above with:
# catalog_privileges_entity_engineers = ["USE_CATALOG", "BROWSE", "CREATE_SCHEMA", "USE_SCHEMA", "SELECT", "MODIFY"]
# volume_privileges_entity_engineers  = ["READ_VOLUME", "WRITE_VOLUME"]

# Workloads write throughout their tier.
catalog_privileges_sp_databricks = ["USE_CATALOG", "BROWSE", "CREATE_SCHEMA", "USE_SCHEMA", "SELECT", "MODIFY"]
