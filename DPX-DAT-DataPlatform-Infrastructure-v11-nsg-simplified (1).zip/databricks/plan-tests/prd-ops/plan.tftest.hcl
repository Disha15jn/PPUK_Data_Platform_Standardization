# One plan of the prd-ops state of the Databricks root, for reading.
#
# Providers are mocked, with the same lookups the unit tests use, so it needs no
# credentials and no network. Run it with `make plan` (scripts/terraform_plan.sh),
# which passes the instance's var files and the fixtures in tests/fixtures/. It
# asserts nothing: its job is to print the plan.

mock_provider "databricks" {
  source = "./tests/mocks/workspace"
}

mock_provider "databricks" {
  alias  = "account"
  source = "./tests/mocks/account"
}

run "plan" {
  command = plan
}
