/**
 * Doubtless Group data platform: Databricks workspace configuration.
 *
 * Configures one workspace: its group assignments, compute, secrets and
 * connectivity and, in an analytical workspace, its entities' catalogs, storage
 * and governance, on the Azure resources that infra/20-platform-services
 * provisions. One state per workspace, two per environment: dev-anl, dev-ops,
 * tst-anl, tst-ops, stg-anl, stg-ops, prd-anl and prd-ops. The operational state
 * binds the environment's catalogs and creates nothing in the metastore. It
 * creates no Azure resources: the Databricks provider only.
 *
 * The root keeps the reference platform's flat shape, file layout, resource
 * addresses and variable names. Doubtless additions are in their own files:
 * workload-access.tf, metastore.tf, usage-policies.tf (parked with serverless
 * compute) and governance.tf.
 */

################ Local Variables ###############

locals {
  # Derive the workspace URL from the workspace ID and region number.
  workspace_url = "https://adb-${var.workspace_id}.${var.workspace_region_number}.azuredatabricks.net"

  # The secret scope's Key Vault, from its subscription, resource group and name.
  key_vault_uri         = "https://${var.key_vault_name}.vault.azure.net/"
  key_vault_resource_id = "/subscriptions/${var.subscription_id}/resourceGroups/${var.resource_group_name}/providers/Microsoft.KeyVault/vaults/${var.key_vault_name}"

  # Production is compared once, here, against a validated environment list.
  is_prod       = var.environment == "prd"
  is_analytical = var.workspace_type == "analytical"

  # Metastore-level objects (credentials, catalogs, locations, schemas, volumes,
  # grants and masking) are the analytical state's. The operational state binds
  # the same catalogs to its own workspace and creates none of them.
  owns_catalogs = local.is_analytical && var.create_business_domain_catalogs

  # The shared domain is an entity with data of its own that also holds the
  # governance schema and masking functions.
  shared_business_domain = var.shared_business_domain_name
  shared_catalog_name    = "${var.environment}_${lower(local.shared_business_domain)}"

  # One catalog per entity per environment, {env}_{entity}, bound to both of the
  # environment's workspaces. (The reference platform gave the operational
  # workspace catalogs of its own, {entity}_op_{env}.)
  business_domain_catalogs = {
    for domain in var.business_domains : domain => {
      name            = "${var.environment}_${lower(domain)}"
      business_domain = domain
      requires_rls    = "false"
    }
  }

  # Every entity carries data, the shared one included, so every catalog gets
  # its landing and export schemas and volumes. (The reference platform's shared
  # domain held governance only and was left out here.)
  entity_catalogs = local.business_domain_catalogs

  # Each entity's containers in the trusted account, as infra/20-platform-services
  # names them: {entity}-uc, -landing and -export. One set serves both workspaces.
  catalog_containers = {
    for domain in keys(local.business_domain_catalogs) : domain => {
      uc      = "${lower(domain)}-uc"
      landing = "${lower(domain)}-landing"
      export  = "${lower(domain)}-export"
    }
  }

  # Prefix for metastore-level objects (credentials, external locations), which
  # are unique across the metastore: the environment.
  metastore_object_name_prefix = var.environment

  # Default names
  secret_scope_name = coalesce(var.secret_scope_name, "azure_keyvault")
}
