/**
 * The Metastore (Doubtless addition)
 *
 * The region's Unity Catalog metastore is shared with other programmes'
 * workspaces, and this root does not own it. Databricks created it
 * automatically, and the account attaches every new workspace in the region
 * to it. This root reads it and changes nothing on it.
 */

# The regional metastore, looked up by region: every state reads its ID.
data "databricks_metastore" "this" {
  provider = databricks.account
  region   = var.region
}

# The metastore this workspace is attached to. The account attaches new
# workspaces in the region automatically; this root relies on that and does
# not manage it. Every Unity Catalog object here assumes the regional
# metastore, so a workspace left unattached, or attached elsewhere, stops the
# plan before anything is created. The data source's id is the attached
# metastore's ID, or no_metastore when none is attached.
data "databricks_current_metastore" "this" {
  lifecycle {
    postcondition {
      condition     = self.id == data.databricks_metastore.this.id
      error_message = "This workspace is not attached to the ${var.region} metastore. New workspaces attach through the metastore's automatic assignment: check in the account console that it is still on and that the workspace is listed against the metastore."
    }
  }
}
