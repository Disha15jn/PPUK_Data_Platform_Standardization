################ Account-Level Groups ###############

# Every group comes from Entra, created by hand by the Calandra team and
# brought into the Databricks account by automatic identity management.
# This root only looks groups up, by display name: the reference platform's
# lookup mode. Its create mode, membership by email and group nesting are not
# carried over.
#
# A lookup fails loudly if a group has not reached the account yet; Terraform
# sees only groups provisioned to the account directly.
#
# Role keys: personas carry entitlements and compute, never data; data
# groups carry data access, never entitlements.

locals {
  # Which environment-wide role keys this state was given.
  has_group = {
    for key in ["platform_admins", "engineers", "scientists", "analysts", "sp_databricks", "pii_authorized"] :
    key => contains(keys(var.external_group_names), key)
  }
}

################ Environment-Wide Group Lookups ###############

# The Databricks admin group: workspace ADMIN, and owner of catalogs,
# credentials and locations.
data "databricks_group" "external_platform_admins" {
  count        = local.has_group.platform_admins ? 1 : 0
  provider     = databricks.account
  display_name = var.external_group_names["platform_admins"]
}

# Personas. engineers and analysts are Doubtless's two personas;
# scientists stays free for a data science persona.
data "databricks_group" "external_engineers" {
  count        = local.has_group.engineers ? 1 : 0
  provider     = databricks.account
  display_name = var.external_group_names["engineers"]
}

data "databricks_group" "external_scientists" {
  count        = local.has_group.scientists ? 1 : 0
  provider     = databricks.account
  display_name = var.external_group_names["scientists"]
}

data "databricks_group" "external_analysts" {
  count        = local.has_group.analysts ? 1 : 0
  provider     = databricks.account
  display_name = var.external_group_names["analysts"]
}

# Excepted from every masking policy.
data "databricks_group" "external_pii_authorized" {
  count        = local.has_group.pii_authorized ? 1 : 0
  provider     = databricks.account
  display_name = var.external_group_names["pii_authorized"]
}

################ Per-Entity Group Lookups ###############

# Each entity's Contributor group, under the reference platform's 'engineers'
# key, which its writing catalog, warehouse and volume grants hang off. Its
# Reader group is the 'analysts' key below.
data "databricks_group" "external_entity_engineers" {
  for_each     = { for domain, roles in var.external_entity_group_names : domain => roles["engineers"] if lookup(roles, "engineers", null) != null }
  provider     = databricks.account
  display_name = each.value
}

data "databricks_group" "external_entity_scientists" {
  for_each     = { for domain, roles in var.external_entity_group_names : domain => roles["scientists"] if lookup(roles, "scientists", null) != null }
  provider     = databricks.account
  display_name = each.value
}

data "databricks_group" "external_entity_analysts" {
  for_each     = { for domain, roles in var.external_entity_group_names : domain => roles["analysts"] if lookup(roles, "analysts", null) != null }
  provider     = databricks.account
  display_name = each.value
}

locals {
  all_entity_engineers = {
    for entity, group in data.databricks_group.external_entity_engineers : entity => {
      id           = group.id
      display_name = group.display_name
    }
  }

  all_entity_scientists = {
    for entity, group in data.databricks_group.external_entity_scientists : entity => {
      id           = group.id
      display_name = group.display_name
    }
  }

  all_entity_analysts = {
    for entity, group in data.databricks_group.external_entity_analysts : entity => {
      id           = group.id
      display_name = group.display_name
    }
  }

  # Environment-wide groups, as the attributes the grants use, or null where
  # the key is not set.
  env_group_lookups = {
    platform_admins = data.databricks_group.external_platform_admins
    engineers       = data.databricks_group.external_engineers
    scientists      = data.databricks_group.external_scientists
    analysts        = data.databricks_group.external_analysts
    pii_authorized  = data.databricks_group.external_pii_authorized
  }
  env_groups = {
    for key, lookup in local.env_group_lookups : key => length(lookup) == 0 ? null : {
      id               = lookup[0].id
      display_name     = lookup[0].display_name
      acl_principal_id = lookup[0].acl_principal_id
    }
  }

  platform_admins = local.env_groups.platform_admins
  env_engineers   = local.env_groups.engineers
  env_scientists  = local.env_groups.scientists
  env_analysts    = local.env_groups.analysts
  pii_authorized  = local.env_groups.pii_authorized
}

################ Workspace Group Assignments ###############

resource "databricks_mws_permission_assignment" "platform_admins" {
  count        = local.has_group.platform_admins ? 1 : 0
  provider     = databricks.account
  workspace_id = var.workspace_id
  principal_id = local.platform_admins.id
  permissions  = ["ADMIN"]
}

resource "databricks_mws_permission_assignment" "env_engineers" {
  count        = local.has_group.engineers ? 1 : 0
  provider     = databricks.account
  workspace_id = var.workspace_id
  principal_id = local.env_engineers.id
  permissions  = ["USER"]
}

resource "databricks_mws_permission_assignment" "env_scientists" {
  count        = local.has_group.scientists ? 1 : 0
  provider     = databricks.account
  workspace_id = var.workspace_id
  principal_id = local.env_scientists.id
  permissions  = ["USER"]
}

resource "databricks_mws_permission_assignment" "env_analysts" {
  count        = local.has_group.analysts ? 1 : 0
  provider     = databricks.account
  workspace_id = var.workspace_id
  principal_id = local.env_analysts.id
  permissions  = ["USER"]
}

# Contributor groups are assigned to the workspace so that warehouse permissions
# can name them, but they get no entitlements.
resource "databricks_mws_permission_assignment" "entity_engineers" {
  for_each     = local.all_entity_engineers
  provider     = databricks.account
  workspace_id = var.workspace_id
  principal_id = each.value.id
  permissions  = ["USER"]
}

resource "databricks_mws_permission_assignment" "entity_scientists" {
  for_each     = local.all_entity_scientists
  provider     = databricks.account
  workspace_id = var.workspace_id
  principal_id = each.value.id
  permissions  = ["USER"]
}

resource "databricks_mws_permission_assignment" "entity_analysts" {
  for_each     = local.all_entity_analysts
  provider     = databricks.account
  workspace_id = var.workspace_id
  principal_id = each.value.id
  permissions  = ["USER"]
}

################ Persona Entitlements ###############

# Personas say what someone can do. Since 14 September 2026 the built-in
# users group carries no entitlements, so an assigned group without its own
# cannot sign in. Cluster creation stays off: people create compute
# through the policies they hold CAN_USE on.
#
# depends_on: a group's entitlements can only be set once it has been assigned
# to the workspace, which Terraform cannot see from the references.

resource "databricks_entitlements" "env_engineers" {
  count                      = local.has_group.engineers ? 1 : 0
  group_id                   = local.env_engineers.id
  allow_cluster_create       = false
  allow_instance_pool_create = false
  databricks_sql_access      = true
  workspace_access           = true

  depends_on = [databricks_mws_permission_assignment.env_engineers]
}

resource "databricks_entitlements" "env_scientists" {
  count                      = local.has_group.scientists ? 1 : 0
  group_id                   = local.env_scientists.id
  allow_cluster_create       = false
  allow_instance_pool_create = false
  databricks_sql_access      = true
  workspace_access           = true

  depends_on = [databricks_mws_permission_assignment.env_scientists]
}

resource "databricks_entitlements" "env_analysts" {
  count                      = local.has_group.analysts ? 1 : 0
  group_id                   = local.env_analysts.id
  allow_cluster_create       = false
  allow_instance_pool_create = false
  databricks_sql_access      = true
  workspace_access           = true

  depends_on = [databricks_mws_permission_assignment.env_analysts]
}

################ Catalog-Level Permissions for Entity Groups ###############

# Each entity's Contributor group reaches its own catalog only, in whichever
# workspace it is bound. Granted from the analytical state. Privileges come
# from the environment's var file: write in dev and tst, read in stg and prd.
# Catalog grants give capability; the bundles grant schema access.
#
# On the shared catalog, which holds the masking functions, the shared
# entity's own group also gets EXECUTE, merged into this one grant: a second
# grant on the same principal and catalog would fight this one on every plan.
resource "databricks_grant" "account_entity_engineers_catalog" {
  for_each  = local.owns_catalogs ? local.all_entity_engineers : {}
  catalog   = databricks_catalog.business_domain[each.key].name
  principal = each.value.display_name
  privileges = (
    databricks_catalog.business_domain[each.key].name == local.shared_catalog_name
    ? distinct(concat(var.catalog_privileges_entity_engineers, ["EXECUTE"]))
    : var.catalog_privileges_entity_engineers
  )
}

resource "databricks_grant" "account_entity_scientists_catalog" {
  for_each   = local.owns_catalogs ? local.all_entity_scientists : {}
  catalog    = databricks_catalog.business_domain[each.key].name
  principal  = each.value.display_name
  privileges = var.catalog_privileges_entity_scientists
}

# An entity's analysts key holds its Reader group. On the shared catalog it gets
# EXECUTE merged into this one grant, like the Contributor's.
resource "databricks_grant" "account_entity_analysts_catalog" {
  for_each  = local.owns_catalogs ? local.all_entity_analysts : {}
  catalog   = databricks_catalog.business_domain[each.key].name
  principal = each.value.display_name
  privileges = (
    databricks_catalog.business_domain[each.key].name == local.shared_catalog_name
    ? distinct(concat(var.catalog_privileges_entity_analysts, ["EXECUTE"]))
    : var.catalog_privileges_entity_analysts
  )
}

################ Schema-Level Permissions ###############

# Not managed here. The bundles create the bronze, silver and gold schemas and
# grant on them: Terraform owns only what is named at plan time.
