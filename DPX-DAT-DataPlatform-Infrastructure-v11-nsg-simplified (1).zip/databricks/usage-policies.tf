/**
 * Serverless Usage Policies (Doubtless addition)
 *
 * One serverless usage policy per workspace, carrying the mandatory tags, so
 * that serverless compute is attributed. The provider resource is
 * databricks_budget_policy (Public Preview), on the account provider only.
 *
 * A policy's tags reach only the principals assigned to it, so the personas
 * and the tier's sp-databricks group are made its users.
 */

# ---------------------------------------------------------------------------
# SERVERLESS COMPUTE PARKED (2026-10-13, Azure DevOps work item 107902)
#
# Doubtless infrastructure security have not yet approved serverless compute.
# A Network Connectivity Configuration would give it a private route to our
# storage, but serverless compute still runs, and processes our data, on
# Databricks-managed infrastructure outside our network. Until that is
# understood and approved, the initial deployment builds nothing that sets up
# serverless compute or runs on it. The code is commented out, not deleted,
# so that it can be restored as it was: each parked line is the original line
# behind a leading "# ", and each blank line is a bare "#". To strip
# the prefix: sed -E 's/^# ?//'.
#
# Parked here: the serverless usage policy for this workspace, which carries the
# mandatory tags so that serverless spend is attributed, and the rule set that
# lets the personas and the workload group use it.
# To restore: strip the leading "# " from every line below this note, restore
# the usage_policy_id output, unpark the usage policy tests,
# retire the matching case in scripts/tests/test_serverless_parked.py, and work
# through "Serverless compute is parked" in this root's README for the rest.
# ---------------------------------------------------------------------------
# resource "databricks_budget_policy" "workspace" {
#   provider = databricks.account
#   # The account lists every programme's usage policies together, so the name
#   # carries this platform's prefix.
#   policy_name           = "dpx-dat-${var.environment}-${var.workspace_type}-usage-policy"
#   binding_workspace_ids = [tonumber(var.workspace_id)]
#   custom_tags           = [for key, value in var.common_tags : { key = key, value = value }]
# }
#
# locals {
#   usage_policy_users = compact([
#     try(local.env_engineers.acl_principal_id, null),
#     try(local.env_scientists.acl_principal_id, null),
#     try(local.env_analysts.acl_principal_id, null),
#     try(local.sp_databricks.acl_principal_id, null),
#   ])
# }
#
# resource "databricks_access_control_rule_set" "usage_policy" {
#   count    = length(local.usage_policy_users) > 0 ? 1 : 0
#   provider = databricks.account
#   name     = "accounts/${var.databricks_account_id}/budgetPolicies/${databricks_budget_policy.workspace.policy_id}/ruleSets/default"
#
#   grant_rules {
#     principals = local.usage_policy_users
#     role       = "roles/budgetPolicy.user"
#   }
# }
