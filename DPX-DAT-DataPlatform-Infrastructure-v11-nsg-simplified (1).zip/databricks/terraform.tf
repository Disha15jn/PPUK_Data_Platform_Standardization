terraform {
  required_version = "~> 1.16"

  required_providers {
    databricks = {
      source  = "databricks/databricks"
      version = "~> 1.133"
    }
  }

  # Partial configuration: each state instance's settings are in an
  # environments/<instance>.tfbackend file, never tracked, made from its template.
  backend "azurerm" {}
}
