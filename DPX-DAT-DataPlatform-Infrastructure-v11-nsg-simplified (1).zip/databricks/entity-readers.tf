/**
 * Each entity's Reader group
 *
 * The Reader sits in the reference platform's per-entity 'analysts' key, which
 * already has a lookup, a workspace assignment, a catalog grant and warehouse
 * use. These are the grants that key lacks, matching the Contributor's: the
 * shared catalog's masking functions and the landing and export volumes.
 * Privileges are read only in every environment.
 */

################ Shared Catalog Permissions ###############

# Every other entity's Reader may use the masking functions in the shared
# catalog, and nothing more: no SELECT on the shared entity's data. The shared
# entity's own Reader has EXECUTE in its catalog grant instead. As for the
# Contributor, the operational workspace grants nothing here: the analytical
# state that creates the shared catalog owns its grants.
resource "databricks_grant" "entity_analysts_shared_catalog" {
  for_each = local.owns_catalogs && contains(keys(databricks_catalog.business_domain), local.shared_business_domain) ? {
    for entity, group in local.all_entity_analysts : entity => group if entity != local.shared_business_domain
  } : {}

  catalog    = databricks_catalog.business_domain[local.shared_business_domain].name
  principal  = each.value.display_name
  privileges = ["USE_CATALOG", "USE_SCHEMA", "EXECUTE"]
}

################ Volume Permissions ###############

# Each entity's Reader on its own landing and export volumes. The volume name is
# built from the configured catalog, schema and volume names, as for the
# Contributor, so it is known at plan time and still waits for the volume.
resource "databricks_grant" "entity_analysts_landing_volume" {
  for_each   = var.create_volumes && var.create_external_locations && local.owns_catalogs ? local.all_entity_analysts : {}
  volume     = "${databricks_volume.landing[each.key].catalog_name}.${databricks_volume.landing[each.key].schema_name}.${databricks_volume.landing[each.key].name}"
  principal  = each.value.display_name
  privileges = var.volume_privileges_entity_analysts
}

resource "databricks_grant" "entity_analysts_export_volume" {
  for_each   = var.create_volumes && var.create_external_locations && local.owns_catalogs ? local.all_entity_analysts : {}
  volume     = "${databricks_volume.export[each.key].catalog_name}.${databricks_volume.export[each.key].schema_name}.${databricks_volume.export[each.key].name}"
  principal  = each.value.display_name
  privileges = var.volume_privileges_entity_analysts
}
