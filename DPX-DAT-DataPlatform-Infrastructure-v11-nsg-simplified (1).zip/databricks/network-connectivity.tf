/*
 * Network Connectivity Configuration (NCC)
 *
 * Lets serverless compute reach private resources in Azure: here, each
 * environment's trusted storage account, whose public access is disabled.
 *
 * - Two account-level NCCs for the region, one per tier, where the reference
 *   platform has one. dev-anl owns the non-production NCC, which every dev,
 *   tst and stg state binds to, operational ones included; prd-anl owns the
 *   production NCC, which prd-anl and prd-ops bind to (manage_shared_ncc). So
 *   dev needs nothing from production, and a development merge cannot change
 *   production's NCC. Every other state looks its tier's NCC up by name.
 * - Each analytical state adds the private endpoint rules for its own
 *   environment's trusted account, blob and dfs, from its own environment's
 *   outputs. An operational state adds none: it shares its environment's
 *   account, whose rules that environment's analytical state adds. Each rule
 *   then needs approving on the storage side within 14 days, in its own
 *   environment's subscription: a runbook step.
 * - Provision for lower environments to read production's catalogues:
 *   with enable_prd_storage_on_nonprod_ncc, prd-anl also adds production's
 *   trusted-storage rules to the non-production NCC. Off by default. It is the
 *   network route only; the read itself still needs a read-only catalogue
 *   binding (catalog_reader_workspace_ids) and the users' grants.
 *
 * The region is a variable, and the NCC's drift is detected normally: the
 * reference platform hard-coded its region and ignored every change. The NCC's
 * name is not derived from it: see ncc_names.
 */

# ---------------------------------------------------------------------------
# SERVERLESS COMPUTE PARKED (2026-10-13, Azure DevOps work item 107902)
#
# Doubtless infrastructure security have not yet approved serverless compute.
# A Network Connectivity Configuration would give it a private route to our
# storage, but serverless compute still runs, and processes our data, on
# Databricks-managed infrastructure outside our network. Until that is
# understood and approved, the initial deployment builds nothing that sets up
# serverless compute or runs on it. The code is commented out, not deleted,
# so that it can be restored as it was: each parked line is the original line
# behind a leading "# ", and each blank line is a bare "#". To strip
# the prefix: sed -E 's/^# ?//'.
#
# Parked here: the two account-level NCCs (one per tier), each workspace's
# binding to its tier's NCC, and the private endpoint rules for each
# environment's trusted storage, including prd-anl's provision for lower
# environments.
# To restore: strip the leading "# " from every line below this note, restore
# the outputs, switches and var-file lines that point here, unpark the NCC
# tests and mocks,
# retire the matching case in scripts/tests/test_serverless_parked.py, and work
# through "Serverless compute is parked" in this root's README for the rest.
# ---------------------------------------------------------------------------
# ################ Account-Level NCC Configuration ###############
#
# locals {
#   # The account is shared with other programmes, and every state but the
#   # tier's owner finds its NCC by name, so the names are this platform's own:
#   # a generic name could find another programme's NCC. NCC names are at most
#   # 30 characters.
#   ncc_names = {
#     nonprod = "dpx-dat-gwc-nonprod-ncc"
#     prod    = "dpx-dat-gwc-prod-ncc"
#   }
#   ncc_name = local.ncc_names[local.is_prod ? "prod" : "nonprod"]
# }
#
# resource "databricks_mws_network_connectivity_config" "this" {
#   provider = databricks.account
#   count    = var.manage_shared_ncc && var.enable_ncc ? 1 : 0
#
#   name   = local.ncc_name
#   region = var.region
#
#   # No egress_config: storage is reached through the private endpoint rules
#   # below. The service-endpoint subnets the reference platform could set are
#   # deprecated, and serverless subnet allowlisting ended on 9 June 2026.
#
#   # Every workspace in the tier depends on it: tearing down dev must not take
#   # tst's and stg's connectivity with it.
#   lifecycle {
#     prevent_destroy = true
#   }
# }
#
# # Every state that does not own its tier's NCC looks it up.
# data "databricks_mws_network_connectivity_config" "this" {
#   provider = databricks.account
#   count    = !var.manage_shared_ncc && var.enable_ncc ? 1 : 0
#
#   name = local.ncc_name
# }
#
# locals {
#   ncc_id = var.enable_ncc ? (
#     var.manage_shared_ncc
#     ? databricks_mws_network_connectivity_config.this[0].network_connectivity_config_id
#     : data.databricks_mws_network_connectivity_config.this[0].network_connectivity_config_id
#   ) : null
#
#   ncc_private_endpoint_rules = {
#     for rule in var.ncc_private_endpoint_rules : rule.name => rule
#   }
# }
#
# ################ Workspace Binding ###############
#
# resource "databricks_mws_ncc_binding" "workspace" {
#   provider                       = databricks.account
#   count                          = var.enable_ncc ? 1 : 0
#   network_connectivity_config_id = local.ncc_id
#   workspace_id                   = var.workspace_id
# }
#
# ################ NCC Private Endpoint Rules ###############
#
# # Each analytical state's own, for its own environment's storage. Several states
# # may add rules to one NCC: the NCC's egress_config, where rules show, is
# # read-only in the provider, so no state sees another's rules as drift.
# resource "databricks_mws_ncc_private_endpoint_rule" "this" {
#   provider = databricks.account
#   for_each = var.enable_ncc && var.workspace_type == "analytical" ? local.ncc_private_endpoint_rules : {}
#
#   network_connectivity_config_id = local.ncc_id
#   resource_id                    = each.value.resource_id
#   group_id                       = each.value.group_id
#
#   # Private endpoint rules do not support updates.
#   lifecycle {
#     create_before_destroy = false
#   }
# }
#
# ################ Production Storage on the Non-Production NCC ###############
#
# # The network provision for lower environments to read production's
# # catalogues. The rules sit in prd-anl's state, applied from production:
# # only a production change can open production's storage to non-production
# # serverless compute, and each endpoint is approved on production's storage, in
# # production's subscription. The route reaches every workspace bound to the
# # non-production NCC: both of dev's, tst's and stg's.
# data "databricks_mws_network_connectivity_config" "nonprod" {
#   provider = databricks.account
#   count    = var.enable_prd_storage_on_nonprod_ncc && var.enable_ncc ? 1 : 0
#
#   name = local.ncc_names.nonprod
# }
#
# resource "databricks_mws_ncc_private_endpoint_rule" "prd_storage_on_nonprod_ncc" {
#   provider = databricks.account
#   for_each = var.enable_prd_storage_on_nonprod_ncc && var.enable_ncc ? local.ncc_private_endpoint_rules : {}
#
#   network_connectivity_config_id = data.databricks_mws_network_connectivity_config.nonprod[0].network_connectivity_config_id
#   resource_id                    = each.value.resource_id
#   group_id                       = each.value.group_id
#
#   # Private endpoint rules do not support updates.
#   lifecycle {
#     create_before_destroy = false
#   }
# }
