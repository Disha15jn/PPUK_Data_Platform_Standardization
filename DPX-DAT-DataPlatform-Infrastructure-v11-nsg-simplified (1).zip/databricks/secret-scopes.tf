/**
 * Secret Scope Configuration
 *
 * An Azure Key Vault-backed secret scope, on the environment's separate
 * access-policy vault. Key Vault-backed scopes support only the vault
 * access-policy model, not Azure RBAC (Microsoft Learn, checked 24 September
 * 2026), so the platform's RBAC vault cannot back one.
 *
 * The AzureDatabricks application reads the vault through an access policy of
 * Get and List, which infra/20-platform-services grants; no Access Connector
 * role is involved. The vault has no public network access: its firewall admits
 * only its private endpoint and trusted Microsoft services, and Azure Databricks
 * reads it as a trusted service.
 */

################ Secret Scopes ###############

resource "databricks_secret_scope" "key_vault" {
  count = var.create_secret_scope ? 1 : 0
  name  = local.secret_scope_name

  keyvault_metadata {
    resource_id = local.key_vault_resource_id
    dns_name    = local.key_vault_uri
  }
}
