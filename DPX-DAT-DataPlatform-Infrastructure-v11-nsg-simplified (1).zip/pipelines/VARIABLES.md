# Pipeline variables and their placeholder values

Every value below that is not in a tracked `*.tfvars` file comes from an Azure DevOps variable
group or the pipeline itself. **All values here are placeholders**: replace each one before the
first run. Nothing secret or environment-specific is committed.

Azure DevOps upper-cases variable names when it turns them into environment variables, and
Terraform reads `TF_VAR_<name>` case-sensitively. So the pipelines do not rely on `TF_VAR_*`
variables in a group: each plan and apply step maps them explicitly, for example
`TF_VAR_subscription_id: $(subscription_id)`. Create the variables below with exactly these names
(lower-case, as written) and link the group to the pipeline.

Placeholder GUIDs are all zeros. Placeholder names are in `<angle brackets>`.

## State backend: group `TF-Backend-GWC` (non-production) and the production equivalent

| Variable | Used by | Placeholder |
|---|---|---|
| `backend-subscription-id` | every root | `00000000-0000-0000-0000-000000000000` |
| `backend-resource-group-name` | every root | `<state-resource-group>` |
| `backend-storage-account-name` | every root; also where the `outputs` container lives | `<state-storage-account>` |
| `backend-container-name` | landing zone, platform | `<state-container>` |

One state storage account per tier (non-production, production) so the production identity needs
no rights on non-production storage. The `outputs` container (`network-<env>.json`,
`platform-<env>.json`, `databricks-<instance>.json`) is in that account:
Storage Blob Data Contributor for the publishing pipeline's identity, Reader for the reading one's.
The Databricks pipeline uses a container named `databricks` for its state.

## Identifiers: group `TF-Identifiers-<env>` (dev, tst, stg, prd)

One group per environment. The platform and Databricks pipelines both link it: the Databricks
pipeline builds the name from the instance, so `dev-anl` and `dev-ops` read `TF-Identifiers-dev`.
The first three values differ by environment. The last four are the same for every environment
in a tier (non-production, production), so each non-production group holds the same values.

| Variable | Used by | Placeholder |
|---|---|---|
| `subscription_id` | landing zone, platform | `00000000-0000-0000-0000-000000000000` (that environment's subscription) |
| `law_central_sub_id` | landing zone | `00000000-0000-0000-0000-000000000000` (central Log Analytics subscription) |
| `pdns_sub_id` | landing zone | `00000000-0000-0000-0000-000000000000` (central private DNS subscription) |
| `tenant_id` | landing zone, platform | `00000000-0000-0000-0000-000000000000` |
| `azure_databricks_service_principal_object_id` | platform | `00000000-0000-0000-0000-000000000000` (object ID of the AzureDatabricks enterprise application, application ID `2ff814a6-3304-4ab8-85cb-cd0e6f879c1d`: `az ad sp show --id 2ff814a6-3304-4ab8-85cb-cd0e6f879c1d --query id -o tsv`) |
| `databricks_account_id` | Databricks | `00000000-0000-0000-0000-000000000000` |
| `service_principal_application_id` | Databricks | `00000000-0000-0000-0000-000000000000` (the tier's pipeline identity) |

## Already in use

`ADO-SSH` (SSH key variables), the service connection `ado-sc-dat-dataplatform-001` and the pool
`dpx_inf_gwc_linux_pba` for non-production.

## Dev platform services: `20-Platform.dev.yml`

Plans `infra/20-platform-services` for dev and, on a manual run from `main`, applies the saved plan. It follows the landing-zone pipeline (`10.LZone.dev.yml`): Build plans and publishes the plan file as artifact `tfplan`, Scan runs Checkov over it, and Apply downloads `tfplan` and applies it behind the `dpx-dat-dev_deployment` environment, which the landing-zone pipeline shares. Anything queued from another branch plans only, because Apply runs only for a manual run from `main`.

Three things differ from the landing-zone pipeline. Scan can be switched on for a run, where the landing-zone pipeline's condition ends in `False`: it runs when the plan has changes and the parameter `runCheckov` is ticked, and Checkov is `--soft-fail`, so findings do not stop an apply. `runCheckov` is unticked by default, because the Checkov install step (copied from the central pipeline template) fails on the agent pool's current image: the deadsnakes PPA cannot be reached, Python 3.7 does not exist on Ubuntu 24.04, and the system-wide `pip install` is refused. Whether the pool can reach PyPI is untested. Tick it once the install step works there. Apply starts only if Build succeeded and Scan did not fail, because its condition is `succeeded('Build')` plus a Scan result of Succeeded, SucceededWithIssues or Skipped, where the landing-zone pipeline's `or(succeeded(), True)` lets an apply start after a failed plan. This root does not upload its outputs to the `outputs` container, which does not exist. It writes and checks them (`scripts/write_outputs.sh`) and saves them as the artifact `handoff-outputs`, the hand-off to the Databricks root. A failure there fails the run.

The network outputs come from the `handoff-outputs` artifact of the landing-zone pipeline (definition 2267, `LandingZonePipelineId`), not from the `outputs` container. Failed runs are accepted, because that pipeline's upload to the container fails while the container does not exist, and the artifact is only written after a successful apply. The parameter `networkOutputs` chooses the run when you queue the pipeline.

- `newest-run` (the default) takes the newest completed run of 2267 on `main`. `scripts/select_outputs_run.py` fails if that run published no artifact, and never falls back to an older one. `scripts/check_upstream_run.py` then fails unless the downloaded outputs came from the newest completed run and no run is queued or in progress, which covers a cancelled newest run and one still active.
- `latest-available` takes the newest run on `main` that did publish the artifact, passing over newer ones that did not. Each run passed over is logged as a warning, and the check step's log line says the outputs are not from the newest run. Use it only while the landing-zone pipeline is not yet applying cleanly, because the plan may then describe a network that is no longer what is deployed. Stop using it once the newest run applies.

Either way the check step logs the run, commit and finish time that were used. The download takes exactly the run the first step chose, by its run ID. Both steps call the builds API with the job's access token, so the project's build service needs to see pipeline 2267 and read its artifacts.

The last Build step, `scripts/apply_readiness.sh`, reports what a plan cannot see, for whoever approves the apply. Each line starts `OK`, `PROBLEM` or `UNKNOWN`. It checks that the resource providers our root does not register are registered, that no workspace NSG already holds a rule at priority 100 (where Databricks adds its own VNet rules when it creates a workspace), and that the pipeline identity holds a role on each DNS zone, on the subscription for role assignments, and on the Log Analytics workspace. It never fails the run, and it cannot see a custom role's actions or a condition on a role, so read a `PROBLEM` beside the roles it prints.

An approval can wait a long time, so Apply checks again before it applies. Build saves the landing-zone run its plan used as the artifact `outputs-run`, and Apply runs `scripts/check_upstream_run.py` on that run with the same `networkOutputs` mode just before `Terraform-Apply`. In `newest-run` mode the apply stops if a newer landing-zone run has finished or is running since the plan was made. In `latest-available` mode it only needs the run to be a completed one.

On its first run, permit the groups `TF-Backend-GWC`, `ADO-SSH` and `TF-Identifiers-dev`, the secure file `ado-ssh-private-key`, the service connection `ado-sc-dat-dataplatform-001`, the pool `dpx_inf_gwc_linux_pba` and the environment `dpx-dat-dev_deployment`. Its state key is `platform-services/dev.tfstate`. `scripts/tests/test_platform_dev_pipeline.py` holds the file to this shape.

## Still to name (placeholders in the pipelines)

| Where | Placeholder to replace |
|---|---|
| `10.LZone.prd.yml`, `20-Platform.prd.yml`, `30-Databricks.yml` (prd instances) | `TODO-prod-service-connection`, `TODO-prod-agent-pool` |
| `30-Databricks.yml` | `TODO-TF-Backend-GWC-Prod` (group name) |
| Azure DevOps environments (approvals) | `dpx-dat-<env>_deployment`, `dpx-dat-<instance>_databricks` |
