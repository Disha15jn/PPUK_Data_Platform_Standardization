# The platform services for one environment: resource groups, two Key Vaults,
# the trusted storage account, one Access Connector per entity,
# workload identities and the Databricks workspaces, each with its private
# endpoints. Every diagnostic setting sends to the Landing Zone's central Log
# Analytics workspace, so none is created here.
#
# Each service is a wrapper module in ../modules, around an Azure Verified
# Module. The wrappers fix the security settings; this file supplies the
# environment's values and connects the services together.

# --- Resource groups, by type of resource --------------------------------

module "resource_group" {
  source   = "../modules/resource-group"
  for_each = var.resource_group_names

  enable_telemetry = var.enable_telemetry
  location         = var.location
  name             = each.value
  role_assignments = local.resource_group_role_assignments[each.key]
  tags             = var.common_tags

}

# --- Operations: Key Vaults (ops) -----------------------------------------------

module "platform_key_vault" {
  source = "../modules/key-vault"

  access_model               = "rbac"
  enable_telemetry           = var.enable_telemetry
  location                   = var.location
  lock_enabled               = var.lock_enabled
  log_analytics_workspace_id = var.network.log_analytics_workspace_id
  name                       = var.platform_key_vault.name
  private_endpoint           = local.private_endpoint
  resource_group_name        = module.resource_group["ops"].name
  sku_name                   = var.platform_key_vault.sku_name
  tags                       = var.common_tags
  tenant_id                  = var.tenant_id
}

# The Databricks secret scope's vault. Key Vault-backed scopes need the
# access-policy model, so it is kept apart from the platform vault.
module "secret_scope_key_vault" {
  source = "../modules/key-vault"

  access_model               = "access_policy"
  enable_telemetry           = var.enable_telemetry
  location                   = var.location
  lock_enabled               = var.lock_enabled
  log_analytics_workspace_id = var.network.log_analytics_workspace_id
  name                       = var.secret_scope_key_vault.name
  private_endpoint           = local.private_endpoint
  resource_group_name        = module.resource_group["ops"].name
  secret_reader_object_ids = {
    azure_databricks = var.azure_databricks_service_principal_object_id
  }
  sku_name  = var.secret_scope_key_vault.sku_name
  tags      = var.common_tags
  tenant_id = var.tenant_id
}

# --- Storage (storage) ------------------------------------------------------------

# Each entity's Access Connector is assigned Storage Blob Data Contributor on
# that entity's containers only, and Storage Blob Delegator on the account, so
# the connectors are created before the account. No identity can reach every
# entity's data.
module "trusted_storage" {
  source = "../modules/storage-account"

  account_role_assignments = {
    for entity, connector in module.access_connector : entity => {
      principal_id = connector.principal_id
    }
  }
  containers = {
    for name, entity in local.container_entity : name => {
      role_assignments = {
        connector = {
          principal_id = module.access_connector[entity].principal_id
        }
      }
    }
  }
  enable_telemetry           = var.enable_telemetry
  location                   = var.location
  lock_enabled               = var.lock_enabled
  log_analytics_workspace_id = var.network.log_analytics_workspace_id
  name                       = var.trusted_storage.name
  private_endpoint           = local.private_endpoint
  resource_group_id          = module.resource_group["storage"].resource_id
  sku_name                   = var.trusted_storage.sku_name
  tags                       = var.common_tags
}

# UNTRUSTED STORAGE PARKED (2026-10-14)
# Security want the untrusted account in a separate subscription with its own rules; it is not built yet, so this root creates no untrusted account.
# To restore: delete this note and strip one leading "# " from each parked line. It may be better restored as its own root in the new subscription.

# # Nothing in Databricks reads untrusted: it has no Access Connector and
# # no role assignments. The process that copies its data into the trusted
# # landing containers arrives with the first use case.
# module "untrusted_storage" {
#   source = "../modules/storage-account"
#
#   containers                 = local.untrusted_containers
#   enable_telemetry           = var.enable_telemetry
#   location                   = var.location
#   lock_enabled               = var.lock_enabled
#   log_analytics_workspace_id = var.network.log_analytics_workspace_id
#   name                       = var.untrusted_storage.name
#   private_endpoint           = local.private_endpoint
#   resource_group_id          = module.resource_group["storage"].resource_id
#   sku_name                   = var.untrusted_storage.sku_name
#   tags                       = var.common_tags
# }

# Hexaware's draft private endpoints for the storage accounts, commented
# out until agreed: they have no subnet yet and share one module name, and the
# storage wrapper already creates each account's blob and dfs endpoints from
# local.private_endpoint above.
# module "avm-res-network-privateendpoint" {
#   source  = "Azure/avm-res-network-privateendpoint/azurerm"
#   version = "0.2.0"
#   name = var.trusted_storage.pe_name
#   location = var.location
#   resource_group_name = module.resource_group["storage"].name
#   network_interface_name = var.trusted_storage.pe_nic_name
#   subnet_resource_id = var.network.
#   private_connection_resource_id = module.trusted_storage.resource_id
# }
#
# UNTRUSTED STORAGE PARKED (2026-10-14): see the note above.
# module "avm-res-network-privateendpoint" {
#   source  = "Azure/avm-res-network-privateendpoint/azurerm"
#   version = "0.2.0"
#   name = var.untrusted_storage.pe_name
#   location = var.location
#   resource_group_name = module.resource_group["storage"].name
#   network_interface_name = var.untrusted_storage.pe_nic_name
#   subnet_resource_id =
#   private_connection_resource_id = module.untrusted_storage.resource_id
# }

# --- Databricks (databricks) ------------------------------------------------------

# One Access Connector per entity. Its rights are assigned by the trusted
# storage account, on that entity's containers only.
module "access_connector" {
  source   = "../modules/access-connector"
  for_each = var.entities

  enable_telemetry  = var.enable_telemetry
  location          = var.location
  name              = var.access_connector_names[each.key]
  resource_group_id = module.resource_group["databricks"].resource_id
  tags              = var.common_tags
}

module "workload_identity" {
  source   = "../modules/managed-identity"
  for_each = var.workload_identities

  enable_telemetry    = var.enable_telemetry
  location            = var.location
  name                = each.value.name
  resource_group_name = module.resource_group["databricks"].name
  tags                = var.common_tags
}

module "databricks_workspace" {
  source   = "../modules/databricks-workspace"
  for_each = var.workspaces

  container_subnet            = var.network.databricks_subnets[each.key].container
  enable_telemetry            = var.enable_telemetry
  host_subnet                 = var.network.databricks_subnets[each.key].host
  location                    = var.location
  log_analytics_workspace_id  = var.network.log_analytics_workspace_id
  managed_resource_group_name = each.value.managed_resource_group_name
  name                        = each.value.name
  private_endpoint            = local.workspace_private_endpoints[each.key]
  resource_group_id           = module.resource_group["databricks"].resource_id
  resource_group_name         = module.resource_group["databricks"].name
  storage_connector_name      = each.value.storage_connector_name
  storage_account_sku_name    = each.value.storage_account_sku_name
  tags                        = local.workspace_tags[each.key]
  virtual_network_id          = var.network.virtual_network_id
}

# --- Platform admin rights, only if Calandra's process does not cover them --
#
# Assigned on the resource groups, by the resource-group wrapper, from
# platform_admin_role_assignments.
