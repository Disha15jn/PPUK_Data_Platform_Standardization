# One plan of the dev state of infra/20-platform-services, for reading.
#
# Unlike the unit tests, nothing here stubs an Azure Verified Module, so the plan
# lists every resource those modules would create. Providers are mocked, so it
# needs no credentials and no network. Run it with `make plan`
# (scripts/terraform_plan.sh), which passes environments/dev.tfvars and the
# fixtures in tests/fixtures/. It asserts nothing: its job is to print the plan.

mock_provider "azurerm" {}
mock_provider "azapi" {}

run "plan" {
  command = plan
}
