# Credentials come from the environment, never from here. In the pipeline, the
# ARM_* variables and ARM_OIDC_AZURE_SERVICE_CONNECTION_ID give workload
# identity federation to the backend and both providers.

provider "azurerm" {
  features {}

  # Whoever vends the subscription registers the resource providers the
  # platform needs, so a plan never tries to.
  resource_provider_registrations = "none"
  storage_use_azuread             = true
  subscription_id                 = var.subscription_id
}

provider "azapi" {
  subscription_id = var.subscription_id
  tenant_id       = var.tenant_id
}
