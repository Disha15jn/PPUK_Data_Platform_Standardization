# infra/20-platform-services: stg.
#
# Our configuration only. Upstream values (network, entities) come from
# the generated upstream.tfvars.json, and identifiers (subscription_id,
# tenant_id and the object IDs) from the pipeline's variable groups;
# scripts/check_var_files.py rejects either here.
#
# Names are the ones the Calandra team agreed. Storage and Key Vault names are
# globally unique.

environment = "stg"
location    = "germanywestcentral"

resource_group_names = {
  storage    = "dpx-dat-sto-stg-int-gwc-rg-001"
  databricks = "dpx-dat-dbx-stg-int-gwc-rg-003"
  ops        = "dpx-dat-ops-stg-int-gwc-rg-002"
}

platform_key_vault = {
  name = "dpxdatgdpstgintgwckv001"
}

secret_scope_key_vault = {
  name = "dpxdatdbxstgintgwckv002"
}

trusted_storage = {
  name     = "dpxdattrsstgintgwcst001"
  sku_name = "Standard_LRS"
}

# UNTRUSTED STORAGE PARKED (2026-10-14): see the note in main.tf.
# untrusted_storage = {
#   name     = "dpxdatuntstgintgwcst002"
#   sku_name = "Standard_LRS"
# }

access_connector_names = {
  grp = "dpx-dat-grp-trs-stg-int-gwc-dbac-001"
  duk = "dpx-dat-duk-trs-stg-int-gwc-dbac-002"
}

workspaces = {
  anl = {
    name                        = "dpx-dat-anl-stg-int-gwc-dbw-001"
    managed_resource_group_name = "dpx-dat-anl-stg-int-gwc-rg-004"
    storage_connector_name      = "dpx-dat-anl-dbm-stg-int-gwc-dbac-003"
    storage_account_sku_name    = "Standard_LRS"
  }
  ops = {
    name                        = "dpx-dat-ops-stg-int-gwc-dbw-002"
    managed_resource_group_name = "dpx-dat-ops-stg-int-gwc-rg-005"
    storage_connector_name      = "dpx-dat-ops-dbm-stg-int-gwc-dbac-004"
    storage_account_sku_name    = "Standard_LRS"
  }
}

# One workload identity per entity, for bundle run_as. The Calandra team add
# each to the tier's sp-databricks group.
workload_identities = {
  grp = {
    name = "dpx-dat-dbx-grp-stg-gwc-uai-001"
  }
  duk = {
    name = "dpx-dat-dbx-duk-stg-gwc-uai-002"
  }
}

common_tags = {
  Project            = "doubtless-data-platform"
  Environment        = "stg"
  WorkspaceType      = "shared"
  ManagedBy          = "terraform"
  Application        = "tbc"
  BusinessEntity     = "tbc"
  CostCentre         = "tbc"
  DataClassification = "tbc"
  Owner              = "tbc"
}

# CanNotDelete locks on the storage accounts and Key Vaults: production only,
# to start.
lock_enabled = false
