locals {
  # The trusted containers each entity gets. One set serves both workspaces:
  # the environment's catalogue is bound to both, so there is no second
  # external location to keep apart.
  container_purposes = ["uc", "landing", "export"]

  # The shared resources' private endpoints go in the subnet the landing zone
  # publishes for them; each workspace's own endpoints go in that workspace's
  # subnet. All register in the central private DNS zones.
  private_endpoint = {
    subnet_id            = var.network.private_endpoint_subnet_id
    private_dns_zone_ids = var.network.private_dns_zone_ids
  }

  workspace_private_endpoints = {
    for key in keys(var.workspaces) : key => merge(local.private_endpoint, {
      subnet_id = var.network.databricks_subnets[key].private_endpoint_subnet_id
    })
  }

  trusted_containers = {
    for entity in keys(var.entities) :
    entity => toset([for purpose in local.container_purposes : "${entity}-${purpose}"])
  }

  # Which entity each trusted container belongs to, so that its Access
  # Connector, and no other, is assigned on it.
  container_entity = merge([
    for entity, names in local.trusted_containers : { for name in names : name => entity }
  ]...)

  # UNTRUSTED STORAGE PARKED (2026-10-14): see the note in main.tf.
  # # One container per entity in untrusted, with no role assignments.
  # untrusted_containers = { for entity in keys(var.entities) : entity => {} }

  # The platform admin group's role assignments, by resource group: each var
  # file entry lands on the group it names, as a Group principal.
  resource_group_role_assignments = {
    for group in keys(var.resource_group_names) : group => {
      for key, assignment in var.platform_admin_role_assignments : key => {
        principal_id               = var.platform_admin_group_object_id
        principal_type             = "Group"
        role_definition_id_or_name = assignment.role_definition_name
      } if assignment.resource_group == group
    }
  }

  workspace_tags = {
    for key in keys(var.workspaces) :
    key => merge(var.common_tags, { WorkspaceType = local.workspace_types[key] })
  }

  workspace_types = {
    anl = "analytical"
    ops = "operational"
  }
}
