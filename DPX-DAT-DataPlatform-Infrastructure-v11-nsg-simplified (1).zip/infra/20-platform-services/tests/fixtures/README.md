# Test fixtures

Hand-written stand-ins for the values the pipeline supplies, so the unit tests run
before the upstream states exist, with no credentials:

- `network-outputs-<env>.json`: the landing zone's published `terraform output -json`, in the
  shape that root publishes: an `environment` output and one `network` object. Its names are the
  ones the landing zone gives each environment, so the tests run on the names it will publish;
  only the GUIDs are stand-ins. `scripts/tests/test_fixture_chain.py` proves that resolving it
  gives `upstream-<env>.json`.
- `upstream-<env>.json`: the shape `scripts/resolve_upstream.py` writes into
  `upstream.tfvars.json` from the network and security state's published outputs.
- `identifiers.json`: the identifier variables the pipeline sets from its variable groups. Every
  GUID is zeros.

The apply template always resolves the real outputs, so a fixture can never reach an apply.

`../gen_overrides.py` generates the `override_module` blocks the test files share: run
`python3 gen_overrides.py <env> <tracks>` from `tests/` (names come from `agreed_names.py`) and paste its output.
