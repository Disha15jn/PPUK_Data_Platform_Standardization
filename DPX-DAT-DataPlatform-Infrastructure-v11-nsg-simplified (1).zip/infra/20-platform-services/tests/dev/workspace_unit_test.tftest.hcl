# The workspace wrapper, called directly.
#
# The workspace Verified Module looks up its resource group with a data source.
# Terraform reads a data source at plan time whenever its arguments are known,
# so on a new environment's first plan, before the group exists, the lookup
# fails. The wrapper passes the name through terraform_data, whose output is
# unknown only until the group has been created: the lookup waits for the apply
# on that first plan, and reads at plan time on every later one.

mock_provider "azurerm" {}
mock_provider "azapi" {}

variables {
  name                       = "dbw-tbc-dev-anl"
  location                   = "germanywestcentral"
  resource_group_id          = "/subscriptions/00000000-0000-0000-0000-000000000000/resourceGroups/rg-tbc-dev-databricks"
  resource_group_name        = "rg-tbc-dev-databricks"
  log_analytics_workspace_id = "/subscriptions/00000000-0000-0000-0000-000000000000/resourceGroups/rg-tbc-management/providers/Microsoft.OperationalInsights/workspaces/dpx-inf-mgt-gwc-la-001"
  private_endpoint = {
    subnet_id = "/subscriptions/00000000-0000-0000-0000-000000000000/resourceGroups/rg-net/providers/Microsoft.Network/virtualNetworks/vnet/subnets/snet-pe"
    private_dns_zone_ids = {
      blob       = "/subscriptions/00000000-0000-0000-0000-000000000000/resourceGroups/rg-tbc-dns/providers/Microsoft.Network/privateDnsZones/privatelink.blob.core.windows.net"
      dfs        = "/subscriptions/00000000-0000-0000-0000-000000000000/resourceGroups/rg-tbc-dns/providers/Microsoft.Network/privateDnsZones/privatelink.dfs.core.windows.net"
      vault      = "/subscriptions/00000000-0000-0000-0000-000000000000/resourceGroups/rg-tbc-dns/providers/Microsoft.Network/privateDnsZones/privatelink.vaultcore.azure.net"
      databricks = "/subscriptions/00000000-0000-0000-0000-000000000000/resourceGroups/rg-tbc-dns/providers/Microsoft.Network/privateDnsZones/privatelink.azuredatabricks.net"
    }
  }
  managed_resource_group_name = "rg-tbc-dev-anl-managed"
  storage_connector_name      = "dbac-tbc-dev-anl-dbm"
  virtual_network_id          = "/subscriptions/00000000-0000-0000-0000-000000000000/resourceGroups/rg-net/providers/Microsoft.Network/virtualNetworks/vnet"
  host_subnet                 = { id = "/subscriptions/00000000-0000-0000-0000-000000000000/resourceGroups/rg-net/providers/Microsoft.Network/virtualNetworks/vnet/subnets/h", name = "h" }
  container_subnet            = { id = "/subscriptions/00000000-0000-0000-0000-000000000000/resourceGroups/rg-net/providers/Microsoft.Network/virtualNetworks/vnet/subnets/c", name = "c" }
}

run "resource_group_lookup_waits_for_the_group_on_a_first_plan" {
  command = plan

  module {
    source = "../modules/databricks-workspace"
  }

  override_module {
    target          = module.workspace
    override_during = plan
    outputs = {
      resource_id              = "/subscriptions/00000000-0000-0000-0000-000000000000/resourceGroups/rg-tbc-dev-databricks/providers/Microsoft.Databricks/workspaces/dbw-tbc-dev-anl"
      name                     = "dbw-tbc-dev-anl"
      databricks_workspace_id  = "1234567890123411"
      databricks_workspace_url = "adb-1234567890123411.7.azuredatabricks.net"
    }
  }

  override_data {
    target          = data.azapi_resource.workspace
    override_during = plan
    values = {
      output = {
        managed_resource_group_id = "/subscriptions/00000000-0000-0000-0000-000000000000/resourceGroups/rg-tbc-dev-anl-managed"
        storage_account_name      = "dbstoragetbcdevanl"
      }
    }
  }


  override_module {
    target          = module.workspace_storage_private_endpoint["blob"]
    override_during = plan
    outputs = {
      resource_id = "/subscriptions/00000000-0000-0000-0000-000000000000/resourceGroups/rg-tbc-dev-databricks/providers/Microsoft.Network/privateEndpoints/pe-dbw-tbc-dev-anl-dbstorage-blob"
      name        = "pe-dbw-tbc-dev-anl-dbstorage-blob"
    }
  }

  override_module {
    target          = module.workspace_storage_private_endpoint["dfs"]
    override_during = plan
    outputs = {
      resource_id = "/subscriptions/00000000-0000-0000-0000-000000000000/resourceGroups/rg-tbc-dev-databricks/providers/Microsoft.Network/privateEndpoints/pe-dbw-tbc-dev-anl-dbstorage-dfs"
      name        = "pe-dbw-tbc-dev-anl-dbstorage-dfs"
    }
  }

  assert {
    condition     = terraform_data.resource_group_ready.input == var.resource_group_name
    error_message = "The resource group's name must reach the Verified Module through terraform_data.resource_group_ready, or a new environment's first plan fails on the module's resource group lookup."
  }

  assert {
    condition     = length(module.workspace_storage_private_endpoint) == 2 && length(azurerm_private_endpoint.workspace_storage_unmanaged_dns) == 0
    error_message = "With manage_dns_zone_group true, both workspace storage endpoints come from the private endpoint module, and none from the policy-managed resource."
  }
}

# Where Landing Zone policy creates the DNS zone groups, the workspace storage
# account's endpoints are planned without one, and the zone group the policy
# adds is left alone.
run "policy_created_dns_zone_groups_are_left_alone" {
  command = plan

  module {
    source = "../modules/databricks-workspace"
  }

  variables {
    private_endpoint = {
      subnet_id = "/subscriptions/00000000-0000-0000-0000-000000000000/resourceGroups/rg-net/providers/Microsoft.Network/virtualNetworks/vnet/subnets/snet-pe"
      private_dns_zone_ids = {
        blob       = "/subscriptions/00000000-0000-0000-0000-000000000000/resourceGroups/rg-tbc-dns/providers/Microsoft.Network/privateDnsZones/privatelink.blob.core.windows.net"
        dfs        = "/subscriptions/00000000-0000-0000-0000-000000000000/resourceGroups/rg-tbc-dns/providers/Microsoft.Network/privateDnsZones/privatelink.dfs.core.windows.net"
        vault      = "/subscriptions/00000000-0000-0000-0000-000000000000/resourceGroups/rg-tbc-dns/providers/Microsoft.Network/privateDnsZones/privatelink.vaultcore.azure.net"
        databricks = "/subscriptions/00000000-0000-0000-0000-000000000000/resourceGroups/rg-tbc-dns/providers/Microsoft.Network/privateDnsZones/privatelink.azuredatabricks.net"
      }
      manage_dns_zone_group = false
    }
  }

  override_module {
    target          = module.workspace
    override_during = plan
    outputs = {
      resource_id              = "/subscriptions/00000000-0000-0000-0000-000000000000/resourceGroups/rg-tbc-dev-databricks/providers/Microsoft.Databricks/workspaces/dbw-tbc-dev-anl"
      name                     = "dbw-tbc-dev-anl"
      databricks_workspace_id  = "1234567890123411"
      databricks_workspace_url = "adb-1234567890123411.7.azuredatabricks.net"
    }
  }

  override_data {
    target          = data.azapi_resource.workspace
    override_during = plan
    values = {
      output = {
        managed_resource_group_id = "/subscriptions/00000000-0000-0000-0000-000000000000/resourceGroups/rg-tbc-dev-anl-managed"
        storage_account_name      = "dbstoragetbcdevanl"
      }
    }
  }

  assert {
    condition     = length(module.workspace_storage_private_endpoint) == 0 && length(azurerm_private_endpoint.workspace_storage_unmanaged_dns) == 2
    error_message = "With manage_dns_zone_group false, both endpoints must come from the resource that ignores the zone group the policy adds, not from the private endpoint module."
  }

  assert {
    condition = alltrue([
      for endpoint in values(output.storage_private_endpoint_settings) :
      length(endpoint.private_dns_zone_ids) == 0 && !endpoint.manage_dns_zone_group
    ])
    error_message = "With manage_dns_zone_group false, no endpoint may carry a DNS zone group of ours."
  }
}

