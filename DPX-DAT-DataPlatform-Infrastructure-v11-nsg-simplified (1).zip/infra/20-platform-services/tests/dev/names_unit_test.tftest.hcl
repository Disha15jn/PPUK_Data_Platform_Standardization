# Every name variable rejects an over-length name and a forbidden character,
# for every resource type we name, so a bad name stops the plan, not
# the apply. Each run calls a wrapper module directly.

mock_provider "azurerm" {}
mock_provider "azapi" {}

run "resource_group_rejects_an_over_length_name" {
  command = plan

  module {
    source = "../modules/resource-group"
  }

  variables {
    name     = "rg-xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx"
    location = "germanywestcentral"
  }

  expect_failures = [var.name]
}

run "resource_group_rejects_a_forbidden_character" {
  command = plan

  module {
    source = "../modules/resource-group"
  }

  variables {
    name     = "rg-ends-with-a-period."
    location = "germanywestcentral"
  }

  expect_failures = [var.name]
}

run "key_vault_rejects_an_over_length_name" {
  command = plan

  module {
    source = "../modules/key-vault"
  }

  variables {
    name                       = "kv-tbc-dev-too-long-name1"
    access_model               = "rbac"
    location                   = "germanywestcentral"
    log_analytics_workspace_id = "/subscriptions/00000000-0000-0000-0000-000000000000/resourceGroups/rg-tbc-management/providers/Microsoft.OperationalInsights/workspaces/dpx-inf-mgt-gwc-la-001"
    private_endpoint = {
      subnet_id            = "/subscriptions/00000000-0000-0000-0000-000000000000/resourceGroups/rg-net/providers/Microsoft.Network/virtualNetworks/vnet/subnets/snet-pe"
      private_dns_zone_ids = { blob = "z", dfs = "z", vault = "z", databricks = "z" }
    }
    resource_group_name = "rg"
    tenant_id           = "00000000-0000-0000-0000-000000000000"
  }

  expect_failures = [var.name]
}

run "key_vault_rejects_a_forbidden_character" {
  command = plan

  module {
    source = "../modules/key-vault"
  }

  variables {
    name                       = "kv--double-hyphen"
    access_model               = "rbac"
    location                   = "germanywestcentral"
    log_analytics_workspace_id = "/subscriptions/00000000-0000-0000-0000-000000000000/resourceGroups/rg-tbc-management/providers/Microsoft.OperationalInsights/workspaces/dpx-inf-mgt-gwc-la-001"
    private_endpoint = {
      subnet_id            = "/subscriptions/00000000-0000-0000-0000-000000000000/resourceGroups/rg-net/providers/Microsoft.Network/virtualNetworks/vnet/subnets/snet-pe"
      private_dns_zone_ids = { blob = "z", dfs = "z", vault = "z", databricks = "z" }
    }
    resource_group_name = "rg"
    tenant_id           = "00000000-0000-0000-0000-000000000000"
  }

  expect_failures = [var.name]
}

run "storage_account_rejects_an_over_length_name" {
  command = plan

  module {
    source = "../modules/storage-account"
  }

  variables {
    name                       = "sttbcdevnamethatistoolong"
    location                   = "germanywestcentral"
    log_analytics_workspace_id = "/subscriptions/00000000-0000-0000-0000-000000000000/resourceGroups/rg-tbc-management/providers/Microsoft.OperationalInsights/workspaces/dpx-inf-mgt-gwc-la-001"
    private_endpoint = {
      subnet_id            = "/subscriptions/00000000-0000-0000-0000-000000000000/resourceGroups/rg-net/providers/Microsoft.Network/virtualNetworks/vnet/subnets/snet-pe"
      private_dns_zone_ids = { blob = "z", dfs = "z", vault = "z", databricks = "z" }
    }
    resource_group_id = "/subscriptions/00000000-0000-0000-0000-000000000000/resourceGroups/rg-tbc-dev-storage"
  }

  expect_failures = [var.name]
}

run "storage_account_rejects_geo_redundant_replication" {
  command = plan

  module {
    source = "../modules/storage-account"
  }

  variables {
    name                       = "sttbcdevtrusted"
    location                   = "germanywestcentral"
    log_analytics_workspace_id = "/subscriptions/00000000-0000-0000-0000-000000000000/resourceGroups/rg-tbc-management/providers/Microsoft.OperationalInsights/workspaces/dpx-inf-mgt-gwc-la-001"
    private_endpoint = {
      subnet_id            = "/subscriptions/00000000-0000-0000-0000-000000000000/resourceGroups/rg-net/providers/Microsoft.Network/virtualNetworks/vnet/subnets/snet-pe"
      private_dns_zone_ids = { blob = "z", dfs = "z", vault = "z", databricks = "z" }
    }
    resource_group_id = "/subscriptions/00000000-0000-0000-0000-000000000000/resourceGroups/rg-tbc-dev-storage"
    sku_name          = "Standard_GRS"
  }

  expect_failures = [var.sku_name]
}

run "storage_account_rejects_a_forbidden_character" {
  command = plan

  module {
    source = "../modules/storage-account"
  }

  variables {
    name                       = "st-tbc-dev"
    location                   = "germanywestcentral"
    log_analytics_workspace_id = "/subscriptions/00000000-0000-0000-0000-000000000000/resourceGroups/rg-tbc-management/providers/Microsoft.OperationalInsights/workspaces/dpx-inf-mgt-gwc-la-001"
    private_endpoint = {
      subnet_id            = "/subscriptions/00000000-0000-0000-0000-000000000000/resourceGroups/rg-net/providers/Microsoft.Network/virtualNetworks/vnet/subnets/snet-pe"
      private_dns_zone_ids = { blob = "z", dfs = "z", vault = "z", databricks = "z" }
    }
    resource_group_id = "/subscriptions/00000000-0000-0000-0000-000000000000/resourceGroups/rg-tbc-dev-storage"
  }

  expect_failures = [var.name]
}

run "access_connector_rejects_an_over_length_name" {
  command = plan

  module {
    source = "../modules/access-connector"
  }

  variables {
    name              = "dbac-xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx"
    location          = "germanywestcentral"
    resource_group_id = "/subscriptions/00000000-0000-0000-0000-000000000000/resourceGroups/rg-tbc-dev-storage"
  }

  expect_failures = [var.name]
}

run "access_connector_rejects_a_forbidden_character" {
  command = plan

  module {
    source = "../modules/access-connector"
  }

  variables {
    name              = "dbac tbc dev"
    location          = "germanywestcentral"
    resource_group_id = "/subscriptions/00000000-0000-0000-0000-000000000000/resourceGroups/rg-tbc-dev-storage"
  }

  expect_failures = [var.name]
}

run "managed_identity_rejects_an_over_length_name" {
  command = plan

  module {
    source = "../modules/managed-identity"
  }

  variables {
    name                = "id-xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx"
    location            = "germanywestcentral"
    resource_group_name = "rg"
  }

  expect_failures = [var.name]
}

run "managed_identity_rejects_a_forbidden_character" {
  command = plan

  module {
    source = "../modules/managed-identity"
  }

  variables {
    name                = "id tbc dev"
    location            = "germanywestcentral"
    resource_group_name = "rg"
  }

  expect_failures = [var.name]
}

run "databricks_workspace_rejects_an_over_length_name" {
  command = plan

  module {
    source = "../modules/databricks-workspace"
  }

  variables {
    name                       = "dbw-xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx"
    location                   = "germanywestcentral"
    resource_group_id          = "/subscriptions/00000000-0000-0000-0000-000000000000/resourceGroups/rg"
    resource_group_name        = "rg"
    log_analytics_workspace_id = "/subscriptions/00000000-0000-0000-0000-000000000000/resourceGroups/rg-tbc-management/providers/Microsoft.OperationalInsights/workspaces/dpx-inf-mgt-gwc-la-001"
    private_endpoint = {
      subnet_id            = "/subscriptions/00000000-0000-0000-0000-000000000000/resourceGroups/rg-net/providers/Microsoft.Network/virtualNetworks/vnet/subnets/snet-pe"
      private_dns_zone_ids = { blob = "z", dfs = "z", vault = "z", databricks = "z" }
    }
    managed_resource_group_name = "rg-managed"
    storage_connector_name      = "dbac-tbc-dev-anl-dbm"
    virtual_network_id          = "/subscriptions/00000000-0000-0000-0000-000000000000/resourceGroups/rg-net/providers/Microsoft.Network/virtualNetworks/vnet"
    host_subnet                 = { id = "/subscriptions/00000000-0000-0000-0000-000000000000/resourceGroups/rg-net/providers/Microsoft.Network/virtualNetworks/vnet/subnets/h", name = "h" }
    container_subnet            = { id = "/subscriptions/00000000-0000-0000-0000-000000000000/resourceGroups/rg-net/providers/Microsoft.Network/virtualNetworks/vnet/subnets/c", name = "c" }
  }

  expect_failures = [var.name]
}

run "databricks_workspace_rejects_geo_redundant_replication" {
  command = plan

  module {
    source = "../modules/databricks-workspace"
  }

  variables {
    name                       = "dbw-tbc-dev-anl"
    location                   = "germanywestcentral"
    resource_group_id          = "/subscriptions/00000000-0000-0000-0000-000000000000/resourceGroups/rg"
    resource_group_name        = "rg"
    log_analytics_workspace_id = "/subscriptions/00000000-0000-0000-0000-000000000000/resourceGroups/rg-tbc-management/providers/Microsoft.OperationalInsights/workspaces/dpx-inf-mgt-gwc-la-001"
    private_endpoint = {
      subnet_id            = "/subscriptions/00000000-0000-0000-0000-000000000000/resourceGroups/rg-net/providers/Microsoft.Network/virtualNetworks/vnet/subnets/snet-pe"
      private_dns_zone_ids = { blob = "z", dfs = "z", vault = "z", databricks = "z" }
    }
    managed_resource_group_name = "rg-managed"
    storage_connector_name      = "dbac-tbc-dev-anl-dbm"
    storage_account_sku_name    = "Standard_GRS"
    virtual_network_id          = "/subscriptions/00000000-0000-0000-0000-000000000000/resourceGroups/rg-net/providers/Microsoft.Network/virtualNetworks/vnet"
    host_subnet                 = { id = "/subscriptions/00000000-0000-0000-0000-000000000000/resourceGroups/rg-net/providers/Microsoft.Network/virtualNetworks/vnet/subnets/h", name = "h" }
    container_subnet            = { id = "/subscriptions/00000000-0000-0000-0000-000000000000/resourceGroups/rg-net/providers/Microsoft.Network/virtualNetworks/vnet/subnets/c", name = "c" }
  }

  expect_failures = [var.storage_account_sku_name]
}

run "databricks_workspace_rejects_a_forbidden_character" {
  command = plan

  module {
    source = "../modules/databricks-workspace"
  }

  variables {
    name                       = "dbw.tbc.dev"
    location                   = "germanywestcentral"
    resource_group_id          = "/subscriptions/00000000-0000-0000-0000-000000000000/resourceGroups/rg"
    resource_group_name        = "rg"
    log_analytics_workspace_id = "/subscriptions/00000000-0000-0000-0000-000000000000/resourceGroups/rg-tbc-management/providers/Microsoft.OperationalInsights/workspaces/dpx-inf-mgt-gwc-la-001"
    private_endpoint = {
      subnet_id            = "/subscriptions/00000000-0000-0000-0000-000000000000/resourceGroups/rg-net/providers/Microsoft.Network/virtualNetworks/vnet/subnets/snet-pe"
      private_dns_zone_ids = { blob = "z", dfs = "z", vault = "z", databricks = "z" }
    }
    managed_resource_group_name = "rg-managed"
    storage_connector_name      = "dbac-tbc-dev-anl-dbm"
    virtual_network_id          = "/subscriptions/00000000-0000-0000-0000-000000000000/resourceGroups/rg-net/providers/Microsoft.Network/virtualNetworks/vnet"
    host_subnet                 = { id = "/subscriptions/00000000-0000-0000-0000-000000000000/resourceGroups/rg-net/providers/Microsoft.Network/virtualNetworks/vnet/subnets/h", name = "h" }
    container_subnet            = { id = "/subscriptions/00000000-0000-0000-0000-000000000000/resourceGroups/rg-net/providers/Microsoft.Network/virtualNetworks/vnet/subnets/c", name = "c" }
  }

  expect_failures = [var.name]
}

run "storage_account_rejects_a_bad_container_name" {
  command = plan

  module {
    source = "../modules/storage-account"
  }

  variables {
    name                       = "sttbcdevtrusted"
    location                   = "germanywestcentral"
    log_analytics_workspace_id = "/subscriptions/00000000-0000-0000-0000-000000000000/resourceGroups/rg-tbc-management/providers/Microsoft.OperationalInsights/workspaces/dpx-inf-mgt-gwc-la-001"
    private_endpoint = {
      subnet_id            = "/subscriptions/00000000-0000-0000-0000-000000000000/resourceGroups/rg-net/providers/Microsoft.Network/virtualNetworks/vnet/subnets/snet-pe"
      private_dns_zone_ids = { blob = "z", dfs = "z", vault = "z", databricks = "z" }
    }
    resource_group_id = "/subscriptions/00000000-0000-0000-0000-000000000000/resourceGroups/rg-tbc-dev-storage"
    containers        = { Bad_Container = {} }
  }

  expect_failures = [var.containers]
}

run "databricks_workspace_rejects_a_bad_managed_resource_group_name" {
  command = plan

  module {
    source = "../modules/databricks-workspace"
  }

  variables {
    name                       = "dbw-tbc-dev-anl"
    location                   = "germanywestcentral"
    resource_group_id          = "/subscriptions/00000000-0000-0000-0000-000000000000/resourceGroups/rg"
    resource_group_name        = "rg"
    log_analytics_workspace_id = "/subscriptions/00000000-0000-0000-0000-000000000000/resourceGroups/rg-tbc-management/providers/Microsoft.OperationalInsights/workspaces/dpx-inf-mgt-gwc-la-001"
    private_endpoint = {
      subnet_id            = "/subscriptions/00000000-0000-0000-0000-000000000000/resourceGroups/rg-net/providers/Microsoft.Network/virtualNetworks/vnet/subnets/snet-pe"
      private_dns_zone_ids = { blob = "z", dfs = "z", vault = "z", databricks = "z" }
    }
    managed_resource_group_name = "rg managed."
    storage_connector_name      = "dbac-tbc-dev-anl-dbm"
    virtual_network_id          = "/subscriptions/00000000-0000-0000-0000-000000000000/resourceGroups/rg-net/providers/Microsoft.Network/virtualNetworks/vnet"
    host_subnet                 = { id = "/subscriptions/00000000-0000-0000-0000-000000000000/resourceGroups/rg-net/providers/Microsoft.Network/virtualNetworks/vnet/subnets/h", name = "h" }
    container_subnet            = { id = "/subscriptions/00000000-0000-0000-0000-000000000000/resourceGroups/rg-net/providers/Microsoft.Network/virtualNetworks/vnet/subnets/c", name = "c" }
  }

  expect_failures = [var.managed_resource_group_name]
}

# A data role at account scope would reach every entity's container, so the
# storage wrapper accepts only Storage Blob Delegator there.
run "storage_account_rejects_a_data_role_at_account_scope" {
  command = plan

  module {
    source = "../modules/storage-account"
  }

  variables {
    name                       = "sttbcdevtrusted"
    location                   = "germanywestcentral"
    log_analytics_workspace_id = "/subscriptions/00000000-0000-0000-0000-000000000000/resourceGroups/rg-tbc-management/providers/Microsoft.OperationalInsights/workspaces/dpx-inf-mgt-gwc-la-001"
    private_endpoint = {
      subnet_id            = "/subscriptions/00000000-0000-0000-0000-000000000000/resourceGroups/rg-net/providers/Microsoft.Network/virtualNetworks/vnet/subnets/snet-pe"
      private_dns_zone_ids = { blob = "z", dfs = "z", vault = "z", databricks = "z" }
    }
    resource_group_id = "/subscriptions/00000000-0000-0000-0000-000000000000/resourceGroups/rg-tbc-dev-storage"
    account_role_assignments = {
      grp = { principal_id = "00000000-0000-0000-0000-00000000a001", role = "Storage Blob Data Contributor" }
    }
  }

  expect_failures = [var.account_role_assignments]
}

# Only the two data roles may be assigned on a container, never an owner or a
# delegator role that belongs on the account.
run "storage_account_rejects_an_unknown_container_role" {
  command = plan

  module {
    source = "../modules/storage-account"
  }

  variables {
    name                       = "sttbcdevtrusted"
    location                   = "germanywestcentral"
    log_analytics_workspace_id = "/subscriptions/00000000-0000-0000-0000-000000000000/resourceGroups/rg-tbc-management/providers/Microsoft.OperationalInsights/workspaces/dpx-inf-mgt-gwc-la-001"
    private_endpoint = {
      subnet_id            = "/subscriptions/00000000-0000-0000-0000-000000000000/resourceGroups/rg-net/providers/Microsoft.Network/virtualNetworks/vnet/subnets/snet-pe"
      private_dns_zone_ids = { blob = "z", dfs = "z", vault = "z", databricks = "z" }
    }
    resource_group_id = "/subscriptions/00000000-0000-0000-0000-000000000000/resourceGroups/rg-tbc-dev-storage"
    containers = {
      grp-uc = { role_assignments = { connector = { principal_id = "00000000-0000-0000-0000-00000000a001", role = "Storage Blob Data Owner" } } }
    }
  }

  expect_failures = [var.containers]
}

run "key_vault_rejects_an_unknown_access_model" {
  command = plan

  module {
    source = "../modules/key-vault"
  }

  variables {
    name                       = "kv-tbc-dev-plat"
    access_model               = "both"
    location                   = "germanywestcentral"
    log_analytics_workspace_id = "/subscriptions/00000000-0000-0000-0000-000000000000/resourceGroups/rg-tbc-management/providers/Microsoft.OperationalInsights/workspaces/dpx-inf-mgt-gwc-la-001"
    private_endpoint = {
      subnet_id            = "/subscriptions/00000000-0000-0000-0000-000000000000/resourceGroups/rg-net/providers/Microsoft.Network/virtualNetworks/vnet/subnets/snet-pe"
      private_dns_zone_ids = { blob = "z", dfs = "z", vault = "z", databricks = "z" }
    }
    resource_group_name = "rg"
    tenant_id           = "00000000-0000-0000-0000-000000000000"
  }

  expect_failures = [var.access_model]
}

run "databricks_workspace_rejects_a_bad_storage_connector_name" {
  command = plan

  module {
    source = "../modules/databricks-workspace"
  }

  variables {
    name                       = "dbw-tbc-dev-anl"
    location                   = "germanywestcentral"
    resource_group_id          = "/subscriptions/00000000-0000-0000-0000-000000000000/resourceGroups/rg"
    resource_group_name        = "rg"
    log_analytics_workspace_id = "/subscriptions/00000000-0000-0000-0000-000000000000/resourceGroups/rg-tbc-management/providers/Microsoft.OperationalInsights/workspaces/dpx-inf-mgt-gwc-la-001"
    private_endpoint = {
      subnet_id            = "/subscriptions/00000000-0000-0000-0000-000000000000/resourceGroups/rg-net/providers/Microsoft.Network/virtualNetworks/vnet/subnets/snet-pe"
      private_dns_zone_ids = { blob = "z", dfs = "z", vault = "z", databricks = "z" }
    }
    managed_resource_group_name = "rg-managed"
    storage_connector_name      = "dbac tbc dev anl-"
    virtual_network_id          = "/subscriptions/00000000-0000-0000-0000-000000000000/resourceGroups/rg-net/providers/Microsoft.Network/virtualNetworks/vnet"
    host_subnet                 = { id = "/subscriptions/00000000-0000-0000-0000-000000000000/resourceGroups/rg-net/providers/Microsoft.Network/virtualNetworks/vnet/subnets/h", name = "h" }
    container_subnet            = { id = "/subscriptions/00000000-0000-0000-0000-000000000000/resourceGroups/rg-net/providers/Microsoft.Network/virtualNetworks/vnet/subnets/c", name = "c" }
  }

  expect_failures = [var.storage_connector_name]
}
