"""Generate the override blocks shared by one environment's unit tests."""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from agreed_names import NAMES  # noqa: E402

SUB = "/subscriptions/00000000-0000-0000-0000-000000000000"


def block(target, outputs):
    lines = [f"override_module {{", f"  target          = {target}", "  override_during = plan", "  outputs = {"]
    width = max(len(k) for k in outputs)
    lines += [f'    {k.ljust(width)} = "{v}"' for k, v in outputs.items()]
    lines += ["  }", "}", ""]
    return "\n".join(lines)


def workspace_read_back(target, managed_resource_group_id, storage_account_name):
    """The workspace as Azure reports it, for the wrapper's azapi_resource data source."""
    return "\n".join([
        "override_data {",
        f"  target          = {target}",
        "  override_during = plan",
        "  values = {",
        "    output = {",
        f'      managed_resource_group_id = "{managed_resource_group_id}"',
        f'      storage_account_name      = "{storage_account_name}"',
        "    }",
        "  }",
        "}",
        "",
    ])


def overrides(env, tracks, entities):
    agreed = NAMES[env]
    rgs = {k: f"{SUB}/resourceGroups/{agreed['resource_groups'][k]}" for k in ("storage", "databricks", "ops")}
    out = []
    for key, rid in rgs.items():
        out.append(block(f'module.resource_group["{key}"].module.resource_group',
                         {"resource_id": rid, "name": agreed["resource_groups"][key], "location": "germanywestcentral"}))
    for label, name in (("platform_key_vault", agreed["key_vaults"]["platform"]),
                        ("secret_scope_key_vault", agreed["key_vaults"]["scope"])):
        out.append(block(f"module.{label}.module.key_vault",
                         {"resource_id": f"{rgs['ops']}/providers/Microsoft.KeyVault/vaults/{name}", "name": name,
                          "uri": f"https://{name}.vault.azure.net/"}))
    for label, name in (("trusted_storage", agreed["storage"]["trusted"]),):
        out.append(block(f"module.{label}.module.storage_account",
                         {"resource_id": f"{rgs['storage']}/providers/Microsoft.Storage/storageAccounts/{name}", "name": name}))
    for n, entity in enumerate(entities, start=1):
        # 'zzz' is the fictitious third entity the fan-out test adds: its names are made up.
        connector = agreed["access_connectors"].get(entity, f"dbac-{entity}")
        identity = agreed["identities"].get(entity, f"id-{entity}")
        out.append(block(f'module.access_connector["{entity}"].module.access_connector',
                         {"resource_id": f"{rgs['databricks']}/providers/Microsoft.Databricks/accessConnectors/{connector}",
                          "name": connector,
                          "system_assigned_mi_principal_id": f"00000000-0000-0000-0000-00000000a{n:03d}"}))
        out.append(block(f'module.workload_identity["{entity}"].module.managed_identity',
                         {"resource_id": f"{rgs['databricks']}/providers/Microsoft.ManagedIdentity/userAssignedIdentities/{identity}",
                          "principal_id": f"00000000-0000-0000-0000-00000000b{n:03d}",
                          "client_id": f"00000000-0000-0000-0000-00000000c{n:03d}"}))
    for n, track in enumerate(tracks, start=1):
        wid = f"12345678901234{n}{n}"
        workspace = agreed["workspaces"][track]
        out.append(block(f'module.databricks_workspace["{track}"].module.workspace',
                         {"resource_id": f"{rgs['databricks']}/providers/Microsoft.Databricks/workspaces/{workspace}",
                          "name": workspace, "databricks_workspace_id": wid,
                          "databricks_workspace_url": f"adb-{wid}.{6 + n}.azuredatabricks.net"}))
        connector = agreed["storage_connectors"][track]
        out.append(block(f'module.databricks_workspace["{track}"].module.storage_access_connector',
                         {"resource_id": f"{rgs['databricks']}/providers/Microsoft.Databricks/accessConnectors/{connector}",
                          "name": connector,
                          "system_assigned_mi_principal_id": f"00000000-0000-0000-0000-00000000d{n:03d}"}))
        # Azure names the workspace storage account at random: a made-up name stands in.
        out.append(workspace_read_back(f'module.databricks_workspace["{track}"].data.azapi_resource.workspace',
                                       f"{SUB}/resourceGroups/{agreed['managed_resource_groups'][track]}",
                                       f"dbstorage{track}{env}fixture"))
        # The account's blob and dfs private endpoints, from the private endpoint module.
        for sub in ("blob", "dfs"):
            name = f"pe-{workspace}-dbstorage-{sub}"
            out.append(block(f'module.databricks_workspace["{track}"].module.workspace_storage_private_endpoint["{sub}"]',
                             {"resource_id": f"{rgs['databricks']}/providers/Microsoft.Network/privateEndpoints/{name}",
                              "name": name}))
    return "\n".join(out)


if __name__ == "__main__":
    env, tracks = sys.argv[1], sys.argv[2].split(",")
    # grp and duk, plus 'zzz', the fictitious third entity the fan-out test adds;
    # an optional third argument lists the entities instead.
    entities = sys.argv[3].split(",") if len(sys.argv) > 3 else ["grp", "duk", "zzz"]
    print(overrides(env, tracks, entities))
