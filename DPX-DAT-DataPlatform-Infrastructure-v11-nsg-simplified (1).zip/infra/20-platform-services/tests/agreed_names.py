"""The names Calandra agreed for the platform-services state, one set per environment.

The storage_connectors are the connectors Azure Databricks uses to reach
each workspace's own storage account ('dbm', Databricks-managed storage), one
per workspace. The trusted storage account name, and the untrusted name reserved while that account is
parked, are the agreed ones with the 'gdp' segment removed: the agreed names are 26 characters and a storage account
name is at most 24. Everything else is as agreed.

Used by gen_overrides.py and by scripts/tests/test_agreed_names.py, which checks
that each environment's var file carries exactly these names.
"""

NAMES = {'dev': {'resource_groups': {'storage': 'dpx-dat-sto-dev-int-gwc-rg-001',
                             'ops': 'dpx-dat-ops-dev-int-gwc-rg-002',
                             'databricks': 'dpx-dat-dbx-dev-int-gwc-rg-003'},
         'managed_resource_groups': {'anl': 'dpx-dat-anl-dev-int-gwc-rg-004',
                                     'ops': 'dpx-dat-ops-dev-int-gwc-rg-005'},
         'key_vaults': {'platform': 'dpxdatgdpdevintgwckv001', 'scope': 'dpxdatdbxdevintgwckv002'},
         'storage': {'trusted': 'dpxdattrsdevintgwcst001'},
         # UNTRUSTED STORAGE PARKED (2026-10-14): reserved name 'untrusted': 'dpxdatuntdevintgwcst002'
         'access_connectors': {'grp': 'dpx-dat-grp-trs-dev-int-gwc-dbac-001',
                               'duk': 'dpx-dat-duk-trs-dev-int-gwc-dbac-002'},
         'workspaces': {'anl': 'dpx-dat-anl-dev-int-gwc-dbw-001', 'ops': 'dpx-dat-ops-dev-int-gwc-dbw-002'},
         'storage_connectors': {'anl': 'dpx-dat-anl-dbm-dev-int-gwc-dbac-003', 'ops': 'dpx-dat-ops-dbm-dev-int-gwc-dbac-004'},
         'identities': {'grp': 'dpx-dat-dbx-grp-dev-gwc-uai-001', 'duk': 'dpx-dat-dbx-duk-dev-gwc-uai-002'}},
 'tst': {'resource_groups': {'storage': 'dpx-dat-sto-tst-int-gwc-rg-001',
                             'ops': 'dpx-dat-ops-tst-int-gwc-rg-002',
                             'databricks': 'dpx-dat-dbx-tst-int-gwc-rg-003'},
         'managed_resource_groups': {'anl': 'dpx-dat-anl-tst-int-gwc-rg-004',
                                     'ops': 'dpx-dat-ops-tst-int-gwc-rg-005'},
         'key_vaults': {'platform': 'dpxdatgdptstintgwckv001', 'scope': 'dpxdatdbxtstintgwckv002'},
         'storage': {'trusted': 'dpxdattrststintgwcst001'},
         # UNTRUSTED STORAGE PARKED (2026-10-14): reserved name 'untrusted': 'dpxdatunttstintgwcst002'
         'access_connectors': {'grp': 'dpx-dat-grp-trs-tst-int-gwc-dbac-001',
                               'duk': 'dpx-dat-duk-trs-tst-int-gwc-dbac-002'},
         'workspaces': {'anl': 'dpx-dat-anl-tst-int-gwc-dbw-001', 'ops': 'dpx-dat-ops-tst-int-gwc-dbw-002'},
         'storage_connectors': {'anl': 'dpx-dat-anl-dbm-tst-int-gwc-dbac-003', 'ops': 'dpx-dat-ops-dbm-tst-int-gwc-dbac-004'},
         'identities': {'grp': 'dpx-dat-dbx-grp-tst-gwc-uai-001', 'duk': 'dpx-dat-dbx-duk-tst-gwc-uai-002'}},
 'stg': {'resource_groups': {'storage': 'dpx-dat-sto-stg-int-gwc-rg-001',
                             'ops': 'dpx-dat-ops-stg-int-gwc-rg-002',
                             'databricks': 'dpx-dat-dbx-stg-int-gwc-rg-003'},
         'managed_resource_groups': {'anl': 'dpx-dat-anl-stg-int-gwc-rg-004',
                                     'ops': 'dpx-dat-ops-stg-int-gwc-rg-005'},
         'key_vaults': {'platform': 'dpxdatgdpstgintgwckv001', 'scope': 'dpxdatdbxstgintgwckv002'},
         'storage': {'trusted': 'dpxdattrsstgintgwcst001'},
         # UNTRUSTED STORAGE PARKED (2026-10-14): reserved name 'untrusted': 'dpxdatuntstgintgwcst002'
         'access_connectors': {'grp': 'dpx-dat-grp-trs-stg-int-gwc-dbac-001',
                               'duk': 'dpx-dat-duk-trs-stg-int-gwc-dbac-002'},
         'workspaces': {'anl': 'dpx-dat-anl-stg-int-gwc-dbw-001', 'ops': 'dpx-dat-ops-stg-int-gwc-dbw-002'},
         'storage_connectors': {'anl': 'dpx-dat-anl-dbm-stg-int-gwc-dbac-003', 'ops': 'dpx-dat-ops-dbm-stg-int-gwc-dbac-004'},
         'identities': {'grp': 'dpx-dat-dbx-grp-stg-gwc-uai-001', 'duk': 'dpx-dat-dbx-duk-stg-gwc-uai-002'}},
 'prd': {'resource_groups': {'storage': 'dpx-dat-sto-prd-int-gwc-rg-001',
                             'ops': 'dpx-dat-ops-prd-int-gwc-rg-002',
                             'databricks': 'dpx-dat-dbx-prd-int-gwc-rg-003'},
         'managed_resource_groups': {'anl': 'dpx-dat-anl-prd-int-gwc-rg-004',
                                     'ops': 'dpx-dat-ops-prd-int-gwc-rg-005'},
         'key_vaults': {'platform': 'dpxdatgdpprdintgwckv001', 'scope': 'dpxdatdbxprdintgwckv002'},
         'storage': {'trusted': 'dpxdattrsprdintgwcst001'},
         # UNTRUSTED STORAGE PARKED (2026-10-14): reserved name 'untrusted': 'dpxdatuntprdintgwcst002'
         'access_connectors': {'grp': 'dpx-dat-grp-trs-prd-int-gwc-dbac-001',
                               'duk': 'dpx-dat-duk-trs-prd-int-gwc-dbac-002'},
         'workspaces': {'anl': 'dpx-dat-anl-prd-int-gwc-dbw-001', 'ops': 'dpx-dat-ops-prd-int-gwc-dbw-002'},
         'storage_connectors': {'anl': 'dpx-dat-anl-dbm-prd-int-gwc-dbac-003', 'ops': 'dpx-dat-ops-dbm-prd-int-gwc-dbac-004'},
         'identities': {'grp': 'dpx-dat-dbx-grp-prd-gwc-uai-001', 'duk': 'dpx-dat-dbx-duk-prd-gwc-uai-002'}}}
