# Outputs published for the Databricks root, named after the
# variables of the reference platform they feed, so that the resolve step is a
# copy rather than a mapping. See config/upstream-contract.yaml.

output "access_connectors" {
  description = "Each entity's Access Connector: its resource ID and its identity's principal ID. Feeds the Databricks root's per-entity storage credentials."
  value = {
    for entity, connector in module.access_connector :
    entity => {
      id           = connector.resource_id
      principal_id = connector.principal_id
    }
  }
}

output "environment" {
  description = "The environment that published these outputs. The resolve step refuses outputs from another environment's state."
  value       = var.environment
}

output "key_vault_name" {
  description = "Name of the Databricks secret scope's Key Vault: the access-policy vault, not the platform's."
  value       = module.secret_scope_key_vault.name
}

output "resource_group_name" {
  description = "Name of the resource group holding the secret scope's Key Vault, from which the Databricks root builds the vault's resource ID."
  value       = module.resource_group["ops"].name
}

output "storage_account_name" {
  description = "Name of the trusted storage account, which holds each entity's landing and export containers."
  value       = module.trusted_storage.name
}

output "subscription_id" {
  description = "The subscription this environment deployed into, from which the Databricks root builds the secret scope vault's resource ID. Both of the environment's workspaces share it."
  value       = var.subscription_id
}

output "trusted_containers" {
  description = "The trusted container names for each entity, so that the Databricks root's storage paths can be tested against them."
  value       = local.trusted_containers
}

output "trusted_storage_account_id" {
  description = "Resource ID of the trusted storage account, for the NCC private endpoint rules this environment's analytical Databricks state adds."
  value       = module.trusted_storage.resource_id
}

output "unity_catalog_storage" {
  description = "Name of the trusted storage account, which holds each entity's Unity Catalog managed storage container."
  value       = module.trusted_storage.name
}

# UNTRUSTED STORAGE PARKED (2026-10-14): see the note in main.tf.
# output "untrusted_storage_account_name" {
#   description = "Name of the untrusted storage account. Not read by Databricks; for the copy process that arrives with the first use case."
#   value       = module.untrusted_storage.name
# }

output "workload_identity_principal_ids" {
  description = "Principal ID of each workload identity, for the Calandra team to add to the tier's sp-databricks group."
  value       = { for key, identity in module.workload_identity : key => identity.principal_id }
}

output "workspaces" {
  description = "Each workspace, by track (anl, ops): its numeric workspace ID, the region number in its URL, its name and URL. The Databricks state for that track reads its own entry."
  value = {
    for key, workspace in module.databricks_workspace :
    key => {
      workspace_id            = workspace.workspace_id
      workspace_name          = workspace.name
      workspace_region_number = workspace.workspace_region_number
      workspace_url           = workspace.workspace_url
    }
  }
}
