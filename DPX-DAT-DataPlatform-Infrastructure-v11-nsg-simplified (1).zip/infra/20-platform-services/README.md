# infra/20-platform-services

The Azure side of one environment: the resource groups, Key Vaults, storage accounts, Access
Connectors, workload identities and Databricks workspaces that the Databricks root then
configures. It creates Azure resources only; nothing inside Databricks.

**Owner:** Cynozure build it; Hexaware run its pipeline.
**State instances:** `dev`, `tst`, `stg` and `prd`, one per environment and per subscription.
dev, tst and stg apply from the `development` branch; prd from `production`.

## What it builds

Everything is private. No resource here has a public endpoint: each is reached through a private
endpoint registered in the central private DNS zones. The storage accounts' and Key Vaults'
endpoints sit in the network root's shared endpoint subnet; each workspace's sit in that
workspace's own endpoint subnet.

| Resource group | What it holds |
|---|---|
| `storage` | The `trusted` ADLS Gen2 storage account and its containers |
| `databricks` | The Databricks workspaces, one Access Connector per entity and one per workspace for its own storage, the workload identities, and the workspace storage accounts' private endpoints |
| `ops` | The platform Key Vault (Azure RBAC) and the Databricks secret scope's Key Vault (access policies) |

In more detail:

- **`trusted` storage** holds the data Databricks reads and writes. Each entity gets three
  containers, `{entity}-uc` for its Unity Catalog managed storage, `{entity}-landing` and
  `{entity}-export`. One set serves both workspaces, because each environment's catalogue is
  bound to both.
  Hierarchical namespace, infrastructure encryption with Microsoft-managed keys, no shared keys,
  no public access, no SFTP, TLS 1.2; the wrapper fixes all of that, and no var file can loosen it.
- **`untrusted` storage is parked** (2026-10-14). It was to be where third parties land data before
  something outside Databricks copies it into the trusted landing container. Security want it in a
  separate subscription with its own rules, and that subscription is not built yet, so this root
  creates no untrusted account. The code is commented out under an `UNTRUSTED STORAGE PARKED` note
  in `main.tf`, `locals.tf`, `variables.tf`, `outputs.tf`, the four var files and the tests. To
  restore it, delete the note and the blank line after it, strip one leading `# ` from each parked
  line, run `terraform fmt`, widen the narrowed test lines back to both accounts, along with
  `tests/gen_overrides.py`, `tests/agreed_names.py`, the `entities` description and the `main.tf`
  header (the parking commit, found with `git log --grep "Park the untrusted"`, shows every line),
  add `untrusted_storage_account_name` back to the four Databricks fixtures, and retire
  `scripts/tests/test_untrusted_storage_parked.py`. It may be better restored as its own root in the
  new subscription.
- **One Access Connector per entity.** The `trusted` account's wrapper assigns its identity
  *Storage Blob Data Contributor* on that entity's own containers only, and *Storage Blob
  Delegator* on the account, which Unity Catalog needs to issue user delegation keys and which
  carries no data access
  ([Use Azure managed identities in Unity Catalog to access storage](https://learn.microsoft.com/en-us/azure/databricks/connect/unity-catalog/cloud-storage/azure-managed-identities),
  checked 30 September 2026). The wrapper accepts data roles at container scope only, and only
  Delegator on the account, so no single identity can reach every entity's data.
- **Two Key Vaults.** The platform's, in Azure RBAC mode, and a second one for the Databricks
  secret scope, in the access-policy model, because Key Vault-backed secret scopes support only
  that model ([Secret management](https://learn.microsoft.com/en-us/azure/databricks/security/secrets/),
  checked 30 September 2026). The second vault grants the AzureDatabricks application Get and List.
  Public network access is disabled on both. Azure Databricks reads the second vault through the
  trusted Microsoft services bypass, which still applies with public access disabled. Purge
  protection is on for both.
- **Workload identities:** user-assigned managed identities, one per entity, for the bundles to run
  as. They get their Databricks rights through the tier's `sp-databricks` Entra group, which the
  Calandra team add them to, so nothing here assigns them a role.
- **Databricks workspaces:** `anl` and `ops` in every environment. Premium, VNet-injected into
  their own host and container subnets with secure cluster connectivity, public network access
  off, and one `databricks_ui_api` private endpoint each, in the workspace's own endpoint subnet. Azure creates the managed
  resource group; the var file only names it.
- **The workspace storage firewall.** Azure also creates, in each managed resource group, the
  workspace's own storage account, for the DBFS root, job output and system data. By default it
  accepts authenticated connections from any network. Here its firewall is on
  ([Enable firewall support for your workspace storage account](https://learn.microsoft.com/en-us/azure/databricks/security/network/storage/firewall-support),
  checked 30 September 2026): Azure Databricks reaches it through an Access Connector of the
  workspace's own (`dpx-dat-anl-dbm-<env>-int-gwc-dbac-003`, and `-ops-…-004` for the
  operational workspace), the VNet through a `blob` and a `dfs` private endpoint, and serverless
  compute through the network security perimeter Azure Databricks attaches. Microsoft does not
  allow the endpoints in the managed resource group, so they sit in `databricks`. Azure names the
  account at random, so the wrapper reads it back from the workspace. No Unity Catalog data lives
  there: every catalogue's storage is in `trusted`.
- **Diagnostic settings** on every vault, storage account and workspace, sending to the Landing
  Zone's central Log Analytics workspace. This root creates no Log Analytics workspace.
- **Delete locks** on the storage accounts and Key Vaults, in production only to start.

Replication is locally redundant outside production and zone-redundant in production, for both
storage accounts and each workspace's own storage account. The wrappers accept nothing else.

## How it is built

`main.tf` reads as a list of the services above. Each is a call to one wrapper module in
`../modules/`, and each wrapper wraps one [Azure Verified Module](https://azure.github.io/Azure-Verified-Modules/)
pinned to an exact version. The wrappers exist to fix the security settings in one place and to
output them, so the tests can assert them; this root supplies the environment's values and wires
the services together. Names come from the var files, which hold the names the Calandra team
agreed. There is no naming module.

Provider pins are `azurerm ~> 4.81` and `azapi ~> 2.12`. The Verified Modules for the workspace
and the managed identity still constrain azurerm below 5.0, so this root stays on 4.x until they
move. Containers are the storage module's own, created through Resource Manager, which private
networking does not block, unlike the storage data plane. A module block cannot carry
`prevent_destroy`, so the containers rely on soft delete and, in production, on the account's
`CanNotDelete` lock.

## Azure Verified Modules

Every Azure resource this root creates comes from an
[Azure Verified Module](https://azure.github.io/Azure-Verified-Modules/), pinned to an exact
version, with one documented exception. `scripts/check_avm_conformance.py` enforces it in
`make checks` and pre-commit: a plain `azurerm` or `azapi` resource anywhere under `infra/` fails
unless it is on the script's allowlist with a reason.

| Azure resource | Wrapper | Verified Module | Version |
| --- | --- | --- | --- |
| Resource group, and any role assignment on it | `resource-group` | `avm-res-resources-resourcegroup` | 0.4.0 |
| Key Vault, its private endpoint, diagnostic setting, lock and access policies | `key-vault` | `avm-res-keyvault-vault` | 0.11.0 |
| Storage account, its containers, their role assignments, the account's role assignments, its two private endpoints, diagnostic settings and lock | `storage-account` | `avm-res-storage-storageaccount` | 0.10.0 |
| Access Connector (one per entity, and one per workspace for its storage firewall) | `access-connector`, `databricks-workspace` | `avm-res-databricks-accessconnector` | 0.1.0 |
| User-assigned managed identity | `managed-identity` | `avm-res-managedidentity-userassignedidentity` | 0.5.2 |
| Databricks workspace, its `databricks_ui_api` private endpoint and diagnostic setting | `databricks-workspace` | `avm-res-databricks-workspace` | 0.5.0 |
| The workspace storage account's `blob` and `dfs` private endpoints | `databricks-workspace` | `avm-res-network-privateendpoint` | 0.2.0 |

What no Verified Module can express, and stays as it is:

| Block | Why |
| --- | --- |
| `azurerm_private_endpoint.workspace_storage_unmanaged_dns` in the workspace wrapper | Used only when Landing Zone policy creates the private endpoints' DNS zone groups (`manage_dns_zone_group = false`). The private endpoint module has no way to ignore a zone group it did not create, so it would plan the policy's removal on every run. This is the one allowlisted resource. |
| `data.azapi_resource.workspace` in the workspace wrapper | A data source, not a resource: it reads back the name Azure gives the workspace storage account, which the workspace module does not output. |
| `terraform_data.resource_group_ready` in the workspace wrapper | Not an Azure resource. It holds the workspace module's resource group lookup until the group exists on a first plan. |

The Databricks root (`../../databricks`) creates no Azure resource at all: it uses the Databricks
provider only, for Unity Catalog and workspace objects, which Azure Verified Modules do not
cover. The same check fails on any `azurerm` or `azapi` resource there.

## Inputs

Every input comes from one of three places, as `../../config/upstream-contract.yaml` sets out:

- **Upstream** (`network`, `entities`): written by `scripts/resolve_upstream.py` into
  `upstream.tfvars.json` from the network root's published outputs, read through
  `../../config/landing-zone-outputs.yaml`, and `config/entities.yaml`, and passed as the last
  `-var-file`. The resolve step refuses outputs published by another environment. Never set in a
  var file we maintain.
- **Identifiers** (`subscription_id`, `tenant_id`, the object IDs): `TF_VAR_*` from the pipeline's
  variable groups. Never tracked. Each environment has its own subscription, so `subscription_id`
  comes from the environment's group; the rest come from the tier's.
- **Our configuration**: `environments/<env>.tfvars`, tracked. Names, SKUs, tags and the
  production lock switch.

`scripts/check_var_files.py` rejects an upstream or identifier variable, or any GUID, in a var
file. The `network` variable's validation rejects a private endpoint subnet outside the workspace
VNet, and any network resource outside this environment's subscription except the DNS zones and
the Log Analytics workspace.

## Outputs

The Databricks root reads this root's outputs, through the same resolve step. They include each
workspace's ID, region number, name and URL; the secret scope vault's name and resource group; the
trusted storage account's name and resource ID (for the NCC private endpoint rules); each entity's
Access Connector ID and principal ID; and the environment name, which the resolve step checks so
that one environment's outputs can never feed another's Databricks state. The workload identities'
principal IDs are output for the Calandra team to add to the `sp-databricks` group.

## Testing

```bash
make test   # from the directory above infra/
```

Plan-mode unit tests ([Terraform tests](https://developer.hashicorp.com/terraform/language/tests),
with [mocked providers](https://developer.hashicorp.com/terraform/language/tests/mocking)) run for
each of the four environments in `tests/<env>/`, with that environment's tracked var file and the
fixtures in `tests/fixtures/`. Every Verified Module is stubbed with `override_module`, so the
tests check what this root passes in and what the wrappers fix, not what Azure would do.
`tests/dev/names_unit_test.tftest.hcl` calls each wrapper directly to prove its name validation,
and `tests/agreed_names.py` holds the Calandra names once so a var file that drifts from them
fails. `tests/gen_overrides.py` generates the override blocks. `make plan` runs the same
instances without the stubs and prints every resource the modules would create.

## Secrets in state

None. This root creates no secrets, and no resource here writes one into state.

<!-- BEGIN_TF_DOCS -->
## Requirements

| Name | Version |
| ---- | ------- |
| terraform | ~> 1.16 |
| azapi | ~> 2.12 |
| azurerm | ~> 4.81 |

## Modules

| Name | Source | Version |
| ---- | ------ | ------- |
| access\_connector | ../modules/access-connector | n/a |
| databricks\_workspace | ../modules/databricks-workspace | n/a |
| platform\_key\_vault | ../modules/key-vault | n/a |
| resource\_group | ../modules/resource-group | n/a |
| secret\_scope\_key\_vault | ../modules/key-vault | n/a |
| trusted\_storage | ../modules/storage-account | n/a |
| workload\_identity | ../modules/managed-identity | n/a |

## Inputs

| Name | Description | Type | Default | Required |
| ---- | ----------- | ---- | ------- | :------: |
| access\_connector\_names | Absolute name of each entity's Access Connector, by entity key. The keys must be exactly the entity keys. | `map(string)` | n/a | yes |
| azure\_databricks\_service\_principal\_object\_id | Identifier. Object ID of the tenant's AzureDatabricks enterprise application, which the secret scope's vault grants Get and List. From the tier's variable group. | `string` | n/a | yes |
| common\_tags | Tags for every resource. Project, Environment, WorkspaceType and ManagedBy are mandatory; Environment must match var.environment. Shared resources carry this WorkspaceType; each workspace carries its own. | `map(string)` | n/a | yes |
| entities | Upstream, from config/entities.yaml. The entities on the platform, by key. Each yields its trusted containers and an Access Connector. | <pre>map(object({<br/>    display_name = string<br/>  }))</pre> | n/a | yes |
| environment | The environment this state instance builds: dev, tst, stg or prd. | `string` | n/a | yes |
| location | Azure region for every resource. Germany West Central is the only region. | `string` | n/a | yes |
| network | Upstream: the network and security state's outputs for this environment<br/>(infra/10-landing-zone), written into upstream.tfvars.json by<br/>scripts/resolve\_upstream.py. Never set in a var file we maintain.<br/>- virtual\_network\_id: the VNet the workspaces are injected into.<br/>- databricks\_subnets: one host subnet, one container subnet and one private<br/>  endpoint subnet per workspace key, each subnet with its resource ID (and,<br/>  for host and container, its name). The workspace's own endpoints go in its<br/>  private endpoint subnet. Host and container are force-new on the workspace.<br/>- private\_endpoint\_subnet\_id: where the shared resources' endpoints go (both<br/>  storage accounts, both Key Vaults). Expected to be the analytical<br/>  workload's endpoint subnet. It must be in virtual\_network\_id's VNet.<br/>- private\_dns\_zone\_ids: the central zones, keyed databricks, blob, dfs and vault.<br/>- log\_analytics\_workspace\_id: the Landing Zone's central Log Analytics workspace, which<br/>  receives every diagnostic setting. The same in every environment.<br/>All but the DNS zones and the Log Analytics workspace must be in this environment's subscription. | <pre>object({<br/>    virtual_network_id = string<br/>    databricks_subnets = map(object({<br/>      host = object({<br/>        id   = string<br/>        name = string<br/>      })<br/>      container = object({<br/>        id   = string<br/>        name = string<br/>      })<br/>      private_endpoint_subnet_id = optional(string)<br/>    }))<br/>    private_endpoint_subnet_id = string<br/>    log_analytics_workspace_id = string<br/>    private_dns_zone_ids       = map(string)<br/>  })</pre> | n/a | yes |
| platform\_key\_vault | The platform's Key Vault, in Azure RBAC mode: its name and SKU. | <pre>object({<br/>    name     = string<br/>    sku_name = optional(string, "standard")<br/>  })</pre> | n/a | yes |
| resource\_group\_names | Names of the three resource groups, grouped by resource type: the names the Calandra team agreed. | <pre>object({<br/>    storage    = string<br/>    databricks = string<br/>    ops        = string<br/>  })</pre> | n/a | yes |
| secret\_scope\_key\_vault | The Databricks secret scope's Key Vault, in the access-policy model: its name and SKU. | <pre>object({<br/>    name     = string<br/>    sku_name = optional(string, "standard")<br/>  })</pre> | n/a | yes |
| subscription\_id | Identifier. The subscription this environment deploys into: each environment has its own, and each environment's holds both of its workspaces. From the environment's variable group. | `string` | n/a | yes |
| tenant\_id | Identifier. The Entra tenant. From the tier's variable group. | `string` | n/a | yes |
| trusted\_storage | The trusted ADLS Gen2 account, which holds Unity Catalog managed storage and trusted data: its name and SKU, Standard\_LRS or Standard\_ZRS (LRS outside production, ZRS in production). | <pre>object({<br/>    name     = string<br/>    sku_name = optional(string, "Standard_ZRS")<br/>  })</pre> | n/a | yes |
| workspaces | The two Databricks workspaces in this environment, by track: 'anl' (analytical) and 'ops' (operational), both required. storage\_account\_sku\_name is the SKU of the workspace's own storage account, Standard\_LRS or Standard\_ZRS (LRS outside production, ZRS in production). storage\_connector\_name names the Access Connector Azure Databricks uses to reach that account once its firewall is on. | <pre>map(object({<br/>    name                        = string<br/>    managed_resource_group_name = string<br/>    storage_connector_name      = string<br/>    storage_account_sku_name    = optional(string, "Standard_ZRS")<br/>  }))</pre> | n/a | yes |
| enable\_telemetry | Whether the Azure Verified Modules send usage telemetry to Microsoft. Off unless the client chooses otherwise. | `bool` | `false` | no |
| lock\_enabled | Whether the storage accounts and Key Vaults carry CanNotDelete locks. True in production only, to start. | `bool` | `false` | no |
| platform\_admin\_group\_object\_id | Identifier. Object ID of the platform admin Entra group. Needed only if platform\_admin\_role\_assignments is not empty. From the tier's variable group. | `string` | `null` | no |
| platform\_admin\_role\_assignments | Azure roles for the platform admin group, by an arbitrary key: each a role name and the resource group key (storage, databricks or ops) it is scoped to. Empty unless Calandra's privileged-access process does not cover them. | <pre>map(object({<br/>    role_definition_name = string<br/>    resource_group       = string<br/>  }))</pre> | `{}` | no |
| workload\_identities | User-assigned managed identities for Databricks workloads, by key, with their names. Each reaches Databricks through its tier's sp-databricks group. | <pre>map(object({<br/>    name = string<br/>  }))</pre> | `{}` | no |

## Outputs

| Name | Description |
| ---- | ----------- |
| access\_connectors | Each entity's Access Connector: its resource ID and its identity's principal ID. Feeds the Databricks root's per-entity storage credentials. |
| environment | The environment that published these outputs. The resolve step refuses outputs from another environment's state. |
| key\_vault\_name | Name of the Databricks secret scope's Key Vault: the access-policy vault, not the platform's. |
| resource\_group\_name | Name of the resource group holding the secret scope's Key Vault, from which the Databricks root builds the vault's resource ID. |
| storage\_account\_name | Name of the trusted storage account, which holds each entity's landing and export containers. |
| subscription\_id | The subscription this environment deployed into, from which the Databricks root builds the secret scope vault's resource ID. Both of the environment's workspaces share it. |
| trusted\_containers | The trusted container names for each entity, so that the Databricks root's storage paths can be tested against them. |
| trusted\_storage\_account\_id | Resource ID of the trusted storage account, for the NCC private endpoint rules this environment's analytical Databricks state adds. |
| unity\_catalog\_storage | Name of the trusted storage account, which holds each entity's Unity Catalog managed storage container. |
| workload\_identity\_principal\_ids | Principal ID of each workload identity, for the Calandra team to add to the tier's sp-databricks group. |
| workspaces | Each workspace, by track (anl, ops): its numeric workspace ID, the region number in its URL, its name and URL. The Databricks state for that track reads its own entry. |
<!-- END_TF_DOCS -->
