terraform {
  required_version = "~> 1.16"

  required_providers {
    azapi = {
      source  = "Azure/azapi"
      version = "~> 2.12"
    }
    azurerm = {
      source  = "hashicorp/azurerm"
      version = "~> 4.81"
    }
  }

  # Partial configuration: each state instance's settings are in a
  # environments/<env>.tfbackend file, never tracked, made from its template.
  backend "azurerm" {}
}
