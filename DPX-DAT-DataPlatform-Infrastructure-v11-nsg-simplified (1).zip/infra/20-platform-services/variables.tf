# Inputs come from three places (config/upstream-contract.yaml):
#
#   upstream     network and entities, written by scripts/resolve_upstream.py
#                into upstream.tfvars.json. Never set in a var file we maintain.
#   identifiers  subscription_id, tenant_id and the object IDs, set as TF_VAR_*
#                from the pipeline's variable groups: the subscription from the
#                environment's, the rest from the tier's. Never tracked.
#   our configuration
#                everything else, in environments/<env>.tfvars.
#
# Required variables come first, then optional ones, each group alphabetical.

# Hexaware's draft of the network variable, commented out: it duplicates the
# declaration further down, which carries the full set of validations.
# variable "network" {
#   description = <<-EOT
#     Upstream: the network and security state's outputs for this environment
#     (infra/10-landing-zone), written into upstream.tfvars.json by
#     scripts/resolve_upstream.py. Never set in a var file we maintain.
#   EOT
#   type = object({
#     virtual_network_id = string
#     databricks_subnets = map(object({
#       host = object({
#         id   = string
#         name = string
#       })
#       container = object({
#         id   = string
#         name = string
#       })
#     }))
#     private_endpoint_subnet_id = string
#     log_analytics_workspace_id = string
#     private_dns_zone_ids       = map(string)
#   })
#   nullable = false
#
#   validation {
#     condition     = can(regex("(?i)^/subscriptions/[^/]+/resourceGroups/[^/]+/providers/Microsoft\\.Network/virtualNetworks/[^/]+$", var.network.virtual_network_id))
#     error_message = "virtual_network_id must be a virtual network resource ID."
#   }
#
#   validation {
#     condition     = can(regex("(?i)^/subscriptions/[^/]+/resourceGroups/[^/]+/providers/Microsoft\\.Network/virtualNetworks/[^/]+/subnets/[^/]+$", var.network.private_endpoint_subnet_id))
#     error_message = "private_endpoint_subnet_id must be a subnet resource ID."
#   }
#
#   validation {
#     condition     = alltrue([for key in ["databricks", "blob", "dfs", "vault"] : contains(keys(var.network.private_dns_zone_ids), key)])
#     error_message = "private_dns_zone_ids must include databricks, blob, dfs and vault."
#   }
#
#   # Azure requires the private endpoint to be in the same subscription as the VNet
#   validation {
#     condition = lower(try(split("/", var.network.private_endpoint_subnet_id)[2], "")) == lower(var.subscription_id)
#     error_message = "The private endpoint subnet must be in this environment's subscription."
#   }
# }

variable "access_connector_names" {
  description = "Absolute name of each entity's Access Connector, by entity key. The keys must be exactly the entity keys."
  type        = map(string)
  nullable    = false

  validation {
    condition     = toset(keys(var.access_connector_names)) == toset(keys(var.entities))
    error_message = "access_connector_names needs exactly one name for each entity: no entity without a name, and no name for an unknown entity."
  }
}

variable "azure_databricks_service_principal_object_id" {
  description = "Identifier. Object ID of the tenant's AzureDatabricks enterprise application, which the secret scope's vault grants Get and List. From the tier's variable group."
  type        = string
  nullable    = false

  validation {
    condition     = can(regex("^[0-9a-f]{8}-([0-9a-f]{4}-){3}[0-9a-f]{12}$", var.azure_databricks_service_principal_object_id))
    error_message = "azure_databricks_service_principal_object_id must be a lower-case GUID."
  }
}

variable "common_tags" {
  description = "Tags for every resource. Project, Environment, WorkspaceType and ManagedBy are mandatory; Environment must match var.environment. Shared resources carry this WorkspaceType; each workspace carries its own."
  type        = map(string)
  nullable    = false

  validation {
    condition     = alltrue([for key in ["Project", "Environment", "WorkspaceType", "ManagedBy"] : contains(keys(var.common_tags), key)])
    error_message = "common_tags must include Project, Environment, WorkspaceType and ManagedBy."
  }

  validation {
    condition     = lookup(var.common_tags, "Environment", "") == var.environment
    error_message = "The Environment tag must equal var.environment."
  }
}

variable "entities" {
  description = "Upstream, from config/entities.yaml. The entities on the platform, by key. Each yields its trusted containers and an Access Connector."
  type = map(object({
    display_name = string
  }))
  nullable = false

  validation {
    condition     = length(var.entities) > 0 && alltrue([for key in keys(var.entities) : can(regex("^[a-z][a-z0-9]{1,9}$", key))])
    error_message = "Entity keys are 2 to 10 lower-case letters and digits, starting with a letter; there must be at least one."
  }
}

variable "environment" {
  description = "The environment this state instance builds: dev, tst, stg or prd."
  type        = string
  nullable    = false

  validation {
    condition     = contains(["dev", "tst", "stg", "prd"], var.environment)
    error_message = "environment must be dev, tst, stg or prd."
  }
}

variable "location" {
  description = "Azure region for every resource. Germany West Central is the only region."
  type        = string
  nullable    = false
}

variable "network" {
  description = <<-EOT
    Upstream: the network and security state's outputs for this environment
    (infra/10-landing-zone), written into upstream.tfvars.json by
    scripts/resolve_upstream.py. Never set in a var file we maintain.
    - virtual_network_id: the VNet the workspaces are injected into.
    - databricks_subnets: one host subnet, one container subnet and one private
      endpoint subnet per workspace key, each subnet with its resource ID (and,
      for host and container, its name). The workspace's own endpoints go in its
      private endpoint subnet. Host and container are force-new on the workspace.
    - private_endpoint_subnet_id: where the shared resources' endpoints go (both
      storage accounts, both Key Vaults). Expected to be the analytical
      workload's endpoint subnet. It must be in virtual_network_id's VNet.
    - private_dns_zone_ids: the central zones, keyed databricks, blob, dfs and vault.
    - log_analytics_workspace_id: the Landing Zone's central Log Analytics workspace, which
      receives every diagnostic setting. The same in every environment.
    All but the DNS zones and the Log Analytics workspace must be in this environment's subscription.
  EOT
  type = object({
    virtual_network_id = string
    databricks_subnets = map(object({
      host = object({
        id   = string
        name = string
      })
      container = object({
        id   = string
        name = string
      })
      private_endpoint_subnet_id = optional(string)
    }))
    private_endpoint_subnet_id = string
    log_analytics_workspace_id = string
    private_dns_zone_ids       = map(string)
  })
  nullable = false

  validation {
    condition     = can(regex("(?i)^/subscriptions/[^/]+/resourceGroups/[^/]+/providers/Microsoft\\.Network/virtualNetworks/[^/]+$", var.network.virtual_network_id))
    error_message = "virtual_network_id must be a virtual network resource ID."
  }

  validation {
    condition     = can(regex("(?i)^/subscriptions/[^/]+/resourceGroups/[^/]+/providers/Microsoft\\.Network/virtualNetworks/[^/]+/subnets/[^/]+$", var.network.private_endpoint_subnet_id))
    error_message = "private_endpoint_subnet_id must be a subnet resource ID."
  }

  validation {
    condition     = startswith(lower(var.network.private_endpoint_subnet_id), "${lower(var.network.virtual_network_id)}/subnets/")
    error_message = "private_endpoint_subnet_id must be a subnet of virtual_network_id's VNet: a workspace's one databricks_ui_api endpoint serves its clusters as well as its users, and clusters must reach it inside their own VNet."
  }

  validation {
    condition = alltrue(flatten([
      for pair in values(var.network.databricks_subnets) : [
        for subnet in [pair.host, pair.container] :
        can(regex("(?i)^/subscriptions/[^/]+/resourceGroups/[^/]+/providers/Microsoft\\.Network/virtualNetworks/[^/]+/subnets/[^/]+$", subnet.id))
        && endswith(subnet.id, "/subnets/${subnet.name}")
      ]
    ]))
    error_message = "Every Databricks subnet must be a subnet resource ID whose last segment is its name."
  }

  # Optional in the type so that a landing-zone output without it fails here,
  # with a message naming it, rather than as a type error.
  validation {
    condition = alltrue([
      for pair in values(var.network.databricks_subnets) :
      pair.private_endpoint_subnet_id != null
      && can(regex("(?i)^/subscriptions/[^/]+/resourceGroups/[^/]+/providers/Microsoft\\.Network/virtualNetworks/[^/]+/subnets/[^/]+$", pair.private_endpoint_subnet_id))
    ])
    error_message = "Every workspace needs its own private endpoint subnet, databricks_subnets.<key>.private_endpoint_subnet_id, as a subnet resource ID: six subnets per environment, three per workload."
  }

  validation {
    condition = alltrue([
      for pair in values(var.network.databricks_subnets) :
      pair.private_endpoint_subnet_id == null
      || startswith(lower(pair.private_endpoint_subnet_id), "${lower(var.network.virtual_network_id)}/subnets/")
    ])
    error_message = "Each workspace's private endpoint subnet must be a subnet of virtual_network_id's VNet: the workspace's one databricks_ui_api endpoint serves its clusters as well as its users, and clusters must reach it inside their own VNet."
  }

  validation {
    condition     = can(regex("(?i)^/subscriptions/[^/]+/resourceGroups/[^/]+/providers/Microsoft\\.OperationalInsights/workspaces/[^/]+$", var.network.log_analytics_workspace_id))
    error_message = "log_analytics_workspace_id must be a Log Analytics workspace resource ID."
  }

  validation {
    condition     = alltrue([for key in ["databricks", "blob", "dfs", "vault"] : contains(keys(var.network.private_dns_zone_ids), key)])
    error_message = "private_dns_zone_ids must include databricks, blob, dfs and vault."
  }

  validation {
    condition     = alltrue([for key in keys(var.workspaces) : contains(keys(var.network.databricks_subnets), key)])
    error_message = "Every workspace needs its own pair of Databricks subnets in network.databricks_subnets."
  }

  # Azure puts a private endpoint, and a VNet-injected workspace, in its
  # virtual network's subscription, and each environment has its own.
  validation {
    condition = alltrue([
      for id in concat(
        [var.network.virtual_network_id, var.network.private_endpoint_subnet_id],
        compact(flatten([for pair in values(var.network.databricks_subnets) : [pair.host.id, pair.container.id, pair.private_endpoint_subnet_id]])),
      ) : lower(try(split("/", id)[2], "")) == lower(var.subscription_id)
    ])
    error_message = "The virtual network, the private endpoint subnets and every Databricks subnet must be in this environment's subscription, var.subscription_id: Azure requires a private endpoint, and a VNet-injected workspace, to be in their virtual network's subscription. Only the private DNS zones and the central Log Analytics workspace may be elsewhere."
  }
}

variable "platform_key_vault" {
  description = "The platform's Key Vault, in Azure RBAC mode: its name and SKU."
  type = object({
    name     = string
    sku_name = optional(string, "standard")
  })
  nullable = false
}

variable "resource_group_names" {
  description = "Names of the three resource groups, grouped by resource type: the names the Calandra team agreed."
  type = object({
    storage    = string
    databricks = string
    ops        = string
  })
  nullable = false
}

variable "secret_scope_key_vault" {
  description = "The Databricks secret scope's Key Vault, in the access-policy model: its name and SKU."
  type = object({
    name     = string
    sku_name = optional(string, "standard")
  })
  nullable = false
}

variable "subscription_id" {
  description = "Identifier. The subscription this environment deploys into: each environment has its own, and each environment's holds both of its workspaces. From the environment's variable group."
  type        = string
  nullable    = false

  validation {
    condition     = can(regex("^[0-9a-f]{8}-([0-9a-f]{4}-){3}[0-9a-f]{12}$", var.subscription_id))
    error_message = "subscription_id must be a lower-case GUID."
  }
}

variable "tenant_id" {
  description = "Identifier. The Entra tenant. From the tier's variable group."
  type        = string
  nullable    = false

  validation {
    condition     = can(regex("^[0-9a-f]{8}-([0-9a-f]{4}-){3}[0-9a-f]{12}$", var.tenant_id))
    error_message = "tenant_id must be a lower-case GUID."
  }
}

variable "trusted_storage" {
  description = "The trusted ADLS Gen2 account, which holds Unity Catalog managed storage and trusted data: its name and SKU, Standard_LRS or Standard_ZRS (LRS outside production, ZRS in production)."
  type = object({
    name     = string
    sku_name = optional(string, "Standard_ZRS")
    # Hexaware's draft private endpoint names, commented out with their endpoints in main.tf.
    # pe_nic_name = string
    # pe_name = string
  })
  nullable = false
}

# UNTRUSTED STORAGE PARKED (2026-10-14): see the note in main.tf.
# variable "untrusted_storage" {
#   description = "The untrusted ADLS Gen2 account, where third parties land data before it is copied into trusted: its name and SKU, Standard_LRS or Standard_ZRS (LRS outside production, ZRS in production)."
#   type = object({
#     name     = string
#     sku_name = optional(string, "Standard_ZRS")
#     # Hexaware's draft private endpoint names, commented out with their endpoints in main.tf.
#     # pe_nic_name = string
#     # pe_name = string
#   })
#   nullable = false
# }

variable "workspaces" {
  description = "The two Databricks workspaces in this environment, by track: 'anl' (analytical) and 'ops' (operational), both required. storage_account_sku_name is the SKU of the workspace's own storage account, Standard_LRS or Standard_ZRS (LRS outside production, ZRS in production). storage_connector_name names the Access Connector Azure Databricks uses to reach that account once its firewall is on."
  type = map(object({
    name                        = string
    managed_resource_group_name = string
    storage_connector_name      = string
    storage_account_sku_name    = optional(string, "Standard_ZRS")
  }))
  nullable = false

  validation {
    condition     = toset(keys(var.workspaces)) == toset(["anl", "ops"])
    error_message = "workspaces must have exactly 'anl' and 'ops': every environment has one analytical and one operational workspace."
  }
}

variable "enable_telemetry" {
  description = "Whether the Azure Verified Modules send usage telemetry to Microsoft. Off unless the client chooses otherwise."
  type        = bool
  default     = false
  nullable    = false
}

variable "lock_enabled" {
  description = "Whether the storage accounts and Key Vaults carry CanNotDelete locks. True in production only, to start."
  type        = bool
  default     = false
  nullable    = false
}

variable "platform_admin_group_object_id" {
  description = "Identifier. Object ID of the platform admin Entra group. Needed only if platform_admin_role_assignments is not empty. From the tier's variable group."
  type        = string
  default     = null

  validation {
    condition     = var.platform_admin_group_object_id == null || can(regex("^[0-9a-f]{8}-([0-9a-f]{4}-){3}[0-9a-f]{12}$", var.platform_admin_group_object_id))
    error_message = "platform_admin_group_object_id must be a lower-case GUID."
  }
}

variable "platform_admin_role_assignments" {
  description = "Azure roles for the platform admin group, by an arbitrary key: each a role name and the resource group key (storage, databricks or ops) it is scoped to. Empty unless Calandra's privileged-access process does not cover them."
  type = map(object({
    role_definition_name = string
    resource_group       = string
  }))
  default  = {}
  nullable = false

  validation {
    condition     = alltrue([for assignment in values(var.platform_admin_role_assignments) : contains(["storage", "databricks", "ops"], assignment.resource_group)])
    error_message = "Each assignment's resource_group must be storage, databricks or ops."
  }

  validation {
    condition     = length(var.platform_admin_role_assignments) == 0 || var.platform_admin_group_object_id != null
    error_message = "platform_admin_group_object_id must be set when there are platform admin role assignments."
  }
}

variable "workload_identities" {
  description = "User-assigned managed identities for Databricks workloads, by key, with their names. Each reaches Databricks through its tier's sp-databricks group."
  type = map(object({
    name = string
  }))
  default  = {}
  nullable = false

  validation {
    condition     = length(setsubtract(keys(var.workload_identities), keys(var.entities))) == 0
    error_message = "Every workload identity key must be an entity key: a stale key would create an identity for an entity that no longer exists."
  }
}
