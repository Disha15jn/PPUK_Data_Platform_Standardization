# Every name and address range comes from environments/<env>.tfvars. Nothing
# environment-specific is hard-coded here.

locals {
  # One host and one container subnet per Databricks workspace key (anl; ops
  # too in prd), plus the shared private endpoint subnet. Subnet names are
  # force-new on the workspace, so settle them before the first apply.
  databricks_subnet_defs = merge([
    for workspace, pair in var.databricks_workspaces : {
      "${workspace}_host" = merge(pair.host, { delegation_name = "databricks_workspace_delegation_${workspace}_host" })
      "${workspace}_con"  = merge(pair.container, { delegation_name = "databricks_workspace_delegation_${workspace}_con" })
    }
  ]...)

  subnets = merge(
    {
      for key, subnet in local.databricks_subnet_defs : key => {
        name          = subnet.name
        address_space = subnet.address_prefix
        delegations = [
          {
            name = subnet.delegation_name
            service_delegation = {
              name = "Microsoft.Databricks/workspaces"
            }
          },
        ]
        private_endpoint_network_policies_enabled = true
        private_endpoint_network_policies         = "Disabled"
        nsg                                       = subnet.nsg_name
        nsg_rule_set                              = "databricks_subnet"
        rt                                        = subnet.route_table_name
      }
    },
    {
      for workspace, subnet in var.private_endpoint_subnets : "pe_${workspace}_snet" => {
        name                                      = subnet.name
        address_space                             = subnet.address_prefix
        delegations                               = null
        private_endpoint_network_policies_enabled = true
        private_endpoint_network_policies         = "Enabled"
        nsg                                       = subnet.nsg_name
        nsg_rule_set                              = "workspace_endpoint"
        rt                                        = subnet.route_table_name
      }
    },
    var.trusted_private_endpoint_subnet == null ? {} : {
      trusted_pe_snet = {
        name                                      = var.trusted_private_endpoint_subnet.name
        address_space                             = var.trusted_private_endpoint_subnet.address_prefix
        delegations                               = null
        private_endpoint_network_policies_enabled = true
        private_endpoint_network_policies         = "Enabled"
        nsg                                       = var.trusted_private_endpoint_subnet.nsg_name
        nsg_rule_set                              = "trusted_endpoint"
        rt                                        = var.trusted_private_endpoint_subnet.route_table_name
      }
    },
  )

  # Keep NSGs and route tables on the existing subnets. The trusted endpoint subnet
  # gets its own NSG with no custom rules and an empty route table. User-defined routes
  # can be added later when the trusted storage and Key Vault routing design is confirmed.
  subnets_with_nsg = {
    for key, subnet in local.subnets : key => subnet if try(subnet.nsg, null) != null
  }

  # Default route to the hub firewall on the Databricks host and container subnets, once the
  # hub team provides the firewall's private IP. The private endpoint subnets keep an empty
  # route table: their traffic stays inside the VNet.
  route_table_routes = {
    for key in keys(local.databricks_subnet_defs) : key => var.hub.firewall_private_ip == null ? {} : {
      default_to_hub_firewall = {
        name                   = "default-to-hub-firewall"
        address_prefix         = "0.0.0.0/0"
        next_hop_type          = "VirtualAppliance"
        next_hop_in_ip_address = var.hub.firewall_private_ip
      }
    }
  }

  subnets_with_route_table = {
    for key, subnet in local.subnets : key => subnet if try(subnet.rt, null) != null
  }
}
