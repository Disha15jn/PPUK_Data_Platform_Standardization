# Stops a plan or apply of an environment whose address ranges are not confirmed.
# Subnets cannot be resized once Databricks workspaces use them.
resource "terraform_data" "ranges_confirmed" {
  lifecycle {
    precondition {
      condition     = var.ranges_confirmed
      error_message = "The address ranges in environments/${var.environment}.tfvars are placeholders, not confirmed by the client. Subnets cannot be resized once workspaces use them. Confirm the ranges, then set ranges_confirmed = true in that file."
    }
  }
}

# Stops web-auth being deployed into the placeholder subscription.
resource "terraform_data" "web_auth_ready" {
  count = var.deploy_web_auth ? 1 : 0

  lifecycle {
    precondition {
      condition     = var.web_auth != null && var.mgt_subscription_id != "00000000-0000-0000-0000-000000000000"
      error_message = "deploy_web_auth is true, but web_auth is not set or mgt_subscription_id is still the all-zeros placeholder. Create the management subscription, set mgt_subscription_id from its variable group, then deploy."
    }
  }
}

# Stops the firewall rules being written without a policy to write them to.
resource "terraform_data" "firewall_rules_ready" {
  count = var.firewall_rules.manage ? 1 : 0

  lifecycle {
    precondition {
      condition     = startswith(coalesce(var.hub.firewall_policy_id, "x"), "/subscriptions/") && var.hub.connectivity_subscription_id != null && !strcontains(coalesce(var.build_agent.subnet_prefix, ""), "192.0.2.") && !strcontains(coalesce(var.hub.nsg_firewall_ip, ""), "192.0.2.")
      error_message = "firewall_rules.manage is true, but hub.firewall_policy_id is not the policy's resource ID, hub.connectivity_subscription_id is not set, or the build agent subnet or firewall address is still a 192.0.2.x placeholder."
    }
  }
}

# Stops rules being written to the build agent's NSG while its details are placeholders.
resource "terraform_data" "build_agent_ready" {
  count = var.build_agent.manage_nsg_rules ? 1 : 0

  lifecycle {
    precondition {
      condition     = !startswith(coalesce(var.build_agent.nsg_name, "TODO"), "TODO") && !startswith(coalesce(var.build_agent.nsg_resource_group_name, "TODO"), "TODO")
      error_message = "build_agent.manage_nsg_rules is true, but the NSG name or resource group is still a TODO placeholder."
    }
  }
}
