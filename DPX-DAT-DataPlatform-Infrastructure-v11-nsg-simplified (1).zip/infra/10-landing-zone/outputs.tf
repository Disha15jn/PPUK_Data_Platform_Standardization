output "environment" {
  description = "The environment that published these outputs. The platform pipeline refuses a file from another environment's state."
  value       = var.environment
}

# The single object infra/20-platform-services reads as its `network` variable.
# Attribute names and nesting are a published interface: they are read by name
# downstream (databricks_subnets.anl.host.id, for instance). Do not rename.
output "network" {
  description = "The network state required by infra/20-platform-services."
  value = {
    virtual_network_id = module.databricks_vnet.resource_id
    # The subnet for the shared endpoints (trusted blob and dfs, and the two Key Vaults):
    # the trusted endpoint subnet when it is set, otherwise the analytical one. The
    # platform root reads this attribute unchanged.
    private_endpoint_subnet_id = var.trusted_private_endpoint_subnet == null ? module.databricks_subnets["pe_anl_snet"].resource_id : module.databricks_subnets["trusted_pe_snet"].resource_id

    # One private endpoint subnet per workspace.
    private_endpoint_subnets = {
      for workspace in keys(var.private_endpoint_subnets) : workspace => {
        id   = module.databricks_subnets["pe_${workspace}_snet"].resource_id
        name = module.databricks_subnets["pe_${workspace}_snet"].name
      }
    }

    # One host and one container subnet per workspace: anl everywhere, ops too in prd.
    databricks_subnets = {
      for workspace in keys(var.databricks_workspaces) : workspace => {
        host = {
          id   = module.databricks_subnets["${workspace}_host"].resource_id
          name = module.databricks_subnets["${workspace}_host"].name
        }
        container = {
          id   = module.databricks_subnets["${workspace}_con"].resource_id
          name = module.databricks_subnets["${workspace}_con"].name
        }
      }
    }

    log_analytics_workspace_id = data.azurerm_log_analytics_workspace.central.id

    private_dns_zone_ids = {
      databricks = local.databricks_zone_id
      blob       = local.blob_zone_id
      dfs        = local.dfs_zone_id
      vault      = local.vault_zone_id
    }
  }
}

# For information: the shared web-auth workspace, when this state deploys it. Not part of
# the `network` contract that infra/20-platform-services reads.
output "web_auth" {
  description = "The shared web-auth workspace, or null when this state does not deploy it."
  value = var.deploy_web_auth ? {
    workspace_id               = module.web_auth[0].workspace_id
    virtual_network_id         = module.web_auth[0].virtual_network_id
    private_endpoint_subnet_id = module.web_auth[0].private_endpoint_subnet_id
  } : null
}
