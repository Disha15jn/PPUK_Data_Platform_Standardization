variable "subscription_id" {
  description = "Identifier. The subscription this environment deploys into: each environment has its own, and production's holds both workspaces. From the environment's variable group."
  type        = string
  nullable    = false

  validation {
    condition     = can(regex("^[0-9a-f]{8}-([0-9a-f]{4}-){3}[0-9a-f]{12}$", var.subscription_id))
    error_message = "subscription_id must be a lower-case GUID."
  }
}

variable "law_central_sub_id" {
  description = "Identifier. The subscription this environment deploys into: each environment has its own, and production's holds both workspaces. From the environment's variable group."
  type        = string
  nullable    = false
}

variable "tenant_id" {
  description = "Identifier. The Entra tenant. From the tier's variable group."
  type        = string
  nullable    = false

  validation {
    condition     = can(regex("^[0-9a-f]{8}-([0-9a-f]{4}-){3}[0-9a-f]{12}$", var.tenant_id))
    error_message = "tenant_id must be a lower-case GUID."
  }
}

variable "location" {
  type    = string
  default = "germanywestcentral"
}

variable "environment" {
  description = "The environment this state deploys: dev, tst, stg or prd. Published as the 'environment' output so the platform pipeline can refuse another environment's file."
  type        = string
  nullable    = false

  validation {
    condition     = contains(["dev", "tst", "stg", "prd"], var.environment)
    error_message = "environment must be dev, tst, stg or prd."
  }
}

variable "network_resource_group_name" {
  description = "Name of the resource group this root creates for the VNet, subnets, NSGs and route tables. The Databricks and storage resource groups are created by infra/20-platform-services, not here."
  type        = string
  nullable    = false
}

variable "vnet" {
  description = "The environment's VNet: name and address space."
  type = object({
    name          = string
    address_space = list(string)
    dns_servers   = optional(list(string), [])
  })
}

variable "private_endpoint_subnets" {
  description = <<-EOT
    A private endpoint subnet for each workspace, keyed by workspace ('anl' and 'ops'), each with
    its own NSG and route table. The 'anl' subnet is also published as the default
    private_endpoint_subnet_id.
  EOT
  type = map(object({
    name             = string
    address_prefix   = string
    nsg_name         = string
    route_table_name = string
  }))
  nullable = false

  validation {
    condition     = toset(keys(var.private_endpoint_subnets)) == toset(["anl", "ops"])
    error_message = "private_endpoint_subnets must have exactly the keys 'anl' and 'ops'."
  }
}

variable "trusted_private_endpoint_subnet" {
  description = "Optional extra subnet reserved for trusted storage and Key Vault private endpoints. An NSG and an empty route table are created and attached; no custom security rules, user-defined routes, private endpoints or DNS configuration are created by this input."
  type = object({
    name             = string
    address_prefix   = string
    nsg_name         = string
    route_table_name = string
  })
  default  = null
  nullable = true
}

variable "databricks_workspaces" {
  description = <<-EOT
    The Databricks subnet pair for each workspace, keyed by workspace: 'anl' and 'ops' in
    every environment. Subnet names are force-new on the workspace.
  EOT
  type = map(object({
    host = object({
      name             = string
      address_prefix   = string
      nsg_name         = string
      route_table_name = string
    })
    container = object({
      name             = string
      address_prefix   = string
      nsg_name         = string
      route_table_name = string
    })
  }))
  nullable = false

  validation {
    condition     = toset(keys(var.databricks_workspaces)) == toset(["anl", "ops"])
    error_message = "Every environment has both workspaces: databricks_workspaces must have exactly the keys 'anl' and 'ops'."
  }
}

variable "ranges_confirmed" {
  description = "Set true only once every address range in this environment's tfvars has been confirmed by the client. Subnets cannot be resized once workspaces use them, so a plan fails while this is false."
  type        = bool
  default     = false
  nullable    = false
}

variable "hub" {
  description = <<-EOT
    The connection to the hub, a Virtual WAN hub in the connectivity subscription (see
    HUB-CONNECTION.md). All optional.
      connect                       true to look up the hub and connect this environment's VNet (and the
                                    web-auth VNet, when deployed) to it. The identity needs rights on the hub
                                    in the connectivity subscription, so it is false until they are granted.
      vhub_name, vhub_resource_group_name, connectivity_subscription_id
                                    the Virtual WAN hub.
      connection_name               name of this environment's VNet connection to the hub.
      web_auth_connection_name      name of the web-auth VNet's connection, when deployed.
      internet_security_enabled     send 0.0.0.0/0 through the hub's firewall (default true). Needs a secured hub.
      firewall_private_ip           optional: also put a 0.0.0.0/0 route to this IP on the Databricks subnets, for
                                    a hub that does not push the default route to spokes.
      firewall_policy_id            resource ID of the hub firewall's policy (dpx-inf-con-gwc-afw-001), only needed
                                    when firewall_rules.manage is true.
      nsg_firewall_ip               the firewall's address as the NSG rules name it, when firewall_private_ip is
                                    null (so no default route is added). A placeholder in the 192.0.2.0/24 documentation
                                    range matches nothing until the real address replaces it.
  EOT
  type = object({
    connect                      = optional(bool, false)
    vhub_name                    = optional(string)
    vhub_resource_group_name     = optional(string)
    connectivity_subscription_id = optional(string)
    connection_name              = optional(string)
    web_auth_connection_name     = optional(string)
    internet_security_enabled    = optional(bool, true)
    firewall_private_ip          = optional(string)
    firewall_policy_id           = optional(string)
    nsg_firewall_ip              = optional(string)
  })
  default  = {}
  nullable = false

  validation {
    condition     = var.hub.firewall_private_ip == null || can(regex("^([0-9]{1,3}\\.){3}[0-9]{1,3}$", var.hub.firewall_private_ip))
    error_message = "hub.firewall_private_ip must be an IPv4 address."
  }

  validation {
    condition = !var.hub.connect || alltrue([
      for value in [var.hub.vhub_name, var.hub.vhub_resource_group_name, var.hub.connectivity_subscription_id, var.hub.connection_name] : value != null && value != ""
    ])
    error_message = "hub.connect needs vhub_name, vhub_resource_group_name, connectivity_subscription_id and connection_name."
  }
}

variable "mgt_subscription_id" {
  description = "Identifier. The management subscription (dpx-sub-dat-mgt-gwc-001) that holds the shared web-auth workspace. The subscription is not created yet, so this stays the all-zeros placeholder until it is, then comes from the variable group like the other identifiers."
  type        = string
  default     = "00000000-0000-0000-0000-000000000000"
  nullable    = false

  validation {
    condition     = can(regex("^[0-9a-f]{8}-([0-9a-f]{4}-){3}[0-9a-f]{12}$", var.mgt_subscription_id))
    error_message = "mgt_subscription_id must be a lower-case GUID."
  }
}

variable "deploy_web_auth" {
  description = "Whether this state creates the shared web-auth workspace in the management subscription. One per region, so only one environment's state (dev) sets this, and only once the subscription exists and mgt_subscription_id is set. A plan fails if it is true while mgt_subscription_id is still the placeholder."
  type        = bool
  default     = false
  nullable    = false
}

variable "web_auth" {
  description = "Names and ranges for the shared web-auth workspace (see deploy_web_auth). Null in environments that do not create it."
  type = object({
    resource_group_name = string
    vnet = object({
      name          = string
      address_space = list(string)
      dns_servers   = optional(list(string), [])
    })
    host_subnet                 = object({ name = string, address_prefix = string, nsg_name = string, route_table_name = string })
    container_subnet            = object({ name = string, address_prefix = string, nsg_name = string, route_table_name = string })
    private_endpoint_subnet     = object({ name = string, address_prefix = string, nsg_name = string, route_table_name = string })
    workspace_name              = string
    managed_resource_group_name = string
    storage_connector_name      = string
    private_dns_zone_id         = optional(string)
  })
  default = null
}

variable "infra_mgt_subscription_id" {
  description = "Identifier. The infrastructure management subscription (dpx-sub-inf-mgt-gwc-001) that holds the build agent pool's NSG. Null uses law_central_sub_id, which is that subscription when the central Log Analytics workspace is in it."
  type        = string
  default     = null

  validation {
    condition     = var.infra_mgt_subscription_id == null || can(regex("^[0-9a-f]{8}-([0-9a-f]{4}-){3}[0-9a-f]{12}$", var.infra_mgt_subscription_id))
    error_message = "infra_mgt_subscription_id must be a lower-case GUID."
  }
}

variable "tags" {
  description = "Resource tags. The Calandra mandatory set (LLD section 'Resource Tagging'): Environment, Cost Centre, Application, Owner and ManagedBy."
  type        = map(string)
  default     = {}
  nullable    = false
}

variable "create_own_dns_zones" {
  description = "True creates the databricks and dfs private DNS zones in this environment's own subscription (dns.tf). False looks them up in the shared central zones instead, which is where the LLD hosts them (DNS table: 'Hosted In: Hub Sub')."
  type        = bool
  default     = true
  nullable    = false
}

variable "build_agent" {
  description = <<-EOT
    The build agent pool's subnet, dpx-pba-inf-mgt-gwc-snet-001 in the existing infrastructure
    management VNet (dpx-inf-mgt-gwc-vnet-001). It is not built here.
      subnet_prefix            its address range. Null leaves out every rule that names it.
      nsg_name, nsg_resource_group_name
                               the NSG on that subnet, in the infrastructure management subscription.
      manage_nsg_rules         true adds the outbound rules (to the hub firewall on 443, and to the workspace
                               endpoint subnets) to that existing NSG. The identity needs Network Contributor on it.
  EOT
  type = object({
    subnet_prefix           = optional(string)
    nsg_name                = optional(string)
    nsg_resource_group_name = optional(string)
    manage_nsg_rules        = optional(bool, false)
  })
  default  = {}
  nullable = false

  validation {
    condition     = var.build_agent.subnet_prefix == null || can(cidrhost(var.build_agent.subnet_prefix, 0))
    error_message = "build_agent.subnet_prefix must be a CIDR range."
  }

  validation {
    condition     = !var.build_agent.manage_nsg_rules || (var.build_agent.nsg_name != null && var.build_agent.nsg_resource_group_name != null)
    error_message = "build_agent.manage_nsg_rules needs nsg_name and nsg_resource_group_name."
  }
}

variable "firewall_rules" {
  description = <<-EOT
    Azure Firewall rules for the data platform (modules/firewall-rules; FIREWALL-AND-NSG-RULES.md lists them).
      manage       true writes them to the hub firewall's policy as one rule collection group. Needs
                   hub.firewall_policy_id and rights on that policy in the connectivity subscription.
                   False leaves the firewall to the hub team, who take the rules from the document.
      mode         fqdn (hostnames, the default: only the named Databricks accounts are reachable) or
                   service_tag (Azure service tags: no upkeep, but every storage account and Event Hub in
                   the region is reachable). See the PDF's section 2.
      group_name   name of the rule collection group. Default: dpx-dat-<environment>-int-gwc-rcg-001.
      group_priority  priority of the group in the policy.
  EOT
  type = object({
    manage         = optional(bool, false)
    mode           = optional(string, "fqdn")
    group_name     = optional(string)
    group_priority = optional(number, 1000)
  })
  default  = {}
  nullable = false

  validation {
    condition     = contains(["fqdn", "service_tag"], var.firewall_rules.mode)
    error_message = "firewall_rules.mode must be fqdn or service_tag."
  }
}

variable "nsg_rules" {
  description = <<-EOT
    All NSG rules, written out in environments/<env>.tfvars. One named set per kind of subnet:
      databricks_subnet    host and container subnets (also the web-auth VNet's)
      workspace_endpoint   ape and ope
      trusted_endpoint     tpe
      web_auth_endpoint    the web-auth endpoint subnet (bpe)
      build_agent          rules added to the build agent pool's existing NSG (see build_agent)
    A set that is missing means an NSG with no rules. Within one set, use each priority once per direction.
  EOT
  type = map(map(object({
    name                         = string
    priority                     = number
    direction                    = string
    access                       = optional(string, "Allow")
    protocol                     = optional(string, "Tcp")
    source_port_range            = optional(string, "*")
    source_address_prefix        = optional(string)
    source_address_prefixes      = optional(list(string))
    destination_port_range       = optional(string)
    destination_port_ranges      = optional(list(string))
    destination_address_prefix   = optional(string)
    destination_address_prefixes = optional(list(string))
  })))
  nullable = false
}
