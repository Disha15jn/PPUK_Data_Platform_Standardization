# Firewall and NSG rules for the data platform

Source: *What the data platform needs to reach outside the network* (Cynozure, 16 October 2026),
the architecture diagram, and the Databricks LLD v0.1. The PDF is an input to the design, not a
firewall specification: the final rule set is Hexaware's and the hub team's to decide.

Two layers, both in this repo:

| Layer | Who owns it | Where in code | Switch |
|---|---|---|---|
| **NSG rules** on our subnets (and, optionally, on the build agent's existing NSG) | us | `nsg_rules` in `environments/<env>.tfvars` (every rule, written out); applied in `main.tf`, `web_auth.tf` and `build_agent.tf` | always on; build agent NSG: `build_agent.manage_nsg_rules` |
| **Azure Firewall rules** (`dpx-inf-con-gwc-afw-001`, connectivity subscription) | the hub team | `modules/firewall-rules`, written by `firewall.tf` | `firewall_rules.manage` (default **false**), needs `hub.firewall_policy_id` |

The same firewall rules are in `FIREWALL-RULES-for-hub-team.csv`, for the hub team to enter
themselves if they would rather not have Terraform write to their policy.

An NSG matches the packet's final destination, not its next hop. A user-defined route to the
firewall does not change that, so the tag rules below still apply to traffic the firewall will
inspect, and a rule that names the firewall's own IP only matches traffic addressed to the firewall.

## 1. NSG rules

All NSGs are at subnet level with a default deny at priority 4096. A custom deny overrides Azure's
built-in AllowVnetInBound, so VNet traffic is allowed explicitly first.

### Compute subnets: `ahx`, `acx`, `opx`, `ocx` (and web-auth `whx`, `wcx`; same rules on all)

| Pri | Rule | Dir | Destination | Port | PDF ref |
|---|---|---|---|---|---|
| 200 | allow-vnet-inbound / outbound | both | VirtualNetwork | any | needed so cluster nodes talk to each other |
| 205 | allow-azure-dns-outbound | out | 168.63.129.16 | 53 | |
| 206 | allow-hub-firewall-outbound | out | the hub firewall's private IP | 443, 6666, 3306, 8443-8451 | section 4: VNet traffic routed through the firewall. Only when the firewall address is set |
| 207 | allow-custom-dns-outbound | out | the VNet's `dns_servers` (hub DNS) | 53 | **new**: without it the default deny blocks the custom DNS servers. Only when `dns_servers` is set |
| 220, 221 | allow-databricks-storage-0 / 1-outbound | out | `Storage.GermanyWestCentral`, `Storage.SwitzerlandNorth` | 443 | C1 to C4 (C2 is the Switzerland North copy) |
| 230 | allow-databricks-eventhub-0-outbound | out | `EventHub.GermanyWestCentral` | 9093 | C5 (Kafka) |
| 4096 | deny-all-inbound / outbound | both | any | any | |

Off by default, switched on in the commented rules in `nsg_rules`:

| Option | Rule | Why it is off |
|---|---|---|
| `allow_azuredatabricks_tag` | `AzureDatabricks` on 443, 3306, 8443-8451 | Microsoft: not required when the workspace uses Private Link. Turn on only if clusters fail with "Control Plane Request Failure". |
| `allow_hive_metastore` | `Sql` on 3306 | Legacy Hive metastore; not needed with Unity Catalog only. |
| `allow_internet_https` | `Internet` on 443 (the LLD's Allow-pass-outbound) | Makes the tag rules above redundant, and leaves the firewall as the only filter. |

This replaces the earlier rule set, which allowed the `AzureDatabricks`, `Sql` and all-region `Storage`
tags and https to the whole internet. If clusters will not start after the change, turn the options above on one at a time.

### Workspace endpoint subnets: `ape` (analytical) and `ope` (operational)

| Pri | Rule | Dir | Source | Port | Why |
|---|---|---|---|---|---|
| 200 | allow-databricks-private-link-inbound | in | VirtualNetwork | 443, 6666, 3306, 8443-8451 | compute to its own endpoint (needed while endpoint policies are on) |
| 205 | allow-zpa-https-inbound | in | ZPA subnet 10.130.8.64/27 | 443 | LLD, and the diagram's ZPA to ui-api flow. On both `ape` and `ope`: the LLD omits it on `ope`, the diagram shows it |
| 206 | **allow-build-agent-https-inbound** | in | **build agent subnet** (`build_agent.subnet_prefix`) | 443 | **new**: the pipeline calls each workspace at its private endpoint |
| 200 | allow-vnet-outbound | out | VirtualNetwork | any | |
| 4096 | deny-all inbound / outbound | both | | | |

The `tpe` (trusted) subnet is unchanged: VNet-only inbound, no build agent rule. The Databricks
pipeline's Key Vault and storage calls would need one if it reaches the trusted endpoints from the pool.

### Build agent subnet `dpx-pba-inf-mgt-gwc-snet-001` (the infrastructure team's NSG)

The subnet and NSG already exist, so these are added to that NSG only when
`build_agent.manage_nsg_rules = true` (and the identity has Network Contributor on it). Otherwise give
the infrastructure team this list:

| Pri | Rule | Dir | Destination | Port |
|---|---|---|---|---|
| 200 | allow-hub-firewall-https-outbound | out | the hub firewall's private IP | 443 |
| 110 | allow-workspace-endpoints-outbound | out | `ape` 10.130.254.0/27 and `ope` | 443 |

Needs `build_agent.subnet_prefix` and `hub.firewall_private_ip`; **neither is known yet**, so these rules
and the endpoint subnets' build agent rule are skipped until they are set. The pool's NSG may also
need port 80 to the firewall for plain-http Ubuntu mirrors (A7).

## 2. Firewall rules (hub firewall)

Sources: the four compute subnets (`ahx`, `acx`, `opx`, `ocx`: 10.130.252.0/25, 10.130.252.128/25,
10.130.253.0/25, 10.130.253.128/25) and the build agent subnet (range to be filled in). `mode = fqdn`
(default) writes destinations as hostnames; `mode = service_tag` writes them as Azure tags where one covers them.

### Databricks compute

| ID | Purpose | Hostname | Service tag | Port | Rule type |
|---|---|---|---|---|---|
| C1 | runtime images and libraries (every cluster downloads this at start) | dbartifactsprodgerwescen.blob.core.windows.net | Storage.GermanyWestCentral | 443 | Application (Https) |
| C2 | second copy of the artifact storage | dbartifactsprodswissnor.blob.core.windows.net | Storage.SwitzerlandNorth | 443 | Application |
| C3 | cluster logs | dblogprodgerwescen.blob.core.windows.net | Storage.GermanyWestCentral | 443 | Application |
| C4 | system tables | ucstprdgerwescen.dfs.core.windows.net | Storage.GermanyWestCentral | 443 | Application |
| C5 | service logging (Event Hubs, Kafka protocol, **not https**) | prod-germanywestcentral-observabilityEventHubs.servicebus.windows.net | EventHub.GermanyWestCentral | TCP 9093 | **Network** (by hostname it needs the policy's DNS proxy) |
| n/a | compute to the workspace endpoints, **only if VNet traffic is routed through the firewall** | | `ape`, `ope` | 443, 6666, 3306, 8443-8451 | Network |
| n/a | compute to the trusted storage and Key Vault endpoints, same condition | | `tpe` | 443 | Network |

### Build agents (pool `dpx_inf_gwc_linux_pba`; production's pool has its own, same list)

| ID | Purpose | Hostname | Service tag | Port | Status in the PDF |
|---|---|---|---|---|---|
| A1 | Databricks account API | accounts.azuredatabricks.net | AzureDatabricks | 443 | **blocked today** (the 13 October run was cut off) |
| A2 | Databricks Terraform provider | registry.terraform.io, github.com, objects.githubusercontent.com, release-assets.githubusercontent.com | none | 443 | not yet tested |
| A3 | pipeline identity sign-in | login.microsoftonline.com | AzureActiveDirectory | 443 | working |
| A4 | Azure Resource Manager | management.azure.com | AzureResourceManager | 443 | working |
| A5 | Terraform | releases.hashicorp.com | none | 443 | working |
| A6 | providers and AVM modules | registry.terraform.io, releases.hashicorp.com, github.com, codeload.github.com | none | 443 | working |
| A7 | tools installed at run time | packages.microsoft.com, pypi.org, files.pythonhosted.org, Ubuntu mirrors | none suitable | 443, and 80 for some mirrors | working |
| n/a | build agent to the workspace endpoints (`ape`, `ope`) | | | 443 | requested; also the diagram note "agent pool should be able to reach the ui-api endpoint" |

Hosts with no tag are always written by hostname. The Ubuntu mirrors in the code are
`archive.ubuntu.com` and `security.ubuntu.com`, which is an assumption: the PDF does not name them.
Azure DevOps's own hosts and the Terraform state storage account already work, so are not listed.

### From the architecture diagram

| Flow | Rule | Port |
|---|---|---|
| ZPA connector subnet to the ui-api endpoints (`ape`, `ope`) | Network | 443 |
| web-auth browser authentication endpoint subnet (`bpe`) to the Databricks control plane | Network, tag `AzureDatabricks` (hostname to confirm) | 443 |

Both are written only when their subnet is known (the ZPA range is in the tfvars; `bpe` only when web-auth is deployed).

## 3. Decisions for the client

1. **Hostnames or service tags** (PDF section 2). Hostnames limit compute to the named Databricks accounts, which
   matters for the UK and EU data rules, but fail until the list is updated if Databricks add a hostname.
   Tags need no upkeep but cover every storage account and Event Hub in the region. Default here: hostnames
   at the firewall, regional tags at the NSG (an NSG cannot match hostnames).
2. **Routes.** The compute subnets' route tables are empty until the hub pushes 0.0.0.0/0 or
   `hub.firewall_private_ip` is set (which adds the route). Until a route exists no cluster or SQL warehouse can start.
3. **Storage service endpoint** (PDF section 4): an alternative that keeps the large image downloads off the
   firewall. Not built; not assessed against the landing zone's policies.
4. **Hive metastore, AzureDatabricks tag, internet https**: off, as above.

## 4. What the first test will show

The Databricks deployment creates a SQL warehouse that starts straight away. If C1 to C5 are not reachable it
waits and times out. `SLOW_IMAGE_DOWNLOAD` points at the artifact storage path (C1), "Control Plane Request
Failure" at the private endpoint or DNS, and `X_NHC_` codes at a failed DNS check.

## 5. Placeholders in `environments/dev.tfvars`

The values still missing are filled with placeholders so every rule exists and the plan is complete.
The ranges are in 192.0.2.0/24, the documentation range, which is never routed, so a placeholder rule
matches nothing until the real value replaces it. Search the file for `PLACEHOLDER` or `TODO`.

| Setting | Placeholder | Replace with |
|---|---|---|
| `build_agent.subnet_prefix` | `192.0.2.0/27` | the range of `dpx-pba-inf-mgt-gwc-snet-001` |
| `hub.nsg_firewall_ip` | `192.0.2.4` | the hub firewall's private IP. Leave `hub.firewall_private_ip` unset if the hub pushes 0.0.0.0/0 to spokes; set it only to add a default route to that IP on the compute subnets |
| `build_agent.nsg_name`, `nsg_resource_group_name` | `TODO-...` | the existing pool NSG |
| `hub.firewall_policy_id` | `TODO-firewall-policy-resource-id` | the firewall policy's resource ID |

Guards stop a plan if `firewall_rules.manage` or `build_agent.manage_nsg_rules` is turned on while any of these
is still a placeholder. Also still needed: the hub's DNS proxy setting (the C5 hostname rule needs it), and
rights on the firewall policy if `firewall_rules.manage` is used.
