# Fetch the Central Log Analytics Workspace
data "azurerm_log_analytics_workspace" "central" {
  name                = "dpx-inf-mgt-gwc-la-001"
  resource_group_name = "dpx-la-inf-mgt-gwc-rg-001"
  provider            = azurerm.law
}

# blob and vault are the shared central zones. databricks and dfs are created in this
# environment's own subscription (dns.tf) unless create_own_dns_zones is false, when the
# shared central zones are used, as the LLD has them.
data "azurerm_private_dns_zone" "blob" {
  name                = "privatelink.blob.core.windows.net"
  resource_group_name = "dpx-pdz-inf-con-gwc-rg-001"
  provider            = azurerm.connectivity
}

data "azurerm_private_dns_zone" "vault" {
  name                = "privatelink.vaultcore.azure.net"
  resource_group_name = "dpx-pdz-inf-con-gwc-rg-001"
  provider            = azurerm.connectivity
}

data "azurerm_private_dns_zone" "databricks" {
  provider = azurerm.connectivity

  name                = "privatelink.azuredatabricks.net"
  resource_group_name = "dpx-pdz-inf-con-gwc-rg-001"
}

data "azurerm_private_dns_zone" "dfs" {
  provider = azurerm.connectivity

  name                = "privatelink.dfs.core.windows.net"
  resource_group_name = "dpx-pdz-inf-con-gwc-rg-001"
}
