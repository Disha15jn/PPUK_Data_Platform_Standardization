# Connection to the hub: a Virtual WAN hub in the connectivity subscription. Off until
# hub.connect is true, because creating a connection needs rights on the hub that the
# pipeline identity may not have yet (HUB-CONNECTION.md).

data "azurerm_virtual_hub" "this" {
  count    = var.hub.connect ? 1 : 0
  provider = azurerm.connectivity

  name                = var.hub.vhub_name
  resource_group_name = var.hub.vhub_resource_group_name
}

# This environment's VNet. With internet_security_enabled on a secured hub, 0.0.0.0/0 goes
# through the hub's firewall, so the Databricks subnets can reach the control plane once the
# firewall rules exist.
resource "azurerm_virtual_hub_connection" "internal" {
  count    = var.hub.connect ? 1 : 0
  provider = azurerm.connectivity

  internet_security_enabled = var.hub.internet_security_enabled
  name                      = var.hub.connection_name
  remote_virtual_network_id = module.databricks_vnet.resource_id
  virtual_hub_id            = data.azurerm_virtual_hub.this[0].id
}

# The web-auth VNet, when this state deploys it.
resource "azurerm_virtual_hub_connection" "web_auth" {
  count    = var.hub.connect && var.deploy_web_auth ? 1 : 0
  provider = azurerm.connectivity

  internet_security_enabled = var.hub.internet_security_enabled
  name                      = coalesce(var.hub.web_auth_connection_name, "${var.web_auth.vnet.name}-vhubconn")
  remote_virtual_network_id = module.web_auth[0].virtual_network_id
  virtual_hub_id            = data.azurerm_virtual_hub.this[0].id
}
