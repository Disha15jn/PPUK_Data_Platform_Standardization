# infra/10-landing-zone: dev.
#
# DEV internal network, subscription dpx-sub-dat-dev-gwc-int-001. VNet 10.130.252.0/22.
# Names follow the Calandra convention in the naming README:
#   subnet  dpx-dat-<service>-dev-int-gwc-snet-<nnn>
# and each subnet's NSG and route table take the same name with nsg / rt in place of snet.
# Ranges are the client's CIDR allocation for DEV, matched to the names as the Databricks LLD v0.1
# subnet table assigns them.
#
#   ahx  analytical Databricks host         10.130.252.0/25    (allocation subnet 1)
#   acx  analytical Databricks container    10.130.252.128/25  (allocation subnet 2)
#   opx  operational Databricks host        10.130.253.0/25    (allocation subnet 3)
#   ocx  operational Databricks container   10.130.253.128/25  (allocation subnet 4)
#   ape  analytical private endpoints      10.130.254.0/27    (LLD)
#   ope  operational private endpoints     10.130.254.32/27   (as set in this file)
#   tpe  trusted private endpoints         10.130.254.64/27   (as set in this file)
#   (The LLD's subnet table and its NSG sections disagree on which of .32 and .64 is trusted.)
#
# Subnet names are force-new on the Databricks workspace.
#
# subscription_id, tenant_id, law_central_sub_id and pdns_sub_id are identifiers: they
# come from the pipeline's variable groups as TF_VAR_*, not from this file.

environment = "dev"
location    = "germanywestcentral"

# Dev ranges are confirmed by the client.
ranges_confirmed            = true
network_resource_group_name = "dpx-dat-net-dev-int-gwc-rg-001"

vnet = {
  name          = "dpx-dat-dev-int-gwc-vnet-001"
  address_space = ["10.130.252.0/22"]
  dns_servers   = ["10.130.0.132"] # hub DNS
}

# Connection to the hub (see HUB-CONNECTION.md): the Virtual WAN hub in the connectivity
# subscription. connect stays false until the pipeline identity has rights on the hub; then
# set it to true and the next apply connects this VNet (and web-auth's) to the hub.
tags = {
  Environment   = "dev"
  Application   = "Databricks"
  ManagedBy     = "Terraform"
  Owner         = "TODO-owner"
  "Cost Centre" = "TODO-cost-centre"
}

# true creates the databricks and dfs private DNS zones in this subscription. The LLD hosts them
# in the hub subscription; set false to use the shared central zones instead.
create_own_dns_zones = false

hub = {
  connect                      = true
  vhub_name                    = "dpx-inf-con-gwc-vhub-001"
  vhub_resource_group_name     = "dpx-vhub-inf-con-gwc-rg-001"
  connectivity_subscription_id = "b116cab1-74d6-4848-9bb2-32f11adf2f8c"
  connection_name              = "dpx-dat-dev-int-gwc-vhubconn-001"
  web_auth_connection_name     = "dpx-dat-mgt-gwc-vhubconn-001"
  # firewall_private_ip = "10.x.x.x" # only if the hub does not push the default route: adds a 0.0.0.0/0 route
  #                                    # to this IP on the compute subnets. The NSG rules' firewall address is in nsg_rules.
  # PLACEHOLDER: only used when firewall_rules.manage is true.
  # firewall_policy_id = "TODO-firewall-policy-resource-id"
}

# The build agent pool's subnet, dpx-pba-inf-mgt-gwc-snet-001 in the existing infrastructure
# management VNet. Its range is not in the LLD: fill it in (a /27) and the endpoint subnets'
# NSGs will accept the pool on 443, and the firewall rules will name it as a source. The subnet
# and its NSG belong to the infrastructure team; manage_nsg_rules adds our outbound rules to that
# NSG once it is known and the pipeline identity has Network Contributor on it.
# PLACEHOLDERS: 192.0.2.0/27 is in the documentation range, so the rules that name the pool exist but
# match nothing until the real range replaces it. The NSG name and resource group are guesses to confirm.
build_agent = {
  subnet_prefix           = "10.130.8.0/27"
  nsg_name                = "dpx-pba-inf-mgt-gwc-nsg-001"
  nsg_resource_group_name = "dpx-pba-inf-mgt-gwc-rg-001"
  manage_nsg_rules        = true
}

# Azure Firewall rules (FIREWALL-AND-NSG-RULES.md). The hub team may prefer to own them: leave
# manage = false and give them the document. mode: fqdn (hostnames) or service_tag (Azure tags).
firewall_rules = {
  manage = false
  mode   = "fqdn"
}

# Workspace private endpoint subnets. Keys stay anl/ops so the output contract is unchanged.
private_endpoint_subnets = {
  anl = {
    name             = "dpx-dat-ape-dev-int-gwc-snet-001"
    address_prefix   = "10.130.254.0/27"
    nsg_name         = "dpx-dat-ape-dev-int-gwc-nsg-001"
    route_table_name = "dpx-dat-ape-dev-int-gwc-rt-001"
  }
  ops = {
    name             = "dpx-dat-ope-dev-int-gwc-snet-001"
    address_prefix   = "10.130.254.32/27"
    nsg_name         = "dpx-dat-ope-dev-int-gwc-nsg-001"
    route_table_name = "dpx-dat-ope-dev-int-gwc-rt-001"
  }
}

# Trusted storage and Key Vault endpoints: 4 in this subnet (trusted blob, trusted dfs,
# platform Key Vault, secret scope Key Vault). Published as private_endpoint_subnet_id.
trusted_private_endpoint_subnet = {
  name             = "dpx-dat-tpe-dev-int-gwc-snet-001"
  address_prefix   = "10.130.254.64/27"
  nsg_name         = "dpx-dat-tpe-dev-int-gwc-nsg-001"
  route_table_name = "dpx-dat-tpe-dev-int-gwc-rt-001"
}

databricks_workspaces = {
  anl = {
    host = {
      name             = "dpx-dat-ahx-dev-int-gwc-snet-001"
      address_prefix   = "10.130.252.0/25"
      nsg_name         = "dpx-dat-ahx-dev-int-gwc-nsg-001"
      route_table_name = "dpx-dat-ahx-dev-int-gwc-rt-001"
    }
    container = {
      name             = "dpx-dat-acx-dev-int-gwc-snet-001"
      address_prefix   = "10.130.252.128/25"
      nsg_name         = "dpx-dat-acx-dev-int-gwc-nsg-001"
      route_table_name = "dpx-dat-acx-dev-int-gwc-rt-001"
    }
  }
  ops = {
    host = {
      name             = "dpx-dat-opx-dev-int-gwc-snet-001"
      address_prefix   = "10.130.253.0/25"
      nsg_name         = "dpx-dat-opx-dev-int-gwc-nsg-001"
      route_table_name = "dpx-dat-opx-dev-int-gwc-rt-001"
    }
    container = {
      name             = "dpx-dat-ocx-dev-int-gwc-snet-001"
      address_prefix   = "10.130.253.128/25"
      nsg_name         = "dpx-dat-ocx-dev-int-gwc-nsg-001"
      route_table_name = "dpx-dat-ocx-dev-int-gwc-rt-001"
    }
  }
}

# Shared web-auth workspace in the management subscription dpx-sub-dat-mgt-gwc-001, which is
# not created yet. Names and ranges follow the Databricks LLD v0.1 (subscription dpx-sub-dat-mgt-gwc-001, 10.130.192.0/21)
# (VNet 10.130.199.0/24; 10.130.199.224/27 is spare). It is not deployed until the
# subscription exists: then set mgt_subscription_id from its variable group and
# deploy_web_auth = true. Only dev's state deploys it: one per region.
deploy_web_auth = true

web_auth = {
  resource_group_name = "dpx-dat-wau-mgt-gwc-rg-001"
  vnet = {
    name          = "dpx-dat-mgt-gwc-vnet-001"
    address_space = ["10.130.199.0/24"]
    dns_servers   = ["10.130.0.132"] # hub DNS
  }
  host_subnet = {
    name             = "dpx-dat-whx-mgt-gwc-snet-001"
    address_prefix   = "10.130.199.128/27"
    nsg_name         = "dpx-dat-whx-mgt-gwc-nsg-001"
    route_table_name = "dpx-dat-whx-mgt-gwc-rt-001"
  }
  container_subnet = {
    name             = "dpx-dat-wcx-mgt-gwc-snet-001"
    address_prefix   = "10.130.199.160/27"
    nsg_name         = "dpx-dat-wcx-mgt-gwc-nsg-001"
    route_table_name = "dpx-dat-wcx-mgt-gwc-rt-001"
  }
  private_endpoint_subnet = {
    name             = "dpx-dat-bpe-mgt-gwc-snet-001"
    address_prefix   = "10.130.199.192/27"
    nsg_name         = "dpx-dat-bpe-mgt-gwc-nsg-001"
    route_table_name = "dpx-dat-bpe-mgt-gwc-rt-001"
  }
  workspace_name              = "dpx-dat-wau-mgt-gwc-dbw-001"
  managed_resource_group_name = "dpx-dat-wau-mgt-gwc-rg-002"
  storage_connector_name      = "dpx-dat-wau-mgt-gwc-dbac-001"
}

# ---------------------------------------------------------------------------------------------
# NSG rules. Every rule is written out here; change a value here and nothing else.
# Default deny at 4096 on every subnet; a custom deny overrides Azure's built-in AllowVnetInBound,
# so traffic inside the VNet is allowed explicitly (priority 200). A priority may be used once per
# direction in one set. Keep the map keys and names as they are: renaming recreates the rule.
#
# Values to confirm before apply:
#   10.130.0.132    hub firewall address (rule 206) and hub DNS server (rule 207)
#   10.130.8.64/27  ZPA connectors' subnet, built from the management repo (rule 205 on ape and ope)
#   10.130.8.0/27   build agent pool's subnet (rule 206 on ape and ope, and the build agent NSG)
#   10.130.254.0/27, 10.130.254.32/27   ape and ope (build agent outbound rule 210)
# ---------------------------------------------------------------------------------------------
nsg_rules = {
  databricks_subnet = {
    allow_vnet_inbound = {
      name                       = "allow-vnet-inbound"
      priority                   = 200
      direction                  = "Inbound"
      access                     = "Allow"
      protocol                   = "*"
      source_address_prefix      = "VirtualNetwork"
      destination_port_range     = "*"
      destination_address_prefix = "VirtualNetwork"
    }
    allow_vnet_outbound = {
      name                       = "allow-vnet-outbound"
      priority                   = 200
      direction                  = "Outbound"
      access                     = "Allow"
      protocol                   = "*"
      source_address_prefix      = "VirtualNetwork"
      destination_port_range     = "*"
      destination_address_prefix = "VirtualNetwork"
    }
    allow_azure_dns_outbound = {
      name                       = "allow-azure-dns-outbound"
      priority                   = 205
      direction                  = "Outbound"
      protocol                   = "*"
      source_address_prefix      = "VirtualNetwork"
      destination_port_range     = "53"
      destination_address_prefix = "168.63.129.16"
    }
    allow_firewall_outbound = {
      name                       = "allow-hub-firewall-outbound"
      priority                   = 206
      direction                  = "Outbound"
      source_address_prefix      = "VirtualNetwork"
      destination_port_ranges    = ["443", "6666", "3306", "8443-8451"]
      destination_address_prefix = "10.130.0.132"
    }
    allow_custom_dns_outbound = {
      name                         = "allow-custom-dns-outbound"
      priority                     = 207
      direction                    = "Outbound"
      protocol                     = "*"
      source_address_prefix        = "VirtualNetwork"
      destination_port_range       = "53"
      destination_address_prefixes = ["10.130.0.132"]
    }
    allow_storage_0_outbound = {
      name                       = "allow-databricks-storage-0-outbound"
      priority                   = 220
      direction                  = "Outbound"
      source_address_prefix      = "VirtualNetwork"
      destination_port_range     = "443"
      destination_address_prefix = "Storage.GermanyWestCentral"
    }
    allow_storage_1_outbound = {
      name                       = "allow-databricks-storage-1-outbound"
      priority                   = 221
      direction                  = "Outbound"
      source_address_prefix      = "VirtualNetwork"
      destination_port_range     = "443"
      destination_address_prefix = "Storage.SwitzerlandNorth"
    }
    allow_eventhub_0_outbound = {
      name                       = "allow-databricks-eventhub-0-outbound"
      priority                   = 230
      direction                  = "Outbound"
      source_address_prefix      = "VirtualNetwork"
      destination_port_range     = "9093"
      destination_address_prefix = "EventHub.GermanyWestCentral"
    }
    deny_all_inbound = {
      name                       = "deny-all-inbound"
      priority                   = 4096
      direction                  = "Inbound"
      access                     = "Deny"
      protocol                   = "*"
      source_address_prefix      = "*"
      destination_port_range     = "*"
      destination_address_prefix = "*"
    }
    deny_all_outbound = {
      name                       = "deny-all-outbound"
      priority                   = 4096
      direction                  = "Outbound"
      access                     = "Deny"
      protocol                   = "*"
      source_address_prefix      = "*"
      destination_port_range     = "*"
      destination_address_prefix = "*"
    }
    # Off (the outbound-access note says private link makes them unnecessary). To turn one on, copy it in:
    #   allow_azuredatabricks_outbound  210  Outbound  443, 3306, 8443-8451  to AzureDatabricks
    #   allow_sql_outbound              240  Outbound  3306                  to Sql  (legacy Hive metastore)
    #   allow_internet_https_outbound   250  Outbound  443                   to Internet
  }
  workspace_endpoint = {
    allow_private_link_inbound = {
      name                       = "allow-databricks-private-link-inbound"
      priority                   = 200
      direction                  = "Inbound"
      source_address_prefix      = "VirtualNetwork"
      destination_port_ranges    = ["443", "6666", "3306", "8443-8451"]
      destination_address_prefix = "VirtualNetwork"
    }
    allow_vnet_outbound = {
      name                       = "allow-vnet-outbound"
      priority                   = 200
      direction                  = "Outbound"
      access                     = "Allow"
      protocol                   = "*"
      source_address_prefix      = "VirtualNetwork"
      destination_port_range     = "*"
      destination_address_prefix = "VirtualNetwork"
    }
    allow_external_https_inbound = {
      name                       = "allow-zpa-https-inbound"
      priority                   = 205
      direction                  = "Inbound"
      source_address_prefixes    = ["10.130.8.64/27"]
      destination_port_range     = "443"
      destination_address_prefix = "VirtualNetwork"
    }
    allow_build_agent_https_inbound = {
      name                       = "allow-build-agent-https-inbound"
      priority                   = 206
      direction                  = "Inbound"
      source_address_prefixes    = ["10.130.8.0/27"]
      destination_port_range     = "443"
      destination_address_prefix = "VirtualNetwork"
    }
    deny_all_inbound = {
      name                       = "deny-all-inbound"
      priority                   = 4096
      direction                  = "Inbound"
      access                     = "Deny"
      protocol                   = "*"
      source_address_prefix      = "*"
      destination_port_range     = "*"
      destination_address_prefix = "*"
    }
    deny_all_outbound = {
      name                       = "deny-all-outbound"
      priority                   = 4096
      direction                  = "Outbound"
      access                     = "Deny"
      protocol                   = "*"
      source_address_prefix      = "*"
      destination_port_range     = "*"
      destination_address_prefix = "*"
    }
  }
  trusted_endpoint = {
    allow_private_link_inbound = {
      name                       = "allow-databricks-private-link-inbound"
      priority                   = 200
      direction                  = "Inbound"
      source_address_prefix      = "VirtualNetwork"
      destination_port_ranges    = ["443", "6666", "3306", "8443-8451"]
      destination_address_prefix = "VirtualNetwork"
    }
    allow_vnet_outbound = {
      name                       = "allow-vnet-outbound"
      priority                   = 200
      direction                  = "Outbound"
      access                     = "Allow"
      protocol                   = "*"
      source_address_prefix      = "VirtualNetwork"
      destination_port_range     = "*"
      destination_address_prefix = "VirtualNetwork"
    }
    deny_all_inbound = {
      name                       = "deny-all-inbound"
      priority                   = 4096
      direction                  = "Inbound"
      access                     = "Deny"
      protocol                   = "*"
      source_address_prefix      = "*"
      destination_port_range     = "*"
      destination_address_prefix = "*"
    }
    deny_all_outbound = {
      name                       = "deny-all-outbound"
      priority                   = 4096
      direction                  = "Outbound"
      access                     = "Deny"
      protocol                   = "*"
      source_address_prefix      = "*"
      destination_port_range     = "*"
      destination_address_prefix = "*"
    }
  }
  web_auth_endpoint = {
    allow_private_link_inbound = {
      name                       = "allow-databricks-private-link-inbound"
      priority                   = 200
      direction                  = "Inbound"
      source_address_prefix      = "VirtualNetwork"
      destination_port_ranges    = ["443", "6666", "3306", "8443-8451"]
      destination_address_prefix = "VirtualNetwork"
    }
    allow_vnet_outbound = {
      name                       = "allow-vnet-outbound"
      priority                   = 200
      direction                  = "Outbound"
      access                     = "Allow"
      protocol                   = "*"
      source_address_prefix      = "VirtualNetwork"
      destination_port_range     = "*"
      destination_address_prefix = "VirtualNetwork"
    }
    allow_external_https_inbound = {
      name                       = "allow-zpa-https-inbound"
      priority                   = 205
      direction                  = "Inbound"
      source_address_prefixes    = ["10.130.8.64/27"]
      destination_port_range     = "443"
      destination_address_prefix = "VirtualNetwork"
    }
    allow_build_agent_https_inbound = {
      name                       = "allow-build-agent-https-inbound"
      priority                   = 206
      direction                  = "Inbound"
      source_address_prefixes    = ["10.130.8.0/27"]
      destination_port_range     = "443"
      destination_address_prefix = "VirtualNetwork"
    }
    allow_paas_https_outbound = {
      name                       = "allow-web-authentication-outbound"
      priority                   = 210
      direction                  = "Outbound"
      source_address_prefix      = "VirtualNetwork"
      destination_port_range     = "443"
      destination_address_prefix = "AzureDatabricks"
    }
    deny_all_inbound = {
      name                       = "deny-all-inbound"
      priority                   = 4096
      direction                  = "Inbound"
      access                     = "Deny"
      protocol                   = "*"
      source_address_prefix      = "*"
      destination_port_range     = "*"
      destination_address_prefix = "*"
    }
    deny_all_outbound = {
      name                       = "deny-all-outbound"
      priority                   = 4096
      direction                  = "Outbound"
      access                     = "Deny"
      protocol                   = "*"
      source_address_prefix      = "*"
      destination_port_range     = "*"
      destination_address_prefix = "*"
    }
  }
  build_agent = {
    allow_firewall_https_outbound = {
      name                       = "allow-hub-firewall-https-outbound"
      priority                   = 200
      direction                  = "Outbound"
      source_address_prefix      = "VirtualNetwork"
      destination_port_range     = "443"
      destination_address_prefix = "10.130.0.132"
    }
    allow_workspace_endpoints_outbound = {
      name                         = "allow-workspace-endpoints-outbound"
      priority                     = 210
      direction                    = "Outbound"
      source_address_prefix        = "VirtualNetwork"
      destination_port_range       = "443"
      destination_address_prefixes = ["10.130.254.0/27", "10.130.254.32/27"]
    }
  }
}
