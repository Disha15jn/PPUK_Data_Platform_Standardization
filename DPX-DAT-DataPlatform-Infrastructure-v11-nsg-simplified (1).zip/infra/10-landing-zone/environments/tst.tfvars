# infra/10-landing-zone: tst.
#
# PLACEHOLDER ranges: every address_prefix and the VNet range marked PLACEHOLDER below are NOT
# confirmed by the client. They follow dev's layout (dev: 10.130.252.0/22) so that validate and
# plan work. Replace them with the allocated ranges before the first apply: subnets cannot be
# resized in place once resources use them. Names follow dpx-dat-<id>-<env>-int-gwc-<type>-<nnn>.
#
# Subnet names are force-new on the Databricks workspace.
#
# subscription_id, tenant_id, law_central_sub_id and pdns_sub_id are identifiers: they come from
# the pipeline's variable groups, not from this file.

environment = "tst"
location    = "germanywestcentral"

# Placeholder ranges: plan and apply are blocked until the client confirms them and this is set to true.
ranges_confirmed            = false
network_resource_group_name = "dpx-dat-net-tst-int-gwc-rg-001"

vnet = {
  name          = "dpx-dat-net-tst-int-gwc-vnet-001"
  address_space = ["10.130.248.0/22"] # PLACEHOLDER: not confirmed by the client
}

private_endpoint_subnets = {
  anl = {
    name             = "dpx-dat-pep-tst-int-gwc-snet-001"
    address_prefix   = "10.130.250.0/27" # PLACEHOLDER
    nsg_name         = "dpx-dat-pep-tst-int-gwc-nsg-001"
    route_table_name = "dpx-dat-pep-tst-int-gwc-rt-001"
  }
  ops = {
    name             = "dpx-dat-pep-tst-int-gwc-snet-002"
    address_prefix   = "10.130.250.32/27" # PLACEHOLDER
    nsg_name         = "dpx-dat-pep-tst-int-gwc-nsg-002"
    route_table_name = "dpx-dat-pep-tst-int-gwc-rt-002"
  }
}

databricks_workspaces = {
  anl = {
    host = {
      name             = "dpx-dat-dbx-tst-int-gwc-snet-001"
      address_prefix   = "10.130.248.0/25" # PLACEHOLDER
      nsg_name         = "dpx-dat-dbx-tst-int-gwc-nsg-001"
      route_table_name = "dpx-dat-dbx-tst-int-gwc-rt-001"
    }
    container = {
      name             = "dpx-dat-dbx-tst-int-gwc-snet-002"
      address_prefix   = "10.130.248.128/25" # PLACEHOLDER
      nsg_name         = "dpx-dat-dbx-tst-int-gwc-nsg-002"
      route_table_name = "dpx-dat-dbx-tst-int-gwc-rt-002"
    }
  }
  ops = {
    host = {
      name             = "dpx-dat-dbx-tst-int-gwc-snet-003"
      address_prefix   = "10.130.249.0/25" # PLACEHOLDER
      nsg_name         = "dpx-dat-dbx-tst-int-gwc-nsg-003"
      route_table_name = "dpx-dat-dbx-tst-int-gwc-rt-003"
    }
    container = {
      name             = "dpx-dat-dbx-tst-int-gwc-snet-004"
      address_prefix   = "10.130.249.128/25" # PLACEHOLDER
      nsg_name         = "dpx-dat-dbx-tst-int-gwc-nsg-004"
      route_table_name = "dpx-dat-dbx-tst-int-gwc-rt-004"
    }
  }
}

# NSG rules: default deny, Databricks traffic allowed explicitly (the same as dev's, see dev.tfvars for the
# explanation). Not yet in this environment: the hub firewall rule (206) and custom DNS rule (207) on the
# compute subnets, the ZPA (205) and build agent (206) inbound rules on ape and ope, and the web-auth
# and trusted endpoint sets. Add them from dev.tfvars when this environment gets those.
nsg_rules = {
  databricks_subnet = {
    allow_vnet_inbound = {
      name                       = "allow-vnet-inbound"
      priority                   = 200
      direction                  = "Inbound"
      access                     = "Allow"
      protocol                   = "*"
      source_address_prefix      = "VirtualNetwork"
      destination_port_range     = "*"
      destination_address_prefix = "VirtualNetwork"
    }
    allow_vnet_outbound = {
      name                       = "allow-vnet-outbound"
      priority                   = 200
      direction                  = "Outbound"
      access                     = "Allow"
      protocol                   = "*"
      source_address_prefix      = "VirtualNetwork"
      destination_port_range     = "*"
      destination_address_prefix = "VirtualNetwork"
    }
    allow_azure_dns_outbound = {
      name                       = "allow-azure-dns-outbound"
      priority                   = 205
      direction                  = "Outbound"
      protocol                   = "*"
      source_address_prefix      = "VirtualNetwork"
      destination_port_range     = "53"
      destination_address_prefix = "168.63.129.16"
    }
    allow_storage_0_outbound = {
      name                       = "allow-databricks-storage-0-outbound"
      priority                   = 220
      direction                  = "Outbound"
      source_address_prefix      = "VirtualNetwork"
      destination_port_range     = "443"
      destination_address_prefix = "Storage.GermanyWestCentral"
    }
    allow_storage_1_outbound = {
      name                       = "allow-databricks-storage-1-outbound"
      priority                   = 221
      direction                  = "Outbound"
      source_address_prefix      = "VirtualNetwork"
      destination_port_range     = "443"
      destination_address_prefix = "Storage.SwitzerlandNorth"
    }
    allow_eventhub_0_outbound = {
      name                       = "allow-databricks-eventhub-0-outbound"
      priority                   = 230
      direction                  = "Outbound"
      source_address_prefix      = "VirtualNetwork"
      destination_port_range     = "9093"
      destination_address_prefix = "EventHub.GermanyWestCentral"
    }
    deny_all_inbound = {
      name                       = "deny-all-inbound"
      priority                   = 4096
      direction                  = "Inbound"
      access                     = "Deny"
      protocol                   = "*"
      source_address_prefix      = "*"
      destination_port_range     = "*"
      destination_address_prefix = "*"
    }
    deny_all_outbound = {
      name                       = "deny-all-outbound"
      priority                   = 4096
      direction                  = "Outbound"
      access                     = "Deny"
      protocol                   = "*"
      source_address_prefix      = "*"
      destination_port_range     = "*"
      destination_address_prefix = "*"
    }
    # Off (the outbound-access note says private link makes them unnecessary). To turn one on, copy it in:
    #   allow_azuredatabricks_outbound  210  Outbound  443, 3306, 8443-8451  to AzureDatabricks
    #   allow_sql_outbound              240  Outbound  3306                  to Sql  (legacy Hive metastore)
    #   allow_internet_https_outbound   250  Outbound  443                   to Internet
  }
  workspace_endpoint = {
    allow_private_link_inbound = {
      name                       = "allow-databricks-private-link-inbound"
      priority                   = 200
      direction                  = "Inbound"
      source_address_prefix      = "VirtualNetwork"
      destination_port_ranges    = ["443", "6666", "3306", "8443-8451"]
      destination_address_prefix = "VirtualNetwork"
    }
    allow_vnet_outbound = {
      name                       = "allow-vnet-outbound"
      priority                   = 200
      direction                  = "Outbound"
      access                     = "Allow"
      protocol                   = "*"
      source_address_prefix      = "VirtualNetwork"
      destination_port_range     = "*"
      destination_address_prefix = "VirtualNetwork"
    }
    deny_all_inbound = {
      name                       = "deny-all-inbound"
      priority                   = 4096
      direction                  = "Inbound"
      access                     = "Deny"
      protocol                   = "*"
      source_address_prefix      = "*"
      destination_port_range     = "*"
      destination_address_prefix = "*"
    }
    deny_all_outbound = {
      name                       = "deny-all-outbound"
      priority                   = 4096
      direction                  = "Outbound"
      access                     = "Deny"
      protocol                   = "*"
      source_address_prefix      = "*"
      destination_port_range     = "*"
      destination_address_prefix = "*"
    }
  }
}
