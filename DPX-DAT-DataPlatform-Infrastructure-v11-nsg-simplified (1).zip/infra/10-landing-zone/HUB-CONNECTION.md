# Connecting the dev network to the hub

The VNet, subnets, NSGs and route tables are built by this root. What is **not** built yet is the
connection to the hub, because the values come from the hub (Tier 0) team. The code is ready for
them: set the `hub` variable in `environments/dev.tfvars` and the next apply wires everything.
While `hub = {}`, nothing changes: route tables stay empty and the VNet uses Azure DNS. A
Terraform apply of the network works either way; clusters and SQL warehouses will not start, and
the build agents cannot reach the workspaces, until the hub is connected.

## What Terraform does once `hub` is set

The hub is a Virtual WAN hub, `dpx-inf-con-gwc-vhub-001` in resource group
`dpx-vhub-inf-con-gwc-rg-001`, subscription `b116cab1-74d6-4848-9bb2-32f11adf2f8c` (connectivity).
The values are in `environments/dev.tfvars`; `connect` is `false` until the pipeline identity has
rights on the hub.

| `hub` attribute | Effect |
|---|---|
| `connect = true` | looks up the hub and creates a VNet connection from this environment's VNet to it (`hub.tf`), and one for the web-auth VNet when that is deployed. The connection resource lives on the hub, so the identity needs Network Contributor (or equivalent) on the hub and `join` rights on our VNet |
| `internet_security_enabled` | sends `0.0.0.0/0` through the hub's firewall (a secured hub). Default true |
| `firewall_private_ip` | optional: also a `0.0.0.0/0` route to that IP on each Databricks subnet, only if the hub does not push the default route to spokes |
| `dns_servers` | custom DNS servers on the VNet, so `privatelink.*` names resolve through the hub |

No peering is created: a Virtual WAN hub connects spokes by VNet connection.

## What we still need from the hub team

1. **Rights** for the pipeline identity on the hub (above). Until then `connect` stays false and the
   network applies without it.
2. Whether the hub is **secured** (an Azure Firewall or routing intent on it), so that
   `internet_security_enabled` takes effect.
3. The **DNS servers** to set on the VNet, able to resolve `privatelink.azuredatabricks.net`,
   `privatelink.blob.core.windows.net`, `privatelink.dfs.core.windows.net` and
   `privatelink.vaultcore.azure.net`.
4. Confirmation that **the firewall rules below are added on the hub firewall**. It is not in our
   subscription and nothing in this repository manages it.

## Firewall rules the hub team need to add

Source: the host and container subnets of both workspaces (`ahx`, `acx`, `opx`, `ocx`). These are
the outbound rules Azure Databricks provisions on a VNet-injected workspace; the current list is
at <https://learn.microsoft.com/en-us/azure/databricks/security/network/classic/vnet-inject>.

| Destination | Port | Purpose |
|---|---|---|
| `AzureDatabricks` service tag | TCP 443 | Databricks infrastructure, secure cluster connectivity relay, library repositories |
| `AzureDatabricks` service tag | TCP 3306 | Metastore |
| `AzureDatabricks` service tag | TCP 8443 | Compute to control plane API calls, and API calls to the workspace from the compute plane |
| `AzureDatabricks` service tag | TCP 8444 | Unity Catalog logging and lineage streaming |
| `AzureDatabricks` service tag | TCP 8445-8451 | Reserved by Databricks for future use |
| `Storage` service tag (ideally `Storage.GermanyWestCentral`) | TCP 443 | Artifact, log and workspace storage |
| `EventHub` service tag | TCP 9093 | Event Hub |
| `Sql` service tag | TCP 3306 | Still needed for workspaces created with the current template |
| Between the four Databricks subnets | any | Cluster-internal traffic |

Also needed, from the diagram: the ADO build agent pool (`dpx_inf_gwc_linux_pba`) must reach
`accounts.azuredatabricks.net` over HTTPS (public) and each workspace's `ui-api` private endpoint
(`ape` and `ope` subnets), and users reach the workspaces through the firewall from on-premises.

Microsoft also says new VNets need an explicit outbound method. This design provides it with the
default route to the firewall; if the hub team prefer a NAT gateway for the Databricks subnets,
tell us and we will add one.

## Private DNS zones created here

`privatelink.azuredatabricks.net` and `privatelink.dfs.core.windows.net` are created by this root
in the environment's own subscription (`dns.tf`), each linked to the environment's VNet. Only
`blob` and `vault` still come from the shared central zones. Two consequences to agree with the hub
team:

- **Resolution from the hub.** For the hub firewall's DNS proxy, ADO agents and users to resolve
  these zones, the zones must also be linked to the VNet that does the resolving. The hub team add
  those links (or tell us the VNet ID and we add them here).
- **Duplicate zone names.** The central zone set may already have a `privatelink.azuredatabricks.net`
  or `privatelink.dfs.core.windows.net`. Two zones with the same name only cause trouble if one VNet
  is linked to both, so the hub must not link the same VNet to both.
- **Policy.** If Landing Zone policy denies creating `privatelink.*` zones in an application
  subscription, the plan will fail on these two zones; the policy would need an exemption.

## Web-auth workspace, in the management subscription

The shared web-auth workspace is in `web_auth.tf` and `infra/modules/databricks-web-auth`: its own
resource group and VNet (two delegated Databricks subnets and a private endpoint subnet, each with
an NSG and route table), a Premium workspace with public network access off and
`NoAzureDatabricksRules`, a Delete lock, and its single `browser_authentication` private endpoint
registering in the `databricks` zone (the `pl-auth` record).

The management subscription (`dpx-sub-dat-mgt-gwc-001`) does not exist yet, so nothing is deployed:
`deploy_web_auth = false`, and `mgt_subscription_id` is the all-zeros placeholder. When it exists:

1. Give the pipeline identity Contributor on it (and register Microsoft.Databricks, Microsoft.Network,
   Microsoft.Storage and Microsoft.OperationalInsights there: the provider is set not to register).
2. Add `mgt_subscription_id` to the variable group and `TF_VAR_mgt_subscription_id: $(mgt_subscription_id)`
   to the dev pipeline's plan and apply steps.
3. Set `deploy_web_auth = true` in `environments/dev.tfvars`. Only dev's state does this, because
   Azure allows one `browser_authentication` endpoint per region.

Because each environment now has its own `databricks` zone, the `pl-auth` record exists only in the
zone the web-auth endpoint registers in (dev's). Browser sign-in to tst, stg and prd workspaces needs
the same record in their zones: raise this with Tom and the hub team before those environments are used.

## Firewall and NSG rules

See `FIREWALL-AND-NSG-RULES.md` for every rule the platform needs (from the Cynozure outbound-access note, the diagram and the LLD), and `FIREWALL-RULES-for-hub-team.csv` for the firewall rules in a form the hub team can enter or import.

## ZPA connectors

The ZPA connector VMs are built from the management repo (DPX-AVM-MANAGEMENT), not from this one.
This repo only needs their subnet, `dpx-inf-zpa-mgt-gwc-snet-001` (10.130.8.64/27), which is the source
of `allow_external_https_inbound` in `nsg_rules` in `environments/<env>.tfvars` (ape, ope and the web-auth
endpoint subnet accept https on 443 from it).

## Browser sign-in: the `pl-auth` record

Azure allows one `pl-auth.germanywestcentral` record per region and private DNS zone, and it must
point at the `browser_authentication` endpoint. Before the web-auth workspace registers it, check
that no other workspace already owns it in the central zone:

```bash
az network private-dns record-set a list \
  --subscription <pdns_sub_id> \
  --resource-group ppg-pdns-shd-con-gwc-rg-001 \
  --zone-name privatelink.azuredatabricks.net \
  --query "[?starts_with(name, 'pl-auth')].{name:name, ips:aRecords[].ipv4Address}" -o table
```

An empty result means it is free. Overwriting an existing record breaks browser sign-in for the
workspaces that use it.
