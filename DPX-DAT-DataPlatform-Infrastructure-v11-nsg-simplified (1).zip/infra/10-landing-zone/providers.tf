provider "azurerm" {
  features {
  }
  subscription_id                 = var.subscription_id
  resource_provider_registrations = "none"
}

provider "azapi" {
  subscription_id = var.subscription_id
  tenant_id       = var.tenant_id
}

# Central Log Analytics workspace's subscription (read-only lookups).
provider "azurerm" {
  alias = "law"

  features {}
  subscription_id                 = var.law_central_sub_id
  resource_provider_registrations = "none"
}

# Hub private DNS zones' subscription (read-only lookups).

# Management subscription (dpx-sub-dat-mgt-gwc-001): the shared web-auth workspace. The
# subscription does not exist yet, so this provider only configures lazily: nothing uses it
# while deploy_web_auth is false.
provider "azurerm" {
  alias = "mgt"

  features {}
  subscription_id = var.mgt_subscription_id

  resource_provider_registrations = "none"
}

provider "azapi" {
  alias = "mgt"

  subscription_id = var.mgt_subscription_id
  tenant_id       = var.tenant_id
}

# Infrastructure management subscription: the build agent pool's NSG. Falls back to the central
# Log Analytics subscription, which is the same subscription (dpx-sub-inf-mgt-gwc-001).
provider "azurerm" {
  alias = "infra_mgt"

  features {}
  subscription_id = coalesce(var.infra_mgt_subscription_id, var.law_central_sub_id)

  resource_provider_registrations = "none"
}

provider "azapi" {
  alias = "infra_mgt"

  subscription_id = coalesce(var.infra_mgt_subscription_id, var.law_central_sub_id)
  tenant_id       = var.tenant_id
}

# Connectivity subscription: the Virtual WAN hub, and the VNet connections that live on it.
provider "azurerm" {
  alias = "connectivity"

  features {}
  subscription_id = coalesce(var.hub.connectivity_subscription_id, var.subscription_id)

  resource_provider_registrations = "none"
}



