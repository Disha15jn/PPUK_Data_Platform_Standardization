# Outbound rules on the build agent pool's existing NSG (subnet dpx-pba-inf-mgt-gwc-snet-001 in
# the infrastructure management subscription): https to the hub firewall, and to the workspace
# endpoint subnets. Off until build_agent.manage_nsg_rules is true; the subnet and NSG belong to
# the infrastructure team, so otherwise the same rules are listed in FIREWALL-AND-NSG-RULES.md.

resource "azurerm_network_security_rule" "build_agent" {
  for_each = var.build_agent.manage_nsg_rules ? lookup(var.nsg_rules, "build_agent", {}) : {}
  provider = azurerm.infra_mgt

  depends_on = [terraform_data.build_agent_ready]

  access                       = each.value.access
  destination_address_prefix   = each.value.destination_address_prefix
  destination_address_prefixes = each.value.destination_address_prefixes
  destination_port_range       = each.value.destination_port_range
  destination_port_ranges      = each.value.destination_port_ranges
  direction                    = each.value.direction
  name                         = each.value.name
  network_security_group_name  = var.build_agent.nsg_name
  priority                     = each.value.priority
  protocol                     = each.value.protocol
  resource_group_name          = var.build_agent.nsg_resource_group_name
  source_address_prefix        = each.value.source_address_prefix
  source_address_prefixes      = each.value.source_address_prefixes
  source_port_range            = each.value.source_port_range
}
