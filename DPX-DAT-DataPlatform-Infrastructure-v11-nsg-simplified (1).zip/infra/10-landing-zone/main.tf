
module "databricks_network_rg" {
  source           = "Azure/avm-res-resources-resourcegroup/azurerm"
  version          = "0.4.0"
  name             = var.network_resource_group_name
  location         = var.location
  enable_telemetry = false
  tags             = var.tags
}

module "databricks_vnet" {
  source           = "Azure/avm-res-network-virtualnetwork/azurerm"
  name             = var.vnet.name
  version          = "0.22.2"
  location         = var.location
  parent_id        = module.databricks_network_rg.resource_id
  enable_telemetry = false
  address_space    = var.vnet.address_space
  tags             = var.tags

  # Empty keeps Azure-provided DNS.
  dns_servers = length(var.vnet.dns_servers) == 0 ? null : { dns_servers = var.vnet.dns_servers }
}

module "databricks_subnets" {
  for_each                                  = local.subnets
  source                                    = "Azure/avm-res-network-virtualnetwork/azurerm//modules/subnet"
  version                                   = "0.22.2"
  name                                      = local.subnets[each.key].name
  address_prefix                            = local.subnets[each.key].address_space
  parent_id                                 = module.databricks_vnet.resource_id
  delegations                               = local.subnets[each.key].delegations
  private_endpoint_network_policies_enabled = local.subnets[each.key].private_endpoint_network_policies_enabled
  private_endpoint_network_policies         = local.subnets[each.key].private_endpoint_network_policies
  network_security_group = contains(keys(local.subnets_with_nsg), each.key) ? {
    id = module.all_nsgs[each.key].resource_id
  } : null
  route_table = contains(keys(local.subnets_with_route_table), each.key) ? {
    id = module.all_route_tables[each.key].resource_id
  } : null

  depends_on = [module.all_nsgs, module.all_route_tables]
}

module "all_nsgs" {
  for_each            = local.subnets_with_nsg
  source              = "Azure/avm-res-network-networksecuritygroup/azurerm"
  version             = "0.5.2"
  name                = local.subnets[each.key].nsg
  security_rules      = lookup(var.nsg_rules, local.subnets[each.key].nsg_rule_set, {})
  location            = var.location
  resource_group_name = module.databricks_network_rg.name
  enable_telemetry    = false
  tags                = var.tags
}

module "all_route_tables" {
  for_each            = local.subnets_with_route_table
  source              = "Azure/avm-res-network-routetable/azurerm"
  version             = "0.5.0"
  name                = local.subnets[each.key].rt
  routes              = lookup(local.route_table_routes, each.key, {})
  location            = var.location
  resource_group_name = module.databricks_network_rg.name
  enable_telemetry    = false
  tags                = var.tags
}
