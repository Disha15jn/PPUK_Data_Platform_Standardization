# The databricks and dfs private DNS zones, created in this environment's own subscription
# instead of looked up in the shared central one. blob and vault still come from the shared
# zones (data.tf). Each zone is linked to this environment's VNet; the databricks zone is
# also linked to the web-auth VNet when it is deployed, so
# the browser_authentication endpoint's pl-auth record and the workspaces' private names resolve
# there.
#
# For hub users and the hub firewall's DNS to resolve these zones, the hub VNet needs a link
# to them too, which the hub team add (see HUB-CONNECTION.md).

locals {
  # The zone IDs published to the platform root: created here, or the shared central zones.
  databricks_zone_id = data.azurerm_private_dns_zone.databricks.id
  dfs_zone_id        = data.azurerm_private_dns_zone.dfs.id
  blob_zone_id       = data.azurerm_private_dns_zone.blob.id
  vault_zone_id      = data.azurerm_private_dns_zone.vault.id
}
