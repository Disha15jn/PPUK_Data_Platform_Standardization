terraform {
  required_version = "~> 1.16"

  required_providers {
    azapi = {
      source  = "Azure/azapi"
      version = "~> 2.12"
    }
    azurerm = {
      source  = "hashicorp/azurerm"
      version = "~> 4.81"
    }
  }

  # Partial configuration: the pipeline's Terraform-Init supplies the storage account,
  # container and key (landing-zone/<env>.tfstate); a local init uses
  # environments/<env>.tfbackend, made from its template and never tracked.
  backend "azurerm" {}
}
