# The shared web-auth workspace, in the management subscription (dpx-sub-dat-mgt-gwc-001).
# Azure allows one browser_authentication endpoint per region and private DNS zone, so this
# is created by one environment's state only (deploy_web_auth, set in dev).
#
# The subscription is not created yet: mgt_subscription_id stays the all-zeros placeholder
# and deploy_web_auth stays false until it is. See HUB-CONNECTION.md.

module "web_auth" {
  source = "../modules/databricks-web-auth"
  count  = var.deploy_web_auth ? 1 : 0

  providers = {
    azurerm = azurerm.mgt
    azapi   = azapi.mgt
  }

  container_subnet               = var.web_auth.container_subnet
  databricks_subnet_nsg_rules    = lookup(var.nsg_rules, "databricks_subnet", {})
  private_endpoint_nsg_rules     = lookup(var.nsg_rules, "web_auth_endpoint", {})
  tags                           = var.tags
  databricks_private_dns_zone_id = coalesce(var.web_auth.private_dns_zone_id, local.databricks_zone_id)
  host_subnet                    = var.web_auth.host_subnet
  location                       = var.location
  log_analytics_workspace_id     = data.azurerm_log_analytics_workspace.central.id
  managed_resource_group_name    = var.web_auth.managed_resource_group_name
  private_endpoint_subnet        = var.web_auth.private_endpoint_subnet
  resource_group_name            = var.web_auth.resource_group_name
  storage_connector_name         = var.web_auth.storage_connector_name
  vnet                           = var.web_auth.vnet
  workspace_name                 = var.web_auth.workspace_name

  depends_on = [terraform_data.web_auth_ready]
}
