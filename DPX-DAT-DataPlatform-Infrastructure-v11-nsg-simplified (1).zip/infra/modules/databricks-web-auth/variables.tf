variable "resource_group_name" {
  description = "Name of the web-auth resource group in the management subscription."
  type        = string
  nullable    = false
}

variable "location" {
  description = "Azure region."
  type        = string
  nullable    = false
}

variable "vnet" {
  description = "The web-auth VNet: name, address space and custom DNS servers (empty keeps Azure-provided DNS)."
  type = object({
    name          = string
    address_space = list(string)
    dns_servers   = optional(list(string), [])
  })
  nullable = false
}

variable "host_subnet" {
  description = "The workspace's host (public) subnet, with its NSG and route table names."
  type = object({
    name             = string
    address_prefix   = string
    nsg_name         = string
    route_table_name = string
  })
  nullable = false
}

variable "container_subnet" {
  description = "The workspace's container (private) subnet, with its NSG and route table names."
  type = object({
    name             = string
    address_prefix   = string
    nsg_name         = string
    route_table_name = string
  })
  nullable = false
}

variable "private_endpoint_subnet" {
  description = "The subnet for the browser_authentication private endpoint, with its NSG and route table names."
  type = object({
    name             = string
    address_prefix   = string
    nsg_name         = string
    route_table_name = string
  })
  nullable = false
}

variable "databricks_subnet_nsg_rules" {
  description = "NSG rules for the host and container subnets (from modules/nsg-rules)."
  type        = any
  nullable    = false
}

variable "private_endpoint_nsg_rules" {
  description = "NSG rules for the private endpoint subnet (from modules/nsg-rules)."
  type        = any
  nullable    = false
}

variable "workspace_name" {
  description = "Name of the web-auth workspace."
  type        = string
  nullable    = false
}

variable "managed_resource_group_name" {
  description = "Name of the resource group Azure creates for the workspace's managed resources. Unique per subscription."
  type        = string
  nullable    = false
}

variable "storage_connector_name" {
  description = "Name of the Access Connector Azure Databricks uses to reach the workspace storage account once its firewall is on."
  type        = string
  nullable    = false
}

variable "lock_name" {
  description = "Name of the Delete lock on the workspace. Without it, deleting the workspace breaks browser sign-in for every workspace in the region."
  type        = string
  default     = "lock-web-auth-do-not-delete"
  nullable    = false
}

variable "databricks_private_dns_zone_id" {
  description = "Resource ID of the privatelink.azuredatabricks.net zone the browser_authentication endpoint registers in (the pl-auth record)."
  type        = string
  nullable    = false
}

variable "log_analytics_workspace_id" {
  description = "Resource ID of the Log Analytics workspace that receives the workspace's diagnostics."
  type        = string
  nullable    = false
}

variable "enable_telemetry" {
  description = "Whether the Azure Verified Modules send usage telemetry to Microsoft."
  type        = bool
  default     = false
  nullable    = false
}

variable "tags" {
  description = "Tags for the resources."
  type        = map(string)
  default     = null
}
