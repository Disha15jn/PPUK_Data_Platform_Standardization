output "virtual_network_id" {
  description = "Resource ID of the web-auth VNet."
  value       = module.vnet.resource_id
}

output "workspace_id" {
  description = "Azure resource ID of the web-auth workspace."
  value       = module.workspace.resource_id
}

output "workspace_name" {
  description = "Name of the web-auth workspace."
  value       = module.workspace.name
}

output "private_endpoint_subnet_id" {
  description = "Resource ID of the subnet holding the browser_authentication endpoint."
  value       = module.subnets["private_endpoint"].resource_id
}
