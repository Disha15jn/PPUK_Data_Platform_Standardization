# The shared web-auth workspace, in the management subscription.
#
# Browser sign-in to a workspace with public access off needs one browser_authentication
# private endpoint per region and private DNS zone. This workspace exists only to hold it:
# no workloads, and no databricks_ui_api endpoint. It is Premium, injected into a VNet of
# its own, public network access off, NoAzureDatabricksRules, with a Delete lock.
#
# The caller passes this module the azurerm and azapi providers of the management
# subscription (providers = { azurerm = azurerm.mgt, azapi = azapi.mgt }), so everything
# here, Verified Modules included, is created in that subscription.

locals {
  subnets = {
    host = {
      subnet      = var.host_subnet
      delegations = [{ name = "databricks_workspace_delegation_host", service_delegation = { name = "Microsoft.Databricks/workspaces" } }]
      policies    = "Disabled"
      nsg_rules   = var.databricks_subnet_nsg_rules
    }
    container = {
      subnet      = var.container_subnet
      delegations = [{ name = "databricks_workspace_delegation_container", service_delegation = { name = "Microsoft.Databricks/workspaces" } }]
      policies    = "Disabled"
      nsg_rules   = var.databricks_subnet_nsg_rules
    }
    private_endpoint = {
      subnet      = var.private_endpoint_subnet
      delegations = null
      policies    = "Enabled"
      nsg_rules   = var.private_endpoint_nsg_rules
    }
  }

  diagnostic_settings = {
    log_analytics = {
      workspace_resource_id = var.log_analytics_workspace_id
      metric_categories     = []
    }
  }
}

module "resource_group" {
  source  = "Azure/avm-res-resources-resourcegroup/azurerm"
  version = "0.4.0"

  enable_telemetry = var.enable_telemetry
  location         = var.location
  name             = var.resource_group_name
  tags             = var.tags
}

module "vnet" {
  source  = "Azure/avm-res-network-virtualnetwork/azurerm"
  version = "0.22.2"

  address_space    = var.vnet.address_space
  dns_servers      = length(var.vnet.dns_servers) == 0 ? null : { dns_servers = var.vnet.dns_servers }
  enable_telemetry = var.enable_telemetry
  location         = var.location
  name             = var.vnet.name
  parent_id        = module.resource_group.resource_id
  tags             = var.tags
}

module "nsgs" {
  source   = "Azure/avm-res-network-networksecuritygroup/azurerm"
  version  = "0.5.2"
  for_each = local.subnets

  enable_telemetry    = var.enable_telemetry
  location            = var.location
  name                = each.value.subnet.nsg_name
  resource_group_name = module.resource_group.name
  security_rules      = each.value.nsg_rules
  tags                = var.tags
}

module "route_tables" {
  source   = "Azure/avm-res-network-routetable/azurerm"
  version  = "0.5.0"
  for_each = local.subnets

  enable_telemetry    = var.enable_telemetry
  location            = var.location
  name                = each.value.subnet.route_table_name
  resource_group_name = module.resource_group.name
  tags                = var.tags
}

module "subnets" {
  source   = "Azure/avm-res-network-virtualnetwork/azurerm//modules/subnet"
  version  = "0.22.2"
  for_each = local.subnets

  address_prefix                            = each.value.subnet.address_prefix
  delegations                               = each.value.delegations
  name                                      = each.value.subnet.name
  network_security_group                    = { id = module.nsgs[each.key].resource_id }
  parent_id                                 = module.vnet.resource_id
  private_endpoint_network_policies         = each.value.policies
  private_endpoint_network_policies_enabled = true
  route_table                               = { id = module.route_tables[each.key].resource_id }

  depends_on = [module.nsgs, module.route_tables]
}

# The Verified Module looks up its resource group with a data source at plan time, which
# fails on a first plan while the group does not exist yet. terraform_data's output is
# unknown until it is created, so the lookup waits for the apply (same pattern as
# infra/modules/databricks-workspace).
resource "terraform_data" "resource_group_ready" {
  input = var.resource_group_name

  depends_on = [module.resource_group]
}

# Azure Databricks reaches the workspace storage account through this connector once the
# account's firewall is on.
module "storage_access_connector" {
  source  = "Azure/avm-res-databricks-accessconnector/azurerm"
  version = "0.1.0"

  enable_telemetry = var.enable_telemetry
  location         = var.location
  managed_identities = {
    system_assigned = true
  }
  name      = var.storage_connector_name
  parent_id = module.resource_group.resource_id
  tags      = var.tags
}

module "workspace" {
  source  = "Azure/avm-res-databricks-workspace/azurerm"
  version = "0.5.0"

  access_connector_id = module.storage_access_connector.resource_id
  custom_parameters = {
    no_public_ip                                         = true
    virtual_network_id                                   = module.vnet.resource_id
    public_subnet_name                                   = var.host_subnet.name
    public_subnet_network_security_group_association_id  = module.subnets["host"].resource_id
    private_subnet_name                                  = var.container_subnet.name
    private_subnet_network_security_group_association_id = module.subnets["container"].resource_id
  }
  default_storage_firewall_enabled      = true
  diagnostic_settings                   = local.diagnostic_settings
  enable_telemetry                      = var.enable_telemetry
  infrastructure_encryption_enabled     = true
  location                              = var.location
  lock                                  = { kind = "CanNotDelete", name = var.lock_name }
  managed_resource_group_name           = var.managed_resource_group_name
  name                                  = var.workspace_name
  network_security_group_rules_required = "NoAzureDatabricksRules"

  # The only private endpoint this workspace has: browser_authentication, in the private
  # endpoint subnet, registered in the central databricks zone (the pl-auth record).
  private_endpoints = {
    browser_authentication = {
      subresource_name              = "browser_authentication"
      subnet_resource_id            = module.subnets["private_endpoint"].resource_id
      private_dns_zone_resource_ids = [var.databricks_private_dns_zone_id]
    }
  }
  private_endpoints_manage_dns_zone_group = true
  public_network_access_enabled           = false
  resource_group_name                     = terraform_data.resource_group_ready.output
  sku                                     = "premium"
  tags                                    = var.tags
}
