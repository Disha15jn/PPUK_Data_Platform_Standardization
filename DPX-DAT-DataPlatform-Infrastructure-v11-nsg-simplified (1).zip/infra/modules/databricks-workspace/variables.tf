variable "container_subnet" {
  description = "The workspace's container (private) subnet, from the network and security state: its resource ID, which is also its NSG association ID, and its name."
  type = object({
    id   = string
    name = string
  })
  nullable = false
}

variable "host_subnet" {
  description = "The workspace's host (public) subnet, from the network and security state: its resource ID, which is also its NSG association ID, and its name."
  type = object({
    id   = string
    name = string
  })
  nullable = false
}

variable "location" {
  description = "Azure region for the workspace."
  type        = string
  nullable    = false
}

variable "log_analytics_workspace_id" {
  description = "Resource ID of the Log Analytics workspace that receives the workspace's diagnostics."
  type        = string
  nullable    = false
}

variable "managed_resource_group_name" {
  description = "Name of the resource group Azure creates for the workspace's managed resources. Unique per subscription."
  type        = string
  nullable    = false

  validation {
    condition     = can(regex("^[-\\w\\.\\(\\)]{1,90}$", var.managed_resource_group_name)) && !endswith(var.managed_resource_group_name, ".")
    error_message = "A resource group name is 1 to 90 letters, digits, underscores, hyphens, periods and parentheses, and cannot end with a period."
  }
}

variable "name" {
  description = "Workspace name, as the Calandra team agreed it."
  type        = string
  nullable    = false

  validation {
    condition     = can(regex("^[A-Za-z0-9][A-Za-z0-9_-]{1,62}[A-Za-z0-9]$", var.name))
    error_message = "A Databricks workspace name is 3 to 64 letters, digits, underscores and hyphens, starting and ending with a letter or digit."
  }
}

variable "private_endpoint" {
  description = <<-EOT
    Where the workspace's private endpoints go: its databricks_ui_api endpoint, and
    the blob and dfs endpoints on the workspace storage account.
    - subnet_id: the private endpoint subnet.
    - private_dns_zone_ids: central private DNS zone IDs by key; 'databricks', 'blob'
      and 'dfs' are used.
    - manage_dns_zone_group: false if Landing Zone policy creates the DNS zone groups.
  EOT
  type = object({
    subnet_id             = string
    private_dns_zone_ids  = map(string)
    manage_dns_zone_group = optional(bool, true)
  })
  nullable = false

  validation {
    condition     = alltrue([for key in ["databricks", "blob", "dfs"] : contains(keys(var.private_endpoint.private_dns_zone_ids), key)])
    error_message = "private_dns_zone_ids must include 'databricks', 'blob' and 'dfs'."
  }
}

variable "resource_group_id" {
  description = "Resource ID of the resource group the workspace belongs to, which also holds its storage Access Connector."
  type        = string
  nullable    = false
}

variable "resource_group_name" {
  description = "Name of the resource group the workspace belongs to, which also holds the workspace storage account's private endpoints."
  type        = string
  nullable    = false
}

variable "storage_connector_name" {
  description = "Name of the Access Connector Azure Databricks uses to reach the workspace storage account once its firewall is on, as the Calandra team agreed it."
  type        = string
  nullable    = false

  validation {
    condition     = can(regex("^[A-Za-z0-9][A-Za-z0-9_.-]{1,62}[A-Za-z0-9_]$", var.storage_connector_name))
    error_message = "An Access Connector name is 3 to 64 letters, digits, underscores, periods and hyphens, starting with a letter or digit and ending with a letter, digit or underscore."
  }
}

variable "virtual_network_id" {
  description = "Resource ID of the VNet the workspace is injected into. Force-new on the workspace."
  type        = string
  nullable    = false
}

variable "enable_telemetry" {
  description = "Whether the Azure Verified Module sends usage telemetry to Microsoft. Off unless the client chooses otherwise."
  type        = bool
  default     = false
  nullable    = false
}

variable "storage_account_sku_name" {
  description = "SKU of the workspace's own storage account, which sets its replication: Standard_LRS or Standard_ZRS. Zone-redundant by default, so the data stays in the region."
  type        = string
  default     = "Standard_ZRS"
  nullable    = false

  validation {
    condition     = contains(["Standard_LRS", "Standard_ZRS"], var.storage_account_sku_name)
    error_message = "storage_account_sku_name must be Standard_LRS or Standard_ZRS: both keep the data in the region, and geo-redundant replication copies it to another."
  }
}

variable "tags" {
  description = "Tags for the workspace."
  type        = map(string)
  default     = {}
  nullable    = false
}
