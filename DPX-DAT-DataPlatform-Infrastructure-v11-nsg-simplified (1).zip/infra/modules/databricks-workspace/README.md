# Databricks workspace

An Azure Databricks workspace, wrapping `avm-res-databricks-workspace`: premium, VNet-injected with secure cluster connectivity, and reached only through Private Link. The workspace storage account's firewall is on, so that account too is reached only through private endpoints: the wrapper creates the Access Connector Azure Databricks uses for it and, through `avm-res-network-privateendpoint`, the account's blob and dfs endpoints. The one plain resource in the platform root is the variant of those endpoints used when Landing Zone policy creates the DNS zone groups, which the module cannot ignore. It outputs the region number parsed from the workspace URL, which the Databricks root builds its provider host from.

Part of `infra/20-platform-services`, which calls it from its `main.tf`. Validated through that root, never on its own.

<!-- BEGIN_TF_DOCS -->
## Requirements

| Name | Version |
| ---- | ------- |
| terraform | ~> 1.16 |
| azapi | ~> 2.12 |
| azurerm | ~> 4.81 |

## Providers

| Name | Version |
| ---- | ------- |
| azapi | ~> 2.12 |
| azurerm | ~> 4.81 |
| terraform | n/a |

## Modules

| Name | Source | Version |
| ---- | ------ | ------- |
| storage\_access\_connector | Azure/avm-res-databricks-accessconnector/azurerm | 0.1.0 |
| workspace | Azure/avm-res-databricks-workspace/azurerm | 0.5.0 |
| workspace\_storage\_private\_endpoint | Azure/avm-res-network-privateendpoint/azurerm | 0.2.0 |

## Resources

| Name | Type |
| ---- | ---- |
| [azurerm_private_endpoint.workspace_storage_unmanaged_dns](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/private_endpoint) | resource |
| [terraform_data.resource_group_ready](https://registry.terraform.io/providers/hashicorp/terraform/latest/docs/resources/data) | resource |
| [azapi_resource.workspace](https://registry.terraform.io/providers/Azure/azapi/latest/docs/data-sources/resource) | data source |

## Inputs

| Name | Description | Type | Default | Required |
| ---- | ----------- | ---- | ------- | :------: |
| container\_subnet | The workspace's container (private) subnet, from the network and security state: its resource ID, which is also its NSG association ID, and its name. | <pre>object({<br/>    id   = string<br/>    name = string<br/>  })</pre> | n/a | yes |
| host\_subnet | The workspace's host (public) subnet, from the network and security state: its resource ID, which is also its NSG association ID, and its name. | <pre>object({<br/>    id   = string<br/>    name = string<br/>  })</pre> | n/a | yes |
| location | Azure region for the workspace. | `string` | n/a | yes |
| log\_analytics\_workspace\_id | Resource ID of the Log Analytics workspace that receives the workspace's diagnostics. | `string` | n/a | yes |
| managed\_resource\_group\_name | Name of the resource group Azure creates for the workspace's managed resources. Unique per subscription. | `string` | n/a | yes |
| name | Workspace name, as the Calandra team agreed it. | `string` | n/a | yes |
| private\_endpoint | Where the workspace's private endpoints go: its databricks\_ui\_api endpoint, and<br/>the blob and dfs endpoints on the workspace storage account.<br/>- subnet\_id: the private endpoint subnet.<br/>- private\_dns\_zone\_ids: central private DNS zone IDs by key; 'databricks', 'blob'<br/>  and 'dfs' are used.<br/>- manage\_dns\_zone\_group: false if Landing Zone policy creates the DNS zone groups. | <pre>object({<br/>    subnet_id             = string<br/>    private_dns_zone_ids  = map(string)<br/>    manage_dns_zone_group = optional(bool, true)<br/>  })</pre> | n/a | yes |
| resource\_group\_id | Resource ID of the resource group the workspace belongs to, which also holds its storage Access Connector. | `string` | n/a | yes |
| resource\_group\_name | Name of the resource group the workspace belongs to, which also holds the workspace storage account's private endpoints. | `string` | n/a | yes |
| storage\_connector\_name | Name of the Access Connector Azure Databricks uses to reach the workspace storage account once its firewall is on, as the Calandra team agreed it. | `string` | n/a | yes |
| virtual\_network\_id | Resource ID of the VNet the workspace is injected into. Force-new on the workspace. | `string` | n/a | yes |
| enable\_telemetry | Whether the Azure Verified Module sends usage telemetry to Microsoft. Off unless the client chooses otherwise. | `bool` | `false` | no |
| storage\_account\_sku\_name | SKU of the workspace's own storage account, which sets its replication: Standard\_LRS or Standard\_ZRS. Zone-redundant by default, so the data stays in the region. | `string` | `"Standard_ZRS"` | no |
| tags | Tags for the workspace. | `map(string)` | `{}` | no |

## Outputs

| Name | Description |
| ---- | ----------- |
| diagnostic\_workspace\_ids | The Log Analytics workspaces the workspace's diagnostic settings send to, so that tests can check them. |
| name | Name of the workspace. |
| network\_settings | The VNet and subnets the workspace is injected into, so that tests can check them. |
| private\_endpoint\_settings | The subnet and DNS zone of each of the workspace's private endpoints, by sub-resource, so that tests can check them. |
| resource\_id | Azure resource ID of the workspace. |
| settings | The workspace's fixed network and encryption settings, so that tests can check them. |
| storage\_account\_sku\_name | The SKU of the workspace's own storage account, which sets its replication, so that tests can check it. |
| storage\_firewall | The workspace storage account's firewall: the Access Connector passed to the Verified Module, and that connector's name, so that tests can check them. Whether it is on is in settings. |
| storage\_private\_endpoint\_settings | The workspace storage account's private endpoints, by sub-resource: name, resource group, subnet, target and DNS zones, as passed to the private endpoint module or planned as the policy-managed resource, so that tests can check them. |
| workspace\_id | The workspace's numeric ID in the Databricks control plane. |
| workspace\_region\_number | The number in the workspace URL, adb-<workspace\_id>.<number>.azuredatabricks.net, which the Databricks provider host is built from. Fails rather than returning null if the URL has another form. |
| workspace\_url | The workspace URL, adb-<workspace\_id>.<number>.azuredatabricks.net. |
<!-- END_TF_DOCS -->
