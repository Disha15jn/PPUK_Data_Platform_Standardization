variable "location" {
  description = "Azure region for the identity."
  type        = string
  nullable    = false
}

variable "name" {
  description = "Managed identity name, as the Calandra team agreed it."
  type        = string
  nullable    = false

  validation {
    condition     = can(regex("^[A-Za-z0-9][A-Za-z0-9_-]{2,127}$", var.name))
    error_message = "A managed identity name is 3 to 128 letters, digits, underscores and hyphens, starting with a letter or digit."
  }
}

variable "resource_group_name" {
  description = "Name of the resource group the identity belongs to."
  type        = string
  nullable    = false
}

variable "enable_telemetry" {
  description = "Whether the Azure Verified Module sends usage telemetry to Microsoft. Off unless the client chooses otherwise."
  type        = bool
  default     = false
  nullable    = false
}

variable "tags" {
  description = "Tags for the identity."
  type        = map(string)
  default     = {}
  nullable    = false
}
