output "client_id" {
  description = "Client (application) ID of the identity."
  value       = module.managed_identity.client_id
}

output "principal_id" {
  description = "Principal (object) ID of the identity, for the Calandra team to add to the tier's sp-databricks group."
  value       = module.managed_identity.principal_id
}

output "resource_id" {
  description = "Resource ID of the identity."
  value       = module.managed_identity.resource_id
}
