# A user-assigned managed identity for a Databricks workload.
#
# The identity gets no Azure or Databricks rights here. It reaches Databricks
# as a member of its tier's sp-databricks Entra group, which the Calandra
# team manage by hand, so this module outputs the principal ID they need.

module "managed_identity" {
  source  = "Azure/avm-res-managedidentity-userassignedidentity/azurerm"
  version = "0.5.2"

  enable_telemetry    = var.enable_telemetry
  location            = var.location
  name                = var.name
  resource_group_name = var.resource_group_name
  tags                = var.tags
}
