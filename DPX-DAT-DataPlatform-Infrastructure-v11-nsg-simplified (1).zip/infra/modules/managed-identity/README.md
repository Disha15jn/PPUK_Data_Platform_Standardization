# Managed identity

A user-assigned managed identity for a Databricks workload, wrapping `avm-res-managedidentity-userassignedidentity`. It gets no rights here: it reaches Databricks as a member of its tier's `sp-databricks` Entra group, which the Calandra team manage.

Part of `infra/20-platform-services`, which calls it from its `main.tf`. Validated through that root, never on its own.

<!-- BEGIN_TF_DOCS -->
## Requirements

| Name | Version |
| ---- | ------- |
| terraform | ~> 1.16 |
| azapi | ~> 2.12 |
| azurerm | ~> 4.81 |

## Modules

| Name | Source | Version |
| ---- | ------ | ------- |
| managed\_identity | Azure/avm-res-managedidentity-userassignedidentity/azurerm | 0.5.2 |

## Inputs

| Name | Description | Type | Default | Required |
| ---- | ----------- | ---- | ------- | :------: |
| location | Azure region for the identity. | `string` | n/a | yes |
| name | Managed identity name, as the Calandra team agreed it. | `string` | n/a | yes |
| resource\_group\_name | Name of the resource group the identity belongs to. | `string` | n/a | yes |
| enable\_telemetry | Whether the Azure Verified Module sends usage telemetry to Microsoft. Off unless the client chooses otherwise. | `bool` | `false` | no |
| tags | Tags for the identity. | `map(string)` | `{}` | no |

## Outputs

| Name | Description |
| ---- | ----------- |
| client\_id | Client (application) ID of the identity. |
| principal\_id | Principal (object) ID of the identity, for the Calandra team to add to the tier's sp-databricks group. |
| resource\_id | Resource ID of the identity. |
<!-- END_TF_DOCS -->
