variable "location" {
  description = "Azure region for the resource group."
  type        = string
  nullable    = false
}

variable "name" {
  description = "Resource group name, as the Calandra team agreed it."
  type        = string
  nullable    = false

  validation {
    condition     = can(regex("^[-\\w\\.\\(\\)]{1,90}$", var.name)) && !endswith(var.name, ".")
    error_message = "A resource group name is 1 to 90 letters, digits, underscores, hyphens, periods and parentheses, and cannot end with a period."
  }
}

variable "enable_telemetry" {
  description = "Whether the Azure Verified Module sends usage telemetry to Microsoft. Off unless the client chooses otherwise."
  type        = bool
  default     = false
  nullable    = false
}

variable "tags" {
  description = "Tags for the resource group."
  type        = map(string)
  default     = {}
  nullable    = false
}

variable "role_assignments" {
  description = <<-EOT
    Azure role assignments on the resource group, by an arbitrary key:
    - principal_id: the object ID of the identity or group.
    - role_definition_id_or_name: a built-in role name, or a role definition resource ID.
    - principal_type: User, Group or ServicePrincipal, so that a freshly created
      principal does not fail its first assignment while Entra replicates it.
    Empty unless the platform admin group needs rights that Calandra's
    privileged-access process does not give it. With a role name, the Verified
    Module looks the definition up at plan time, which needs
    Microsoft.Authorization/roleDefinitions/read in the subscription.
  EOT
  type = map(object({
    principal_id               = string
    role_definition_id_or_name = string
    principal_type             = optional(string)
  }))
  default  = {}
  nullable = false

  validation {
    condition     = alltrue([for assignment in values(var.role_assignments) : assignment.principal_type == null || contains(["User", "Group", "ServicePrincipal"], assignment.principal_type)])
    error_message = "A role assignment's principal_type must be User, Group or ServicePrincipal."
  }
}
