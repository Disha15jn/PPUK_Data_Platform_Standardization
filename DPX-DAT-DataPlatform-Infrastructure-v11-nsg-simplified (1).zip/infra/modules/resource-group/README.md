# Resource group

A resource group, wrapping the Azure Verified Module `avm-res-resources-resourcegroup`, with any role assignments on it through the module's `role_assignments` input. The platform keeps three, grouped by resource type: `storage`, `databricks` and `ops`. It carries no management lock, because a lock on a resource group blocks deleting anything inside it.

Part of `infra/20-platform-services`, which calls it from its `main.tf`. Validated through that root, never on its own.

<!-- BEGIN_TF_DOCS -->
## Requirements

| Name | Version |
| ---- | ------- |
| terraform | ~> 1.16 |
| azapi | ~> 2.12 |

## Modules

| Name | Source | Version |
| ---- | ------ | ------- |
| resource\_group | Azure/avm-res-resources-resourcegroup/azurerm | 0.4.0 |

## Inputs

| Name | Description | Type | Default | Required |
| ---- | ----------- | ---- | ------- | :------: |
| location | Azure region for the resource group. | `string` | n/a | yes |
| name | Resource group name, as the Calandra team agreed it. | `string` | n/a | yes |
| enable\_telemetry | Whether the Azure Verified Module sends usage telemetry to Microsoft. Off unless the client chooses otherwise. | `bool` | `false` | no |
| role\_assignments | Azure role assignments on the resource group, by an arbitrary key:<br/>- principal\_id: the object ID of the identity or group.<br/>- role\_definition\_id\_or\_name: a built-in role name, or a role definition resource ID.<br/>- principal\_type: User, Group or ServicePrincipal, so that a freshly created<br/>  principal does not fail its first assignment while Entra replicates it.<br/>Empty unless the platform admin group needs rights that Calandra's<br/>privileged-access process does not give it. With a role name, the Verified<br/>Module looks the definition up at plan time, which needs<br/>Microsoft.Authorization/roleDefinitions/read in the subscription. | <pre>map(object({<br/>    principal_id               = string<br/>    role_definition_id_or_name = string<br/>    principal_type             = optional(string)<br/>  }))</pre> | `{}` | no |
| tags | Tags for the resource group. | `map(string)` | `{}` | no |

## Outputs

| Name | Description |
| ---- | ----------- |
| location | Azure region of the resource group. |
| name | Name of the resource group. |
| resource\_id | Resource ID of the resource group. |
| role\_assignments | Each role assignment on the group, by key: principal, role, principal type and the group as its scope, so that tests can check them. |
<!-- END_TF_DOCS -->
