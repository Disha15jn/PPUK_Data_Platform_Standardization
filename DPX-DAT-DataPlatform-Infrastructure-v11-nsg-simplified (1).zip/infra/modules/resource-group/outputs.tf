output "location" {
  description = "Azure region of the resource group."
  value       = module.resource_group.location
}

output "name" {
  description = "Name of the resource group."
  value       = module.resource_group.name
}

output "resource_id" {
  description = "Resource ID of the resource group."
  value       = module.resource_group.resource_id
}

output "role_assignments" {
  description = "Each role assignment on the group, by key: principal, role, principal type and the group as its scope, so that tests can check them."
  value = {
    for key, assignment in var.role_assignments : key => {
      principal_id               = assignment.principal_id
      principal_type             = assignment.principal_type
      role_definition_id_or_name = assignment.role_definition_id_or_name
      scope                      = module.resource_group.resource_id
    }
  }
}
