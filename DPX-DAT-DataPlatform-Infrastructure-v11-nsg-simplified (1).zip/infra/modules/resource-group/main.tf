# A resource group, grouped by the type of resource it holds, with any role
# assignments on it, through the Verified Module's role_assignments input.
#
# No management lock here: a CanNotDelete lock on a resource group also blocks
# deleting anything inside it, such as a private endpoint that must be replaced.
# Locks go on the storage accounts and Key Vaults themselves.

module "resource_group" {
  source  = "Azure/avm-res-resources-resourcegroup/azurerm"
  version = "0.4.0"

  enable_telemetry = var.enable_telemetry
  location         = var.location
  name             = var.name
  role_assignments = var.role_assignments
  tags             = var.tags
}
