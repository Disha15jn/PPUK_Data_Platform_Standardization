variable "location" {
  description = "Azure region for the connector."
  type        = string
  nullable    = false
}

variable "name" {
  description = "Access Connector name, as the Calandra team agreed it."
  type        = string
  nullable    = false

  validation {
    condition     = can(regex("^[A-Za-z0-9][A-Za-z0-9_.-]{1,62}[A-Za-z0-9_]$", var.name))
    error_message = "An Access Connector name is 3 to 64 letters, digits, underscores, periods and hyphens, starting with a letter or digit and ending with a letter, digit or underscore."
  }
}

variable "resource_group_id" {
  description = "Resource ID of the resource group the connector belongs to."
  type        = string
  nullable    = false
}

variable "enable_telemetry" {
  description = "Whether the Azure Verified Module sends usage telemetry to Microsoft. Off unless the client chooses otherwise."
  type        = bool
  default     = false
  nullable    = false
}

variable "tags" {
  description = "Tags for the connector."
  type        = map(string)
  default     = {}
  nullable    = false
}
