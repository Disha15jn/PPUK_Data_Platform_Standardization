output "name" {
  description = "Name of the connector."
  value       = module.access_connector.name
}

output "principal_id" {
  description = "Principal ID of the connector's system-assigned managed identity, which the storage account module assigns its roles to."
  value       = module.access_connector.system_assigned_mi_principal_id
}

output "resource_id" {
  description = "Resource ID of the connector: the Databricks storage credential's access_connector_id."
  value       = module.access_connector.resource_id
}
