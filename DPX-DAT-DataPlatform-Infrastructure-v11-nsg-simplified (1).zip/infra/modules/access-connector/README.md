# Access Connector

One entity's Azure Databricks Access Connector, wrapping `avm-res-databricks-accessconnector`. The connector is all this module creates: the storage account module assigns its identity *Storage Blob Data Contributor* on that entity's containers only, and *Storage Blob Delegator* on the account, which Unity Catalog needs to request user delegation keys and which carries no data access (Microsoft Learn's container-level option).

Part of `infra/20-platform-services`, which calls it from its `main.tf`. Validated through that root, never on its own.

<!-- BEGIN_TF_DOCS -->
## Requirements

| Name | Version |
| ---- | ------- |
| terraform | ~> 1.16 |
| azapi | ~> 2.12 |

## Modules

| Name | Source | Version |
| ---- | ------ | ------- |
| access\_connector | Azure/avm-res-databricks-accessconnector/azurerm | 0.1.0 |

## Inputs

| Name | Description | Type | Default | Required |
| ---- | ----------- | ---- | ------- | :------: |
| location | Azure region for the connector. | `string` | n/a | yes |
| name | Access Connector name, as the Calandra team agreed it. | `string` | n/a | yes |
| resource\_group\_id | Resource ID of the resource group the connector belongs to. | `string` | n/a | yes |
| enable\_telemetry | Whether the Azure Verified Module sends usage telemetry to Microsoft. Off unless the client chooses otherwise. | `bool` | `false` | no |
| tags | Tags for the connector. | `map(string)` | `{}` | no |

## Outputs

| Name | Description |
| ---- | ----------- |
| name | Name of the connector. |
| principal\_id | Principal ID of the connector's system-assigned managed identity, which the storage account module assigns its roles to. |
| resource\_id | Resource ID of the connector: the Databricks storage credential's access\_connector\_id. |
<!-- END_TF_DOCS -->
