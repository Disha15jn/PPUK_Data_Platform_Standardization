# One entity's Azure Databricks Access Connector.
#
# The connector itself is all this module creates. Its system-assigned identity
# gets its rights from the storage account module, which assigns Storage Blob
# Data Contributor on that entity's containers, and only at container scope,
# and Storage Blob Delegator on the account, which Unity Catalog needs to
# request user delegation keys and which carries no data access. This is
# Microsoft Learn's container-level option ('Use Azure managed identities in
# Unity Catalog to access storage', 11 September 2026). Per-entity isolation
# depends on no data role ever being assigned at account scope, which the
# storage module's inputs cannot express.

module "access_connector" {
  source  = "Azure/avm-res-databricks-accessconnector/azurerm"
  version = "0.1.0"

  enable_telemetry = var.enable_telemetry
  location         = var.location
  managed_identities = {
    system_assigned = true
  }
  name      = var.name
  parent_id = var.resource_group_id
  tags      = var.tags
}
