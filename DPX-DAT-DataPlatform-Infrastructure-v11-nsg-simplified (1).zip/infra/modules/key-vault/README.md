# Key Vault

A Key Vault, wrapping `avm-res-keyvault-vault`, in one of two access models: `rbac` for the platform vault, or `access_policy` for the Databricks secret scope's vault, which Key Vault-backed scopes require. Purge protection is always on, and each vault is reached through a private endpoint.

Part of `infra/20-platform-services`, which calls it from its `main.tf`. Validated through that root, never on its own.

<!-- BEGIN_TF_DOCS -->
## Requirements

| Name | Version |
| ---- | ------- |
| terraform | ~> 1.16 |
| azapi | ~> 2.12 |
| azurerm | ~> 4.81 |

## Modules

| Name | Source | Version |
| ---- | ------ | ------- |
| key\_vault | Azure/avm-res-keyvault-vault/azurerm | 0.11.0 |

## Inputs

| Name | Description | Type | Default | Required |
| ---- | ----------- | ---- | ------- | :------: |
| access\_model | 'rbac' for the platform vault, or 'access\_policy' for the Databricks secret scope's vault. | `string` | n/a | yes |
| location | Azure region for the vault. | `string` | n/a | yes |
| log\_analytics\_workspace\_id | Resource ID of the Log Analytics workspace that receives the vault's diagnostics. | `string` | n/a | yes |
| name | Key Vault name, as the Calandra team agreed it. | `string` | n/a | yes |
| private\_endpoint | Where the vault's private endpoint goes, from the network and security state:<br/>- subnet\_id: the private endpoint subnet.<br/>- private\_dns\_zone\_ids: central private DNS zone IDs by key; 'vault' is used.<br/>- manage\_dns\_zone\_group: false if Landing Zone policy creates the DNS zone<br/>  group instead, so that Terraform does not fight the policy. | <pre>object({<br/>    subnet_id             = string<br/>    private_dns_zone_ids  = map(string)<br/>    manage_dns_zone_group = optional(bool, true)<br/>  })</pre> | n/a | yes |
| resource\_group\_name | Name of the resource group the vault belongs to. | `string` | n/a | yes |
| tenant\_id | Entra tenant ID the vault authenticates against. | `string` | n/a | yes |
| enable\_telemetry | Whether the Azure Verified Module sends usage telemetry to Microsoft. Off unless the client chooses otherwise. | `bool` | `false` | no |
| lock\_enabled | Whether to put a CanNotDelete lock on the vault. True in production. | `bool` | `false` | no |
| secret\_reader\_object\_ids | In access\_policy mode only: principals that may Get and List secrets, by an arbitrary key. The secret scope's vault gives the tenant's AzureDatabricks application exactly these rights. | `map(string)` | `{}` | no |
| sku\_name | Key Vault SKU: 'standard' or 'premium'. | `string` | `"standard"` | no |
| soft\_delete\_retention\_days | How long deleted items are kept, in days: 7 to 90. | `number` | `90` | no |
| tags | Tags for the vault. | `map(string)` | `{}` | no |

## Outputs

| Name | Description |
| ---- | ----------- |
| access\_model | The vault's access model: 'rbac' or 'access\_policy'. |
| diagnostic\_workspace\_ids | The Log Analytics workspaces the vault's diagnostic settings send to, so that tests can check them. |
| lock\_enabled | Whether the resource carries a CanNotDelete lock, so that tests can check it. |
| name | Name of the vault. |
| network\_settings | The vault's firewall and public access settings, so that tests can check them. |
| private\_endpoint\_settings | The subnet and DNS zones the vault's private endpoint is created with, so that tests can check them. |
| resource\_id | Resource ID of the vault. |
| secret\_reader\_permissions | The secret permissions each secret reader receives in access\_policy mode; empty in rbac mode. |
| uri | The vault's URI. |
<!-- END_TF_DOCS -->
