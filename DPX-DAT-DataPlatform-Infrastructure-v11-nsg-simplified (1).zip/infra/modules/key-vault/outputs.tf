output "access_model" {
  description = "The vault's access model: 'rbac' or 'access_policy'."
  value       = var.access_model
}

output "diagnostic_workspace_ids" {
  description = "The Log Analytics workspaces the vault's diagnostic settings send to, so that tests can check them."
  value       = toset([for setting in values(local.diagnostic_settings) : setting.workspace_resource_id])
}

output "lock_enabled" {
  description = "Whether the resource carries a CanNotDelete lock, so that tests can check it."
  value       = var.lock_enabled
}

output "name" {
  description = "Name of the vault."
  value       = module.key_vault.name
}

output "network_settings" {
  description = "The vault's firewall and public access settings, so that tests can check them."
  value       = local.network_settings
}

output "private_endpoint_settings" {
  description = "The subnet and DNS zones the vault's private endpoint is created with, so that tests can check them."
  value = {
    subnet_id            = var.private_endpoint.subnet_id
    private_dns_zone_ids = [var.private_endpoint.private_dns_zone_ids["vault"]]
    tags                 = var.tags
  }
}

output "resource_id" {
  description = "Resource ID of the vault."
  value       = module.key_vault.resource_id
}

output "secret_reader_permissions" {
  description = "The secret permissions each secret reader receives in access_policy mode; empty in rbac mode."
  value       = local.access_policy_mode ? local.secret_reader_permissions : []
}

output "uri" {
  description = "The vault's URI."
  value       = module.key_vault.uri
}
