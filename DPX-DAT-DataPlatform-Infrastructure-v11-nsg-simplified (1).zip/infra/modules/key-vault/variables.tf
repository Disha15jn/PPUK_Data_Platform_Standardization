variable "access_model" {
  description = "'rbac' for the platform vault, or 'access_policy' for the Databricks secret scope's vault."
  type        = string
  nullable    = false

  validation {
    condition     = contains(["rbac", "access_policy"], var.access_model)
    error_message = "access_model must be 'rbac' or 'access_policy'."
  }
}

variable "location" {
  description = "Azure region for the vault."
  type        = string
  nullable    = false
}

variable "log_analytics_workspace_id" {
  description = "Resource ID of the Log Analytics workspace that receives the vault's diagnostics."
  type        = string
  nullable    = false
}

variable "name" {
  description = "Key Vault name, as the Calandra team agreed it."
  type        = string
  nullable    = false

  validation {
    condition     = can(regex("^[A-Za-z][A-Za-z0-9-]{1,22}[A-Za-z0-9]$", var.name)) && !strcontains(var.name, "--")
    error_message = "A Key Vault name is 3 to 24 letters, digits and hyphens, starts with a letter, ends with a letter or digit, and has no consecutive hyphens."
  }
}

variable "private_endpoint" {
  description = <<-EOT
    Where the vault's private endpoint goes, from the network and security state:
    - subnet_id: the private endpoint subnet.
    - private_dns_zone_ids: central private DNS zone IDs by key; 'vault' is used.
    - manage_dns_zone_group: false if Landing Zone policy creates the DNS zone
      group instead, so that Terraform does not fight the policy.
  EOT
  type = object({
    subnet_id             = string
    private_dns_zone_ids  = map(string)
    manage_dns_zone_group = optional(bool, true)
  })
  nullable = false

  validation {
    condition     = contains(keys(var.private_endpoint.private_dns_zone_ids), "vault")
    error_message = "private_dns_zone_ids must include 'vault'."
  }
}

variable "resource_group_name" {
  description = "Name of the resource group the vault belongs to."
  type        = string
  nullable    = false
}

variable "tenant_id" {
  description = "Entra tenant ID the vault authenticates against."
  type        = string
  nullable    = false
}

variable "enable_telemetry" {
  description = "Whether the Azure Verified Module sends usage telemetry to Microsoft. Off unless the client chooses otherwise."
  type        = bool
  default     = false
  nullable    = false
}

variable "lock_enabled" {
  description = "Whether to put a CanNotDelete lock on the vault. True in production."
  type        = bool
  default     = false
  nullable    = false
}

variable "secret_reader_object_ids" {
  description = "In access_policy mode only: principals that may Get and List secrets, by an arbitrary key. The secret scope's vault gives the tenant's AzureDatabricks application exactly these rights."
  type        = map(string)
  default     = {}
  nullable    = false

  validation {
    condition     = alltrue([for id in values(var.secret_reader_object_ids) : can(regex("^[0-9a-f]{8}-([0-9a-f]{4}-){3}[0-9a-f]{12}$", id))])
    error_message = "Each secret reader must be a lower-case object ID GUID."
  }
}

variable "sku_name" {
  description = "Key Vault SKU: 'standard' or 'premium'."
  type        = string
  default     = "standard"
  nullable    = false
}

variable "soft_delete_retention_days" {
  description = "How long deleted items are kept, in days: 7 to 90."
  type        = number
  default     = 90
  nullable    = false
}

variable "tags" {
  description = "Tags for the vault."
  type        = map(string)
  default     = {}
  nullable    = false
}
