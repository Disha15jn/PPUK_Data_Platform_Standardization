variable "location" {
  description = "Azure region for the storage account."
  type        = string
  nullable    = false
}

variable "log_analytics_workspace_id" {
  description = "Resource ID of the Log Analytics workspace that receives the account's diagnostics."
  type        = string
  nullable    = false
}

variable "name" {
  description = "Storage account name, as the Calandra team agreed it. Azure allows 24 characters, lower-case letters and digits, and the name must be unique across Azure."
  type        = string
  nullable    = false

  validation {
    condition     = can(regex("^[a-z0-9]{3,24}$", var.name))
    error_message = "A storage account name is 3 to 24 lower-case letters and digits."
  }
}

variable "private_endpoint" {
  description = <<-EOT
    Where the account's private endpoints go, from the network and security state:
    - subnet_id: the private endpoint subnet.
    - private_dns_zone_ids: central private DNS zone IDs by key; 'blob' and 'dfs' are used.
    - manage_dns_zone_group: false if Landing Zone policy creates the DNS zone
      groups instead, so that Terraform does not fight the policy.
  EOT
  type = object({
    subnet_id             = string
    private_dns_zone_ids  = map(string)
    manage_dns_zone_group = optional(bool, true)
  })
  nullable = false

  validation {
    condition     = alltrue([for key in ["blob", "dfs"] : contains(keys(var.private_endpoint.private_dns_zone_ids), key)])
    error_message = "private_dns_zone_ids must include 'blob' and 'dfs'."
  }
}

variable "resource_group_id" {
  description = "Resource ID of the resource group the account belongs to."
  type        = string
  nullable    = false
}

variable "containers" {
  description = <<-EOT
    The containers to create in the account, by name, each with the role assignments its
    users need, by an arbitrary key:
    - principal_id: the object ID of the identity.
    - role: Storage Blob Data Contributor (the default) or Storage Blob Data Reader. Only
      data roles, and only here, at container scope: no data role can be granted on the
      account, which is what keeps one entity's identity out of another's containers.
    - principal_type: ServicePrincipal (the default), User or Group.
    The Verified Module creates each container and its assignments through Resource
    Manager, which private networking does not block, unlike the storage data plane.
  EOT
  type = map(object({
    role_assignments = optional(map(object({
      principal_id   = string
      role           = optional(string, "Storage Blob Data Contributor")
      principal_type = optional(string, "ServicePrincipal")
    })), {})
  }))
  default  = {}
  nullable = false

  validation {
    condition     = alltrue([for name in keys(var.containers) : can(regex("^[a-z0-9](-?[a-z0-9])*$", name)) && length(name) >= 3 && length(name) <= 63])
    error_message = "A container name is 3 to 63 lower-case letters, digits and single hyphens, starting and ending with a letter or digit."
  }

  validation {
    condition = alltrue(flatten([
      for container in values(var.containers) : [
        for assignment in values(container.role_assignments) : contains(keys(local.container_roles), assignment.role)
      ]
    ]))
    error_message = "A container role assignment must be Storage Blob Data Contributor or Storage Blob Data Reader."
  }

  validation {
    condition = alltrue(flatten([
      for container in values(var.containers) : [
        for assignment in values(container.role_assignments) : contains(["ServicePrincipal", "User", "Group"], assignment.principal_type)
      ]
    ]))
    error_message = "A role assignment's principal_type must be ServicePrincipal, User or Group."
  }
}

variable "account_role_assignments" {
  description = <<-EOT
    Role assignments on the account itself, by an arbitrary key:
    - principal_id: the object ID of the identity.
    - role: only Storage Blob Delegator, which lets Unity Catalog request user delegation
      keys and carries no data access. A data role at account scope would reach every
      container, so none is accepted here.
    - principal_type: ServicePrincipal (the default), User or Group.
  EOT
  type = map(object({
    principal_id   = string
    role           = optional(string, "Storage Blob Delegator")
    principal_type = optional(string, "ServicePrincipal")
  }))
  default  = {}
  nullable = false

  validation {
    condition     = alltrue([for assignment in values(var.account_role_assignments) : contains(keys(local.account_roles), assignment.role)])
    error_message = "An account-scope role assignment must be Storage Blob Delegator: a data role on the account would reach every container."
  }

  validation {
    condition     = alltrue([for assignment in values(var.account_role_assignments) : contains(["ServicePrincipal", "User", "Group"], assignment.principal_type)])
    error_message = "A role assignment's principal_type must be ServicePrincipal, User or Group."
  }
}

variable "enable_telemetry" {
  description = "Whether the Azure Verified Module sends usage telemetry to Microsoft. Off unless the client chooses otherwise."
  type        = bool
  default     = false
  nullable    = false
}

variable "lock_enabled" {
  description = "Whether to put a CanNotDelete lock on the account. True in production."
  type        = bool
  default     = false
  nullable    = false
}

variable "sku_name" {
  description = "Storage SKU, which sets the replication: Standard_LRS or Standard_ZRS. Zone-redundant by default."
  type        = string
  default     = "Standard_ZRS"
  nullable    = false

  validation {
    condition     = contains(["Standard_LRS", "Standard_ZRS"], var.sku_name)
    error_message = "sku_name must be Standard_LRS or Standard_ZRS: both keep the data in the region, and geo-redundant replication copies it to another."
  }
}

variable "soft_delete_retention_days" {
  description = "How long deleted blobs and containers can be recovered, in days."
  type        = number
  default     = 7
  nullable    = false

  validation {
    condition     = var.soft_delete_retention_days >= 1 && var.soft_delete_retention_days <= 365
    error_message = "Soft delete retention must be between 1 and 365 days."
  }
}

variable "tags" {
  description = "Tags for the account."
  type        = map(string)
  default     = {}
  nullable    = false
}
