# An ADLS Gen2 storage account with its containers and role assignments.
#
# The security settings are fixed here, not taken from a var file: hierarchical
# namespace, infrastructure encryption with Microsoft-managed keys (which can
# only be set when the account is created), no shared keys, no public network
# access, no SFTP and TLS 1.2. The account is reached through its blob and dfs
# private endpoints only.
#
# Containers and role assignments are the Verified Module's, through its
# containers and role_assignments inputs, so that every Azure resource here is
# created by the module. It creates them through Azure Resource Manager, which
# private networking does not block, unlike the storage data plane. A module
# block cannot carry prevent_destroy, so the containers rely on soft delete and,
# in production, on the account's CanNotDelete lock.

locals {
  settings = {
    access_tier                       = "Hot"
    account_kind                      = "StorageV2"
    allow_nested_items_to_be_public   = false
    default_to_oauth_authentication   = true
    hierarchical_namespace_enabled    = true
    https_traffic_only_enabled        = true
    infrastructure_encryption_enabled = true
    min_tls_version                   = "TLS1_2"
    network_default_action            = "Deny"
    nfsv3_enabled                     = false
    public_network_access_enabled     = false
    sftp_enabled                      = false
    shared_access_key_enabled         = false
  }

  # The built-in roles this module may assign, by name, as role definition IDs.
  # Passing IDs lets the Verified Module skip its role-definition lookup, an
  # Authorization API read at plan time that the pipeline identity need not hold.
  # Data roles are allowed at container scope only; Delegator at account scope only.
  container_roles = {
    "Storage Blob Data Contributor" = "/providers/Microsoft.Authorization/roleDefinitions/ba92f5b4-2d11-453d-a403-e96b0029c9fe"
    "Storage Blob Data Reader"      = "/providers/Microsoft.Authorization/roleDefinitions/2a2b9908-6ea1-4ae2-8e65-a410df84e7d1"
  }
  account_roles = {
    "Storage Blob Delegator" = "/providers/Microsoft.Authorization/roleDefinitions/db58b8e5-c6ad-4a2a-8342-4190687cbf4a"
  }

  containers = {
    for name, container in var.containers : name => {
      name = name
      role_assignments = {
        for key, assignment in container.role_assignments : key => {
          principal_id               = assignment.principal_id
          principal_type             = assignment.principal_type
          role_definition_id_or_name = local.container_roles[assignment.role]
        }
      }
    }
  }

  account_role_assignments = {
    for key, assignment in var.account_role_assignments : key => {
      principal_id               = assignment.principal_id
      principal_type             = assignment.principal_type
      role_definition_id_or_name = local.account_roles[assignment.role]
    }
  }

  # Soft delete for containers and blobs. A module block cannot carry
  # prevent_destroy, so outside production this is the only thing that makes a
  # deleted container recoverable.
  blob_properties = {
    container_delete_retention_policy = {
      enabled = true
      days    = var.soft_delete_retention_days
    }
    delete_retention_policy = {
      enabled = true
      days    = var.soft_delete_retention_days
    }
  }

  # Every diagnostic setting the account gets, and where it sends its logs. Each
  # is named: the azapi resource behind it requires a name and the Verified
  # Module does not generate one, so a plan under real providers fails without it.
  diagnostic_settings_blob = {
    log_analytics = {
      name                  = "send-to-log-analytics"
      workspace_resource_id = var.log_analytics_workspace_id
      logs                  = [{ category_group = "allLogs" }]
      metrics               = [{ category = "Transaction" }]
    }
  }
  diagnostic_settings_storage_account = {
    log_analytics = {
      name                  = "send-to-log-analytics"
      workspace_resource_id = var.log_analytics_workspace_id
      metrics               = [{ category = "Transaction" }]
    }
  }

  # Each endpoint is named: the Verified Module names an unnamed one
  # "pe-<account>", so blob and dfs would collide. Its connection name derives
  # from this name.
  private_endpoints = {
    for subresource in ["blob", "dfs"] : subresource => {
      name                          = "pe-${var.name}-${subresource}"
      subresource_name              = subresource
      subnet_resource_id            = var.private_endpoint.subnet_id
      private_dns_zone_resource_ids = [var.private_endpoint.private_dns_zone_ids[subresource]]
      tags                          = var.tags
    }
  }
}

module "storage_account" {
  source  = "Azure/avm-res-storage-storageaccount/azurerm"
  version = "0.10.0"

  access_tier                         = local.settings.access_tier
  account_kind                        = local.settings.account_kind
  account_sku_name                    = var.sku_name
  allow_nested_items_to_be_public     = local.settings.allow_nested_items_to_be_public
  blob_properties                     = local.blob_properties
  containers                          = local.containers
  cross_tenant_replication_enabled    = false
  default_to_oauth_authentication     = local.settings.default_to_oauth_authentication
  diagnostic_settings_blob            = local.diagnostic_settings_blob
  diagnostic_settings_storage_account = local.diagnostic_settings_storage_account
  enable_telemetry                    = var.enable_telemetry
  https_traffic_only_enabled          = local.settings.https_traffic_only_enabled
  infrastructure_encryption_enabled   = local.settings.infrastructure_encryption_enabled
  is_hns_enabled                      = local.settings.hierarchical_namespace_enabled
  local_user_enabled                  = false
  location                            = var.location
  lock                                = var.lock_enabled ? { kind = "CanNotDelete" } : null
  min_tls_version                     = local.settings.min_tls_version
  name                                = var.name
  network_rules = {
    bypass         = ["AzureServices"]
    default_action = local.settings.network_default_action
  }
  nfsv3_enabled                           = local.settings.nfsv3_enabled
  parent_id                               = var.resource_group_id
  private_endpoints                       = local.private_endpoints
  private_endpoints_manage_dns_zone_group = var.private_endpoint.manage_dns_zone_group
  public_network_access_enabled           = local.settings.public_network_access_enabled
  # A role assignment for an identity created in the same apply can fail while
  # Entra replicates it; the module retries that, and the storage operation it
  # retries by default.
  retry = {
    error_message_regex = ["StorageAccountOperationInProgress", "PrincipalNotFound"]
  }
  role_assignment_definition_lookup_enabled = false
  role_assignments                          = local.account_role_assignments
  sftp_enabled                              = local.settings.sftp_enabled
  shared_access_key_enabled                 = local.settings.shared_access_key_enabled
  tags                                      = var.tags
}
