# Storage account

An ADLS Gen2 storage account, its containers and their role assignments, wrapping `avm-res-storage-storageaccount`. Hierarchical namespace, infrastructure encryption and Microsoft-managed keys are fixed; shared keys, public network access and SFTP are off. Containers and role assignments go through the Verified Module's own inputs, so it creates every Azure resource here, through Azure Resource Manager. Data roles are accepted at container scope only, and only *Storage Blob Delegator* on the account, which is what keeps one entity's identity out of another's containers. A module block cannot carry `prevent_destroy`, so the containers rely on soft delete and, in production, on the account's `CanNotDelete` lock.

Part of `infra/20-platform-services`, which calls it from its `main.tf`. Validated through that root, never on its own.

<!-- BEGIN_TF_DOCS -->
## Requirements

| Name | Version |
| ---- | ------- |
| terraform | ~> 1.16 |
| azapi | ~> 2.12 |

## Modules

| Name | Source | Version |
| ---- | ------ | ------- |
| storage\_account | Azure/avm-res-storage-storageaccount/azurerm | 0.10.0 |

## Inputs

| Name | Description | Type | Default | Required |
| ---- | ----------- | ---- | ------- | :------: |
| location | Azure region for the storage account. | `string` | n/a | yes |
| log\_analytics\_workspace\_id | Resource ID of the Log Analytics workspace that receives the account's diagnostics. | `string` | n/a | yes |
| name | Storage account name, as the Calandra team agreed it. Azure allows 24 characters, lower-case letters and digits, and the name must be unique across Azure. | `string` | n/a | yes |
| private\_endpoint | Where the account's private endpoints go, from the network and security state:<br/>- subnet\_id: the private endpoint subnet.<br/>- private\_dns\_zone\_ids: central private DNS zone IDs by key; 'blob' and 'dfs' are used.<br/>- manage\_dns\_zone\_group: false if Landing Zone policy creates the DNS zone<br/>  groups instead, so that Terraform does not fight the policy. | <pre>object({<br/>    subnet_id             = string<br/>    private_dns_zone_ids  = map(string)<br/>    manage_dns_zone_group = optional(bool, true)<br/>  })</pre> | n/a | yes |
| resource\_group\_id | Resource ID of the resource group the account belongs to. | `string` | n/a | yes |
| account\_role\_assignments | Role assignments on the account itself, by an arbitrary key:<br/>- principal\_id: the object ID of the identity.<br/>- role: only Storage Blob Delegator, which lets Unity Catalog request user delegation<br/>  keys and carries no data access. A data role at account scope would reach every<br/>  container, so none is accepted here.<br/>- principal\_type: ServicePrincipal (the default), User or Group. | <pre>map(object({<br/>    principal_id   = string<br/>    role           = optional(string, "Storage Blob Delegator")<br/>    principal_type = optional(string, "ServicePrincipal")<br/>  }))</pre> | `{}` | no |
| containers | The containers to create in the account, by name, each with the role assignments its<br/>users need, by an arbitrary key:<br/>- principal\_id: the object ID of the identity.<br/>- role: Storage Blob Data Contributor (the default) or Storage Blob Data Reader. Only<br/>  data roles, and only here, at container scope: no data role can be granted on the<br/>  account, which is what keeps one entity's identity out of another's containers.<br/>- principal\_type: ServicePrincipal (the default), User or Group.<br/>The Verified Module creates each container and its assignments through Resource<br/>Manager, which private networking does not block, unlike the storage data plane. | <pre>map(object({<br/>    role_assignments = optional(map(object({<br/>      principal_id   = string<br/>      role           = optional(string, "Storage Blob Data Contributor")<br/>      principal_type = optional(string, "ServicePrincipal")<br/>    })), {})<br/>  }))</pre> | `{}` | no |
| enable\_telemetry | Whether the Azure Verified Module sends usage telemetry to Microsoft. Off unless the client chooses otherwise. | `bool` | `false` | no |
| lock\_enabled | Whether to put a CanNotDelete lock on the account. True in production. | `bool` | `false` | no |
| sku\_name | Storage SKU, which sets the replication: Standard\_LRS or Standard\_ZRS. Zone-redundant by default. | `string` | `"Standard_ZRS"` | no |
| soft\_delete\_retention\_days | How long deleted blobs and containers can be recovered, in days. | `number` | `7` | no |
| tags | Tags for the account. | `map(string)` | `{}` | no |

## Outputs

| Name | Description |
| ---- | ----------- |
| account\_role\_assignments | Each account-scope role assignment, by key: principal, role, principal type and the account as its scope, so that tests can check them. |
| container\_ids | Resource ID of each container, by name: the account's resource ID plus '/blobServices/default/containers/<name>'. |
| container\_role\_assignments | Each container's role assignments, by container name then key: principal, role, principal type and the container as its scope, so that tests can check them. |
| diagnostic\_setting\_names | The names of the account's diagnostic settings, so that tests can check each has one. A null name is not valid for the azapi resource behind them. |
| diagnostic\_workspace\_ids | The Log Analytics workspaces the account's diagnostic settings send to, so that tests can check them. |
| lock\_enabled | Whether the resource carries a CanNotDelete lock, so that tests can check it. |
| name | Name of the storage account. |
| private\_endpoint\_settings | The name, subnet and DNS zone of each private endpoint, by subresource, so that tests can check them. |
| resource\_id | Resource ID of the storage account. |
| settings | The account's fixed security settings, so that tests can check them. |
| sku\_name | The account's SKU, which sets its replication, so that tests can check it. |
| soft\_delete\_policies | The account's soft delete policies for containers and for blobs, each whether it is enabled and for how many days, so that tests can check them. |
<!-- END_TF_DOCS -->
