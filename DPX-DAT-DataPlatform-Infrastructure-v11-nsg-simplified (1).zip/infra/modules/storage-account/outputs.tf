output "account_role_assignments" {
  description = "Each account-scope role assignment, by key: principal, role, principal type and the account as its scope, so that tests can check them."
  value = {
    for key, assignment in var.account_role_assignments : key => {
      principal_id   = assignment.principal_id
      principal_type = assignment.principal_type
      role           = assignment.role
      scope          = module.storage_account.resource_id
    }
  }
}

output "container_ids" {
  description = "Resource ID of each container, by name: the account's resource ID plus '/blobServices/default/containers/<name>'."
  value = {
    for name in keys(var.containers) :
    name => "${module.storage_account.resource_id}/blobServices/default/containers/${name}"
  }
}

output "container_role_assignments" {
  description = "Each container's role assignments, by container name then key: principal, role, principal type and the container as its scope, so that tests can check them."
  value = {
    for name, container in var.containers : name => {
      for key, assignment in container.role_assignments : key => {
        principal_id   = assignment.principal_id
        principal_type = assignment.principal_type
        role           = assignment.role
        scope          = "${module.storage_account.resource_id}/blobServices/default/containers/${name}"
      }
    }
  }
}

output "diagnostic_setting_names" {
  description = "The names of the account's diagnostic settings, so that tests can check each has one. A null name is not valid for the azapi resource behind them."
  value = [
    for setting in concat(values(local.diagnostic_settings_blob), values(local.diagnostic_settings_storage_account)) : lookup(setting, "name", null)
  ]
}

output "diagnostic_workspace_ids" {
  description = "The Log Analytics workspaces the account's diagnostic settings send to, so that tests can check them."
  value = toset([
    for setting in concat(values(local.diagnostic_settings_blob), values(local.diagnostic_settings_storage_account)) : setting.workspace_resource_id
  ])
}

output "lock_enabled" {
  description = "Whether the resource carries a CanNotDelete lock, so that tests can check it."
  value       = var.lock_enabled
}

output "name" {
  description = "Name of the storage account."
  value       = module.storage_account.name
}

output "private_endpoint_settings" {
  description = "The name, subnet and DNS zone of each private endpoint, by subresource, so that tests can check them."
  value = {
    for subresource, endpoint in local.private_endpoints : subresource => {
      name                 = endpoint.name
      subnet_id            = endpoint.subnet_resource_id
      private_dns_zone_ids = endpoint.private_dns_zone_resource_ids
      tags                 = var.tags
    }
  }
}

output "resource_id" {
  description = "Resource ID of the storage account."
  value       = module.storage_account.resource_id
}

output "settings" {
  description = "The account's fixed security settings, so that tests can check them."
  value       = local.settings
}

output "soft_delete_policies" {
  description = "The account's soft delete policies for containers and for blobs, each whether it is enabled and for how many days, so that tests can check them."
  value = {
    containers = local.blob_properties.container_delete_retention_policy
    blobs      = local.blob_properties.delete_retention_policy
  }
}

output "sku_name" {
  description = "The account's SKU, which sets its replication, so that tests can check it."
  value       = var.sku_name
}
