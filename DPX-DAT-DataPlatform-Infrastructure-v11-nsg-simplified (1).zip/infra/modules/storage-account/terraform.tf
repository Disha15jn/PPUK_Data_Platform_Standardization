# The providers this module and the Verified Module it wraps use, declared here
# so that callers and tests bind the right provider (Azure/azapi, not a
# hashicorp/azapi guessed from the local name). The storage Verified Module
# creates everything, containers and role assignments included, through azapi.
terraform {
  required_version = "~> 1.16"

  required_providers {
    azapi = {
      source  = "Azure/azapi"
      version = "~> 2.12"
    }
  }
}
